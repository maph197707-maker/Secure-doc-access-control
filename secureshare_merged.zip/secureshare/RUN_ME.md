# Run SecureShare (Windows)

1. Install Python 3.12+ from python.org (tick "Add python.exe to PATH").
2. Open the `secureshare` folder (the one containing `app`, `requirements.txt`, `install.bat`).
3. Double-click `install.bat`  -> creates `.venv`, installs pip packages, creates `.env` with fresh
   secrets, creates the database and storage folders. (Needs internet.)
4. Double-click `start.bat`    -> open http://127.0.0.1:8000

Manual equivalent:
    python -m venv .venv
    .venv\Scripts\activate
    python -m pip install --upgrade pip
    python -m pip install -r requirements.txt -r requirements-dev.txt
    python -m scripts.setup_db
    python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
    python -m pytest tests -q

VERIFY EVERYTHING: after install.bat, double-click verify.bat. It runs selfcheck.py, a real end-to-end check over live HTTP
(register, login, upload, encryption on disk, link, second-device view/download, revoke, guest, every page)
and the test suite, and saves selfcheck_report.txt + pytest_report.txt. Send me those two files.

Test order: Register -> Login -> Upload PDF -> Create secure link -> open it in a private window ->
View/Download -> Revoke -> reopen (must be denied) -> Logout; and "Continue as guest".

Optional (.env): SMTP_* for email codes (needed for sign-up codes, forgot-password and recipient codes),
TWILIO_* for SMS codes, GOOGLE_*/MICROSOFT_* for the Google / Microsoft sign-in buttons.
OAuth redirect URIs to register with the provider (exact): <base>/oauth/google/callback and
<base>/oauth/microsoft/callback, e.g. http://localhost:8000/oauth/google/callback (see .env.example).
Without them those features are shown as unavailable (never faked).

Change made in this build: app/middleware/csrf.py no longer swaps the request object for a bare
Request before call_next (can break every form POST on current Starlette). Static checks done:
all .py compile, all `from app...` imports resolve, all templates parse and reference existing
templates, no UI link without a route. NOT executed in the authoring sandbox (no internet).

See WHATSAPP_SHARING.md to make links that open on other people's phones, and for folder upload (zip).
Changes: csrf.py fix; more upload types incl. .zip (validator signature checks added for gif/webp).
