"""Self-check (run by verify.bat):  python selfcheck.py

Starts the REAL app under uvicorn on 127.0.0.1:8765 with a throw-away database and storage folder and drives
the whole user journey over real HTTP (cookies, CSRF, redirects):
register -> email code -> login -> MFA -> upload (encrypted on disk) -> view/download -> secure link
(password, limits, one-time, recipient email code, rotate, revoke) -> guest -> Google/Microsoft OAuth -> password reset.
Only two things are replaced: the SMTP transport (mail is captured in memory) and the Google/Microsoft HTTP
endpoints (a fake identity provider). Your real .env and database are never touched.
Writes selfcheck_report.txt. Exit code 0 = everything passed."""
import os, sys, re, time, threading, tempfile, json, urllib.parse, glob, logging
logging.disable(logging.INFO)
tmp = tempfile.mkdtemp(prefix="ss-live-")
os.environ.update(DATABASE_URL=f"sqlite+aiosqlite:///{tmp}/live.db", STORAGE_ROOT=f"{tmp}/storage/encrypted",
    QUARANTINE_ROOT=f"{tmp}/storage/q", TEMP_ROOT=f"{tmp}/storage/t", PROCESSED_ROOT=f"{tmp}/storage/p",
    APP_ENV="dev", SIGNUP_EMAIL_VERIFICATION_REQUIRED="true",
    GOOGLE_CLIENT_ID="gid", GOOGLE_CLIENT_SECRET="gsec", MICROSOFT_CLIENT_ID="mid", MICROSOFT_CLIENT_SECRET="msec")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import httpx, uvicorn
from tests.support import providers
box = providers.Outbox(); providers.OUTBOX = box
from app.integrations import factory, oauth
from app.integrations.email import EmailService
em = EmailService(box.email, "no-reply@test.invalid", "SecureShare")
factory.get_email_service = lambda: em
FAKE = {"info": {"sub": "g-1", "email": "oauth.user@gmail.com", "email_verified": True, "name": "OAuth User"}}
def tx(m, url, h, body):
    if url.endswith("/token"): return 200, json.dumps({"access_token": "AT"})
    return 200, json.dumps(FAKE["info"])
oauth.default_transport = lambda: tx
from app.main import app
from scripts.seed_roles import seed_roles
import asyncio
from app.db.session import create_tables
asyncio.run(create_tables()); asyncio.run(seed_roles())

import socket
_s = socket.socket(); _s.bind(("127.0.0.1", 0)); PORT = _s.getsockname()[1]; _s.close(); BASE = f"http://127.0.0.1:{PORT}"
srv = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=PORT, log_level="warning"))
threading.Thread(target=srv.run, daemon=True).start()
for _ in range(100):
    try: httpx.get(BASE + "/health", timeout=1); break
    except Exception: time.sleep(0.1)

PASS, FAIL = [], []
LINES = []
def check(name, cond, extra=""):
    (PASS if cond else FAIL).append(name)
    line = ("PASS " if cond else "FAIL ") + name + (f"  -> {extra}" if (extra and not cond) else "")
    LINES.append(line); print(line)
def csrf(html): m = re.search(r'name="csrf_token"\s+value="([^"]+)"', html); return m.group(1) if m else ""
def meta_csrf(html): m = re.search(r'name="csrf-token" content="([^"]+)"', html); return m.group(1) if m else ""
def browser(): return httpx.Client(base_url=BASE, follow_redirects=False, timeout=30)
def code_for(addr):
    return box.email.code_for(addr)

PW = "Str0ng-Passw0rd!x"
PDF = b"%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n" + b"SECRET-PAYLOAD-12345 " * 40
EMAIL = "alice@example.com"

# ── 1 register -> verification -> login (verification REQUIRED) ──
a = browser()
r = a.post("/register", data={"csrf_token": csrf(a.get("/register").text), "email": EMAIL, "password": PW, "full_name": "Alice A"})
check("register redirects to /verify-email", r.status_code == 303 and "/verify-email" in r.headers["location"], r.text[:200])
t = csrf(a.get("/login").text)
r = a.post("/login", data={"csrf_token": t, "email": EMAIL, "password": PW})
check("login blocked before email verified", r.status_code == 400 and "ss_session" not in a.cookies)
page = a.get("/verify-email", params={"email": EMAIL})
r = a.post("/verify-email", data={"csrf_token": csrf(page.text), "email": EMAIL, "code": "000000"})
check("wrong verification code rejected", r.status_code == 400)
r = a.post("/verify-email", data={"csrf_token": csrf(page.text), "email": EMAIL, "code": code_for(EMAIL)})
check("email verified with real code", r.status_code == 200 and "success" in r.text.lower() or "verified" in r.text.lower(), r.text[:300])
r = a.post("/login", data={"csrf_token": t, "email": EMAIL, "password": PW})
check("login after verification -> /dashboard + session cookie", r.status_code == 303 and r.headers["location"] == "/dashboard" and "ss_session" in a.cookies)
d = a.get("/dashboard"); check("dashboard renders", d.status_code == 200 and "Total Documents" in d.text)

# ── 2 MFA enable / enforce ──
from app.services import mfa
sp = a.get("/settings/security")
st = a.post("/settings/security/mfa/start", data={"csrf_token": csrf(sp.text)})
secret = re.search(r"<code>([A-Z2-7]{16,})</code>", st.text).group(1)
en = a.post("/settings/security/mfa/enable", data={"csrf_token": csrf(st.text), "code": mfa.totp_at(secret)})
check("MFA enabled with TOTP", en.status_code == 200 and "Recovery codes" in en.text)
recovery = re.findall(r"<code>([0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4})</code>", en.text)
a.post("/logout", data={"csrf_token": a.cookies.get("ss_csrf") or csrf(a.get("/login").text)})
a2 = browser(); t2 = csrf(a2.get("/login").text)
r = a2.post("/login", data={"csrf_token": t2, "email": EMAIL, "password": PW})
check("login with MFA -> /mfa challenge, no session yet", r.status_code == 303 and r.headers["location"] == "/mfa" and "ss_session" not in a2.cookies)
mp = a2.get("/mfa")
r = a2.post("/mfa", data={"csrf_token": csrf(mp.text), "code": "123456"})
check("wrong TOTP rejected", r.status_code == 400)
# TOTP replay protection: current code may already be used at enable time -> use next step window if rejected
code = mfa.totp_at(secret, time.time() + 30)
r = a2.post("/mfa", data={"csrf_token": csrf(mp.text), "code": code})
if r.status_code != 303: r = a2.post("/mfa", data={"csrf_token": csrf(mp.text), "code": recovery[0]})
check("MFA code accepted -> dashboard", r.status_code == 303 and r.headers["location"] == "/dashboard" and "ss_session" in a2.cookies, r.text[:200])
a = a2

# ── 3 upload (real XHR path), stored encrypted, view, download ──
home = a.get("/documents/upload")
up = a.post("/api/v1/documents/upload", files={"file": ("report.pdf", PDF, "application/pdf")}, headers={"X-CSRF-Token": meta_csrf(home.text)})
check("upload via API used by upload.js -> 2xx + id", up.status_code in (200, 201) and "id" in up.json(), up.text[:300])
doc_id = up.json()["id"]
blobs = [f for f in glob.glob(f"{tmp}/storage/**/*", recursive=True) if os.path.isfile(f)]
check("blob stored on disk", len(blobs) >= 1)
check("plaintext NOT on disk (encrypted at rest)", all(b"SECRET-PAYLOAD" not in open(f, "rb").read() for f in blobs))
check("documents list shows it", "report.pdf" in a.get("/documents").text)
check("document detail page", a.get(f"/documents/{doc_id}").status_code == 200)
v = a.get(f"/documents/{doc_id}/viewer"); check("owner view returns decrypted bytes", v.status_code == 200 and v.content == PDF, str(v.status_code))
dl = a.get(f"/documents/{doc_id}/download"); check("owner download returns identical bytes", dl.status_code == 200 and dl.content == PDF and "attachment" in dl.headers.get("content-disposition", ""))

# ── 4 secure share wizard: password + limits ──
LINKPW = "link-secret-9"
w = a.get(f"/documents/{doc_id}/share", follow_redirects=True)
ik = re.search(r'name="idempotency_key" value="([^"]+)"', w.text).group(1)
def step(n, **f):
    return a.post("/shares/create", data={"csrf_token": csrf_cur(), "idempotency_key": ik, "step": str(n), **f})
cur = {"html": w.text}
def csrf_cur(): return csrf(cur["html"])
r = step(1, document_id=doc_id); cur["html"] = r.text; check("wizard step1", r.status_code == 200, r.text[:200])
r = step(2, password_protect="on", link_password=LINKPW, link_expiry="on", limit_views="on", max_views="5",
         allow_download="on", limit_downloads="on", max_downloads="1"); cur["html"] = r.text
check("wizard step2 (password/expiry/limits)", r.status_code == 200, re.sub(r"\s+", " ", r.text)[:300])
r = step(3, binding_mode="NONE"); cur["html"] = r.text; check("wizard step3", r.status_code == 200, r.text[:200])
r = step(4); html = r.text
m = re.search(r'(http://[^"\s<]+/view/[A-Za-z0-9_\-]+)', html)
check("link generated", r.status_code == 200 and m is not None, html[:300])
link = m.group(1); token = link.rsplit("/", 1)[1]
check("QR code rendered", "<svg" in html)
link_id = re.search(r'/shares/([0-9a-f\-]{36})/revoke', html)
if not link_id:
    sh = a.get("/shares"); link_id = re.search(r'/shares/([0-9a-f\-]{36})', sh.text)
link_id = link_id.group(1)

# ── 5 recipient (separate browser, no session) ──
rc = browser()
g = rc.get(f"/view/{token}")
check("recipient sees password gate", g.status_code == 200 and "protected" in g.text.lower())
r = rc.post(f"/view/{token}", data={"csrf_token": csrf(g.text), "password": "wrong-pass"})
check("wrong link password rejected", r.status_code == 401)
r = rc.post(f"/view/{token}", data={"csrf_token": csrf(g.text), "password": LINKPW})
check("right link password unlocks", r.status_code == 303)
op = rc.get(f"/view/{token}"); check("recipient sees document page", op.status_code == 200 and "report.pdf" in op.text and "Download" in op.text)
c = rc.get(f"/view/{token}/content"); check("recipient VIEW returns bytes", c.status_code == 200 and c.content == PDF, str(c.status_code))
check("recipient VIEW is rendered inline as pdf", c.headers.get("content-type") == "application/pdf" and c.headers.get("content-disposition", "").startswith("inline") and "frame-ancestors" in c.headers.get("content-security-policy", ""))
d1 = rc.get(f"/view/{token}/download"); check("recipient DOWNLOAD #1 ok", d1.status_code == 200 and d1.content == PDF)
d2 = rc.get(f"/view/{token}/download"); check("download limit (1) enforced on #2", d2.status_code == 403, str(d2.status_code))
nb = browser(); r = nb.get(f"/view/{token}/content")
check("another browser without password cannot fetch content", r.status_code in (302, 303), str(r.status_code))

# ── 6 revoke -> denied ──
sd = a.get(f"/shares/{link_id}")
r = a.post(f"/shares/{link_id}/revoke", data={"csrf_token": csrf(sd.text) or meta_csrf(sd.text)})
check("owner revoke link", r.status_code == 303)
for who, cl in (("unlocked recipient", rc), ("fresh browser", browser())):
    r1 = cl.get(f"/view/{token}"); r2 = cl.get(f"/view/{token}/content"); r3 = cl.get(f"/view/{token}/download")
    check(f"revoked link denied for {who}", all(x.status_code in (403, 404, 410) for x in (r1, r2, r3)) and PDF not in r2.content, f"{r1.status_code},{r2.status_code},{r3.status_code}")

# ── 7 rotate + second link w/o password, one-time view, expiry fields ──
w = a.get(f"/documents/{doc_id}/share", follow_redirects=True); cur["html"] = w.text; ik = re.search(r'name="idempotency_key" value="([^"]+)"', w.text).group(1)
step(1, document_id=doc_id); r = step(2, one_time="on"); cur["html"] = r.text
r = step(3, binding_mode="NONE"); cur["html"] = r.text; r = step(4)
m2 = re.search(r'(http://[^"\s<]+/view/[A-Za-z0-9_\-]+)', r.text); tok2 = m2.group(1).rsplit("/", 1)[1]
rc2 = browser(); o = rc2.get(f"/view/{tok2}")
check("no-password link opens directly", o.status_code == 200 and "report.pdf" in o.text)
v1 = rc2.get(f"/view/{tok2}/content"); v2 = rc2.get(f"/view/{tok2}/content")
check("one-time view: first ok, second denied", v1.status_code == 200 and v2.status_code == 403, f"{v1.status_code},{v2.status_code}")


# ── 7b rotate: old token dead, new token works ──
w = a.get(f"/documents/{doc_id}/share", follow_redirects=True); cur["html"] = w.text; ik = re.search(r'name="idempotency_key" value="([^"]+)"', w.text).group(1)
step(1, document_id=doc_id); r = step(2); cur["html"] = r.text; r = step(3, binding_mode="NONE"); cur["html"] = r.text; r = step(4)
tok3 = re.search(r'/view/([A-Za-z0-9_\-]+)', r.text).group(1)
lid3 = re.search(r'/shares/([0-9a-f\-]{36})', r.text)
if not lid3:
    lid3 = re.search(r'/shares/([0-9a-f\-]{36})', a.get("/shares").text)
lid3 = lid3.group(1)
sd = a.get(f"/shares/{lid3}")
rr = a.post(f"/shares/{lid3}/rotate", data={"csrf_token": csrf(sd.text)})
newtok = re.search(r'http://[^"\s<]+/view/([A-Za-z0-9_\-]+)', rr.text)
check("rotate returns a new link", rr.status_code == 200 and newtok is not None and newtok.group(1) != tok3, rr.text[:200])
check("old rotated token denied", browser().get(f"/view/{tok3}").status_code in (403, 404))
check("new rotated token opens", browser().get(f"/view/{newtok.group(1)}").status_code == 200)

# ── 7c recipient verification by email code ──
w = a.get(f"/documents/{doc_id}/share", follow_redirects=True); cur["html"] = w.text; ik = re.search(r'name="idempotency_key" value="([^"]+)"', w.text).group(1)
step(1, document_id=doc_id); r = step(2, allow_download="on"); cur["html"] = r.text
r = step(3, binding_mode="EMAIL_OTP", recipient_email="bob@example.com"); cur["html"] = r.text
check("wizard step3 email-bound accepted", r.status_code == 200, re.sub(r"\s+", " ", r.text)[:200]); r = step(4)
tok4 = re.search(r'http://[^"\s<]+/view/([A-Za-z0-9_\-]+)', r.text).group(1)
bob = browser(); g = bob.get(f"/view/{tok4}")
check("bound link asks for recipient email", g.status_code == 200 and "email" in g.text.lower() and "report.pdf" not in g.text)
check("bound link content denied before verification", bob.get(f"/view/{tok4}/content").status_code in (302, 303, 403))
ev = browser(); eg = ev.get(f"/view/{tok4}"); ev.post(f"/view/{tok4}/claim", data={"csrf_token": csrf(eg.text), "email": "eve@example.com"})
check("non-recipient gets no code", not box.email.to("eve@example.com"))
cl = bob.post(f"/view/{tok4}/claim", data={"csrf_token": csrf(g.text), "email": "bob@example.com"})
pending = re.search(r'name="pending" value="([^"]*)"', cl.text)
check("code emailed to recipient", cl.status_code == 200 and bool(box.email.to("bob@example.com")) and pending is not None, cl.text[:200])
bad = bob.post(f"/view/{tok4}/code", data={"csrf_token": csrf(cl.text), "code": "000000", "pending": pending.group(1)})
check("wrong recipient code rejected", bad.status_code in (400, 401))
ok = bob.post(f"/view/{tok4}/code", data={"csrf_token": csrf(cl.text), "code": code_for("bob@example.com"), "pending": pending.group(1)})
check("right recipient code accepted", ok.status_code == 303, ok.text[:200])
bv = bob.get(f"/view/{tok4}/content"); check("verified recipient can view", bv.status_code == 200 and bv.content == PDF)

# ── 8 guest ──
gb = browser(); lp = gb.get("/login")
check("login page shows Google+Microsoft enabled", 'href="/oauth/google"' in lp.text and 'href="/oauth/microsoft"' in lp.text)
r = gb.post("/guest-login", data={"csrf_token": csrf(lp.text)})
check("guest login -> /dashboard", r.status_code == 303 and r.headers["location"] == "/dashboard" and "ss_session" in gb.cookies)
check("guest dashboard", gb.get("/dashboard").status_code == 200)
gh = gb.get("/documents/upload"); gup = gb.post("/api/v1/documents/upload", files={"file": ("g.txt", b"guest data " * 10, "text/plain")}, headers={"X-CSRF-Token": meta_csrf(gh.text)})
check("guest can upload", gup.status_code in (200, 201), gup.text[:200])
check("guest cannot read alice's doc", gb.get(f"/documents/{doc_id}/download").status_code in (403, 404))

# ── 9 Google + Microsoft OAuth through the live server ──
for prov, info in (("google", {"sub": "g-1", "email": "oauth.user@gmail.com", "email_verified": True, "name": "OAuth User"}),
                   ("microsoft", {"sub": "m-1", "email": "ms.user@outlook.com", "email_verified": True, "name": "MS User"})):
    FAKE["info"] = info
    ob = browser(); r = ob.get(f"/oauth/{prov}")
    loc = r.headers.get("location", ""); q = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(loc).query))
    check(f"{prov}: button -> provider authorize URL", r.status_code == 303 and "state" in q and q.get("code_challenge_method") == "S256", loc[:120])
    r = ob.get(f"/oauth/{prov}/callback", params={"code": "abc", "state": q["state"]})
    check(f"{prov}: callback -> session -> /dashboard", r.status_code == 303 and r.headers["location"] == "/dashboard" and "ss_session" in ob.cookies, r.text[:200])
    dd = ob.get("/dashboard"); check(f"{prov}: dashboard accessible", dd.status_code == 200)
    ob.get(f"/oauth/{prov}")  # second visit not required

# ── 10 forgot / reset password through real emailed link ──
fb = browser(); fp = fb.get("/forgot-password")
r = fb.post("/forgot-password", data={"csrf_token": csrf(fp.text), "email": EMAIL})
check("forgot-password accepted", r.status_code == 200 and "on its way" in r.text, r.text[:200])
mail = [m for m in box.email.to(EMAIL) if "Reset" in m["Subject"]]
body = mail[-1].get_content() if mail else ""
ml = re.search(r"(http://[^\s]+/reset-password\?[^\s]+)", body)
check("reset email delivered with link", ml is not None, body[:300])
u = urllib.parse.urlparse(ml.group(1)); rp = fb.get(u.path + "?" + u.query)
check("reset page prefilled", rp.status_code == 200 and "reset_token" in rp.text)
NEW = "N3w-Passw0rd!zz"
r = fb.post("/reset-password", data={"csrf_token": csrf(rp.text), "reset_token": dict(urllib.parse.parse_qsl(u.query))["token"], "email": EMAIL, "new_password": NEW, "confirm": NEW})
check("password reset -> /login?reset=success", r.status_code == 303 and "reset=success" in r.headers["location"], r.text[:200])
lb = browser(); lt = csrf(lb.get("/login").text)
check("old password no longer works", lb.post("/login", data={"csrf_token": lt, "email": EMAIL, "password": PW}).status_code == 400)
r = lb.post("/login", data={"csrf_token": lt, "email": EMAIL, "password": NEW})
check("new password reaches MFA step", r.status_code == 303 and r.headers["location"] == "/mfa")

summary = f"\n{len(PASS)} passed, {len(FAIL)} failed"
print(summary)
for f in FAIL: print("  FAILED:", f)
open("selfcheck_report.txt", "w", encoding="utf-8").write("\n".join(LINES) + summary + "\n")
srv.should_exit = True
sys.exit(1 if FAIL else 0)
