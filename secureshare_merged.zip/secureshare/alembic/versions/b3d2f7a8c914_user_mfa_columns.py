"""users: totp_secret (encrypted) + recovery_codes for real MFA

Revision ID: b3d2f7a8c914
Revises: a7c1e5d90b21
Create Date: 2026-10-04 10:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = 'b3d2f7a8c914'
down_revision: Union[str, None] = 'a7c1e5d90b21'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table('users') as b:
        b.add_column(sa.Column('totp_secret', sa.String(length=255), nullable=True))
        b.add_column(sa.Column('recovery_codes', sa.JSON(), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table('users') as b:
        b.drop_column('recovery_codes')
        b.drop_column('totp_secret')
