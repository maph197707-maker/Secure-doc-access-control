"""otp_challenges: persisted, hashed one-time-code challenges (replaces email_verifications)

Revision ID: a7c1e5d90b21
Revises: 318ac60dfa77
Create Date: 2026-10-03 16:30:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = 'a7c1e5d90b21'
down_revision: Union[str, None] = '318ac60dfa77'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table('otp_challenges',
    sa.Column('purpose', sa.String(length=32), nullable=False),
    sa.Column('channel', sa.String(length=8), nullable=False),
    sa.Column('subject', sa.String(length=100), nullable=False),
    sa.Column('destination_hash', sa.String(length=64), nullable=False),
    sa.Column('destination_hint', sa.String(length=80), nullable=False),
    sa.Column('otp_hash', sa.String(length=64), nullable=False),
    sa.Column('status', sa.String(length=16), nullable=False),
    sa.Column('expires_at', sa.DateTime(), nullable=False),
    sa.Column('attempt_count', sa.Integer(), nullable=False),
    sa.Column('max_attempts', sa.Integer(), nullable=False),
    sa.Column('resend_available_at', sa.DateTime(), nullable=False),
    sa.Column('sent_at', sa.DateTime(), nullable=True),
    sa.Column('verified_at', sa.DateTime(), nullable=True),
    sa.Column('id', sa.String(length=36), nullable=False),
    sa.Column('created_at', sa.DateTime(), nullable=False),
    sa.Column('updated_at', sa.DateTime(), nullable=False),
    sa.PrimaryKeyConstraint('id')
    )
    with op.batch_alter_table('otp_challenges', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_otp_challenges_id'), ['id'], unique=False)
        batch_op.create_index(batch_op.f('ix_otp_challenges_subject'), ['subject'], unique=False)
        batch_op.create_index('ix_otp_lookup', ['purpose', 'subject', 'destination_hash', 'created_at'], unique=False)
        batch_op.create_index('ix_otp_dest_created', ['destination_hash', 'created_at'], unique=False)

    # The old table only ever held a hash that nothing verified against (the code lived in process memory).
    with op.batch_alter_table('email_verifications', schema=None) as batch_op:
        batch_op.drop_index(batch_op.f('ix_email_verifications_user_id'))
        batch_op.drop_index(batch_op.f('ix_email_verifications_token_hash'))
        batch_op.drop_index(batch_op.f('ix_email_verifications_id'))
    op.drop_table('email_verifications')


def downgrade() -> None:
    op.create_table('email_verifications',
    sa.Column('user_id', sa.String(length=36), nullable=False),
    sa.Column('token_hash', sa.String(length=64), nullable=False),
    sa.Column('otp_hash', sa.String(length=64), nullable=True),
    sa.Column('expires_at', sa.DateTime(), nullable=False),
    sa.Column('used_at', sa.DateTime(), nullable=True),
    sa.Column('id', sa.String(length=36), nullable=False),
    sa.Column('created_at', sa.DateTime(), nullable=False),
    sa.Column('updated_at', sa.DateTime(), nullable=False),
    sa.ForeignKeyConstraint(['user_id'], ['users.id'], ),
    sa.PrimaryKeyConstraint('id')
    )
    with op.batch_alter_table('email_verifications', schema=None) as batch_op:
        batch_op.create_index(batch_op.f('ix_email_verifications_id'), ['id'], unique=False)
        batch_op.create_index(batch_op.f('ix_email_verifications_token_hash'), ['token_hash'], unique=False)
        batch_op.create_index(batch_op.f('ix_email_verifications_user_id'), ['user_id'], unique=False)

    with op.batch_alter_table('otp_challenges', schema=None) as batch_op:
        batch_op.drop_index('ix_otp_dest_created')
        batch_op.drop_index('ix_otp_lookup')
        batch_op.drop_index(batch_op.f('ix_otp_challenges_subject'))
        batch_op.drop_index(batch_op.f('ix_otp_challenges_id'))
    op.drop_table('otp_challenges')
