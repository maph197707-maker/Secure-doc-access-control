@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Run install.bat first.
    pause
    exit /b 1
)
set "MODE=dev"
if /i "%~1"=="lan" set "MODE=demo"
".venv\Scripts\python.exe" -m scripts.setup_db
".venv\Scripts\python.exe" -m scripts.run %MODE%
pause
