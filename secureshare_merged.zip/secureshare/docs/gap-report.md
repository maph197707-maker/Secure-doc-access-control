# Gap report: SecureShare vs the v3 spec (updated after the UI build)

Spec file list: **303 paths. 93 real, 183 empty stubs, 27 missing.** (Was 35 real / 191 stub / 110 missing.)

## Test results (build sandbox, Python 3.12.3, Node 22)
- `python -W error::DeprecationWarning -m unittest discover -s tests -t .` -> **78 tests, OK**
- JS: `node --check` on all modules + pure-function tests (OTP split, strength meter, search grouping, redirect safety, viewer fail-closed).
- NOT run here (no network / no browser): FastAPI server, SQLAlchemy/Alembic, Argon2, Playwright/axe-core screenshots. These are UNVERIFIED.

## Still stubs (not implemented)
- **(root)/**: .dockerignore, .gitignore, CONTRIBUTING.md, Dockerfile, README.md, SECURITY.md, alembic.ini, docker-compose.prod.yml, docker-compose.yml, requirements-dev.txt, requirements.txt
- **.vscode/**: extensions.json, launch.json, settings.json, tasks.json
- **alembic/**: env.py
- **app/**: lifespan.py
- **app/api/**: router.py
- **app/api/v1/**: access.py, admin.py, alerts.py, analytics.py, audit.py, auth.py, dashboard.py, devices.py, dlp.py, documents.py, health.py, links.py, notifications.py, policies.py, recipients.py, risk.py, search.py, security_score.py, sessions.py, share.py, signatures.py, simulator.py, users.py
- **app/config/**: constants.py, logging.py, settings.py
- **app/core/**: dependencies.py, error_handlers.py, exceptions.py, responses.py, utils.py
- **app/db/**: base.py, session.py, unit_of_work.py
- **app/integrations/**: ai.py, email.py, kms.py, network_intel.py, oauth.py, ocr.py, search.py, sms.py, storage.py
- **app/middleware/**: access_log.py, csrf.py, host_guard.py, rate_limit.py, request_id.py, security_headers.py
- **app/ml/**: baseline.py, classifier.py, features.py, pii_ner.py
- **app/models/**: access_attempt.py, access_grant.py, access_policy.py, access_request.py, audit.py, auth.py, behaviour_profile.py, classification.py, device.py, dlp_finding.py, document.py, document_metadata.py, document_version.py, download.py, encryption_key.py, folder.py, link_policy.py, notification.py, oauth_account.py, permission.py, processing_job.py, recipient.py, risk.py, role.py, secure_link.py, security_alert.py, security_event.py, session.py, share_draft.py, signature.py, subscription.py, system_setting.py, tag.py, usage_metric.py, user.py, user_preference.py, view_session.py, watermark_record.py
- **app/repositories/**: audit.py, document.py, share.py, user.py
- **app/schemas/**: audit.py, auth.py, document.py, policy.py, share.py, user.py
- **app/security/**: threat_detection.py
- **app/services/**: access_control.py, admin.py, alerts.py, analytics.py, attack_simulator.py, auth.py, devices.py, documents.py, folders.py, identity.py, mfa.py, notifications.py, policy_simulator.py, quotas.py, search.py, secure_links.py, sessions.py, viewer.py, zero_trust.py
- **app/web/**: admin.py, dev.py, public.py, share_flow.py, user.py
- **app/workers/**: celery_app.py
- **app/workers/tasks/**: ai_tasks.py, alert_tasks.py, audit_tasks.py, dlp_tasks.py, document_tasks.py, maintenance_tasks.py, notification_tasks.py
- **deploy/caddy/**: Caddyfile
- **deploy/nginx/**: nginx.conf, security-headers.conf
- **docs/**: ai-risk.md, api.md, architecture.md, authentication.md, backup-recovery.md, cryptography.md, database.md, demo-guide.md, deployment.md, dlp.md, key-management.md, security.md, technology-coverage.md, technology-stack.md, threat-model.md, traceability.md, troubleshooting.md, zero-trust.md
- **scripts/**: backup_keys.py, create_admin.py, fetch_vendor.py, reset_demo.py, restore_keys.py, rotate_keys.py, seed_demo.py, seed_roles.py, smoke.py, verify_audit.py

## Still missing (file does not exist)
- **app/integrations/**: queue.py
- **app/static/js/**: webauthn.js
- **app/templates/admin/**: user_detail.html, users.html
- **app/templates/auth/**: mfa.html, passkey.html, reset_password.html
- **app/templates/public/**: welcome_mobile.html
- **app/templates/security/**: activity.html, audit.html, devices.html, sessions.html
- **app/templates/sharing/**: detail.html
- **app/templates/viewer/**: _info_panel.html, _thumbs.html
- **tests/api/**: test_admin_authz.py, test_auth_api.py, test_documents_api.py, test_idor.py
- **tests/e2e/**: test_accessibility.py, test_full_flow.py, test_ui_screens.py
- **tests/integration/**: test_migrations.py, test_share_flow.py, test_upload_pipeline.py
- **tests/performance/**: locustfile.py
- **tests/workers/**: test_tasks.py

## Next, in order
1. settings + app factory + middleware (CSP, CSRF, request-id, host guard)
2. SQLAlchemy models + Alembic migrations
3. auth/sessions routes wired to the existing OTP/lockout/password code
4. upload pipeline + storage + queue; share-link create/redeem using the PDP and atomic counters
5. web routes that build the template contexts in tests/fixtures/ui_contexts.py from real services
6. Playwright screenshots + axe-core to verify the UI against the reference