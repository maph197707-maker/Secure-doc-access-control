# Databases: SQLite (local) or PostgreSQL (Supabase / Neon / any)

Only `DATABASE_URL` changes. Application code is identical (SQLAlchemy + Alembic).

| Mode | DATABASE_URL |
|---|---|
| A. SQLite (default) | `sqlite:///./data/secureshare.db` |
| B. Supabase | `postgresql+psycopg://postgres.REF:PASSWORD@aws-0-REGION.pooler.supabase.com:5432/postgres?sslmode=require` |
| C. Neon | `postgresql+psycopg://USER:PASSWORD@ep-xxxx.REGION.aws.neon.tech/DB?sslmode=require` |

`postgres://` and `postgresql://` URLs pasted from a provider dashboard are converted automatically.
URL-encode special characters in the password (`@` -> `%40`). Free-tier limits change: check the
provider; nothing in the code depends on them.

## PostgreSQL steps
1. Create a project/database at the provider, copy the connection URI.
2. `pip install -r requirements.txt -r requirements-postgres.txt`
3. Put the URL in `.env` as `DATABASE_URL=`.
4. `alembic upgrade head`
5. Start the server. Check **/admin/database** (admin only): type, Connected, masked host, version,
   migration Current/Pending. Passwords and the full URL are never shown.

Windows note: psycopg async needs the selector event loop; if you see
`ProactorEventLoop` errors run under WSL/Docker or set
`asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())` before uvicorn starts.

## Migrations
    alembic upgrade head            # apply
    alembic current                 # what is applied
    alembic revision --autogenerate -m "message"   # after changing models
SQLite to PostgreSQL does not copy data; start the new database empty (or export/import yourself).
