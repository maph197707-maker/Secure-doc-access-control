# Recipient-bound links, phone OTP, Redis state, expiry timezone (2.9.2)

## Recipient verification modes (wizard step 3)
| Mode | Who can open it | Code goes to |
|---|---|---|
| `NONE` | anyone with the link (optional password) | - |
| `EMAIL_OTP` | the named recipient | the email on file |
| `PHONE_OTP` | the named recipient | the phone on file (E.164) |

A mode is selectable only when its channel is configured in this deployment (real SMTP for email, Twilio for SMS).
Codes live in the `otp_challenges` table (hashed, with expiry, attempt count, cooldown and one-time use).

Visitor flow on `/view/{token}`: password (if any) -> enter recipient email -> code -> signed cookie
(1 h, path-scoped to that token) -> `/content` and `/download`. Without the cookie both return 303 back
to the page; the bytes are never streamed. Routes: `POST /view/{token}/claim`, `POST /view/{token}/code`.

Security properties (tests in `tests/unit/test_recipient_gate.py`):
* the code is sent to the contact **on file**, never to what the visitor typed;
* a non-matching email gets the identical response, so recipients cannot be enumerated;
* claims are throttled per (link, IP) and per link; codes allow 5 attempts, 30 s resend cooldown;
* a `pending` token (before the code is proven) can never be used as a verified session;
* delivery failure clears the stored code and cooldown so the recipient can retry at once.

## Phone OTP for signed-in users
`/verify-phone` (send / verify). Per-number (`OTP_MAX_SENDS_PER_HOUR`, default 5/h) and per-account (2x) send caps protect the SMS bill.
Changing the number clears `phone_verified` until the new one is verified.

## Redis state
`pip install -r requirements-redis.txt`, set `APP_MODE=full` and `REDIS_URL`. Rate limits, OTP attempts and
cooldowns then hold across workers. Production refuses to start if Redis is unreachable (falling back to
per-process memory would make those limits bypassable); development falls back with a warning.

## Expiry timezone
The wizard sends the browser's IANA zone (`tz`) with the `datetime-local` value. Stored times are naive UTC.
DST gap (non-existent local time) -> the real instant the clock would show; DST fold (ambiguous) -> the
earlier instant, so a link never outlives what the owner typed. No JavaScript -> UTC, and the page says so.

## No migration needed
`binding_mode`, `recipients.phone`, `phone_verified`, `otp_verified`, `bound_at` already exist in 2.9.1.
