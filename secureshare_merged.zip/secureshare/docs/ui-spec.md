# UI spec (built from the two reference boards)

Stack: Jinja2 (StrictUndefined, autoescape) + vanilla ES modules. No CDN, no inline script/style (strict CSP ready).
Charts are **server-rendered SVG** (`chart_points`, `donut_segments` filters); no Chart.js. Polling (`polling.js`) replaces HTMX.

## Screens built (template -> route -> data it expects from a service)
| Ref # | Screen | Template | Route | Context contract (see tests/fixtures/ui_contexts.py) |
|---|---|---|---|---|
| 1,19,20 | Landing + CTA | public/landing.html | / | features, tour_steps |
| 2 | Create account | auth/register.html | /register | values, errors, progress, sms_available |
| 3 | Login | auth/login.html | /login | email, error, oauth{google,microsoft} |
| 4 | Dashboard (+14, 17 mobile) | dashboard/dashboard.html | /dashboard | hour, metrics[label,value,delta,icon,suffix], activity, recent |
| 4b | Email verification | auth/verify_email.html | /verify-email | status, email_masked, attempts_left, cooldown |
| 5 | Home | dashboard/home.html | /home | actions, quick |
| 6 | Share wizard | sharing/wizard.html | /shares/create | step, draft, binding_modes, idempotency_key |
| 7 | Upload + AI/DLP | documents/upload.html (+_analysis_panel) | /documents/upload | doc, analysis{scan_status,dlp_level,...} |
| 8 | Link generated | sharing/link_ready.html | /shares/{id} | full_link (creation only), qr_svg, share |
| 9 | Public link gate | public/share_gate.html | /share/{token} | token, password_required, error |
| 10 | Identity verification | auth/verify_identity.html | /verify-identity | steps (from PDP), attempts_left, locked_seconds |
| 11 | Protected viewer | viewer/viewer.html | /viewer/{token} | policy, watermark, integrity, stopped |
| 12 | Analytics | analytics/analytics.html | /analytics | range, metrics, trend, types |
| 13 | Admin | admin/dashboard.html | /admin | metrics, recent_users |
| 15 | Notifications | notifications/list.html | /notifications | notifications, unread |
| 16 | Security score | security/score.html | /security/score | result = security_score.ScoreResult |
| 18 | Versions / compare | documents/versions.html, compare.html | /documents/{id}/versions, /compare | versions, diff |
| - | My documents, details, links list, errors | documents/list, detail; sharing/list; errors/error | /documents, /documents/{id}, /shares | see fixtures |

## Design decisions and deviations from the reference (honest list)
- Brand gradient end colour darkened from #12C8E8 to #0C8094 so white button text meets WCAG AA (reference cyan = 2.0:1). `--accent` stays bright for dark surfaces.
- Success/warning/danger/primary/purple *text* colours darkened (tokens `--success`, `--warning`, `--danger`, `--primary-text`, `--accent-2-text`) to reach 4.5:1 on their tinted badges. Enforced by `ContrastTests`.
- Security Score shows the controls the engine really computes (encryption, key protection, signatures, binding, MFA, devices, expiry, DLP, watermark, audit) instead of the board's 5 sample rows.
- Google/Microsoft buttons and SMS steps render disabled with the reason when unconfigured (PROVIDER_UNAVAILABLE).
- The viewer page images come from the server (`page_url`); the template never receives keys or storage paths.
## Not verified / not done
- **No browser rendering or screenshots yet** (no browser in the build sandbox): pixel-level match with the reference is UNVERIFIED. Playwright screenshots at 390/768/1440 are the next UI step.
- axe-core run, keyboard-only pass, and horizontal-scroll check at 360px need a browser: UNVERIFIED. (Static a11y lint and contrast math are tested.)
- Illustrations are simple original SVGs, simpler than the reference art.
- Passkey UI (`webauthn.js`), folders UI dialog, SSE live feed are not built.
