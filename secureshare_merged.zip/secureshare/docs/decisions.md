# decisions

Status: PLANNED - to be written as milestones complete.

## 2026-10-01 Audit outcome and scope of first build pass
- Q: Build all 15 milestones in one pass? Choice: no. The build sandbox has no network and no FastAPI/SQLAlchemy/pytest, so web code cannot be executed. Built and proved the framework-independent security core first; refused to ship unrun web code labelled "working" (rules R5/R6).
- Used cryptography's native Argon2id for key-backup encryption (avoids an extra dependency).
- Tests are unittest classes so they run with both `python -m unittest` and pytest.

## 2026-10-01 UI layer
- Dropped HTMX and Chart.js (cannot be downloaded in the build sandbox; R10 fallback): charts are server-side SVG, async panels use polling.js. Both choices also shrink the CSP surface.
- Components consolidated into components/ui.html + icons.html (macro files) instead of ~40 one-macro files.
- Jinja gotcha fixed: dict keys named `values` must be accessed as `d['values']` (attribute lookup returns dict.values()).
- Contrast tests found 6 AA failures in the reference-derived palette; tokens adjusted (see ui-spec.md).
