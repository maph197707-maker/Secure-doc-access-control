# Multi-device demo: Laptop -> SecureShare server -> Phone / second laptop

## 0. Start the server so other devices can reach it
    pip install -r requirements.txt
    cp .env.example .env            # then generate SECRET_KEY / MASTER_SECRET
    alembic upgrade head            # (or let the dev app create tables)
    python -m scripts.run demo      # = uvicorn app.main:app --host 0.0.0.0 --port 8000, prints the LAN URL
    python -m scripts.lan_info      # print the LAN URL again any time
Same Wi-Fi only. Nothing is exposed to the Internet. If the phone cannot connect, allow Python through
the OS firewall for *private* networks. `localhost` on the phone is the phone itself: always use the
LAN URL (e.g. `http://192.168.1.20:8000`).

## 1. Device A (owner)
1. Open `http://localhost:8000`, register, verify, sign in.
2. **Sharing -> Create Link**: pick or upload a document -> security options (password, expiry, max
   views, allow downloads, one-time) -> recipient -> **Generate Link**.
3. Copy the link (it is shown once) or scan the QR code. The link already contains the LAN address.

## 2. Device B (anyone on the Wi-Fi, no account needed for link sharing)
Open the link -> (password if set) -> **View** or **Download**. Bytes are decrypted per request on the
server (AES-256-GCM); the file is never reachable at /static, /uploads or /files.

For account-to-account sharing (VIEW / DOWNLOAD / EDIT / RESHARE with expiry) use
`POST /api/v1/shares`, then Device B signs in and uses **Shared With Me** (`GET /api/v1/shares/with-me`).

## 3. Revoke and prove it
Device A: **Sharing -> link -> Revoke** (or `DELETE /api/v1/links/{id}`).
Device B: reload -> "This link has been revoked or expired" (HTTP 403). No logout needed; the server
checks the database on every request. Rotate issues a new URL and kills the old one instantly.

## 4. Audit trail
`SECURE_LINK_CREATE / _VIEW / _DOWNLOAD / _DENIED / _PASSWORD_FAIL / _LOCKED / _ROTATE / _REVOKE`
are in `audit_logs` (hash-chained). Passwords, OTPs and keys are never logged.
