# Feature matrix (statuses are honest; see PROGRESS.md)
| Feature | Status | Module | Tests |
|---|---|---|---|
| SHA-256 / SHA3-256 / HMAC / HKDF / constant-time compare | ACTIVE | app/crypto/hashing.py | tests/crypto |
| Opaque tokens (keyed hash only) | ACTIVE | app/crypto/tokens.py | tests/crypto |
| Chunked streaming AES-256-GCM | ACTIVE | app/crypto/aead.py | tests/crypto |
| Envelope KEK/DEK, rotation, key states, encrypted backup | ACTIVE (DEV key provider) | app/crypto/envelope.py | tests/crypto |
| KMS wiring | DocumentService now wraps DEKs via build_kms (kms_aws / kms_vault refs; local rows stay readable); AWS/Vault adapters tested with fake clients only, NOT live. Azure/HSM: PROVIDER_UNAVAILABLE | app/services/key_wrap.py, documents.py | tests/unit/test_kms_scan_wiring.py |
| Ed25519 / RSA-PSS / ECDSA signatures | ACTIVE | app/crypto/signatures.py | tests/crypto |
| Argon2id passwords | UNVERIFIED (needs argon2-cffi) | app/crypto/password.py | - |
| Upload validation, zip-bomb, traversal guards | ACTIVE | app/security | tests/security |
| Malware scan | ACTIVE: real clamd INSTREAM client (tested vs a protocol-faithful fake; NOT run against a live clamd) + DEV EICAR scanner; wired into upload (INFECTED rejected, unavailable never recorded as CLEAN, QUARANTINED docs never served) | app/integrations/malware.py, app/services/upload_scan.py, documents.py | tests/security/test_clamd_scanner.py, tests/unit/test_kms_scan_wiring.py |
| DLP regex+validators | ACTIVE; NER/Presidio PROVIDER_UNAVAILABLE | app/services/dlp.py | tests/unit |
| Audit hash chain + Merkle | ACTIVE (pure logic + repository verify()/merkle_anchor(), FOR UPDATE on append; DB path NEVER EXECUTED here) | app/services/audit.py | tests/unit |
| Explainable risk engine | ACTIVE (pure logic) | app/services/risk.py | tests/unit |
| Zero-Trust PDP | ACTIVE (pure logic; wiring PLANNED) | app/services/policy_engine.py | tests/unit |
| Watermark renderer | ACTIVE | app/services/watermark.py | tests/unit |
| Email/SMS OTP: DB-persisted hashed codes, expiry, attempts, cooldown, one-time use; SMTP + Twilio providers | ACTIVE (needs real SMTP/Twilio credentials) | app/services/otp.py, app/models/otp.py, app/integrations/email.py, sms.py | tests/unit/test_otp_service.py, test_email_provider.py, test_sms_provider.py, tests/api/test_registration_otp.py |
| Rate limiter, lockout, StateStore (in-memory DEV; Redis optional) | ACTIVE | app/integrations/state.py, app/services/rate_limiter.py | tests/unit |
| Atomic usage counters (SQL, race-tested on SQLite; PostgreSQL UNVERIFIED) | ACTIVE | app/services/usage_counters.py | tests/unit |
| Link reputation, security score, statistical anomaly | ACTIVE (pure logic; DB wiring PLANNED) | app/services | tests/unit |
| Design system + 26 screens (templates, CSS, JS) | PROTOTYPE: renders and lints clean; not yet wired to routes/DB; no browser check | app/templates, app/static | tests/unit/test_ui.py, tests/js |
| Web app, DB, auth, sessions, links, viewer, UI screens, admin, MFA, analytics | PLANNED | - | - |

| Notification fan-out | ACTIVE (pure planner/dispatcher, tested; async DB wrapper notify_fan_out NEVER EXECUTED; SMS off until a per-user pref exists) | app/services/notify_fanout.py, notifications.py | tests/unit/test_notify_fanout.py |
| Redis StateStore | Adapter exists (RedisStateStore, fake-client tested); live Redis UNVERIFIED | app/integrations/state.py | tests/unit/test_redis_state.py |
| OAuth (Google/Microsoft) | Code+PKCE(S256), single-use state, nonce/aud check, verified-email-only, safe account-link decision; tested with a fake transport. Routes/UI for it NOT wired; live providers UNVERIFIED | app/integrations/oauth.py | tests/unit/test_oauth_flow.py |
| Semantic search | Vector search: dependency-free hashed n-gram embedder (lexical-vector, NOT neural, labelled as such) + optional sentence-transformers adapter. Not yet exposed on /search route | app/services/semantic.py, integrations/search.py | tests/unit/test_semantic_llm_ner.py |
| Hosted LLM | OpenAI/Anthropic adapter: DLP-masks text first, never sends RESTRICTED/TOP_SECRET, advisory only (never_downgrade). Live calls UNVERIFIED (no key/network). Enabled by AI_BACKEND=llm + key | app/integrations/llm.py, ai.py | tests/unit/test_semantic_llm_ner.py |
| Free-text NER | Presidio adapter (injectable analyzer, tested). Real use needs presidio-analyzer + spaCy model; otherwise MODEL_UNAVAILABLE | app/ml/pii_ner.py | tests/unit/test_semantic_llm_ner.py |
| Zero-Trust wiring | AccessControlService now uses live RiskEngine score (fallback MEDIUM on engine failure) + classification ABAC (RESTRICTED/TOP_SECRET need MFA) + session MFA state in /documents view/download. ABAC logic tested; the DB/route path NEVER EXECUTED here | grants_logic.py, access_control.py, dependencies.py, api/v1/documents.py | tests/unit/test_abac_wiring.py |
