# SMS / OTP delivery

`SMSService -> SMSProvider -> TwilioSMSProvider` (`app/integrations/sms.py`). Twilio Programmable Messaging is the
only production provider: `POST https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/Messages.json`, HTTP Basic auth
(Account SID + Auth Token), form fields `To`, `Body` and either `From` or `MessagingServiceSid`; success is HTTP `201`
with a message `sid`.

| Variable | Meaning |
|---|---|
| `TWILIO_ACCOUNT_SID` | Account SID (`AC...`) |
| `TWILIO_AUTH_TOKEN` | Auth token (secret) |
| `TWILIO_FROM_NUMBER` | E.164 sender number, **or** |
| `TWILIO_MESSAGING_SERVICE_SID` | Messaging Service SID (`MG...`, wins over the number) |
| `SMS_DEFAULT_COUNTRY_CODE` | applied to bare national numbers (default `+91`) |
| `SMS_TIMEOUT_SECONDS` | HTTP timeout (default 10) |

Codes are generated, hashed, stored and verified by **our backend** (`app/services/otp.py`, table `otp_challenges`);
Twilio only carries the message. Failures raise `SMSDeliveryError(reason)` with a category - `auth_failed`, `timeout`,
`network_error`, `provider_rate_limited`, `recipient_rejected`, `provider_unavailable`, `provider_rejected` - which
`OtpService` turns into an audited `OTP_DELIVERY_FAILED` event and an HTTP 422/502/503. Nothing pretends to have sent.

Trial accounts can only text verified numbers (Twilio error 21608 -> `recipient_rejected`). Sending to India needs a
DLT-registered sender/template on the Twilio side; that is Twilio account configuration, not code.
Check your credentials with `python -m scripts.test_sms +15551234567`.
