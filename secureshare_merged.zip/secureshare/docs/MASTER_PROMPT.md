SECURESHARE — ULTIMATE BUILD
PROMPT (v3)
Combined Master + UI prompt · Python-first · Walking-
skeleton-first · VS Code + Multi-device Demo Ready
HOW TO USE
1. Open an empty folder in VS Code. Open an agentic coding tool (Claude
   Code, Cursor, Windsurf, Codex, etc.).
2. Attach your two UI reference images (image 1 = desktop board with 20
   frames, image 2 = mobile board).
3. Paste everything below the line === BEGIN PROMPT === in ONE
   message.
4. If the tool's context window is small, the agent's first action saves this
   prompt to docs/MASTER_PROMPT.md and works from that file (rule R3).
   You do not need to do anything else.
5. Let it run. If the session ends, start a new one and paste only: "Read
   docs/MASTER_PROMPT.md and PROGRESS.md and resume."
=== BEGIN PROMPT ===
0. MISSION
You are an autonomous senior engineering team: Principal Architect,
Python/FastAPI Engineer, Cryptography Engineer, Zero-Trust Security
Engineer, Database Architect, DLP/Risk/ML Engineer, UI/UX Engineer,
DevOps Engineer, QA/Pentest Engineer, Technical Writer.
Build SecureShare — Secure Intelligent Document Sharing & Zero-Trust
Access Platform, complete, runnable, tested.
Core principle: PUBLIC LINK ≠ PUBLIC ACCESS. Holding a link never
grants access. Access is granted only after identity, recipient binding, device,
session, context, risk, DLP, policy, permission and usage limits all pass — on
the backend.
Success definition: the owner runs ONE command on a plain
Windows/macOS/Linux laptop with only Python installed, opens the app,
and every screen and button works against a real database with real security
behaviour, verified by tests whose output you show.

1. OPERATING RULES (READ TWICE)
   R1. Autonomy. Never ask questions. When ambiguous, choose the
   safest reasonable option, log it in docs/decisions.md (date, question,
   choice, reason), continue.
   R2. Never stop early. Do not stop after planning, skeleton, models, UI or
   API. Continue milestone by milestone (section 12) until the Completion
   Gate (section 16) is met.
   R3. Memory across resets. First action: save this whole prompt to
    docs/MASTER_PROMPT.md . Keep PROGRESS.md (current milestone, done,
   failing, next step, last command run + result). After any context reset, re-
   read both and resume.
   R4. Whole layers. Deliver complete units (all models of a milestone, a
   complete service, complete routes). No "rest is similar", no ... , no stub
   bodies, no pass -only functions.
   R5. Verify after every milestone: install → migrate → lint → type-check
   → tests → boot app → hit the new routes. Read every error, find the root
   cause, fix, re-run. Never disable, skip, or weaken a security check or
   test to make something pass.
   R6. Never claim a feature works unless you ran it and a test proves it.
   Show real command output in the final report. Anything unverified is
   labelled UNVERIFIED with the reason.
   R7. Error-loop protocol. If the same error persists after 3 different fix
   attempts: stop patching, re-read the error and the code path from the
   start, write the hypothesis in docs/decisions.md , try the simplest
   correct alternative (e.g. a different library, a smaller design). Never loop
   silently, never delete the failing feature, never mark it done.
   R8. Git discipline. git init at start; commit after each milestone with
   message M<n>: <title> — tests green . Never commit .env , keys,
   the DB file, storage/ , or secureshare.db .
   R9. Dependency honesty. Do NOT rely on remembered version
   numbers. Install with pip, confirm they resolve on Python 3.12 on
   Windows + Linux (wheels available), run the tests, THEN pip freeze -
   style pin into requirements.txt (generated from pyproject.toml ). If a
   package has no Windows wheel, replace it with a pure-Python alternative
   or make it an optional adapter that reports PROVIDER_UNAVAILABLE .
   R10. No network at runtime for assets. Vendor htmx, Chart.js, Inter font
   and the Lucide icon sprite into app/static/vendor/ via
    scripts/fetch_vendor.py (pinned version + SHA-256 check,
   downloaded once and committed). If the download is impossible in the
   environment, write the fallback (system font stack, simple inline-SVG
   icons, table instead of chart) and record it in decisions.md ; the app
   must still run.

2. TRUTHFULNESS RULES (NO FAKE
RESULTS)
Forbidden in production code paths: mock/fake APIs, hardcoded analytics
or scores, static JSON standing in for a database, fake encryption, fake AI,
dead buttons, TODO-only features, "coming soon" UI, frontend-only
authorization, homemade crypto.
Every feature has exactly one status in docs/feature-matrix.md :
    ACTIVE — implemented and tested.
    PROTOTYPE — works but limited; labelled in UI and docs.
    PROVIDER_UNAVAILABLE — needs an external service not configured
    (ClamAV, IP reputation, SMS, Google/Microsoft OAuth, cloud KMS,
    Presidio, Tesseract). UI and API say so explicitly, control shown disabled
    with the reason. Never report "malware-free", "VPN detected", "Tor
    detected", "malicious IP" unless a configured provider returned it.
    PLANNED — not built, never shown as operational.
Demo data only via scripts/seed_demo.py , labelled "DEMO", created
through the real services. Every number, chart, badge, list in the UI reference
images is sample data: in the app each is read from the database. Never
hardcode "98/100", "248", "1,482", "John Doe", "DOC-775641", dates or
percentages. A test greps templates for these strings and fails if found.

3. TECHNOLOGY (PYTHON-FIRST)
Python 3.12+. No Node backend, no React/TypeScript/Vite/npm. Node is
optional (Tailwind CLI only); the committed compiled CSS must work without
it.
 Area              Choice
 Web/API           FastAPI, Uvicorn (Gunicorn+Uvicorn workers on Linux
                   prod), Starlette middleware
 Config/validation Pydantic v2, pydantic-settings
 DB                SQLAlchemy 2.x async, Alembic (batch mode for
                   SQLite), aiosqlite (LITE), asyncpg (FULL)
                   Jinja2 + HTMX (vendored) + small vanilla ES modules +
 Frontend          Chart.js (vendored) + hand-written CSS with design
                   tokens
 Passwords         argon2-cffi (Argon2id)
                    cryptography (AES-256-GCM, Ed25519, RSA-PSS,
 Crypto            ECDSA P-256, HKDF), hashlib (SHA-256, SHA3-256),
                   hmac, secrets
 MFA               pyotp, segno (QR), py_webauthn
 OAuth             Authlib (Google/Microsoft; disabled unless configured)
 Sessions/CSRF server-side
                   itsdangerous
                                sessions (DB, cache in StateStore),

 Jobs              TaskQueue interface: InlineThreadQueue (LITE) /
                   Celery+Redis (FULL)
 Rate limit        StateStore-backed limiter (in-memory LITE / Redis FULL,
                   atomic ops)
 Area               Choice
                  filetype (pure Python), zipfile safety checks. Not
 File checks     python-magic
 Parsing         PyMuPDF, pypdf, python-docx, openpyxl, python-pptx,
                 Pillow
 OCR / AV        pytesseract adapter / clamd adapter — optional,
                  PROVIDER_UNAVAILABLE if missing


 DLP/ML          regex+validator engine, numpy, scikit-learn
                 (IsolationForest, TF-IDF+LogReg)
 Search          PostgreSQL FTS (FULL) / SQLite FTS5 (LITE) behind one
                  SearchProvider interface

 HTTP/mail       httpx (SSRF-safe wrapper), aiosmtplib
 Logging/metrics structlog, prometheus-client
 Tests           pytest, pytest-asyncio, pytest-cov, hypothesis, httpx
                 AsyncClient, Playwright (Python) + axe-core, Locust
 Quality         Ruff, mypy, Bandit, pip-audit
Non-Python components (only where unavoidable): PostgreSQL, Redis,
Nginx/Caddy, MinIO/S3, ClamAV, Tesseract, Docker, and small browser JS
for WebAuthn, viewer interaction, Chart.js, clipboard, OTP inputs.

4. RUN MODES (must work on a plain
laptop in VS Code)
LITE mode (default, only Python + pip):
   DATABASE_URL=sqlite+aiosqlite:///./secureshare.db . Models stay
   PostgreSQL-compatible: no PG-only types (use Uuid , JSON , portable
   enums as strings with CHECK constraints). No SELECT … FOR UPDATE
   dependence: enforce counters and one-time use with atomic UPDATE …
   WHERE remaining > 0     and check rowcount, which works on both
    engines.
    No Redis → StateStore interface: InMemoryStateStore (single
    process, DEV) and RedisStateStore .
    No Celery → TaskQueue interface: InlineThreadQueue (thread pool
    inside the API process; same job table, status, retries, audit) and
     CeleryQueue . Same task functions for both.

    Local encrypted disk storage; LocalDevelopmentKeyProvider ; email →
    console + /dev/outbox page (DEV only); malware scanner =
     PROVIDER_UNAVAILABLE or DEV scanner, both clearly labelled in UI.

    One command: python -m scripts.run dev → checks Python
    version, runs doctor , creates .env from .env.example with freshly
    generated random secrets if missing, runs migrations, seeds
    roles/permissions, starts Uvicorn. No make needed. Also
     .vscode/launch.json , tasks.json , settings.json ,
     extensions.json for run/debug/test.

FULL mode ( APP_MODE=full , Docker Compose): PostgreSQL, Redis,
Celery worker + beat, MinIO, ClamAV, Nginx. Celery on Windows uses --
pool=solo or --pool=threads ; never prefork.

Windows/macOS rules: pathlib everywhere; UTF-8 everywhere; no
shell-only scripts; set the correct asyncio policy on Windows; no libmagic; all
subprocess calls list-form; handle \r\n ; SQLite path relative to project root,
not CWD.
Multi-device demo: python -m scripts.run demo starts Uvicorn on
 0.0.0.0:8000 , prints the LAN URL and a terminal QR (segno). Settings:
 ALLOWED_HOSTS , TRUSTED_ORIGINS , COOKIE_SECURE , PUBLIC_BASE_URL
(used in share links and QR codes). Wrong host → clear error page, never
blank. Honest HTTPS rule: WebAuthn and Secure cookies work only on
 localhost or HTTPS. Over plain HTTP the app auto-disables passkeys with
a visible "requires HTTPS" note and uses non-Secure cookies only when
 APP_ENV=dev . docs/demo-guide.md documents (a) free HTTPS tunnel
(Cloudflare Tunnel/ngrok) and (b) mkcert + uvicorn --ssl-keyfile/--
ssl-certfile .
5. ARCHITECTURE
Modular monolith + workers. No microservices.
 Browser -> Nginx -> FastAPI middleware (request-id, security
 headers, rate limit, CSRF)
   -> Authentication -> Authorization (RBAC) -> Zero-Trust PDP -
 > Services -> Repositories -> DB
 Files: Service -> StorageProvider -> AES-256-GCM ciphertext ->
 disk / MinIO
 Jobs : API -> TaskQueue -> worker -> scan / OCR / DLP /
 classify / index / notify
 Every sensitive step -> Audit service (hash-linked chain)


Rules: no business logic in route functions; routes call services; services call
repositories/providers; Protocol interfaces for storage, KMS, malware,
email, SMS, AI, network-intel, OCR, queue, state, search. Provider-specific
code lives only under app/integrations/ . Web (HTML) routes and API
routes call the same services.
5.1 Project structure (create this; add files only
when needed)
 secureshare/
 ├── PROGRESS.md README.md SECURITY.md CONTRIBUTING.md
 Makefile(optional)
 ├── pyproject.toml requirements.txt requirements-dev.txt
 alembic.ini
 ├── Dockerfile docker-compose.yml docker-compose.prod.yml
 ├── .env.example .gitignore .dockerignore
 ├── .vscode/ (launch.json tasks.json settings.json
 extensions.json)
 ├── .github/workflows/ci.yml
 ├── deploy/nginx/ (nginx.conf security-headers.conf)
 deploy/caddy/Caddyfile
 ├── alembic/ (env.py versions/)
 ├── app/
 │    ├── main.py lifespan.py
 │    ├── config/ (settings.py logging.py constants.py)
 │    ├── core/ (exceptions.py error_handlers.py responses.py
 dependencies.py enums.py utils.py)
│   ├── middleware/ (request_id security_headers rate_limit
csrf access_log host_guard)
│   ├── db/ (base.py session.py unit_of_work.py)
│   ├── models/ (user role permission auth device session
document document_version
│   │               document_metadata classification
processing_job encryption_key signature
│   │               secure_link link_policy recipient
access_policy access_request access_grant
│   │               access_attempt risk behaviour_profile
security_event security_alert audit
│   │               dlp_finding watermark_record notification
usage_metric system_setting
│   │               subscription download view_session folder tag
share_draft oauth_account
│   │               user_preference)
│   ├── schemas/ repositories/
│   ├── services/ (auth identity mfa devices sessions
documents secure_links access_control
│   │                 policy_engine zero_trust risk dlp watermark
viewer audit alerts
│   │                 notifications analytics security_score
attack_simulator policy_simulator
│   │                 quotas admin search folders)
│   ├── crypto/ (aead envelope hashing signatures tokens
password)
│   ├── integrations/ (storage kms malware email sms ocr ai
queue state network_intel search oauth)
│   ├── ml/ (anomaly_detector baseline features classifier
pii_ner)
│   ├── security/ (validators path_security archive_safety
threat_detection)
│   ├── workers/ (celery_app.py tasks/)
│   ├── api/ (router.py v1/…)
│   ├── web/ (public.py user.py admin.py share_flow.py dev.py)
│   ├── templates/ (layouts/ components/ public/ auth/
dashboard/ documents/ sharing/ viewer/
│   │                 security/ analytics/ notifications/ admin/
errors/ emails/ dev/)
│   └── static/ (css/ js/ vendor/ fonts/ icons/ img/
manifest.webmanifest service-worker.js)
├── storage/ (gitignored, never webserved: encrypted/
quarantine/ temporary/ processed/)
├── scripts/ (run.py doctor.py smoke.py create_admin.py
 seed_roles.py seed_demo.py reset_demo.py
 │                 rotate_keys.py backup_keys.py restore_keys.py
 verify_audit.py fetch_vendor.py)
 ├── tests/ (unit integration api security crypto workers e2e
 performance conftest.py)
 └── docs/ (MASTER_PROMPT.md repository-audit.md decisions.md
 architecture.md technology-stack.md
               security.md cryptography.md key-management.md
 authentication.md zero-trust.md ai-risk.md
               dlp.md api.md database.md deployment.md threat-
 model.md backup-recovery.md
               feature-matrix.md technology-coverage.md
 traceability.md troubleshooting.md
               ui-spec.md demo-guide.md screenshots/)


If the repository already contains work, FIRST audit it → docs/repository-
audit.md (architecture, working/broken features, vulnerabilities, hardcoded
secrets, dead code, missing validation/authz, unsafe file handling, insecure
logging, test gaps, refactor plan). Reuse what is correct. If empty, record that
and proceed.

6. DOMAIN REQUIREMENTS
6.1 Authentication & sessions
Registration (full name, email, optional phone, password with strength
meter), login, logout, email verification (6-digit OTP or token link), password
reset/change, Argon2id, strong password policy (length ≥ 12, breached-
pattern/common-password list), failed-login tracking with escalating lockout,
login history, email OTP, TOTP, hashed single-use backup codes, passkeys
(py_webauthn), step-up auth, risk-triggered MFA, device registration + new-
device detection, session list + revoke, idle + absolute timeouts, re-auth for
sensitive actions, Google/Microsoft login via Authlib (disabled with reason
when not configured).
Sessions: opaque random ID in HttpOnly, SameSite=Lax cookie ( Secure +
 __Host- prefix in production); only a hash stored server-side; rotate on login
and privilege change; bound to device record; server-side revocation. CSRF
token on every unsafe cookie-authenticated request, including HTMX (send
via hx-headers from a meta tag set by csrf.js ). Never store plaintext
passwords/OTPs/tokens, never log secrets, never return hashes. Login
errors must not reveal whether an email exists; response timing must be
equalised.
6.2 RBAC + ABAC
Roles ADMIN, MANAGER, USER (tables roles, permissions, user_roles,
role_permissions). Permissions:
DOCUMENT_VIEW/DOWNLOAD/UPLOAD/EDIT/DELETE/SHARE/RESHARE/REVO
USER_MANAGE, AUDIT_VIEW, SECURITY_VIEW, ANALYTICS_VIEW,
POLICY_MANAGE, SYSTEM_MANAGE. Per-document grants: VIEW,
DOWNLOAD, PRINT, COPY, EDIT, RESHARE, COMMENT, SIGN, DELETE.
ABAC attributes: user (role, department, status, MFA, trust), document
(owner, classification, sensitivity, department), request (time, IP context,
device, risk, action). Object-level ownership/grant check on every
document/link/share/version/notification endpoint (prevent IDOR; return
404 not 403 for objects the user cannot know exist). Admin routes:
authentication + role + permission + audit.
6.3 Document pipeline
 Upload -> authn/authz -> size limit -> extension -> MIME ->
 magic bytes -> filename normalise
  -> random internal name -> quarantine -> OOXML/zip bomb check
 -> malware scan (job)
  -> SHA-256 + SHA3-256 -> text extraction/OCR (job) -> DLP
 (job) -> classification (job)
  -> sign -> generate DEK -> AES-256-GCM encrypt -> wrap DEK ->
 store ciphertext -> metadata -> audit


Types (configurable in settings, UI reads them): PDF, DOCX, XLSX, PPTX,
TXT, CSV, PNG, JPG/JPEG; max size from settings. Never trust client
filename/MIME; never use user input in a path; storage outside any web root;
temp files in secure temp dirs removed in finally . Stream uploads to disk
in chunks; enforce size while streaming. Lifecycle (each audited):
UPLOADED, VALIDATED, QUARANTINED, SCANNING, ANALYZED,
CLASSIFIED, DLP_DONE, SIGNED, ENCRYPTED, STORED, SHARED,
ARCHIVED, EXPIRED, REVOKED, DELETED. Versioning: number, created_by,
hashes, encryption metadata, change summary, compare (metadata + text
diff), restore, never silent deletion. Malware: MalwareScanner interface;
LocalDevelopmentMalwareScanner (EICAR/blocklist, labelled DEV) and
ClamAVScanner ; when not configured status is PROVIDER_UNAVAILABLE and
a setting decides hold vs allow-with-warning (default: allow with visible
warning in LITE, hold in production).
6.4 Encryption & keys
Envelope encryption: random 256-bit DEK per document version → AES-
256-GCM → DEK wrapped by KEK from KeyProvider . Store wrapped DEK,
key ref, key version, algorithm, nonce prefix. Never store raw DEK/KEK in DB.
Chunked streaming: 1 MiB chunks, 96-bit nonce = 64-bit random prefix + 32-
bit counter, AAD = document_id | version | key_version | chunk_index
| final_flag (reordering/truncation/tamper fails). Never load large files
fully into memory. HKDF derives sub-keys (audit key, token key, CSRF key)
from a master secret. KeyProviders: LocalDevelopmentKeyProvider
(env/keyfile, DEV) + adapters for AWS KMS, Azure Key Vault, Vault, HSM
(adapters may be PROVIDER_UNAVAILABLE ). Key states GENERATED,
ACTIVE, ROTATING, EXPIRED, REVOKED, DESTROYED; rotation re-wraps
DEKs; every key event audited; encrypted KEK backup export (Argon2id +
AES-GCM, passphrase) with restore script and test. Do not claim
cryptographic erasure unless the DEK is really destroyed with no copies;
document exactly what deletion guarantees. Decrypt only after the PDP
returns ALLOW or RESTRICT for that exact action.
6.5 Signatures & integrity
Ed25519 default; RSA-PSS and ECDSA P-256 supported. Sign SHA-256 of
plaintext at upload; store signature, algorithm, public-key ref, signer,
timestamp. On view/verify: decrypt in memory, recompute hash, verify
signature, compare stored SHA-256 and SHA3-256. Modified document or
tampered ciphertext fails with a clear reason. Do not claim legal validity.
6.6 Secure links
/share/{opaque_token} , token = secrets.token_urlsafe(32) ; store
only SHA-256/HMAC of token; constant-time compare; URL reveals nothing;
full link shown only at creation, later a masked prefix + Rotate. Options:
recipient binding, link password (Argon2id), MFA requirement, device
binding, start/expiry, max views, max downloads, one-time view/download,
revoke, rotate, QR, self-destruct, usage counter, reputation (NORMAL /
SUSPICIOUS / ABUSED computed from access frequency, failed
verifications, unique devices/IPs, denied requests, time anomalies). Binding
modes: Email; Email+OTP; Email+Phone(OTP); Email+Device;
Email+Passkey; Email+OTP+Device; Email+Phone+Passkey (phone/SMS
modes PROVIDER_UNAVAILABLE unless an SMS provider is configured).
Create share + recipient + policy + link + audit in one transaction. Wizard
draft state lives server-side in share_drafts (auto-expiring); final submit is
idempotent (idempotency key).
6.7 Zero-Trust Policy Decision Point
One pure, deterministic evaluate(context) -> Decision used by
production access, the policy simulator and the attack simulator (no
separate simulation logic). Inputs: identity, auth level, email verified,
MFA/passkey state, recipient-binding result, device trust, session status,
IP/network state ( UNKNOWN / PROVIDER_UNAVAILABLE without a provider),
time window, document sensitivity, DLP level, requested permission, risk
score/level, link status/reputation, policy status/version, usage counters,
expiry, revocation. Pipeline: authenticate → identify document/action →
ownership → RBAC → ABAC → document policy → share policy → expiry →
revocation → device → MFA → usage limits → risk → DLP → decide. Output:
 decision (ALLOW|DENY|VERIFY|RESTRICT) , policy_id , policy_version ,
 reasons[] , required_actions[] , risk_score , dlp_level ,
 restrictions{} , correlation_id . Precedence DENY > VERIFY >
RESTRICT > ALLOW; default DENY. Risk/AI produce signals only and never
override the PDP. Policy snapshots are versioned, hashed, optionally signed;
changes audited. DLP mapping: HIGH/CRITICAL → require MFA + recipient
verification, watermark ON, download off by default, print/copy/reshare
denied, higher audit severity, alert. Continuous zero-trust: the viewer re-
evaluates on a timer and on events (session revoked, risk changed, policy
changed, link revoked) and stops delivering pages when the decision is no
longer ALLOW/RESTRICT. User-facing denial messages give reason +
required action without leaking internals.
6.8 Risk, behaviour, DLP, intelligence
   Risk engine: deterministic weighted rules over recorded signals (new
   device, failed logins/OTPs, unusual hour vs baseline, rapid downloads,
   repeated denials, IP diversity, link reputation, sensitivity, DLP level, session
   age) → score 0–100, level LOW/MEDIUM/HIGH/CRITICAL, reasons[]
   each referencing stored event IDs. IsolationForest = optional labelled
   "signal". LLM (optional) may only summarise stored evidence.
   Behaviour engine: per-user baseline (hours, devices, networks,
   download volume) in behaviour_profiles , updated by a job; statistical
   z-score/EWMA detector.
   DLP: regex+validator engine: emails, phones, government IDs
   (configurable country patterns; Aadhaar-like with Verhoeff checksum,
   PAN-like pattern), bank accounts, credit cards (Luhn), confidential labels,
   sensitive keywords. Levels NONE/LOW/MEDIUM/HIGH/CRITICAL. Store
   findings with location and masked sample only. Presidio/NER/cloud DLP
   via provider interface → PROVIDER_UNAVAILABLE when absent.
   Intelligence (four separate services): analysis/extraction/OCR, security
   classification (rules + TF-IDF/LogReg with model provenance label), user
   search (FTS), AI assistance (rule-based default).
   Network/device signals: interfaces for IP reputation, geo,
   VPN/proxy/Tor, impossible-travel (haversine, needs geo provider).
   Without provider return UNKNOWN / PROVIDER_UNAVAILABLE ; never
   fabricate.
6.9 Protected viewer & watermark
Server renders authorised content and delivers watermarked page
images/text (PyMuPDF for PDF, Pillow for images, converted output for
Office where feasible; if an Office/CSV type cannot be rendered, show
extracted text view labelled PROTOTYPE). Browser never receives keys,
storage paths, or the decrypted original unless download is allowed by
policy. Watermark text from real recipient, session ID, document ID,
timestamp, classification. Page navigation, zoom, fullscreen, thumbnails, in-
document search (only if COPY/text allowed), security/integrity/signature
status panel, screenshot warning banner, view-only mode, periodic recheck,
stop on revocation. Copy/print enforced server-side (no raw download, no
text layer when COPY denied), reinforced by CSS/JS; UI states honestly that
screenshots cannot be prevented, only deterred, watermarked and audited.
Controlled download re-authorises, decrypts as a stream, applies watermark
if policy demands, counts atomically, audits.
6.10 Audit, alerts, analytics, score, simulators
   Audit chain: hash_n = SHA3-256(hash_{n-1} ||
   canonical_json(event_n)) , per-chain sequence, optional HMAC seal
   with separate audit key (HKDF), daily Merkle root stored.
    verify_chain() on demand and scheduled; tampering raises a
   CRITICAL alert. INSERT-only DB role in FULL mode; in LITE, enforce
   append-only at the repository layer and verify via chain. Audit everything
   security-relevant (registration, login/fail, logout, MFA, OTP fail, upload,
   access, download, share, permission change, revocation, device/session,
   risk, DLP, policy decisions, key events, signatures, link events, admin
   actions).
   Alerts: failed logins/OTPs, new device, download spikes, high risk, link
   abuse, DLP, policy violation, audit-chain failure; severity, read/unread,
   acknowledge, evidence, actor, target, timestamp; SSE live feed with
   polling fallback.
   Analytics: SQL aggregates only; every metric returns current ,
    previous_period , delta_percent .

   Security score: per document and per account from real controls
   (encryption, key protection, integrity, signature, recipient binding,
   MFA/passkey, device verification, expiry, risk controls, DLP, watermark,
   audit, restrictions); returns score, status label, per-control weight/state,
   weak controls, recommendations, source data per factor.
   Policy simulator: what-if scenarios through the SAME evaluate() ;
   writes nothing to production counters.
   Attack simulator (admin only): runs against the real implementation in
   an isolated test document/tenant; shows TEST / EXPECTED / ACTUAL /
   PASS-FAIL / SECURITY EVENT for: invalid & expired token, wrong &
   repeated OTP, unauthorised recipient, modified document, invalid
   signature, revoked link, excessive downloads, unknown device, high-risk
   session, permission violation, direct encrypted-file access, path traversal,
   malicious upload, tampered ciphertext, tampered metadata.
7. UI / UX (TWO REFERENCE IMAGES =
VISUAL SOURCE OF TRUTH)
7.0 Rules
1. Recreate layout, hierarchy, colour, spacing, rounding, glow, iconography.
   Do not paste the images, use them as backgrounds, or copy illustrations
   pixel-for-pixel. All illustrations (shield, cloud, documents, leaves,
   mountains, QR frame) are original inline SVG/CSS.
2. All sample data is replaced by real DB data (section 2).
3. Every button does a real thing. Missing provider ⇒ disabled + reason +
    PROVIDER_UNAVAILABLE .

4. Stack: Jinja2 + HTMX + vanilla JS + vendored Chart.js. Fonts self-hosted
   (Inter, OFL). Icons: vendored Lucide sprite (ISC) or original SVG. CSP has
   no inline script and no third-party hosts: configure htmx with
    includeIndicatorStyles=false , put no inline <script> / onclick , use
    data-* attributes + external ES modules; inline style="" attributes
   allowed only via CSP style-src 'self' + hashed/nonce'd <style>
   where unavoidable (prefer CSS classes; the gauge dash offset uses a
   CSS custom property set through a nonce'd style or a data attribute read
   by JS).
5. Frame 4 in image 1 is titled "Email Verification" but shows a dashboard →
   treat it as the Dashboard; build Email Verification with the OTP design of
   frame 10 / mobile "Identity Verification".
6. Themes: auth, splash, public link and viewer = dark navy ( layout-dark );
   dashboards, lists, forms = light ( layout-light ); plus user dark-mode
   setting for the app shell.
7.1 Tokens (     tokens.css   ; tune after visual comparison)
 :root{
  --navy-950:#050E2B; --navy-900:#0A1740; --navy-800:#0F2260; -
 -navy-700:#16308A;
  --primary:#1F6BFF; --primary-dark:#1449C7; --accent:#12C8E8;
 --accent-2:#7C5CFF;
     --success:#12B981; --warning:#F5A524; --danger:#EF4444;
     --background:#F3F7FE; --surface:#FFFFFF; --surface-
 secondary:#EAF1FD;
     --text-primary:#0E1A3D; --text-secondary:#5B6B8C; --
 border:#DCE6F6;
     --grad-brand:linear-gradient(90deg,#1F6BFF 0%,#12C8E8 100%);
     --grad-hero-text:linear-gradient(90deg,#12C8E8,#1F6BFF);
     --grad-dark:linear-gradient(160deg,#050E2B 0%,#0F2260
 60%,#16308A 100%);
     --radius-sm:10px; --radius-md:16px; --radius-lg:24px;
     --shadow:0 8px 30px rgba(20,60,160,.12); --glow:0 0 24px
 rgba(18,200,232,.35);
 }


Add dark-mode overrides. Primary buttons = brand gradient, 12px/pill radius,
white text, glow on hover/focus. Cards white, 16–20px radius, 1px border,
soft shadow. Glass blur only on dark hero cards. Success green, warning
amber, risk red, AI purple. Inter; H1 clamp(2rem,4vw,3.25rem) 700 with
gradient keyword. Breakpoints 360 / 768 / 1024 / 1440.
7.2 Layouts
     Desktop ≥1024: left sidebar 240px (shield logo + "SecureShare", tagline
     "Share • Protect • Stay Secure"; Home, Documents, Sharing, Analytics,
     Security, Settings; active = blue gradient pill; bottom card "Your Data.
     Your Control."), top header 72px (global search "Search documents,
     users, or anything...", notification bell with unread badge, avatar + "Hello,
     {name}" + role), content max 1280px, 24px gaps.
     Tablet 768–1023: collapsible icon-only sidebar.
     Mobile <768: no sidebar; header (logo, bell, avatar); bottom nav (Home,
     Documents, Analytics, Profile; admin gets Admin); floating "+" on
     Documents; tables → stacked cards; modals → bottom sheets; viewer
     full-screen with bottom actions (Download, Share, Fullscreen). Tap
     targets ≥ 44px; no horizontal scroll at 360px.
     Admin shell: Admin Dashboard, User Management, Access Control,
     Device Management, Reports, Threat Detection, Settings.
     Public/auth (dark): centred card or split hero with shield illustration,
     leaf/mountain art, glowing cyan edge.
7.3 Shared components (Jinja macros in
               , styled only in
templates/components/                  )        components.css

Button (primary/secondary/ghost/danger/icon), Input (leading icon,
password reveal, error text), Select, Toggle, Checkbox, TagChip(+Add tags),
Stepper(4), UploadZone, ProgressBar, MetricCard (label, number, green/red
delta), DocumentCard/Row (PDF red, DOCX blue, XLSX green, ZIP orange;
name, size, relative time, ⋯ menu), StatusBadge, RiskBadge, ScoreGauge
(SVG ring, server-computed offset), OTPInput (6 boxes),
VerificationChecklist, ShareChannelButton, QRCard, Timeline/ActivityItem,
NotificationItem, AuditEvent, Table+Pagination, Modal/BottomSheet, Toast,
EmptyState, LoadingSkeleton, ErrorState (with request ID),
PermissionDenied (reason + required action), Tabs, FAB, BottomNav,
Sidebar, TopBar. Build tokens + components first; no page-level
duplicated styling.
Every sensitive page has loading, empty, error, permission-denied, security-
state and success states. Accessibility: semantic HTML, keyboard
navigation, focus rings, ARIA, AA contrast, prefers-reduced-motion ,
accessible errors.
7.4 Screen inventory (20 desktop frames +
mobile)
 #      Screen             Route                            Layout     Must show
                                                                       from DB)
 1      Landing            /                                dark/light Logo, nav,
                                                            hero       Document
                                                                       a Smarter
                                                                       (gradient k
                                                                       subtext, Ge
                                                                       Free, Watc
                                                                       (opens rea
                                                                       guide page
                                                                       walkthroug
                                                                       illustration
                                                                       strip: End-
#   Screen           Route       Layout     Must show
                                            from DB)
                                            Encryption
                                            Detection,
                                            Access, Se
                                            Sharing, D
                                            Protection
                                            Monitoring
                                            Full Name,
                                            Phone, Pas
                                            (+strength
                                            Create Acc
                                 light form "Already ha
2   Create Account   /register   + steps account? L
                                 rail       Secure Reg
                                            Email Verifi
                                            Phone Ver
                                            MFA Setup
                                            reflects rea
                                            Welcome B
                                            Password,
                                            password?
3   Login            /login      dark split continue
                                            + Microsof
                                                      w
                                            (disabled+
                                            unconfigur
                                            account lin
#    Screen          Route            Layout       Must show
                                                   from DB)
                                                   Time-base
                                                   "Good mor
                                                   {name}!"; M
                                                   Total Docu
                                                   Active Link
4    Dashboard       /dashboard       app shell    Download
                                                   Score with
                                                   vs previou
                                                   Document
                                                   line chart (
                                                   Recent Ac
                                                   6-box OTP
4b Email
   Verification      /verify-email    dark/light   link result,
                                                   30–60 s co
                                                   success st
                                                   "Welcome
                                                   Secure Wo
                                                   action card
                                                   Document
                                                   Now, Gene
                                                   Link→Crea
5    Home/Overview   /home            app shell    View Analy
                                                   Reports, A
                                                   Intelligence
                                                   Quick Actio
                                                   Upload, Ne
                                                   Secure Lin
                                                   AI Insights
6    Share wizard    /shares/create   app shell    Stepper 1 U
                                                   Security Se
                                                   Recipient
                                                   Generate L
                                                   dropzone "
                                                   drop your fi
                                                   Choose Fil
#   Screen           Route               Layout    Must show
                                                   from DB)
                                                   Supports …
                                                   (types+siz
                                                   settings); t
                                                   Password
                                                   Link Expiry
                                                   Views, Allo
                                                   Download
                                                   Access, Re
                                                   Verification
                                                   Next/Back
                                                   File details
                                                   size, progr
                                                   Document
                                                   Category,
                                                   AI Analysis
7   Upload                               app shell panel:  Clas
    (detailed)       /documents/upload
                                                   Sensitive D
                                                   Detection
                                                   Malware S
                                                   / Scanning
                                                   unavailable
                                                   Quarantine
                                                   Success b
                                                   Copy, QR,
                                                   buttons (W
                                                   Telegram,
8   Link Generated   /shares/{id}        app shell Link, QR C
                                                   Details (ex
                                                   downloads
                                                   views, stat
                                                   Rotate Link
9   Public link      /share/{token}      dark      Shield art,
    (protected)                                    protected.
                                                   verify to ac
                                                   document
                                                   field, Conti
#    Screen         Route                    Layout    Must show
                                                       from DB)
                                                       badges Se
                                                       Encrypted
                                                       6-box OTP
                                                       email, Verif
                                                       checklist E
10   Identity                                light     Verified / O
     Verification   /verify-identity
                                                       / Device V
                                                       Risk Check
                                                       counter, lo
                                                       message
                                                       Toolbar: fil
                                                       zoom %, s
                                                       controls, D
                                                       (only if pol
                                                       else disabl
                                                       reason); le
                                             dark      thumbnails
11   Protected      /viewer/{token}   and    toolbar + page  with
                                                       watermark
     Viewer         /documents/{id}/viewer   light     Document
                                             panel     Classificat
                                                       Uploaded
                                                       Uploaded
                                                       Document
                                                       Watermark
                                                       integrity/si
                                                       status
12   Analytics      /analytics               app shell Range sele
                                                       days …); M
                                                       Total Docu
                                                       Total Acce
                                                       Download
                                                       Events; Ac
                                                       Trends line
                                                       Document
                                                       donut with
#    Screen           Route               Layout    Must show
                                                    from DB)
                                                    %; <detai
                                                    table fallba
                                                    Total Users
                                                    Users, Sec
13   Admin Panel                          admin     Incidents;
                      /admin
                                          shell     Users table
                                                    name, ema
                                                    Manage U
     User Dashboard                                 Greeting, c
14   (mobile)         /dashboard   <768   mobile metrics, Re
                                                    bottom na
                                                    Icon+type
                                                    (Documen
                                                    with you, L
15   Notifications    /notifications      app shell accessed,
                                                    login, Thre
                                                    Document
                                                    completed
                                                    time, Mark
                                                    Gauge "{sc
                                                    {label}" fro
                                                    calculation
                                                    rows Encry
                                                    Access Co
16   Security Score   /security/score     app shell Malware P
                                                    DLP, Audit
                                                    Monitoring
                                                    Active/Inac
                                                    weight; we
                                                    + recomm
                                                    Gauge, co
17   Mobile           all                 mobile (Documen
     responsive                                     Download
                                                    Events), bo
 #        Screen            Route                                 Must show
                                                             Layout
                                                                  from DB)
                                                                  Version list
 18       Versions &         /documents/{id}/versions ,
                                                        app shell date, "Late
          Compare            /compare                             Compare V
                                                                  View Chan
                                                                  "Your Docu
 19– Final landing /                                              Safer. Sma
                             / bottom                   dark      Started; ba
 20 CTA                                                           Secure · F
                                                                  Reliable
Mobile-only (image 2): Splash /welcome ("Your Documents. Your Control.",
page dots, Get Started; shown once per first mobile visit, remembered by
cookie, skippable); My Documents /documents (search, chips All · Recent ·
Shared · Personal, DocumentRows with ⋯, FAB "+"); Upload, Link
Generation, Analytics, Notifications, Security Score, Version Compare, Admin
as single-column versions of the rows above; Document Details
 /documents/{id} (tabs Overview / Activity (real access log) / Permissions
(grants, expiry); actions Share Link, Download, More Options: rename, move
to folder, version history, revoke all links, delete); public link + identity
verification + recipient viewer in dark mobile theme.
7.5 Interaction details
     OTP boxes: auto-advance, backspace goes back, paste splits 6 digits,
     inputmode="numeric" , autocomplete="one-time-code" , server-driven
     attempts counter and lockout, resend cooldown 30–60 s.
     Wizard: state on server; refresh keeps progress; final submit idempotent.
     Copy: Clipboard API with fallback; toast "Link copied".
     Charts: Chart.js, gradient fill, rounded points, tooltips, responsive,
     accessible table fallback; SVG gauge.
     Toggles: HTMX with optimistic UI + rollback on error.
     Search: debounced /api/v1/search , grouped results (documents;
     users for admins); / focuses it.
   Loading: skeletons, never blank. Errors: ErrorState with request ID.
   Denied: PermissionDenied card with reason + required action.
   Motion: subtle fade/slide, glow on focus; honour reduced-motion.
   PWA: manifest + service worker that caches only the static shell and
   never documents, API data or authenticated HTML.
7.6 Backend additions the UI requires
folders    (+ documents.folder_id ), tags / document_tags ,
documents.doc_type      , documents.category , share_drafts , users.phone
(+verification status), oauth_accounts , user_preferences (theme,
onboarding seen, notification settings). Analytics helpers return current +
previous + % delta. Endpoints: GET /api/v1/dashboard ,
 /analytics/summary?range= , /documents?
filter=all|recent|shared|personal&q= , /notifications (+ mark-all-
read), /security-score , /documents/{id}/versions/compare .
Notification types generated by real events: SHARED_WITH_YOU,
LINK_ACCESSED, NEW_DEVICE_LOGIN, THREAT_DETECTED,
DOCUMENT_COMPLETED.

8. ROUTES (reconciled — declare static
paths before parametrised ones)
Route-order rule: /shares/create , /documents/upload ,
 /signatures/verify must be registered before /shares/{id} ,
 /documents/{id} , /signatures/{id} . A test asserts no static path is
shadowed.
Public: / /welcome /login /register /forgot-password /reset-
password /verify-email /verify-identity /mfa /passkey
/share/{token} /viewer/{token} /verify /security /about /privacy
/terms (+ /dev/outbox DEV only).
User: /home /dashboard /documents /documents/upload
/documents/{id} /documents/{id}/viewer /versions /compare
/analysis /security /share /shares /shares/create /shares/{id}
/shared-with-me /access-requests /signatures /signatures/verify
/search /notifications /security/devices /security/sessions
/security/activity /security/audit /security/risk /security/score
/security/alerts /analytics /profile /settings/security
/settings/privacy /settings/account .
Admin (server-enforced): /admin /admin/users /admin/users/{id}
/admin/roles /admin/permissions /admin/documents /admin/links
/admin/access /admin/policies /admin/security /admin/security-
events /admin/risk /admin/dlp /admin/devices /admin/sessions
/admin/analytics /admin/usage /admin/audit /admin/attack-
simulator /admin/system-health /admin/configuration /admin/backup
/admin/reports    .
API: everything under /api/v1/ — auth, users, documents (+versions,
analysis, security, share), links, share/{token}, access, policies, recipients,
devices, sessions, risk, dlp, audit, alerts, analytics, security-score, simulator,
notifications, search, signatures, health, dashboard, admin, /metrics
(admin/internal only). All list endpoints: pagination, filtering, sorting, search.
One error envelope {"error":{"code","message","request_id"}} , no
stack traces/paths/secrets. HTML routes render the
ErrorState/PermissionDenied templates instead.

9. SECURITY BASELINE (apply
everywhere)
Parameterised ORM queries; strict Pydantic validation; Jinja autoescape ON;
strict CSP (no inline script, no third-party hosts); HSTS (prod), frame denial,
nosniff, referrer policy, permissions policy; CSRF on cookie-authenticated
unsafe requests; allow-listed redirects ( next= only to internal paths); SSRF-
safe outbound HTTP (block private/loopback/link-local, redirects re-
validated); rate limits on login, register, reset, OTP send/verify, passkey
challenge, link verification, download, admin actions; atomic counters;
request IDs + structured logs without secrets; startup fails in production if
secrets/keys are missing, default, or weak (dev auto-generates); separate
public / authenticated / recipient / admin / internal-worker boundaries; job
payloads validated and secret-free; least-privilege DB roles (FULL); honest
deletion semantics; backup/recovery documented (DB, ciphertext, key
backup, restore order); Host-header validation via ALLOWED_HOSTS .
10. TECHNOLOGY COVERAGE MATRIX
(all rows implemented with an
established library and ≥1 test; mark
honestly if a provider is missing)
Create docs/technology-coverage.md with columns: Technology | Purpose
| Module path | Table(s) | API/UI entry | Test file | Status.
1 SHA-256 · 2 SHA3-256 · 3 HMAC-SHA256 · 4 AES-256-GCM (chunked
streaming) · 5 Envelope KEK/DEK · 6 HKDF · 7 Key rotation + lifecycle
states · 8 Encrypted key backup (Argon2id + AES-GCM) · 9 Argon2id · 10
Ed25519 · 11 RSA-PSS · 12 ECDSA P-256 · 13 Signature verify + tamper
detection · 14 Secure random tokens · 15 Constant-time compare · 16 TOTP
· 17 Backup codes · 18 Email OTP · 19 SMS OTP interface · 20
Passkeys/WebAuthn · 21 Server sessions + rotation · 22 CSRF · 23 Security
headers + CSP · 24 Rate limiting · 25 Lockout/brute-force · 26 RBAC · 27
ABAC · 28 Zero-Trust PDP · 29 Continuous re-evaluation · 30 Policy
versioning + hash + signature · 31 Explainable risk scoring · 32 Statistical
anomaly detection · 33 IsolationForest signal · 34 Behaviour baseline · 35
Impossible travel · 36 Device fingerprint + trust · 37 Link reputation · 38
Recipient binding (7 modes) · 39 Opaque links + QR · 40 Atomic usage
limits · 41 Upload validation · 42 Path traversal/symlink guard · 43
Zip/OOXML bomb guard · 44 Quarantine + malware interface · 45 Text
extraction · 46 OCR adapter · 47 Classification (rules + TF-IDF/LogReg) ·
48 DLP (Luhn, Verhoeff, PAN, bank) · 49 PII/NER interface · 50 Full-text
search · 51 Semantic search (optional, off) · 52 Dynamic watermark · 53
Server-rendered viewer · 54 Controlled download · 55 Hash-linked audit
chain · 56 Chain verification + Merkle root · 57 Alerts + SSE · 58 SQL
analytics · 59 Security score · 60 Policy simulator · 61 Attack simulator · 62
Background jobs with status/retries · 63 Structured logging + request IDs ·
64 Prometheus metrics · 65 PWA shell (no private caching) · 66
Quotas/subscriptions · 67 Backup/recovery scripts · 68 CI pipeline.
11. PRIORITY TIERS (build P0 fully before
P1, P1 before P2 — prevents half-built
breadth)
   P0 (core, must be ACTIVE): settings, DB+migrations,
   auth+sessions+CSRF+rate-limit, RBAC, crypto layer, upload pipeline,
   encrypted storage, signatures, DLP, secure links, PDP, recipient OTP
   verification, protected viewer with watermark, revocation, audit chain,
   dashboard, security score, base UI.
   P1: TOTP/backup codes/passkeys, device trust, risk+behaviour engines,
   alerts+SSE, analytics, notifications, versions/compare, folders/tags,
   simulators, admin console, quotas, search.
   P2: OAuth, semantic search, optional adapters (KMS, Presidio, S3/MinIO,
   ClamAV, Tesseract), Prometheus, load tests, PWA polish, landing extras.
   Never leave a P0 item PARTIAL to start a P2 item.

12. BUILD MILESTONES (run all, in order,
no asking)
Strategy: walking skeleton first. M0–M4 produce one thin end-to-end
path (register → login → upload → encrypt → share link → recipient OTP →
watermarked view → audit) running on real code. Then widen. Each
milestone ends: implement → connect → test → fix → secure → document
→ update PROGRESS.md → git commit.
 M      Deliverable                                   Gate to pass
        Repo audit, scaffold, pyproject , settings
        (startup validation), logging,                python -m

 M0      scripts/run.py + doctor.py ,
                                                      scripts.run dev
                                                      boots a health page
         .env.example , .vscode , Dockerfile
        skeleton, fresh-venv pip install test         on a clean venv
 M1     All models + constraints + indexes, Alembic   upgrade head /
        (SQLite + PostgreSQL), seed                   downgrade base /
M      Deliverable                                       Gate to pass
       roles/permissions                                 upgrade head;
                                                         model-vs-migration
                                                         drift test
                                                         every component
M2     Design tokens + component macros + base           renders on a
       layouts + static vendoring + error pages          /dev/components
                                                         gallery (DEV only)
       Crypto layer: AEAD streaming, envelope,           tamper, truncation,
M3     KeyProvider, hashing, signatures, tokens,         reorder, wrong-key,
       password                                          wrong-AAD,
                                                         backup/restore tests
       Auth: register, verify-email, login, sessions,    auth negative tests;
M4     lockout, reset, CSRF, rate limit, audit hooks +   screens pass text
       auth screens (2, 3, 4b)                           check
       Storage + upload pipeline + validators +          malicious upload,
M5     quarantine + scanner interface + lifecycle +      traversal, bomb,
       TaskQueue (inline) + job tracking                 oversize tests
       DLP, extraction, classification, OCR adapter,     DLP validator tests
M6     search index                                      (Luhn/Verhoeff),
                                                         masked findings
M7  Access control: RBAC/ABAC, grants, access            IDOR + OTP brute-
    requests, recipient binding, OTP                     force tests
    PDP + secure links + redeem flow + atomic            expired/revoked/one-
M8 counters + reputation + share wizard (6, 8, 9,        time/limit tests via
    10)                                                  PDP
    Protected viewer + watermark + controlled            revoke-while-viewing
M9 download + view sessions + continuous re-             stops delivery
    evaluation (11)
    Audit chain + verify + alerts + notifications +      tampered chain
M10 analytics + security score +
    dashboard/home/analytics/score/notifications
                                                         detected; dashboard
                                                         changes with real
    screens (4, 5, 12, 15, 16)                           actions
 M   Deliverable                                          Gate to pass
     MFA (TOTP, backup, passkeys), devices, step-         risk reasons trace to
 M11 up, risk + behaviour engines, network-intel          event IDs
     interfaces
     Versions/compare, folders/tags, simulators,          all admin routes
 M12 admin console, quotas, usage, landing +              401/403 for non-
     mobile-only screens, PWA shell                       admins
     Full test suite: unit, integration, API, security,   coverage ≥ 80% on
 M13 e2e (Playwright), performance (Locust), lint,        security-critical
     mypy, Bandit, pip-audit, coverage                    modules
                                                          docker compose

 M14 Docker  Compose dev/prod, Nginx/Caddy, CI,
     celery adapters, FULL-mode verification
                                                          up --build
                                                          alembic upgrade
                                                                         +
                                                          head   on clean DB
         Demo: seed_demo.py , reset_demo.py ,             completion gate
 M15      run demo , demo guide, screenshots, docs,
                                                          below
         feature matrix, traceability, final report
If Docker is unavailable in the agent environment, mark M14 items
 UNVERIFIED (no Docker in this environment) — do not fake them.




13. ZERO-ERROR PROTOCOL (HONEST
VERSION)
Nobody can promise error-free code without running it, so prove it:
1. Fresh-venv install of requirements.txt on Python 3.12 succeeds (test
   on the OS available; note the other).
2. scripts/doctor.py : Python version, packages, .env weak/missing
   secrets, DB reachability, migration state, writable storage dirs, free port,
   optional providers; prints exact fix commands. run dev calls it first.
3. scripts/smoke.py : boots against a temp DB, logs in as seeded users,
   requests every page route and every list API; fails on any 500, template
   error, missing static file, or broken internal link.
4. Route audit test: every <a href> , form action, HTMX target and JS fetch
   URL in templates/static resolves to a real route; every admin route returns
   401/403 to non-admins; no static route is shadowed.
5. Template lint test: no inline <script> , no onclick= , no external hosts,
   no hardcoded sample numbers from the images.
6. Migrations: upgrade head on empty SQLite and PostgreSQL; downgrade
   base then upgrade head ; drift test.

7. Fresh-clone check in CI: clone → install → migrate → seed → smoke →
   pytest.
8. Final report contains real command output.
Known pitfalls to pre-empt (check each explicitly):
   Async SQLAlchemy: no lazy loading in templates (use
    selectinload /explicit queries); expire_on_commit=False ; don't share
   sessions across tasks.
   SQLite: enable PRAGMA foreign_keys=ON , WAL mode; Alembic
    render_as_batch=True ; no ALTER-column assumptions; timezone-
   aware datetimes stored as UTC.
   Inline job threads must open their own DB session and event loop; never
   reuse the request session.
   Uvicorn --reload on Windows spawns a subprocess: keep the
   InlineThreadQueue lifecycle in lifespan .
   Cookies: Secure cookies are dropped over plain HTTP; SameSite=Lax +
   share links opened from other sites must still work for the GET gate page
   (state-changing steps use POST + CSRF).
   HTMX + CSRF + CSP: verified with a Playwright test, not assumed.
   Large uploads: stream, don't read into memory; test with a file bigger
   than RAM-safe threshold using a generator.
   PyMuPDF/Pillow: cap pixel count and page count to prevent
   decompression/DoS; render with a timeout.
   Passkeys need a stable RP ID = hostname; document the effect of
   changing PUBLIC_BASE_URL .
   Never put secrets, tokens or full sensitive values in logs, URLs (other than
   the share token itself), audit payloads or exception messages.
14. TESTING REQUIREMENTS
Positive path, e2e (Playwright): register → verify → login → MFA → upload
→ scan → analyse → DLP → sign → encrypt → share link → recipient
verifies → PDP decision → watermarked viewer → audit.
Negative tests (all must pass): wrong user/recipient, wrong/expired OTP,
OTP brute force, expired link, revoked link, wrong/untrusted device,
high/critical risk, missing permission, IDOR (documents, links, versions,
notifications, sessions), direct storage access, path traversal, malicious
upload (wrong ext/MIME/magic, zip bomb, EICAR), modified ciphertext,
modified document, invalid signature, download limit exceeded (concurrent
requests race), revoked policy, non-admin calling admin API/routes,
tampered audit chain, CSRF missing/invalid, rate-limit exceeded, session
fixation, expired session, host-header attack.
UI acceptance: Playwright screenshots of every screen in section 7.4 at
390×844, 768×1024, 1440×900 saved to docs/screenshots/ and
compared with the reference frames (list residual differences in docs/ui-
spec.md ); text-check test per screen; data-check test (create doc → share
→ recipient access → dashboard/analytics/notifications/score/audit
change); no horizontal scroll at 360px; bottom nav visible <768px; tap
targets ≥ 44px; axe-core no critical violations, AA contrast; keyboard-only
pass on login, upload, wizard, viewer; disabled provider controls show
reason text.
Quality gates: ruff , mypy , bandit , pip-audit , pytest --cov (≥ 80% on
 crypto , services/policy_engine , services/auth ,
 services/secure_links , security , services/audit ).




15. DEMO & DOCUMENTATION
 scripts/seed_demo.py creates clearly labelled DEMO accounts (admin,
owner, recipient), harmless generated sample documents (including fake
sensitive-looking data for DLP demo), a ready share link, and sample
audit/alerts produced by real service calls. scripts/reset_demo.py resets.
 docs/demo-guide.md : 10-minute script — register → MFA → upload → DLP
result → sign+encrypt → share → recipient on phone opens link → OTP (dev
outbox) → policy decision → watermarked viewer → owner revokes →
viewer stops → audit chain verify → attack simulator → security score.
 docs/deployment.md : single small VPS with Docker Compose +
Caddy/Nginx + Let's Encrypt. Also complete docs/ui-spec.md (per screen:
route, layout regions, components, tokens extracted, exact API endpoints +
queries feeding each widget, states, mobile behaviour, "Not implemented" list
for any widget with no real data source), docs/feature-matrix.md ,
 docs/traceability.md (requirement → module → test).

For any widget in the reference images with no real data source: build the
real backend feature or omit it and list it under "Not implemented".

16. COMPLETION GATE (do not declare
done until ALL are true)
1. python -m scripts.run dev works on a clean machine with only
   Python installed; scripts/smoke.py passes.
2. Every row of the technology matrix is implemented and tested (or
   honestly PROVIDER_UNAVAILABLE ).
3. docker compose up --build starts api, worker, beat, postgres, redis,
   nginx (+ minio/clamav profiles) and alembic upgrade head succeeds
   on a clean DB — or is labelled UNVERIFIED with reason.
4. The full e2e flow (section 14) passes in Playwright.
5. All negative tests pass; ruff , mypy , bandit , pip-audit , pytest --
   cov pass.

6. grep -rEi
   "TODO|FIXME|NotImplemented|placeholder|mock|fake|dummy|coming
   soon"   — every real occurrence resolved (implemented, or converted to a
   labelled provider interface); demo-only strings live in seed_demo.py .
7. No hardcoded analytics/scores; no secrets in the repo; no broken
   imports/migrations; every button/route calls a real endpoint.
8. Every screen in section 7.4 exists, matches the reference within
   documented differences, and passes the UI acceptance checks.
9. docs/feature-matrix.md lists each feature with status, module, tables,
   API, UI, tests.
17. FINAL REPORT (only after the gate
passes)
Project status; architecture; stack; folder tree; DB entities; API inventory;
route inventory; security, encryption, key, auth, zero-trust, AI, DLP and audit
architecture; real test / e2e / security-test output; Docker status; setup;
external dependencies; known limitations; per-feature verification table
marked IMPLEMENTED / PARTIAL / BLOCKED / EXTERNAL DEPENDENCY
/ UNVERIFIED (never claim full completion if anything is partial); remaining
TODOs. Exact commands:
 # LITE (no Docker)
 python -m scripts.run dev                  # or: python -m scripts.run
 demo
 # FULL
 cp .env.example .env
 docker compose up --build
 docker compose exec api alembic upgrade head
 docker compose exec api python scripts/seed_roles.py
 docker compose exec api python scripts/create_admin.py
 docker compose exec api pytest -q




BEGIN NOW: save this prompt to docs/MASTER_PROMPT.md , create
PROGRESS.md , run the repository audit, and continue through M0 → M15
without asking for further instructions.
