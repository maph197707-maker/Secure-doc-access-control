# SECURITY

Run: `pip install -e .[dev]` then `python -m scripts.run dev`.
