"""Unit tests for worker task implementations."""
import pytest
from app.workers.tasks.alert_tasks import detect_threats
from app.workers.tasks.document_tasks import extract_text
from app.workers.tasks.notification_tasks import build as build_notification


def test_alert_task_detect_threats():
    events = [
        {"action": "LOGIN_FAILED", "user_id": "u1", "ip": "1.2.3.4", "at": "2026-10-02T12:00:00"},
        {"action": "LOGIN_FAILED", "user_id": "u1", "ip": "1.2.3.4", "at": "2026-10-02T12:01:00"},
        {"action": "LOGIN_FAILED", "user_id": "u1", "ip": "1.2.3.4", "at": "2026-10-02T12:02:00"},
        {"action": "LOGIN_FAILED", "user_id": "u1", "ip": "1.2.3.4", "at": "2026-10-02T12:03:00"},
        {"action": "LOGIN_FAILED", "user_id": "u1", "ip": "1.2.3.4", "at": "2026-10-02T12:04:00"},
        {"action": "LOGIN_FAILED", "user_id": "u1", "ip": "1.2.3.4", "at": "2026-10-02T12:05:00"},
    ]
    alerts = detect_threats(events)
    assert isinstance(alerts, list)


def test_document_task_extract_text():
    sample_text = b"Hello world SecureShare OCR test"
    res = extract_text(sample_text, "test.txt", "text/plain")
    assert isinstance(res, dict)
    assert res["status"] in ("COMPLETED", "SUCCESS", "EMPTY", "PROVIDER_UNAVAILABLE")
    if res["status"] in ("COMPLETED", "SUCCESS"):
        assert "Hello world" in res["text"]


def test_notification_task_build():
    payload = build_notification(
        user_id="u-123",
        type_="SECURITY",
        title="New Login Detected",
        message="A new device logged into your account.",
        resource_type="session",
        resource_id="s-999",
    )
    assert payload["user_id"] == "u-123"
    assert payload["title"] == "New Login Detected"
    assert payload["read"] is False

    with pytest.raises(ValueError):
        build_notification("u-123", "ALERT", "Leak", "Here is your OTP: 123456")
