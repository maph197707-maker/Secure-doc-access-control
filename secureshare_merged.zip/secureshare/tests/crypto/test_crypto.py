import io, os, unittest
from app.crypto import aead
from app.crypto.aead import IntegrityError, encrypt_bytes, decrypt_bytes, encrypt_stream, decrypt_stream
from app.crypto.envelope import (LocalDevelopmentKeyProvider, KeyError_, new_dek, open_dek, rewrap,
                                 export_backup, import_backup, provider_keks)
from app.crypto.hashing import sha256_hex, sha3_256_hex, hmac_sha256, constant_time_equal, hkdf, digests_of_file
from app.crypto.signatures import SigAlg, generate_keypair, sign, verify
from app.crypto.tokens import new_token, token_hash, verify_token, numeric_otp
from app.core.enums import KeyState

K = os.urandom(32)
KW = dict(doc_id="d1", version=1, key_version=1)


class AeadTests(unittest.TestCase):
    def test_roundtrip_multi_chunk_and_exact_multiple(self):
        for size in (0, 1, 15, 16, 17, 32, 48):
            data = os.urandom(size)
            blob = encrypt_bytes(K, data, chunk_size=16, **KW)
            self.assertEqual(decrypt_bytes(K, blob, chunk_size=16, **KW), data, size)

    def test_streaming_does_not_need_whole_file(self):
        data = os.urandom(5 * 1024 * 1024 + 3)
        out = io.BytesIO()
        n = encrypt_stream(K, io.BytesIO(data), out, **KW)
        self.assertEqual(n, len(data))
        out.seek(0)
        self.assertEqual(b"".join(decrypt_stream(K, out, **KW)), data)

    def _blob(self):
        return encrypt_bytes(K, b"A" * 48, chunk_size=16, **KW)

    def _records(self, blob):
        recs, pos = [], 12
        while pos < len(blob):
            n = int.from_bytes(blob[pos:pos + 4], "big"); recs.append(blob[pos:pos + 4 + n]); pos += 4 + n
        return blob[:12], recs

    def test_truncation_fails(self):
        head, recs = self._records(self._blob())
        with self.assertRaises(IntegrityError):
            decrypt_bytes(K, head + b"".join(recs[:-1]), chunk_size=16, **KW)

    def test_reorder_fails(self):
        head, recs = self._records(self._blob())
        with self.assertRaises(IntegrityError):
            decrypt_bytes(K, head + recs[1] + recs[0] + recs[2], chunk_size=16, **KW)

    def test_bitflip_wrong_key_wrong_aad_fail(self):
        blob = bytearray(self._blob()); blob[-1] ^= 1
        with self.assertRaises(IntegrityError):
            decrypt_bytes(K, bytes(blob), chunk_size=16, **KW)
        good = self._blob()
        with self.assertRaises(IntegrityError):
            decrypt_bytes(os.urandom(32), good, chunk_size=16, **KW)
        with self.assertRaises(IntegrityError):
            decrypt_bytes(K, good, chunk_size=16, doc_id="other", version=1, key_version=1)
        with self.assertRaises(IntegrityError):
            decrypt_bytes(K, good, chunk_size=16, doc_id="d1", version=2, key_version=1)

    def test_garbage_header_and_truncated_tail(self):
        with self.assertRaises(IntegrityError):
            decrypt_bytes(K, b"nope", **KW)
        with self.assertRaises(IntegrityError):
            decrypt_bytes(K, self._blob()[:-5], chunk_size=16, **KW)


class EnvelopeTests(unittest.TestCase):
    def setUp(self):
        self.p = LocalDevelopmentKeyProvider(os.urandom(32))

    def test_wrap_unwrap_and_context_binding(self):
        dek, wk = new_dek(self.p, "d1", 1)
        self.assertEqual(open_dek(self.p, wk, "d1", 1), dek)
        with self.assertRaises(KeyError_):
            open_dek(self.p, wk, "d2", 1)

    def test_rotation_rewrap_keeps_ciphertext_readable(self):
        dek, wk = new_dek(self.p, "d1", 1)
        ct = encrypt_bytes(dek, b"secret", doc_id="d1", version=1, key_version=wk.key_version)
        self.assertEqual(self.p.rotate(), 2)
        wk2 = rewrap(self.p, wk, "d1", 1)
        self.assertEqual(wk2.key_version, 2)
        self.assertEqual(open_dek(self.p, wk2, "d1", 1), dek)
        self.assertIn(("KEY_ROTATED", 2), self.p.events)

    def test_state_machine_and_destroyed_key_unusable(self):
        _, wk = new_dek(self.p, "d1", 1)
        self.p.rotate()
        self.p.retire(1)
        with self.assertRaises(KeyError_):
            self.p._move(2, KeyState.GENERATED)  # ACTIVE -> GENERATED is illegal
        self.p.revoke(1)
        with self.assertRaises(KeyError_):
            open_dek(self.p, wk, "d1", 1)

    def test_backup_roundtrip_wrong_passphrase_and_restore(self):
        _, wk = new_dek(self.p, "d1", 1)
        blob = export_backup(provider_keks(self.p), "correct horse battery")
        with self.assertRaises(KeyError_):
            import_backup(blob, "wrong passphrase!!")
        restored = import_backup(blob, "correct horse battery")
        self.assertEqual(restored, provider_keks(self.p))
        with self.assertRaises(ValueError):
            export_backup({}, "short")


class HashTokenSigTests(unittest.TestCase):
    def test_hash_vectors(self):
        self.assertEqual(sha256_hex(b"abc"), "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
        self.assertEqual(sha3_256_hex(b"abc"), "3a985da74fe225b2045c172d6bd390bd855f086e3e9d525b46bfe24511431532")
        self.assertEqual(hmac_sha256(b"k" * 16, b"m"), hmac_sha256(b"k" * 16, b"m"))
        self.assertTrue(constant_time_equal("a", b"a")); self.assertFalse(constant_time_equal("a", "b"))
        self.assertNotEqual(hkdf(b"m" * 32, b"audit"), hkdf(b"m" * 32, b"token"))
        self.assertEqual(digests_of_file(io.BytesIO(b"abc"))[:2], (sha256_hex(b"abc"), sha3_256_hex(b"abc")))
        with self.assertRaises(ValueError): hkdf(b"short", b"x")

    def test_tokens(self):
        key = os.urandom(32); t = new_token()
        self.assertGreaterEqual(len(t), 43)
        h = token_hash(t, key)
        self.assertNotIn(t, h)
        self.assertTrue(verify_token(t, h, key)); self.assertFalse(verify_token(t + "x", h, key))
        self.assertFalse(verify_token(t, h, os.urandom(32)))
        otp = numeric_otp(); self.assertTrue(otp.isdigit() and len(otp) == 6)

    def test_signatures_all_algorithms_and_tamper(self):
        digest = bytes.fromhex(sha256_hex(b"document"))
        for alg in SigAlg:
            priv, pub = generate_keypair(alg)
            sig = sign(alg, priv, digest)
            self.assertTrue(verify(alg, pub, digest, sig), alg)
            self.assertFalse(verify(alg, pub, bytes.fromhex(sha256_hex(b"modified")), sig), alg)
            bad = bytearray(sig); bad[0] ^= 1
            self.assertFalse(verify(alg, pub, digest, bytes(bad)), alg)
            self.assertFalse(verify(alg, generate_keypair(alg)[1], digest, sig), alg)


if __name__ == "__main__":
    unittest.main()
