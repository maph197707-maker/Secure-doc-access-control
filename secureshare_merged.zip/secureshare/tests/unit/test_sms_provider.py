"""Twilio provider through a mock HTTP transport (no network): request shape per Twilio's Messages API,
success, every failure category, timeouts, and secret hygiene."""
import json
import urllib.parse
from base64 import b64decode
from types import SimpleNamespace

import pytest

from app.integrations import errors as E
from app.integrations.sms import (SMSConfigError, SMSDeliveryError, SMSService, TwilioSMSProvider, mask_phone,
                                  normalize_phone)

SID, TOKEN = "AC" + "1" * 32, "tok_very_secret_value"


class Transport:
    def __init__(self, status=201, body=None, raises=None):
        self.status, self.body, self.raises, self.requests = status, body, raises, []

    def __call__(self, req, timeout):
        self.requests.append((req, timeout))
        if self.raises:
            raise self.raises
        return self.status, json.dumps(self.body if self.body is not None else {"sid": "SM123", "status": "queued"})


def provider(t, **kw):
    kw.setdefault("from_number", "+15005550006")
    return TwilioSMSProvider(SID, TOKEN, transport=t, **kw)


def test_request_matches_the_twilio_messages_api():
    t = Transport()
    mid = SMSService(provider(t), "+91").send_otp("98765 43210", "482913", minutes=10)
    assert mid == "SM123"
    req, timeout = t.requests[0]
    assert req.full_url == f"https://api.twilio.com/2010-04-01/Accounts/{SID}/Messages.json" and req.get_method() == "POST"
    assert b64decode(req.get_header("Authorization").split()[1]).decode() == f"{SID}:{TOKEN}"
    form = urllib.parse.parse_qs(req.data.decode())
    assert form["To"] == ["+919876543210"] and form["From"] == ["+15005550006"] and "MessagingServiceSid" not in form
    assert "482913" in form["Body"][0] and "10 minutes" in form["Body"][0] and timeout == 10


def test_messaging_service_sid_replaces_from_number():
    t = Transport()
    provider(t, from_number="", messaging_service_sid="MG" + "2" * 32).send("+919876543210", "x 123456")
    form = urllib.parse.parse_qs(t.requests[0][0].data.decode())
    assert form["MessagingServiceSid"] == ["MG" + "2" * 32] and "From" not in form


@pytest.mark.parametrize("status,body,reason", [
    (401, {"code": 20003, "message": "Authenticate"}, E.AUTH),
    (429, {"code": 20429, "message": "Too many requests"}, E.RATE_LIMITED),
    (400, {"code": 21211, "message": "Invalid 'To' Phone Number"}, E.RECIPIENT),
    (400, {"code": 21608, "message": "unverified trial number"}, E.RECIPIENT),
    (400, {"code": 21610, "message": "unsubscribed"}, E.RECIPIENT),
    (503, {}, E.UNAVAILABLE), (500, {"message": "boom"}, E.UNAVAILABLE),
    (400, {"code": 21606, "message": "From number invalid"}, E.REJECTED),
    (200, {"sid": "SM1", "status": "queued"}, E.REJECTED),               # only 201 Created is success
    (201, {"sid": "SM1", "status": "failed"}, E.REJECTED),
    (201, {}, E.REJECTED),                                              # no message sid -> not a delivery
])
def test_every_failure_is_categorised_and_raised(status, body, reason):
    with pytest.raises(SMSDeliveryError) as exc:
        provider(Transport(status, body)).send("+919876543210", "code 123456")
    assert exc.value.reason == reason
    text = str(exc.value) + repr(exc.value)
    assert TOKEN not in text and SID not in text and "123456" not in text


def test_non_json_error_body_is_still_a_failure():
    class Html(Transport):
        def __call__(self, req, timeout): return 502, "<html>Bad gateway</html>"
    with pytest.raises(SMSDeliveryError) as exc:
        provider(Html()).send("+919876543210", "x")
    assert exc.value.reason == E.UNAVAILABLE


@pytest.mark.parametrize("raised,reason", [(SMSDeliveryError(E.TIMEOUT, "t"), E.TIMEOUT),
                                           (SMSDeliveryError(E.NETWORK, "n"), E.NETWORK)])
def test_transport_level_faults_propagate_with_their_category(raised, reason):
    with pytest.raises(SMSDeliveryError) as exc:
        provider(Transport(raises=raised)).send("+919876543210", "x")
    assert exc.value.reason == reason


def test_real_transport_maps_network_errors(monkeypatch):
    import urllib.error, urllib.request
    from app.integrations import sms
    req = urllib.request.Request("https://api.twilio.com/x")
    for raised, reason in ((TimeoutError(), E.TIMEOUT), (urllib.error.URLError(TimeoutError()), E.TIMEOUT),
                           (urllib.error.URLError(ConnectionRefusedError()), E.NETWORK), (OSError("x"), E.NETWORK)):
        monkeypatch.setattr(urllib.request, "urlopen", lambda *a, _r=raised, **k: (_ for _ in ()).throw(_r))
        with pytest.raises(SMSDeliveryError) as exc:
            sms._urllib_transport(req, 1)
        assert exc.value.reason == reason


def test_http_errors_from_the_real_transport_are_returned_as_status(monkeypatch):
    import io, urllib.error, urllib.request
    from app.integrations import sms
    err = urllib.error.HTTPError("u", 401, "Unauthorized", {}, io.BytesIO(b'{"code": 20003}'))
    monkeypatch.setattr(urllib.request, "urlopen", lambda *a, **k: (_ for _ in ()).throw(err))
    assert sms._urllib_transport(urllib.request.Request("https://x"), 1) == (401, '{"code": 20003}')


def test_invalid_number_never_reaches_the_provider():
    t = Transport()
    with pytest.raises(SMSDeliveryError) as exc:
        SMSService(provider(t)).send_otp("12", "123456")
    assert exc.value.reason == E.RECIPIENT and t.requests == []


def test_configuration_is_required_and_comes_only_from_settings():
    for kw in (dict(account_sid="", auth_token="t", from_number="+1"), dict(account_sid="a", auth_token="", from_number="+1"),
               dict(account_sid="a", auth_token="t")):
        with pytest.raises(SMSConfigError):
            TwilioSMSProvider(**kw)
    from app.config.settings import Settings
    with pytest.raises(SMSConfigError):
        SMSService.from_settings(Settings(_env_file=None))
    cfg = Settings(_env_file=None, twilio_account_sid=SID, twilio_auth_token=TOKEN, twilio_from_number="+15005550006")
    assert cfg.sms_configured and isinstance(SMSService.from_settings(cfg).provider, TwilioSMSProvider)
    assert TOKEN not in repr(cfg)


def test_phone_helpers():
    assert normalize_phone("98765 43210") == "+919876543210" and normalize_phone("00 44 7700 900123") == "+447700900123"
    assert normalize_phone("+1 (415) 555-2671") == "+14155552671"
    for bad in ("", "12", "+0123", "abc", "+" + "9" * 20):
        with pytest.raises(ValueError):
            normalize_phone(bad)
    assert mask_phone("+919876543210") == "+91*******210"
