import base64, hashlib, json, unittest, urllib.parse
from app.integrations.oauth import OAuthClient, OAuthError, Profile, link_decision, pkce_challenge, provider_status
from app.integrations.state import InMemoryStateStore


def jwt(claims): return "h." + base64.urlsafe_b64encode(json.dumps(claims).encode()).decode().rstrip("=") + ".s"


class Fake:
    def __init__(self, userinfo=None, token_status=200, id_claims=None):
        self.calls, self.userinfo, self.ts, self.idc = [], userinfo or {"sub": "g1", "email": "A@B.co", "email_verified": True, "name": "A"}, token_status, id_claims
    def __call__(self, m, url, h, body):
        self.calls.append((m, url, h, body))
        if "token" in url:
            t = {"access_token": "AT"}
            if self.idc is not None: t["id_token"] = jwt(self.idc)
            return self.ts, json.dumps(t)
        return 200, json.dumps(self.userinfo)


def mk(tx, store=None, p="google"):
    return OAuthClient(p, "cid", "sec", "https://x.example/oauth/cb", store or InMemoryStateStore(), tx)


def qs(url): return dict(urllib.parse.parse_qsl(urllib.parse.urlparse(url).query))


class Flow(unittest.TestCase):
    def test_happy_path_pkce_and_state(self):
        tx, store = Fake(), InMemoryStateStore(); c = mk(tx, store)
        q = qs(c.authorize_url("/documents")); self.assertEqual(q["code_challenge_method"], "S256")
        prof, nxt = c.complete(q["state"], "CODE"); self.assertEqual((prof.email, nxt, prof.email_verified), ("a@b.co", "/documents", True))
        sent = dict(urllib.parse.parse_qsl(tx.calls[0][3].decode()))
        self.assertEqual(pkce_challenge(sent["code_verifier"]), q["code_challenge"])   # verifier matches challenge
        self.assertNotIn("code_verifier", q)                                           # verifier never in the URL

    def test_state_single_use_and_unknown(self):
        c = mk(Fake()); s = qs(c.authorize_url())["state"]; c.complete(s, "c")
        with self.assertRaises(OAuthError): c.complete(s, "c")
        with self.assertRaises(OAuthError): c.complete("forged", "c")
        with self.assertRaises(OAuthError): c.complete("", "c")

    def test_state_consumed_even_when_exchange_fails(self):
        c = mk(Fake(token_status=400)); s = qs(c.authorize_url())["state"]
        with self.assertRaises(OAuthError): c.complete(s, "c")
        with self.assertRaises(OAuthError): c.complete(s, "c")

    def test_cross_provider_state_rejected(self):
        store = InMemoryStateStore(); g = mk(Fake(), store, "google"); m = mk(Fake(), store, "microsoft")
        with self.assertRaises(OAuthError): m.complete(qs(g.authorize_url())["state"], "c")

    def test_nonce_and_aud_checked(self):
        c = mk(Fake(id_claims={"nonce": "WRONG"})); s = qs(c.authorize_url())["state"]
        with self.assertRaises(OAuthError): c.complete(s, "c")
        c = mk(Fake(id_claims={"aud": "other"})); s = qs(c.authorize_url())["state"]
        with self.assertRaises(OAuthError): c.complete(s, "c")

    def test_open_redirect_blocked(self):
        store = InMemoryStateStore(); c = mk(Fake(), store)
        for bad in ("//evil.com", "https://evil.com", "javascript:1"):
            self.assertEqual(c.complete(qs(c.authorize_url(bad))["state"], "c")[1], "/dashboard")

    def test_unverified_and_microsoft_missing_flag(self):
        c = mk(Fake({"sub": "1", "email": "a@b.co", "email_verified": False}))
        self.assertFalse(c.complete(qs(c.authorize_url())["state"], "c")[0].email_verified)
        c = mk(Fake({"sub": "1", "email": "a@b.co"}), p="microsoft")
        self.assertFalse(c.complete(qs(c.authorize_url())["state"], "c")[0].email_verified)

    def test_config_and_https(self):
        self.assertEqual(provider_status("google"), "PROVIDER_UNAVAILABLE")
        with self.assertRaises(OAuthError): OAuthClient("google", "", "", "https://x", InMemoryStateStore())
        with self.assertRaises(OAuthError): OAuthClient("google", "a", "b", "http://evil.com/cb", InMemoryStateStore())

    def test_link_decision(self):
        v = Profile("google", "1", "a@b.co", True); u = Profile("google", "1", "a@b.co", False)
        self.assertEqual(link_decision(v, True, False, False), "LOGIN")
        self.assertEqual(link_decision(u, False, True, False), "REJECT_UNVERIFIED")
        self.assertEqual(link_decision(v, False, True, False), "CONFIRM_REQUIRED")
        self.assertEqual(link_decision(v, False, True, True), "LINK")
        self.assertEqual(link_decision(v, False, False, False), "CREATE")


if __name__ == "__main__":
    unittest.main()
