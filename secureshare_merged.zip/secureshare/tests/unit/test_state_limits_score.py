import os, sqlite3, tempfile, threading, unittest
from app.integrations.state import InMemoryStateStore
from app.services.rate_limiter import hit, lockout_seconds, LoginThrottle
from app.services.usage_counters import consume
from app.services.link_reputation import compute_reputation, LinkStats
from app.services.policy_engine import Reputation
from app.services.security_score import compute_score, WEIGHTS
from app.ml.anomaly_detector import zscore_anomaly, ewma_anomaly


class Clock:
    def __init__(self): self.t = 1000.0
    def __call__(self): return self.t


class StateTests(unittest.TestCase):
    def setUp(self):
        self.c = Clock(); self.s = InMemoryStateStore(self.c)

    def test_ttl_expiry_and_incr_window(self):
        self.assertEqual(self.s.incr("k", 10), 1); self.assertEqual(self.s.incr("k", 10), 2)
        self.c.t += 11
        self.assertEqual(self.s.incr("k", 10), 1)

    def test_rate_limit_blocks_then_recovers(self):
        for i in range(3): self.assertTrue(hit(self.s, "login:ip", 3, 60).allowed)
        r = hit(self.s, "login:ip", 3, 60)
        self.assertFalse(r.allowed); self.assertGreater(r.retry_after, 0)
        self.c.t += 61
        self.assertTrue(hit(self.s, "login:ip", 3, 60).allowed)

    def test_atomic_incr_under_threads(self):
        ts = [threading.Thread(target=lambda: [self.s.incr("n", 100) for _ in range(500)]) for _ in range(8)]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertEqual(self.s.get("n"), 4000)

    def test_lockout_escalates_and_resets(self):
        self.assertEqual([lockout_seconds(n) for n in (1, 4, 5, 6, 7)], [0, 0, 30, 60, 120])
        self.assertEqual(lockout_seconds(99), 3600)
        th = LoginThrottle(self.s)
        for _ in range(4): self.assertEqual(th.record_failure("a@x"), 0)
        self.assertEqual(th.record_failure("a@x"), 30); self.assertGreater(th.locked_for("a@x"), 0)
        self.c.t += 31; self.assertEqual(th.locked_for("a@x"), 0)
        th.record_success("a@x"); self.assertEqual(th.record_failure("a@x"), 0)


class CounterRaceTests(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.TemporaryDirectory(); self.db = os.path.join(self.d.name, "t.db")
        c = sqlite3.connect(self.db)
        c.execute("CREATE TABLE secure_links(id TEXT PRIMARY KEY, revoked INT, max_views INT, views_used INT,"
                  " max_downloads INT, downloads_used INT, one_time INT)")
        c.executemany("INSERT INTO secure_links VALUES(?,?,?,?,?,?,?)", [
            ("lim", 0, 5, 0, 2, 0, 0), ("once", 0, None, 0, None, 0, 1), ("rev", 1, 5, 0, 5, 0, 0)])
        c.commit(); c.close()

    def tearDown(self): self.d.cleanup()

    def run_race(self, link, kind, n=40):
        wins, lock = [], threading.Lock()

        def worker():
            conn = sqlite3.connect(self.db, timeout=30)
            def ex(sql, p):
                with conn:
                    return conn.execute(sql.replace(":id", "?"), (p["id"],)).rowcount
            ok = consume(ex, kind, link); conn.close()
            with lock: wins.append(ok)
        ts = [threading.Thread(target=worker) for _ in range(n)]
        [t.start() for t in ts]; [t.join() for t in ts]
        return sum(wins)

    def test_exactly_max_views_win_a_race(self): self.assertEqual(self.run_race("lim", "view"), 5)
    def test_exactly_max_downloads_win_a_race(self): self.assertEqual(self.run_race("lim", "download"), 2)
    def test_one_time_link_only_once(self): self.assertEqual(self.run_race("once", "view"), 1)
    def test_revoked_never(self): self.assertEqual(self.run_race("rev", "view", 10), 0)


class ReputationScoreAnomalyTests(unittest.TestCase):
    def test_reputation(self):
        self.assertEqual(compute_reputation(LinkStats())[0], Reputation.NORMAL)
        r, why = compute_reputation(LinkStats(failed_verifications=3, unique_ips=4))
        self.assertEqual(r, Reputation.SUSPICIOUS); self.assertIn("MANY_DISTINCT_IPS", why)
        self.assertEqual(compute_reputation(LinkStats(failed_verifications=10, denied_requests=5, unique_ips=5))[0],
                         Reputation.ABUSED)

    def test_score_is_computed_not_hardcoded(self):
        perfect = {n: (1.0, "all") for n in WEIGHTS}
        self.assertEqual(compute_score(perfect).score, 100)
        half = dict(perfect, mfa=(0.0, "MFA off"))
        r = compute_score(half)
        self.assertEqual(r.score, 85); self.assertEqual(r.weak, ["mfa"]); self.assertEqual(r.label, "Good")
        self.assertTrue(r.recommendations)
        self.assertEqual(compute_score({}).label, "No data")
        # not-applicable controls are excluded, weights renormalised
        self.assertEqual(compute_score({"encryption": (1.0, "ok"), "mfa": (None, "n/a")}).score, 100)
        with self.assertRaises(ValueError): compute_score({"bogus": (1.0, "x")})
        with self.assertRaises(ValueError): compute_score({"mfa": (1.5, "x")})

    def test_anomaly_signals(self):
        hist = [10, 11, 9, 10, 10, 11, 9, 10]
        self.assertTrue(zscore_anomaly(hist, 60)[0]); self.assertFalse(zscore_anomaly(hist, 11)[0])
        self.assertFalse(zscore_anomaly([1, 2], 999)[0])            # too little data -> no fabricated alarm
        self.assertTrue(ewma_anomaly(hist, 60)); self.assertFalse(ewma_anomaly(hist, 10))
        self.assertFalse(ewma_anomaly([1], 99))


if __name__ == "__main__":
    unittest.main()
