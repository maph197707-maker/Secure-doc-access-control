"""Production must not start with throw-away secrets (documents would become undecryptable)."""
import pytest
from pydantic import ValidationError

from app.config.settings import Settings

_PROD = dict(app_env="production", smtp_host="smtp.gmail.com", smtp_user="a@gmail.com", smtp_password="abcd efgh ijkl mnop",
             cookie_secure=True,
             public_base_url="https://docs.example.com")
_GOOD = "a" * 64


def _make(**kw):
    return Settings(_env_file=None, **{**_PROD, **kw})


def test_production_with_explicit_secrets_is_accepted():
    assert _make(secret_key=_GOOD, master_secret=_GOOD).is_production


@pytest.mark.parametrize("missing", ["secret_key", "master_secret"])
def test_production_rejects_unset_secret(missing):
    kw = dict(secret_key=_GOOD, master_secret=_GOOD)
    del kw[missing]
    with pytest.raises(ValidationError, match=missing.upper()):
        _make(**kw)


def test_production_rejects_placeholder_short_secret_and_insecure_cookie():
    with pytest.raises(ValidationError, match="SECRET_KEY"):
        _make(secret_key="__GENERATE__", master_secret=_GOOD)
    with pytest.raises(ValidationError, match="MASTER_SECRET"):
        _make(secret_key=_GOOD, master_secret="short")
    with pytest.raises(ValidationError, match="COOKIE_SECURE"):
        _make(secret_key=_GOOD, master_secret=_GOOD, cookie_secure=False)


def test_dev_still_works_without_explicit_secrets():
    assert Settings(_env_file=None, app_env="dev").is_dev


def test_non_dev_requires_explicit_https_public_base_url():
    kw = dict(secret_key=_GOOD, master_secret=_GOOD)
    with pytest.raises(ValidationError, match="PUBLIC_BASE_URL"):
        _make(**kw, public_base_url="http://docs.example.com")
    with pytest.raises(ValidationError, match="PUBLIC_BASE_URL"):
        _make(**kw, public_base_url="http://localhost:8000")
    kw2 = {**_PROD, **kw}
    del kw2["public_base_url"]                       # left at the http://localhost default
    with pytest.raises(ValidationError, match="PUBLIC_BASE_URL"):
        Settings(_env_file=None, **kw2)
    assert _make(**kw).public_base_url.startswith("https://")


def test_dev_may_use_http_localhost():
    assert Settings(_env_file=None, app_env="dev", public_base_url="http://localhost:8000").is_dev


def test_production_requires_real_email_only_when_signup_sends_a_code():
    with pytest.raises(ValidationError, match="Email delivery is required"):
        _make(secret_key=_GOOD, master_secret=_GOOD, smtp_host="", signup_email_verification_required=True)
    with pytest.raises(ValidationError, match="Email delivery is required"):
        _make(secret_key=_GOOD, master_secret=_GOOD, smtp_password="", signup_email_verification_required=True)


def test_production_starts_without_smtp_when_signup_needs_no_email():
    st = _make(secret_key=_GOOD, master_secret=_GOOD, smtp_host="", smtp_password="")
    assert st.is_production and not st.email_configured and st.guest_login_active


def test_secrets_are_not_leaked_by_settings_repr():
    st = _make(secret_key=_GOOD, master_secret=_GOOD, twilio_auth_token="tok_super_secret")
    assert "abcd efgh" not in repr(st) and "tok_super_secret" not in repr(st)
