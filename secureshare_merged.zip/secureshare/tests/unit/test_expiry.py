import unittest
from datetime import datetime

from app.services import expiry as ex


class ExpiryTests(unittest.TestCase):
    def test_kolkata_to_utc(self):
        self.assertEqual(ex.local_to_utc("2026-10-05T10:00", "Asia/Kolkata"), datetime(2026, 10, 5, 4, 30))

    def test_hours_until(self):
        now = datetime(2026, 10, 5, 0, 0)
        self.assertEqual(ex.hours_until("2026-10-05T10:00", "Asia/Kolkata", now), 5)  # 04:30 -> ceil 5h

    def test_default_utc(self):
        self.assertEqual(ex.local_to_utc("2026-10-05T10:00", None), datetime(2026, 10, 5, 10, 0))

    def test_past_rejected(self):
        with self.assertRaises(ex.ExpiryError):
            ex.hours_until("2026-10-01T10:00", "UTC", datetime(2026, 10, 2))

    def test_bad_zone_and_traversal(self):
        for bad in ("Mars/Base", "../../etc/passwd", "x" * 400):
            with self.assertRaises(ex.ExpiryError):
                ex.local_to_utc("2026-10-05T10:00", bad)

    def test_bad_datetime(self):
        with self.assertRaises(ex.ExpiryError):
            ex.local_to_utc("tomorrow", "UTC")

    def test_dst_gap_lands_on_real_instant(self):
        # US spring-forward 2026-03-08: 02:30 does not exist in New York.
        got = ex.local_to_utc("2026-03-08T02:30", "America/New_York")
        self.assertEqual(got, datetime(2026, 3, 8, 7, 30))     # == 03:30 EDT
        self.assertIn("03:30", ex.utc_to_local_str(got, "America/New_York"))

    def test_dst_fold_takes_earlier_instant(self):
        # US fall-back 2026-11-01: 01:30 occurs twice; earlier = EDT (UTC-4) = 05:30 UTC.
        self.assertEqual(ex.local_to_utc("2026-11-01T01:30", "America/New_York"),
                         datetime(2026, 11, 1, 5, 30))

    def test_cap_one_year(self):
        now = datetime(2026, 10, 2)
        self.assertEqual(ex.hours_until("2040-01-01T00:00", "UTC", now), ex.MAX_HOURS)
        self.assertEqual(ex.expires_at("2040-01-01T00:00", "UTC", now).year, 2027)


if __name__ == "__main__":
    unittest.main()
