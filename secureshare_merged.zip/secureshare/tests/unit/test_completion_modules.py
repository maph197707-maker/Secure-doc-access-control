"""Tests for the modules completed in the 2.9.3 completion pass. Stdlib/cryptography only, so they
run without a database; they exercise real logic (no mocking of the unit under test)."""
from __future__ import annotations

import base64
import os
import tempfile
from dataclasses import replace
from datetime import datetime, timedelta

import pytest

from app.core.enums import Classification, Decision, Permission
from app.crypto.envelope import KeyError_, wrap_aad
from app.integrations.kms import KmsUnavailable, LocalKms, build_kms
from app.integrations.state import InMemoryStateStore
from app.integrations.storage import (LocalStorageProvider, ProviderUnavailable, S3StorageProvider,
                                      StorageError, StorageService)
from app.security import threat_detection as td
from app.services import mfa, zero_trust as zt
from app.services.policy_engine import AccessContext, Principal

NOW = datetime(2026, 10, 2, 12)


# ---- storage / kms ---------------------------------------------------------------------------
def test_storage_roundtrip_and_traversal(tmp_path):
    s = StorageService(LocalStorageProvider(tmp_path))
    assert s.save("abc", b"data") == 4 and s.read("abc") == b"data" and s.exists("abc") and s.size("abc") == 4
    for bad in ("../x", "a/b", "", ".."):
        with pytest.raises(StorageError):
            s.save(bad, b"x")
    assert s.delete("abc") and not s.exists("abc") and not s.delete("abc")
    with pytest.raises(StorageError):
        s.read("missing")


def test_storage_refuses_symlink(tmp_path):
    (tmp_path / "real").write_bytes(b"x")
    try:
        os.symlink(tmp_path / "real", tmp_path / "link")
    except OSError:
        pytest.skip("Symlink creation not permitted on this platform")
    with pytest.raises(StorageError):
        StorageService(LocalStorageProvider(tmp_path)).read("link")


def test_s3_without_credentials_is_unavailable():
    with pytest.raises(ProviderUnavailable) as e:
        S3StorageProvider(bucket="b")
    assert e.value.code == "PROVIDER_UNAVAILABLE"


def test_kms_wrap_bound_to_context_and_cloud_backends_unsupported():
    k, aad = LocalKms("m"), wrap_aad("doc", 1)
    wk = k.wrap(b"k" * 32, aad)
    assert k.unwrap(wk, aad) == b"k" * 32
    with pytest.raises(KeyError_):
        k.unwrap(wk, wrap_aad("other", 1))
    for backend in ("aws", "azure", "hsm", "vault"):
        class S:  # noqa: N801
            kms_backend, master_secret = backend, "m"
        with pytest.raises(KmsUnavailable):
            build_kms(S)


# ---- threat detection --------------------------------------------------------------------------
def test_threshold_not_met_means_no_alert():
    ev = [td.SecEvent(f"d{i}", td.DOWNLOAD, NOW + timedelta(seconds=i), user_id="u") for i in range(9)]
    assert td.detect(ev) == []


def test_brute_force_and_rapid_download_detected_with_evidence():
    ev = [td.SecEvent(f"f{i}", td.LOGIN_FAILED, NOW + timedelta(seconds=i * 10), ip="1.2.3.4") for i in range(5)]
    ev += [td.SecEvent(f"d{i}", td.DOWNLOAD, NOW + timedelta(seconds=i), user_id="u") for i in range(10)]
    codes = {a.code: a for a in td.detect(ev)}
    assert set(codes) == {"BRUTE_FORCE", "RAPID_DOWNLOAD"}
    assert codes["BRUTE_FORCE"].evidence_ids == tuple(f"f{i}" for i in range(5))
    assert ("FAILED_LOGIN", "f0") in td.to_risk_events(list(codes.values()))


def test_unusual_ip_needs_prior_login():
    one = [td.SecEvent("l1", td.LOGIN_OK, NOW, "u", "1.1.1.1", "a")]
    assert td.detect(one) == []
    two = one + [td.SecEvent("l2", td.LOGIN_OK, NOW + timedelta(1), "u", "9.9.9.9", "a")]
    assert [a.code for a in td.detect(two)] == ["UNUSUAL_IP"]


# ---- MFA -------------------------------------------------------------------------------------------
def test_totp_rfc6238_vector():
    secret = base64.b32encode(b"12345678901234567890").decode()
    assert mfa.totp_at(secret, 59) == "287082"


def test_totp_replay_and_lockout():
    st, secret, now = InMemoryStateStore(), mfa.new_secret(), 1_700_000_000.0
    code = mfa.totp_at(secret, now)
    assert mfa.verify_totp(st, "u", secret, code, now) == mfa.MfaResult.OK
    assert mfa.verify_totp(st, "u", secret, code, now) == mfa.MfaResult.REPLAYED
    for _ in range(5):
        r = mfa.verify_totp(st, "v", secret, "111111", now)
    assert r == mfa.MfaResult.LOCKED
    assert mfa.verify_totp(st, "v", secret, mfa.totp_at(secret, now), now) == mfa.MfaResult.LOCKED


def test_recovery_codes_single_use_and_hashed():
    plain, hashes = mfa.generate_recovery_codes(3)
    assert all(p not in h for p, h in zip(plain, hashes))
    ok, rest = mfa.consume_recovery_code(hashes, plain[0])
    assert ok and len(rest) == 2 and mfa.consume_recovery_code(rest, plain[0])[0] is False


def test_otp_delivery_never_faked():
    assert mfa.deliver_otp("sms", "+1", "123456") == mfa.MfaResult.PROVIDER_UNAVAILABLE
    assert mfa.deliver_otp("sms", "+1", "1", lambda *a: False) == mfa.MfaResult.PROVIDER_UNAVAILABLE
    assert mfa.deliver_otp("sms", "+1", "1", lambda *a: True) == mfa.MfaResult.DELIVERED


# ---- Zero Trust ------------------------------------------------------------------------------------
def _ctx(**kw):
    return AccessContext(action=Permission.VIEW, now=NOW, principal=Principal.USER, session_active=True,
                         email_verified=True, **kw)


def test_pdp_deny_by_default_and_owner_allow():
    assert zt.decide(_ctx(), role="USER").decision == Decision.DENY
    assert zt.decide(_ctx(is_owner=True), role="USER").decision == Decision.ALLOW
    assert "RBAC_PERMISSION_MISSING" in zt.decide(_ctx(), role="NOPE").reasons


def test_pdp_future_expired_revoked_denied():
    g = _ctx(granted=frozenset({Permission.VIEW}))
    assert zt.decide(g, role="USER").decision == Decision.ALLOW
    assert "LINK_NOT_YET_VALID" in zt.decide(replace(g, valid_from=NOW + timedelta(hours=1)), role="USER").reasons
    assert "LINK_EXPIRED" in zt.decide(replace(g, expires_at=NOW - timedelta(seconds=1)), role="USER").reasons
    assert "POLICY_REVOKED" in zt.decide(replace(g, policy_active=False), role="USER").reasons


def test_pdp_classification_and_risk():
    g = _ctx(granted=frozenset({Permission.VIEW}))
    assert zt.decide(g, role="USER", classification=Classification.RESTRICTED).decision == Decision.VERIFY
    assert zt.decide(replace(g, mfa_verified=True), role="USER", classification="RESTRICTED").decision == Decision.ALLOW
    assert zt.decide(g, role="USER", risk_score=80).decision == Decision.DENY
    assert zt.decide(g, role="USER", risk_score=55).decision == Decision.VERIFY
    assert zt.has_permission("ADMIN", "MANAGE_USERS") and not zt.has_permission("MANAGER", "MANAGE_USERS")


# ---- quotas / search / analytics / folders ----------------------------------------------------------
def test_quota_enforced_server_side():
    from app.services import quotas
    q = quotas.status(900, 3, 1000, 10)
    quotas.check_upload(q, 100)
    with pytest.raises(quotas.QuotaExceeded):
        quotas.check_upload(q, 101)
    with pytest.raises(quotas.QuotaExceeded):
        quotas.check_upload(quotas.status(0, 10, 1000, 10), 1)


def test_search_filters_sort_paginate_and_rejects_bad_sort():
    from app.services.search import search
    docs = [{"name": "Q3 invoice.pdf", "tags": ["finance"], "owner": "a", "classification": "CONFIDENTIAL",
             "created": NOW, "size": 5, "shared": True, "ocr_text": "payment"},
            {"name": "notes.txt", "tags": [], "owner": "b", "classification": "INTERNAL",
             "created": NOW - timedelta(days=3), "size": 9, "ocr_text": "invoice"}]
    assert [d["name"] for d in search(docs, "invoice").items] == ["Q3 invoice.pdf", "notes.txt"]
    assert search(docs, "zzz").total == 0 and search(docs, shared=True).total == 1
    assert search(docs, page_size=1, page=2).items[0]["name"] == "Q3 invoice.pdf"
    with pytest.raises(ValueError):
        search(docs, sort="x; DROP TABLE")


def test_analytics_empty_is_zero_not_fake():
    from app.services.analytics import daily_series, pct_delta
    assert daily_series([], 3, NOW)["values"] == [0, 0, 0]
    assert pct_delta(5, 0) is None and pct_delta(15, 10) == 50.0


def test_folder_cycle_and_duplicate_rules():
    from app.services.folders import FolderError, FolderNode, check_create, check_move
    n = {"a": FolderNode("a", None, "A", "u"), "b": FolderNode("b", "a", "B", "u"), "c": FolderNode("c", "b", "C", "u")}
    with pytest.raises(FolderError):
        check_move(n, "u", "a", "c")
    with pytest.raises(FolderError):
        check_create(n, "u", None, "a")
    with pytest.raises(FolderError):
        check_create(n, "other", "a", "X")      # not their parent
    with pytest.raises(FolderError):
        check_create(n, "u", None, "../x")


# ---- ML / OCR / AI / queue ----------------------------------------------------------------------------
def test_ocr_statuses_are_honest():
    from app.integrations.ocr import LocalOCRProvider
    o = LocalOCRProvider()
    assert o.extract(b"hello", "a.txt").status == "COMPLETED"
    assert o.extract(b"\x00\x01", "a.bin").status == "PROVIDER_UNAVAILABLE"
    assert o.extract(b"%PDF-1.4 junk", "x.pdf").status in ("FAILED", "PROVIDER_UNAVAILABLE")


def test_queue_inline_fallback_is_reported_as_inline():
    from app.integrations.queue import QueueService
    qs = QueueService(use_celery=False)
    j = qs.enqueue("document.extract_text", b"hello", "a.txt", "text/plain")
    assert (j.status, j.mode) == ("EXECUTED_SYNC", "inline")
    assert qs.enqueue("notification.build", "u", "T", "your otp: 123456").status == "FAILED"
    with pytest.raises(KeyError):
        qs.enqueue("nope")


def test_cleanup_temp_removes_only_old_regular_files():
    from app.workers.tasks.maintenance_tasks import cleanup_temp_dir
    d = tempfile.mkdtemp()
    old, new = os.path.join(d, "old"), os.path.join(d, "new")
    open(old, "w").write("x")
    open(new, "w").write("y")
    os.utime(old, (1, 1))
    assert cleanup_temp_dir(d, 60)["removed"] == 1 and os.listdir(d) == ["new"]


def test_viewer_policy_never_allows_on_deny():
    from app.services.viewer import policy_from_decision
    d = zt.decide(_ctx(), role="USER")
    p = policy_from_decision(d)
    assert not p.may_view and not p.can_download


def test_attack_battery_all_blocked_by_real_pdp():
    from app.services import attack_simulator
    r = attack_simulator.run(NOW)
    assert r["total"] == 10 and r["passed"] == r["total"], [x for x in r["results"] if not x["passed"]]


def test_network_intel_never_reports_clean_without_provider():
    from app.integrations.network_intel import lookup
    assert lookup("8.8.8.8").state == "PROVIDER_UNAVAILABLE"
    assert lookup("127.0.0.1").state == "LOOPBACK" and lookup("nope").state == "INVALID"
