"""SMTP provider through a mock smtplib transport (no network): protocol steps, failure categories,
Gmail specifics, and that no secret ever appears in an error."""
import smtplib
import socket
import ssl
from types import SimpleNamespace

import pytest

from app.integrations import errors as E
from app.integrations.email import (EmailConfigError, EmailDeliveryError, EmailService, SmtpEmailProvider,
                                    mask_email, valid_address)

PASSWORD = "abcd efgh ijkl mnop"


class FakeSMTP:
    """Records the protocol conversation. Class attributes script failures per test."""
    log: list = []
    raise_on: dict = {}
    refused: dict = {}

    def __init__(self, host, port, **kw):
        self.log.append(("connect", host, port, kw))
        if "connect" in self.raise_on:
            raise self.raise_on["connect"]

    def __enter__(self): return self
    def __exit__(self, *a): return False

    def _step(self, name, *args):
        self.log.append((name, *args))
        if name in self.raise_on:
            raise self.raise_on[name]

    def starttls(self, context=None): self._step("starttls", isinstance(context, ssl.SSLContext))
    def login(self, user, password): self._step("login", user, password)

    def send_message(self, msg):
        self._step("send", msg["To"], msg["From"], msg["Subject"], msg.get_content())
        return self.refused


@pytest.fixture(autouse=True)
def _reset():
    FakeSMTP.log, FakeSMTP.raise_on, FakeSMTP.refused = [], {}, {}


def provider(**kw):
    return SmtpEmailProvider("smtp.gmail.com", 587, "me@gmail.com", PASSWORD, factory=FakeSMTP, **kw)


def service(**kw):
    return EmailService(provider(**kw), "me@gmail.com", "SecureShare")


def steps():
    return [e[0] for e in FakeSMTP.log]


def test_gmail_starttls_flow_connects_encrypts_logs_in_then_sends():
    service().send_otp("bob@example.com", "482913", minutes=10)
    assert steps() == ["connect", "starttls", "login", "send"]
    assert FakeSMTP.log[0][1:3] == ("smtp.gmail.com", 587) and FakeSMTP.log[0][3]["timeout"] == 10
    assert FakeSMTP.log[1][1] is True                                    # a real SSLContext (cert verification)
    assert FakeSMTP.log[2][1:] == ("me@gmail.com", "abcdefghijklmnop")   # app-password spaces stripped
    _, to, frm, subject, body = FakeSMTP.log[3]
    assert to == "bob@example.com" and "me@gmail.com" in frm and "verification code" in subject.lower()
    assert "482913" in body and "10 minutes" in body


def test_ssl_mode_never_calls_starttls(monkeypatch):
    seen = {}
    class SSLFake(FakeSMTP):
        def __init__(self, host, port, **kw):
            seen.update(kw); super().__init__(host, port, **kw)
    monkeypatch.setattr(smtplib, "SMTP_SSL", SSLFake)
    from email.message import EmailMessage
    msg = EmailMessage(); msg["To"] = "bob@example.com"; msg["From"] = "me@gmail.com"; msg["Subject"] = "s"
    msg.set_content("code 123456")
    SmtpEmailProvider("smtp.gmail.com", 465, "me@gmail.com", PASSWORD, security="ssl").send(msg)
    assert "starttls" not in steps() and isinstance(seen["context"], ssl.SSLContext)


@pytest.mark.parametrize("raised,reason", [
    (smtplib.SMTPAuthenticationError(535, b"5.7.8 Username and Password not accepted"), E.AUTH),
    (smtplib.SMTPRecipientsRefused({"x@y.z": (550, b"no such user")}), E.RECIPIENT),
    (smtplib.SMTPSenderRefused(553, b"bad sender", "me@gmail.com"), E.CONFIG),
    (smtplib.SMTPDataError(550, b"5.4.5 Daily user sending limit exceeded"), E.RATE_LIMITED),
    (smtplib.SMTPDataError(421, b"4.7.0 try later"), E.UNAVAILABLE),
    (smtplib.SMTPDataError(554, b"message rejected"), E.REJECTED),
    (smtplib.SMTPServerDisconnected("gone"), E.UNAVAILABLE),
    (smtplib.SMTPConnectError(421, b"busy"), E.UNAVAILABLE),
    (TimeoutError("timed out"), E.TIMEOUT), (socket.timeout("t"), E.TIMEOUT),
    (ConnectionRefusedError("refused"), E.NETWORK), (ssl.SSLError("bad cert"), E.NETWORK),
])
@pytest.mark.parametrize("stage", ["connect", "login", "send"])
def test_every_failure_is_categorised_and_raised_never_swallowed(raised, reason, stage):
    if stage == "login" and not isinstance(raised, (smtplib.SMTPAuthenticationError,)) and reason == E.RECIPIENT:
        pytest.skip("recipient errors only happen when sending")
    FakeSMTP.raise_on[stage] = raised
    with pytest.raises(EmailDeliveryError) as exc:
        service().send_otp("bob@example.com", "123456")
    assert exc.value.reason == reason
    text = str(exc.value) + repr(exc.value)
    assert PASSWORD not in text and "abcdefghijklmnop" not in text and "123456" not in text


def test_partially_refused_recipient_is_a_failure():
    FakeSMTP.refused = {"bob@example.com": (550, b"mailbox unavailable")}
    with pytest.raises(EmailDeliveryError) as exc:
        service().send_otp("bob@example.com", "123456")
    assert exc.value.reason == E.RECIPIENT


def test_invalid_recipient_never_reaches_the_server():
    for bad in ("", "nope", "a@b", "a b@c.de", "x@y.z\r\nBcc: evil@z.z", "<a@b.cd>"):
        with pytest.raises(EmailDeliveryError):
            service().send_otp(bad, "123456")
    assert FakeSMTP.log == []


def test_missing_configuration_is_refused_up_front():
    for args in (("", 587, "u", "p"), ("h", 587, "", "p"), ("h", 587, "u", "")):
        with pytest.raises(EmailConfigError):
            SmtpEmailProvider(*args)
    with pytest.raises(EmailConfigError):
        SmtpEmailProvider("h", 587, "u", "p", security="none")


def test_from_settings_builds_smtp_only_when_fully_configured():
    st = SimpleNamespace(email_configured=False)
    with pytest.raises(EmailConfigError):
        EmailService.from_settings(st)
    from app.config.settings import Settings
    cfg = Settings(_env_file=None, smtp_host="smtp.gmail.com", smtp_user="me@gmail.com", smtp_password=PASSWORD,
                   email_from_name="SS")
    svc = EmailService.from_settings(cfg)
    assert isinstance(svc.provider, SmtpEmailProvider) and svc.from_addr == "me@gmail.com" and svc.from_name == "SS"
    assert PASSWORD not in repr(cfg) and cfg.smtp_port == 587 and cfg.smtp_security == "starttls"
    assert not Settings(_env_file=None).email_configured                  # nothing configured -> no fake fallback


def test_address_helpers():
    assert valid_address("a.b+c@example.co") and not valid_address("a@b") and not valid_address("a@b.c\nx")
    assert mask_email("alice@example.com") == "a****@example.com"
