"""Pure folder rules that the folder browser relies on (no DB, no FastAPI needed)."""
import pytest

from app.services.folders import MAX_DEPTH, FolderError, FolderNode, check_create, check_move


def N(i, parent, name="x", owner="u"):
    return FolderNode(i, parent, name, owner)


def test_cycle_and_self_moves_are_refused():
    nodes = {"a": N("a", None, "A"), "b": N("b", "a", "B"), "c": N("c", "b", "C")}
    for target in ("a", "b", "c"):
        with pytest.raises(FolderError):
            check_move(nodes, "u", "a", target)


def test_depth_limit_and_duplicates():
    nodes, parent = {}, None
    for i in range(MAX_DEPTH):
        nodes[str(i)] = N(str(i), parent, f"f{i}")
        parent = str(i)
    with pytest.raises(FolderError):
        check_create(nodes, "u", parent, "deeper")
    with pytest.raises(FolderError):
        check_create({"a": N("a", None, "Taxes")}, "u", None, "TAXES")


def test_other_users_folder_is_not_found():
    with pytest.raises(FolderError):
        check_create({"a": N("a", None, "Mine", owner="someone-else")}, "u", "a", "child")
