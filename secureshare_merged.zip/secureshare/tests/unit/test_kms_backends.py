"""AWS KMS / Vault Transit adapters + their wiring into DocumentService.

The fakes below follow the documented request/response shapes and ENFORCE the encryption-context binding (a
wrapped key opened under another context fails), so these tests exercise real adapter logic. They are NOT live
tests: no AWS account or Vault server was contacted (see docs/key-management.md)."""
from __future__ import annotations

import base64
import json
import os
import re

import pytest
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from app.crypto.envelope import KeyError_
from app.integrations import kms as K
from app.services import key_wrap as kw


class FakeClientError(Exception):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.response = {"Error": {"Code": code}}


class FakeAwsKms:
    """boto3 'kms' client stand-in: AES-GCM with the EncryptionContext as AAD."""

    def __init__(self) -> None:
        self._k = AESGCM.generate_key(256)
        self.calls: list[str] = []

    @staticmethod
    def _aad(ctx: dict) -> bytes:
        return json.dumps(ctx, sort_keys=True).encode()

    def encrypt(self, KeyId, Plaintext, EncryptionContext):  # noqa: N803
        self.calls.append("encrypt")
        n = os.urandom(12)
        return {"CiphertextBlob": n + AESGCM(self._k).encrypt(n, Plaintext, self._aad(EncryptionContext))}

    def decrypt(self, CiphertextBlob, KeyId, EncryptionContext):  # noqa: N803
        self.calls.append("decrypt")
        try:
            return {"Plaintext": AESGCM(self._k).decrypt(CiphertextBlob[:12], CiphertextBlob[12:],
                                                         self._aad(EncryptionContext))}
        except Exception:
            raise FakeClientError("InvalidCiphertextException")


class FakeVault:
    """Transport for /v1/transit/{encrypt,decrypt}/<key> on a derived key (context = AAD)."""

    def __init__(self, token: str = "s.tok") -> None:
        self._k, self.token, self.requests = AESGCM.generate_key(256), token, []

    def __call__(self, method, url, headers, body):
        self.requests.append((method, url))
        if headers.get("X-Vault-Token") != self.token:
            return 403, '{"errors":["permission denied"]}'
        op = re.search(r"/v1/transit/(encrypt|decrypt)/", url).group(1)
        req = json.loads(body)
        ctx = base64.b64decode(req["context"])
        try:
            if op == "encrypt":
                n = os.urandom(12)
                ct = n + AESGCM(self._k).encrypt(n, base64.b64decode(req["plaintext"]), ctx)
                return 200, json.dumps({"data": {"ciphertext": "vault:v1:" + base64.b64encode(ct).decode()}})
            raw = base64.b64decode(req["ciphertext"].split(":", 2)[2])
            pt = AESGCM(self._k).decrypt(raw[:12], raw[12:], ctx)
            return 200, json.dumps({"data": {"plaintext": base64.b64encode(pt).decode()}})
        except Exception:
            return 400, '{"errors":["invalid ciphertext or context"]}'


def test_aws_roundtrip_binds_context_and_key_wrap_integration():
    client = FakeAwsKms()
    p = K.AwsKms("alias/secureshare", "eu-west-1", client=client)
    dek, wrapped, ref, ver = kw.wrap_new_dek(p, "aws", "doc-1", 1)
    assert ref == "kms_aws"
    assert kw.unwrap_any("any-master", p, "aws", wrapped, ref, ver, "doc-1", 1) == dek
    with pytest.raises(KeyError_):                      # another document id => other EncryptionContext
        kw.unwrap_any("any-master", p, "aws", wrapped, ref, ver, "doc-2", 1)
    with pytest.raises(KeyError_):                      # the master secret can NOT open a KMS-wrapped key
        kw.unwrap_dek("any-master", wrapped, "kek_v1_gcm", ver, "doc-1", 1)
    assert p.selftest().live_verified is True


def test_aws_outage_is_provider_unavailable_not_a_key_error():
    class Down:
        def encrypt(self, **_): raise ConnectionError("endpoint unreachable")
        def decrypt(self, **_): raise ConnectionError("endpoint unreachable")
    p = K.AwsKms("k", client=Down())
    with pytest.raises(K.KmsUnavailable):
        p.wrap(b"x" * 32, b"aad")


def test_aws_requires_key_id_and_credentials(monkeypatch):
    with pytest.raises(K.KmsUnavailable):
        K.AwsKms("", client=object())
    import sys, types
    boto3 = types.SimpleNamespace(session=types.SimpleNamespace(Session=lambda: types.SimpleNamespace(
        get_credentials=lambda: None)))
    monkeypatch.setitem(sys.modules, "boto3", boto3)
    with pytest.raises(K.KmsUnavailable, match="credentials"):
        K.AwsKms("alias/x")


def test_vault_roundtrip_context_binding_and_bad_token():
    t = FakeVault()
    p = K.VaultTransitKms("https://vault.example.com:8200", "s.tok", "secureshare", transport=t)
    dek, wrapped, ref, ver = kw.wrap_new_dek(p, "vault", "doc-9", 2)
    assert ref == "kms_vault" and ver == "1"
    assert kw.unwrap_any("m", p, "vault", wrapped, ref, ver, "doc-9", 2) == dek
    with pytest.raises(KeyError_):
        kw.unwrap_any("m", p, "vault", wrapped, ref, ver, "doc-9", 3)
    assert t.requests[0][1] == "https://vault.example.com:8200/v1/transit/encrypt/secureshare"
    bad = K.VaultTransitKms("https://vault.example.com:8200", "wrong", "secureshare", transport=t)
    with pytest.raises(KeyError_):
        bad.wrap(b"x" * 32, b"aad")
    assert p.selftest().live_verified is True


def test_vault_refuses_plain_http_remote_and_missing_config():
    with pytest.raises(K.KmsUnavailable):
        K.VaultTransitKms("http://vault.example.com:8200", "t", "k")
    with pytest.raises(K.KmsUnavailable):
        K.VaultTransitKms("", "", "")
    K.VaultTransitKms("http://127.0.0.1:8200", "t", "k", transport=FakeVault("t"))   # localhost dev server is fine


def test_vault_network_failure_is_provider_unavailable():
    def boom(*_a): raise TimeoutError("timed out")
    p = K.VaultTransitKms("https://v.example.com", "t", "k", transport=boom)
    with pytest.raises(K.KmsUnavailable):
        p.wrap(b"x" * 32, b"aad")


def test_build_kms_never_falls_back_to_local_key():
    from app.config.settings import get_settings
    s = get_settings()
    for backend in ("aws", "vault", "azure", "hsm"):
        s2 = s.model_copy(update={"kms_backend": backend, "kms_aws_key_id": "", "vault_addr": ""})
        with pytest.raises(K.KmsUnavailable):
            K.build_kms(s2)
        st = K.kms_status(s2)
        assert st.available is False and "PROVIDER_UNAVAILABLE" in st.detail


@pytest.mark.asyncio
async def test_documents_are_encrypted_with_the_kms_and_old_local_rows_still_open(db, monkeypatch):
    """Real DocumentService upload -> storage -> download with the (fake) AWS KMS as the key provider."""
    from app.config.settings import get_settings
    from app.models.user import User
    from app.models.document_version import DocumentVersion
    from sqlalchemy import select
    from app.services import documents as docs
    from app.services.documents import DocumentService

    s = get_settings()
    owner = User(email="kms-owner@example.com", hashed_password="x", full_name="Kms Owner", status="ACTIVE")
    db.add(owner); await db.flush()

    local_doc = await DocumentService(db).upload(owner.id, "before.txt", b"stored before KMS switch\n" * 5)
    await db.flush()

    client = FakeAwsKms()
    monkeypatch.setattr(s, "kms_backend", "aws")
    monkeypatch.setattr(docs, "build_kms", lambda settings: K.AwsKms("alias/x", client=client))
    svc = DocumentService(db)
    doc = await svc.upload(owner.id, "after.txt", b"top secret after switch\n" * 5)
    await db.flush()
    ver = (await db.execute(select(DocumentVersion).where(DocumentVersion.document_id == doc.id))).scalar_one()
    assert ver.key_reference == "kms_aws" and "encrypt" in client.calls
    assert b"".join(await svc.open_stream(doc)) == b"top secret after switch\n" * 5
    assert "decrypt" in client.calls
    # a row wrapped by the local KEK before the switch stays readable
    assert b"".join(await svc.open_stream(local_doc)) == b"stored before KMS switch\n" * 5
    # KMS outage => the upload is refused (no silent downgrade to the local key)
    class Down:
        def encrypt(self, **_): raise ConnectionError("down")
    monkeypatch.setattr(docs, "build_kms", lambda settings: K.AwsKms("alias/x", client=Down()))
    from app.core.exceptions import ProviderUnavailableError
    with pytest.raises(ProviderUnavailableError):
        await DocumentService(db).upload(owner.id, "x.txt", b"nope nope nope")
