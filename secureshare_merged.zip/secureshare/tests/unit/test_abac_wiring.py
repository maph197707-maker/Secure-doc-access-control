import unittest
from datetime import datetime
from app.core.enums import Decision, DlpLevel, Permission
from app.services import grants_logic as gl

BASE = dict(action=Permission.VIEW, now=datetime(2026, 10, 2), is_owner=True, user_status_active=True,
            email_verified=True, role_permissions={"DOCUMENT_VIEW"}, grants=[], dlp_level=DlpLevel.NONE)


def d(c, mfa): return gl.decide(**BASE, mfa_verified=mfa, classification=c).decision.decision


class AbacWiring(unittest.TestCase):
    def test_internal_unaffected(self):
        self.assertEqual((d("INTERNAL", False), d(None, False)), (Decision.ALLOW, Decision.ALLOW))

    def test_restricted_and_top_secret_need_mfa(self):
        for c in ("RESTRICTED", "TOP_SECRET"):
            self.assertEqual(d(c, False), Decision.VERIFY)
            self.assertEqual(d(c, True), Decision.ALLOW)

    def test_abac_never_upgrades_a_deny(self):
        r = gl.decide(**{**BASE, "user_status_active": False}, mfa_verified=True, classification="RESTRICTED")
        self.assertEqual(r.decision.decision, Decision.DENY)


if __name__ == "__main__":
    unittest.main()
