import html as htmllib
import json
import re
import shutil
import subprocess
import unittest
from html.parser import HTMLParser
from pathlib import Path

from app.web import templating as T
from app.web.route_table import ALL, is_known_route, shadowed_static_routes
from tests.fixtures.ui_contexts import EXPECTED, NOW, contexts

ROOT = Path(__file__).resolve().parents[2]
ENV = T.build_env()
CTX = contexts()
RENDERED = {name: ENV.get_template(name).render(**ctx) for name, ctx in CTX.items()}
ALLOWED_EXTERNAL = ("https://wa.me/", "https://t.me/share/url", "mailto:")


class Audit(HTMLParser):
    """Tiny HTML accessibility/structure auditor."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids, self.label_for, self.inputs, self.problems = [], set(), [], []
        self.h1, self.links, self.assets, self.actions, self.lang, self.main = 0, [], [], [], None, False
        self._stack = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if a.get("id"): self.ids.append(a["id"])
        if tag == "html": self.lang = a.get("lang")
        if tag == "main" and a.get("id") == "main": self.main = True
        if tag == "h1": self.h1 += 1
        if tag == "label" and a.get("for"): self.label_for.add(a["for"])
        if tag in ("input", "select", "textarea") and a.get("type") != "hidden":
            self.inputs.append((tag, a))
        if tag == "img" and "alt" not in a: self.problems.append(f"img without alt: {a.get('src')}")
        if tag == "img":
            for item in self._stack: item["text"] += a.get("alt", "")   # an image's alt text names its link/button
        if tag == "form" and a.get("action") is not None: self.actions.append(a["action"])
        if tag in ("script", "img") and a.get("src"): self.assets.append(a["src"])
        if tag == "link" and a.get("href"): self.assets.append(a["href"])
        if tag == "script" and not a.get("src"): self.problems.append("inline <script>")
        for k in a:
            if k == "style" or (k.startswith("on") and len(k) > 3 and k[2:].isalpha()): self.problems.append(f"forbidden attribute {k} on <{tag}>")
        if tag in ("a", "button", "summary"):
            self._stack.append({"tag": tag, "a": a, "text": ""})
            if tag == "a" and a.get("href") is not None: self.links.append(a["href"])

    def handle_data(self, data):
        for item in self._stack: item["text"] += data

    def handle_endtag(self, tag):
        if tag in ("a", "button", "summary") and self._stack and self._stack[-1]["tag"] == tag:
            it = self._stack.pop()
            if not it["text"].strip() and not it["a"].get("aria-label") and not it["a"].get("aria-labelledby"):
                self.problems.append(f"<{tag}> without accessible name: {it['a']}")


def audit(name):
    p = Audit(); p.feed(RENDERED[name]); return p


class FilterTests(unittest.TestCase):
    def test_helpers(self):
        self.assertEqual((T.filesize(0), T.filesize(1536), T.filesize(5 * 1024 ** 2)), ("0 B", "1.5 KB", "5.0 MB"))
        self.assertEqual(T.greeting(9), "Good morning"); self.assertEqual(T.greeting(13), "Good afternoon"); self.assertEqual(T.greeting(20), "Good evening")
        self.assertEqual(T.delta_text(5), "+5%"); self.assertEqual(T.delta_text(-2.4), "-2%"); self.assertEqual(T.delta_text(None), "no prior data")
        self.assertEqual(T.relative_time(None), "never")
        self.assertEqual(T.relative_time(NOW, NOW), "just now")

    def test_chart_math(self):
        self.assertEqual(T.chart_points([]), ""); self.assertEqual(T.chart_points([0, 0], 100, 100, 10), "10.0,90.0 90.0,90.0")
        pts = T.chart_points([1, 2, 3], 100, 100, 10).split(" ")
        self.assertEqual(len(pts), 3); self.assertEqual(pts[2], "90.0,10.0")           # max value hits the top
        segs = T.donut_segments([1, 1, 2]); self.assertAlmostEqual(sum(s["pct"] for s in segs), 100, places=0)
        self.assertEqual(T.donut_segments([0, 0]), [])


class RenderTests(unittest.TestCase):
    def test_every_screen_renders_with_expected_labels(self):
        for name, labels in EXPECTED.items():
            text = htmllib.unescape(RENDERED[name])
            for label in labels:
                self.assertIn(label, text, f"{name}: missing {label!r}")

    def test_all_page_templates_are_covered(self):
        pages = {str(p.relative_to(ROOT / "app/templates")).replace("\\", "/") for d in ("auth", "public", "dashboard", "documents", "sharing", "viewer", "analytics", "security", "notifications", "admin", "errors")
                 for p in (ROOT / "app/templates" / d).glob("*.html")}
        self.assertEqual(pages - set(RENDERED), set(), "page templates without a render test")

    def test_strict_undefined_catches_missing_context(self):
        with self.assertRaises(Exception):
            ENV.get_template("dashboard/home.html").render(user=CTX["dashboard/dashboard.html"]["user"], unread=0, csrf_token="x")

    def test_states(self):
        c = dict(CTX["documents/list.html"], docs=[]); self.assertIn("No documents found", ENV.get_template("documents/list.html").render(**c))
        c = dict(CTX["viewer/viewer.html"], stopped=True, stopped_reason="The owner revoked this link."); out = ENV.get_template("viewer/viewer.html").render(**c)
        self.assertIn("The owner revoked this link.", out); self.assertNotIn('class="page-img', out)       # nothing delivered after revocation
        c = dict(CTX["auth/verify_email.html"], status="success"); self.assertIn("Your email is verified", ENV.get_template("auth/verify_email.html").render(**c))
        c = dict(CTX["sharing/link_ready.html"], full_link=None); out = ENV.get_template("sharing/link_ready.html").render(**c)
        self.assertIn("Rotate Link", out); self.assertNotIn("share.example.test/share/TOKEN", out)       # full link only at creation
        c = dict(CTX["auth/login.html"], oauth={"google": True, "microsoft": True}); self.assertIn('href="/oauth/google"', ENV.get_template("auth/login.html").render(**c))

    def test_disabled_provider_controls_show_reason_and_no_link(self):
        out = RENDERED["auth/login.html"]
        self.assertNotIn('href="/oauth/google"', out); self.assertRegex(out, r"<button[^>]*disabled[^>]*>.*?Google")
        self.assertIn("Not configured by the administrator", out)


class SecurityLintTests(unittest.TestCase):
    def test_no_xss_in_user_controlled_fields(self):
        evil = "<script>alert(1)</script>"
        out = ENV.get_template("dashboard/dashboard.html").render(**dict(CTX["dashboard/dashboard.html"], user={**CTX["dashboard/dashboard.html"]["user"], "name": evil}))
        self.assertNotIn(evil, out); self.assertIn("&lt;script&gt;", out)
        out = ENV.get_template("documents/list.html").render(**dict(CTX["documents/list.html"], docs=[{**CTX["documents/list.html"]["docs"][0], "name": '"><img src=x onerror=alert(1)>'}]))
        self.assertNotIn("<img src=x", out)
        out = ENV.get_template("auth/login.html").render(**dict(CTX["auth/login.html"], email='" autofocus onfocus="alert(1)', error="<b>x</b>"))
        self.assertNotIn('onfocus="alert', out); self.assertIn("&lt;b&gt;", out)

    def test_password_values_are_never_echoed(self):
        out = ENV.get_template("auth/register.html").render(**dict(CTX["auth/register.html"], values={"email": "a@b.test", "password": "Secret-Pass-123"}))
        self.assertNotIn("Secret-Pass-123", out)

    def test_template_sources_follow_csp_rules(self):
        for f in (ROOT / "app/templates").rglob("*.html"):
            src = f.read_text(encoding="utf-8")
            self.assertNotRegex(src, r"<script(?![^>]*\bsrc=)", f.name)
            self.assertNotRegex(src, r"\sstyle\s*=", f.name); self.assertNotRegex(src, r"\son[a-z]+\s*=", f.name)
            self.assertNotIn("javascript:", src, f.name)
            self.assertNotRegex(src, r"(?:src|href)=\"https?://(?!wa\.me|t\.me)", f.name)

    def test_no_hardcoded_sample_data(self):
        banned = ["98/100", "1,482", "John Doe", "DOC-775641", "Arun Kumar", "Sneha Reddy", "Rohit Sharma"]
        for f in list((ROOT / "app/templates").rglob("*.html")) + list((ROOT / "app/static/js").glob("*.js")):
            text = re.sub(r"<[^>]+>", " ", re.sub(r"\{#.*?#\}", "", f.read_text(encoding="utf-8"), flags=re.S))
            for b in banned: self.assertNotIn(b, text, f"{f.name} contains sample data {b!r}")
            self.assertNotRegex(text, r"\b(?:248|892)\b", f.name)

    def test_rendered_assets_are_local(self):
        for name in RENDERED:
            for a in audit(name).assets: self.assertTrue(a.startswith("/static/"), f"{name}: external asset {a}")


class LinkAuditTests(unittest.TestCase):
    def test_route_table_has_no_shadowed_static_routes(self):
        self.assertEqual(shadowed_static_routes(ALL), [])

    def test_all_internal_links_resolve(self):
        for name in RENDERED:
            p = audit(name)
            for href in p.links + p.actions + p.assets:
                if href in ("", "#") or href.startswith(("#", "?")) or href.startswith(ALLOWED_EXTERNAL): continue
                self.assertTrue(href.startswith("/"), f"{name}: unexpected link {href!r}")
                if href.startswith("/static/"):
                    self.assertTrue((ROOT / "app" / href.lstrip("/").split("?")[0]).is_file(), f"{name}: missing static file {href}")
                else:
                    self.assertTrue(is_known_route(href), f"{name}: link to unknown route {href}")

    def test_static_files_referenced_by_pwa_exist(self):
        sw = (ROOT / "app/static/service-worker.js").read_text()
        for path in re.findall(r"'(/static/[^']+)'", sw): self.assertTrue((ROOT / "app" / path.lstrip("/")).is_file(), path)
        manifest = json.loads((ROOT / "app/static/manifest.webmanifest").read_text())
        for icon in manifest["icons"]: self.assertTrue((ROOT / "app" / icon["src"].lstrip("/")).is_file())
        self.assertNotIn("/api/", sw); self.assertIn("startsWith('/static/')", sw)             # never caches private data


class AccessibilityTests(unittest.TestCase):
    def test_structure_and_names(self):
        for name in RENDERED:
            p = audit(name)
            self.assertEqual(p.problems, [], name)
            if True:
                self.assertEqual(p.lang, "en", name)
                self.assertEqual(p.h1, 1, f"{name}: needs exactly one h1"); self.assertTrue(p.main, f"{name}: missing main#main")
            self.assertEqual(len(p.ids), len(set(p.ids)), f"{name}: duplicate ids {[i for i in p.ids if p.ids.count(i) > 1]}")
            for tag, a in p.inputs:
                ok = a.get("aria-label") or a.get("aria-labelledby") or (a.get("id") in p.label_for)
                self.assertTrue(ok, f"{name}: unlabeled <{tag}> {a}")

    def test_mobile_requirements_present(self):
        out = RENDERED["dashboard/dashboard.html"]
        self.assertIn('class="bottom-nav"', out); self.assertIn('name="viewport"', out)
        self.assertIn("Skip to main content", out)
        css = (ROOT / "app/static/css/layout.css").read_text()
        self.assertIn("max-width:767px", css); self.assertIn("min-height:var(--tap)", css)
        self.assertIn("--tap:44px", (ROOT / "app/static/css/tokens.css").read_text())
        self.assertIn("prefers-reduced-motion", (ROOT / "app/static/css/base.css").read_text())


def _lum(hexc):
    r, g, b = [int(hexc[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def ratio(a, b):
    la, lb = sorted((_lum(a), _lum(b)), reverse=True); return (la + 0.05) / (lb + 0.05)


def tokens(block):
    return dict(re.findall(r"--([a-z0-9-]+):\s*(#[0-9A-Fa-f]{6})", block))


class ContrastTests(unittest.TestCase):
    css = (ROOT / "app/static/css/tokens.css").read_text()
    light = tokens(css.split(':root[data-theme="dark"]')[0])
    dark = {**light, **tokens(css.split(':root[data-theme="dark"]')[1].split("}")[0])}

    def test_wcag_aa_light(self):
        L = self.light
        for fg, bg in [("text-primary", "surface"), ("text-primary", "background"), ("text-secondary", "surface"), ("text-secondary", "background"), ("text-secondary", "surface-secondary"),
                       ("text-primary", "surface-secondary"), ("success", "success-bg"), ("warning", "warning-bg"), ("danger", "danger-bg"),
                       ("accent-2-text", "ai-bg"), ("primary-text", "info-bg"), ("primary-text", "surface-secondary"), ("primary-text", "surface"), ("primary", "surface"), ("danger", "surface"), ("success", "surface")]:
            self.assertGreaterEqual(ratio(L[fg], L[bg]), 4.5, f"light: {fg} on {bg} = {ratio(L[fg], L[bg]):.2f}")

    def test_wcag_aa_dark(self):
        D = self.dark
        for fg, bg in [("text-primary", "surface"), ("text-primary", "background"), ("text-secondary", "surface"), ("text-secondary", "background"), ("text-secondary", "surface-secondary"), ("text-primary", "surface-secondary"), ("primary-text", "surface"), ("primary-text", "background")]:
            self.assertGreaterEqual(ratio(D[fg], D[bg]), 4.5, f"dark: {fg} on {bg} = {ratio(D[fg], D[bg]):.2f}")

    def test_white_text_on_brand_gradient_stops(self):
        stops = re.findall(r"--grad-brand:linear-gradient\(90deg,(#[0-9A-Fa-f]{6}) 0%,(#[0-9A-Fa-f]{6}) 100%\)", self.css)[0]
        for s in stops: self.assertGreaterEqual(ratio("#FFFFFF", s), 4.5, f"white on {s} = {ratio('#FFFFFF', s):.2f}")


class JsTests(unittest.TestCase):
    @unittest.skipUnless(shutil.which("node"), "node not installed")
    def test_js_syntax_and_pure_functions(self):
        for f in list((ROOT / "app/static/js").glob("*.js")) + [ROOT / "app/static/service-worker.js"]:
            r = subprocess.run(["node", "--check", str(f)], capture_output=True, text=True); self.assertEqual(r.returncode, 0, f"{f.name}: {r.stderr}")
        r = subprocess.run(["node", str(ROOT / "tests/js/pure_functions.mjs")], capture_output=True, text=True); self.assertEqual(r.returncode, 0, r.stderr + r.stdout)

    def test_js_never_uses_innerhtml_or_eval(self):
        for f in (ROOT / "app/static/js").glob("*.js"):
            src = f.read_text(); self.assertNotRegex(src, r"\.innerHTML\s*=|\beval\(|document\.write\(|new Function\(", f.name)


if __name__ == "__main__":
    unittest.main()
