"""RESTRICT is enforced, never upgraded; pure, runs offline."""
import unittest
from datetime import datetime

from app.core.enums import Decision as D, DlpLevel, Permission as P
from app.services import grants_logic as gl
from app.services.zero_trust import enforce_restrictions

BASE = dict(now=datetime(2026, 10, 3), is_owner=True, user_status_active=True, email_verified=True,
            role_permissions={"DOCUMENT_VIEW", "DOCUMENT_DOWNLOAD"}, grants=[], dlp_level=DlpLevel.NONE)


class EnforceRestrictions(unittest.TestCase):
    def high_risk(self, action):
        return gl.decide(action=action, **BASE, mfa_verified=True, risk_score=60,
                         risk_level=__import__("app.core.enums", fromlist=["RiskLevel"]).RiskLevel.HIGH).decision

    def test_high_risk_with_mfa_restricts_download_only(self):
        dl = self.high_risk(P.DOWNLOAD)
        self.assertEqual(dl.decision, D.RESTRICT)
        self.assertEqual(enforce_restrictions(dl, P.DOWNLOAD).decision, D.DENY)
        self.assertEqual(enforce_restrictions(dl, P.VIEW).decision, D.RESTRICT)

    def test_non_restrict_decisions_pass_through_unchanged(self):
        allow = gl.decide(action=P.DOWNLOAD, **BASE).decision
        self.assertIs(enforce_restrictions(allow, P.DOWNLOAD), allow)


if __name__ == "__main__":
    unittest.main()
