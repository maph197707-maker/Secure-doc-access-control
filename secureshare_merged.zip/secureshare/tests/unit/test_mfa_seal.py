"""Pure tests (no FastAPI/DB): sealing of the TOTP secret, recovery codes, TOTP replay protection."""
from __future__ import annotations

from app.integrations.state import InMemoryStateStore
from app.services import mfa

MASTER = "m" * 32


def test_secret_is_sealed_and_bound_to_user():
    secret = mfa.new_secret()
    sealed = mfa.seal_secret(secret, MASTER, "user-1")
    assert secret not in sealed and sealed.startswith("v1.")
    assert mfa.open_secret(sealed, MASTER, "user-1") == secret
    assert mfa.open_secret(sealed, MASTER, "user-2") is None          # pasted onto another account
    assert mfa.open_secret(sealed, "x" * 32, "user-1") is None        # wrong master secret
    assert mfa.open_secret(sealed[:-3] + "AAA", MASTER, "user-1") is None   # tampered
    assert mfa.open_secret("garbage", MASTER, "user-1") is None


def test_sealing_is_randomised():
    s = mfa.new_secret()
    assert mfa.seal_secret(s, MASTER, "u") != mfa.seal_secret(s, MASTER, "u")


def test_looks_like_totp():
    assert mfa.looks_like_totp("123456") and mfa.looks_like_totp(" 123 456 ")
    assert not mfa.looks_like_totp("abcd-1234-ef56") and not mfa.looks_like_totp("12345")


def test_totp_ok_then_replay_rejected_then_lockout():
    store, secret = InMemoryStateStore(), mfa.new_secret()
    code = mfa.totp_at(secret)
    assert mfa.verify_totp(store, "u", secret, code) == mfa.MfaResult.OK
    assert mfa.verify_totp(store, "u", secret, code) == mfa.MfaResult.REPLAYED
    for _ in range(mfa.MAX_ATTEMPTS - 1):
        assert mfa.verify_totp(store, "u", secret, "000000") == mfa.MfaResult.WRONG
    assert mfa.verify_totp(store, "u", secret, "000000") == mfa.MfaResult.LOCKED
    assert mfa.verify_totp(store, "u", secret, mfa.totp_at(secret)) == mfa.MfaResult.LOCKED


def test_recovery_codes_are_single_use_and_hashed():
    plain, hashed = mfa.generate_recovery_codes()
    assert len(plain) == len(hashed) == 10 and all(p not in h for p, h in zip(plain, hashed))
    ok, left = mfa.consume_recovery_code(hashed, plain[0].upper())
    assert ok and len(left) == 9
    assert mfa.consume_recovery_code(left, plain[0]) == (False, left)
    assert mfa.consume_recovery_code(left, "nope")[0] is False


def test_challenge_expires_and_closes():
    store = InMemoryStateStore()
    cid = mfa.open_challenge(store, "u")
    assert mfa.resolve_challenge(store, cid) == "u"
    mfa.close_challenge(store, cid)
    assert mfa.resolve_challenge(store, cid) is None
