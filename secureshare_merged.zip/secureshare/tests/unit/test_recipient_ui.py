"""Renders the wizard steps 3-4 and the recipient page with plain Jinja2 (no DB, no FastAPI)."""
import re
import unittest

from app.web import templating as T

ENV = T.build_env()
APP = {"user": {"name": "Asha Verma", "initials": "AV", "role": "USER", "email": "a@x.test"}, "unread": 0,
       "csrf_token": "tok", "request_id": "r1"}
MODES = [("NONE", "Anyone with the link (password optional)", True, ""),
         ("EMAIL_OTP", "Recipient email: one-time code by email", True, ""),
         ("PHONE_OTP", "Recipient phone: one-time code by SMS", False, "SMS delivery is not configured")]
DOC = {"id": "d1", "name": "r.pdf", "size": 10}


def wizard(step, draft=None, error=None):
    return ENV.get_template("sharing/wizard.html").render(
        **APP, step=step, doc=DOC, docs=[], draft=draft or {}, error=error, idempotency_key="k1",
        binding_modes=MODES, types_label="PDF", max_mb=50, accept=".pdf")


class WizardRenderTests(unittest.TestCase):
    def test_step3_offers_modes_phone_field_and_disables_unavailable(self):
        html = wizard(3, {"binding_mode": "EMAIL_OTP", "recipient_email": "bob@x.test"})
        self.assertIn('name="recipient_phone"', html); self.assertIn('id="phone-box" hidden', html)
        self.assertRegex(html, r'<option value="EMAIL_OTP" selected>')
        self.assertRegex(html, r'<option value="PHONE_OTP" disabled>.*unavailable: SMS delivery is not configured')
        self.assertIn('value="bob@x.test"', html)

    def test_step3_defaults_to_no_binding(self):
        self.assertRegex(wizard(3), r'<option value="NONE" selected>')

    def test_step2_carries_timezone_field(self):
        html = wizard(2, {"tz": "Asia/Kolkata"})
        self.assertIn('name="tz" value="Asia/Kolkata" data-tz', html); self.assertIn("Asia/Kolkata", html)

    def test_review_shows_mode_and_zoned_expiry(self):
        html = wizard(4, {"binding_mode": "PHONE_OTP", "recipient_email": "b@x.test", "link_expiry": True,
                          "expires_at": "2026-10-05T10:00", "tz": "Asia/Kolkata"})
        self.assertIn("One-time code by SMS", html); self.assertIn("2026-10-05T10:00 (Asia/Kolkata)", html)

    def test_no_inline_script_or_handlers(self):
        for step in (2, 3, 4):
            html = wizard(step)
            self.assertNotRegex(html, r"<script(?![^>]*src=)"); self.assertNotRegex(html, r"\son[a-z]+=")

    def test_error_is_escaped(self):
        self.assertIn("&lt;b&gt;", wizard(3, error="<b>x</b>"))


class RecipientPageTests(unittest.TestCase):
    def render(self, **kw):
        ctx = dict(csrf_token="t", token="abc", stage="claim", via="email", error=None, notice=None, pending="", email="")
        return ENV.get_template("public/recipient_verify.html").render(**{**ctx, **kw})

    def test_claim_stage(self):
        html = self.render()
        self.assertIn('action="/view/abc/claim"', html); self.assertIn('type="email"', html)
        self.assertNotIn("data-otp", html)

    def test_code_stage_posts_pending_and_wording_follows_channel(self):
        email = self.render(stage="code", pending="r1.123.sig")
        self.assertIn('action="/view/abc/code"', email); self.assertIn('name="pending" value="r1.123.sig"', email)
        self.assertIn("we emailed you", email)
        self.assertIn("we texted you", self.render(stage="code", via="phone", pending="p"))

    def test_user_values_are_escaped(self):
        html = self.render(email='"><script>x</script>', error="<i>")
        self.assertNotIn("<script>x", html); self.assertIn("&lt;i&gt;", html)


if __name__ == "__main__":
    unittest.main()
