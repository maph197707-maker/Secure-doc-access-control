import unittest
from types import SimpleNamespace as R
from app.services.audit import GENESIS, chain_hash, event_payload, rows_to_records, verify_chain, merkle_root


def build(n):
    rows, prev = [], GENESIS
    for i in range(1, n + 1):
        d = {"k": i}
        h = chain_hash(prev, event_payload(i, "A", "u", "document", "d", d))
        rows.append(R(sequence_number=i, action="A", user_id="u", resource_type="document", resource_id="d",
                      details=d, prev_hash=prev, entry_hash=h)); prev = h
    return rows


class AuditRows(unittest.TestCase):
    def test_roundtrip_ok(self):
        self.assertTrue(verify_chain(rows_to_records(build(5))).ok)

    def test_tamper_detected(self):
        rows = build(5); rows[2].details = {"k": 999}
        r = verify_chain(rows_to_records(rows)); self.assertFalse(r.ok); self.assertEqual(r.broken_at, 3)

    def test_deletion_detected(self):
        rows = build(5); del rows[1]
        self.assertFalse(verify_chain(rows_to_records(rows)).ok)

    def test_merkle_changes_on_tamper(self):
        rows = build(4); a = merkle_root([r.entry_hash for r in rows]); rows[1].entry_hash = "f" * 64
        self.assertNotEqual(a, merkle_root([r.entry_hash for r in rows]))


if __name__ == "__main__":
    unittest.main()
