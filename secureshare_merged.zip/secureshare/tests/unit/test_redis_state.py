import unittest
from types import SimpleNamespace

from app.integrations.state import InMemoryStateStore, RedisStateStore, build_state_store


class FakeRedis:
    """Just enough of redis-py (decode_responses=True) for RedisStateStore."""
    def __init__(self):
        self.d, self.exp, self.now = {}, {}, 0.0

    def _live(self, k):
        if k in self.exp and self.exp[k] <= self.now:
            self.d.pop(k, None); self.exp.pop(k, None)
        return k in self.d

    def incr(self, k):
        self._live(k); self.d[k] = str(int(self.d.get(k, "0")) + 1); return int(self.d[k])
    def pexpire(self, k, ms): self.exp[k] = self.now + ms / 1000
    def pttl(self, k):
        if not self._live(k): return -2
        return -1 if k not in self.exp else int((self.exp[k] - self.now) * 1000)
    def get(self, k): return self.d[k] if self._live(k) else None
    def set(self, k, v, px=None):
        self.d[k] = v
        if px: self.exp[k] = self.now + px / 1000
    def delete(self, k): self.d.pop(k, None); self.exp.pop(k, None)


class RedisStoreTests(unittest.TestCase):
    def setUp(self):
        self.r = FakeRedis(); self.s = RedisStateStore(self.r)

    def test_json_roundtrip_and_ttl(self):
        self.s.set("otp:a", {"h": "x", "attempts": 2}, 10)
        self.assertEqual(self.s.get("otp:a"), {"h": "x", "attempts": 2})
        self.assertAlmostEqual(self.s.ttl("otp:a"), 10, delta=0.01)
        self.r.now += 11
        self.assertIsNone(self.s.get("otp:a")); self.assertEqual(self.s.ttl("otp:a"), 0.0)

    def test_incr_fixed_window(self):
        self.assertEqual(self.s.incr("k", 10), 1)
        self.r.now += 5
        self.assertEqual(self.s.incr("k", 10), 2)
        self.assertAlmostEqual(self.s.ttl("k"), 5, delta=0.01)          # not extended
        self.r.now += 6
        self.assertEqual(self.s.incr("k", 10), 1)
        self.assertEqual(self.s.get("k"), 1)

    def test_incr_heals_missing_ttl(self):
        self.r.d["ss:k"] = "7"                                           # crashed creator: no TTL
        self.assertEqual(self.s.incr("k", 30), 8)
        self.assertGreater(self.s.ttl("k"), 0)

    def test_delete_and_prefix(self):
        self.s.set("a", True, 5); self.s.delete("a")
        self.assertIsNone(self.s.get("a")); self.assertTrue(all(k.startswith("ss:") for k in self.r.d))

    def test_build_selects_backend(self):
        lite = SimpleNamespace(redis_url=None, app_mode="lite", is_production=False)
        self.assertIsInstance(build_state_store(lite), InMemoryStateStore)
        bad = SimpleNamespace(redis_url="redis://127.0.0.1:1/0", app_mode="full", is_production=False)
        self.assertIsInstance(build_state_store(bad), InMemoryStateStore)    # dev: falls back
        prod = SimpleNamespace(redis_url="redis://127.0.0.1:1/0", app_mode="full", is_production=True)
        with self.assertRaises(RuntimeError):
            build_state_store(prod)


if __name__ == "__main__":
    unittest.main()
