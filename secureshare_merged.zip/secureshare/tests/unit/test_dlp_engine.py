"""DLP engine: validated detection, no false positives on look-alikes, masking, redaction."""
from app.core.enums import DlpAction, DlpLevel
from app.services import dlp


def _aadhaar() -> str:
    base = "23456789012"
    return next(base + c for c in "0123456789" if dlp.verhoeff_ok(base + c))


def rules(text):
    return {f.rule_name for f in dlp.scan_text(text).findings}


def test_valid_card_detected_invalid_luhn_ignored():
    assert "credit_card" in rules("card 4111 1111 1111 1111")
    assert "credit_card" not in rules("card 4111 1111 1111 1112")
    assert "credit_card" not in rules("order 0000 0000 0000 0000")


def test_aadhaar_requires_verhoeff():
    a = _aadhaar()
    assert "aadhaar" in rules(f"id {a[:4]} {a[4:8]} {a[8:]}")
    assert "aadhaar" not in rules("id 2345 6789 0123")
    assert "aadhaar" not in rules("ref 123456789012")


def test_pan_ssn_iban_checks():
    assert "pan_card" in rules("PAN ABCPD1234E")
    assert "pan_card" not in rules("PAN ABCXD1234E")
    assert "us_ssn" in rules("ssn 123-45-6789") and "us_ssn" not in rules("ssn 000-12-3456")
    assert "iban" in rules("GB82 WEST 1234 5698 7654 32") and "iban" not in rules("GB00 WEST 1234 5698 7654 32")


def test_credentials():
    r = rules("AKIAIOSFODNN7EXAMPLE\n-----BEGIN RSA PRIVATE KEY-----\npassword=correcthorse")
    assert {"aws_access_key", "private_key", "password_assignment"} <= r
    assert "password_assignment" not in rules("password: <your password here>")


def test_levels_and_volume_escalation():
    assert dlp.scan_text("nothing sensitive here").level == DlpLevel.NONE
    assert dlp.scan_text("write to a@example.com").level == DlpLevel.LOW
    many = " ".join(f"user{i}@example.com" for i in range(30))
    assert dlp.scan_text(many).level == DlpLevel.HIGH
    assert dlp.scan_text("4111111111111111").level == DlpLevel.CRITICAL


def test_masked_never_raw():
    rep = dlp.scan_text("4111 1111 1111 1111 and alice@example.com")
    blob = str(rep.to_dict())
    assert "4111 1111" not in blob and "alice@" not in blob
    assert any(f.sample_masked.endswith("1111") for f in rep.findings)


def test_actions():
    assert dlp.action_for(DlpLevel.NONE, DlpLevel.HIGH) == DlpAction.ALLOW
    assert dlp.action_for(DlpLevel.HIGH, None) == DlpAction.WARN
    assert dlp.action_for(DlpLevel.HIGH, DlpLevel.HIGH) == DlpAction.BLOCK
    assert dlp.action_for(DlpLevel.MEDIUM, DlpLevel.HIGH) == DlpAction.WARN


def test_redact_and_bounded_scan():
    out = dlp.redact("pay 4111 1111 1111 1111 now, ref 1234")
    assert "4111" not in out and "[REDACTED:credit_card]" in out and "ref 1234" in out
    rep = dlp.scan_text("x" * (dlp.MAX_SCAN_CHARS + 10))
    assert rep.truncated and rep.chars_scanned == dlp.MAX_SCAN_CHARS
