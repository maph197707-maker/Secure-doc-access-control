import base64, unittest
from app.crypto.envelope import KeyError_, WrappedKey
from app.integrations.kms import LocalKms
from app.integrations.malware import ScanResult, ScanStatus, ClamdScanner
from app.services import key_wrap as kw
from app.services.upload_scan import decide, scan_bytes


class KmsWiring(unittest.TestCase):
    def roundtrip(self, kms, backend):
        dek, w, ref, ver = kw.wrap_new_dek(kms, backend, "doc1", 1)
        self.assertEqual(ref, kw.reference_for_backend(backend))
        self.assertEqual(kw.unwrap_any("m", kms, backend, w, ref, ver, "doc1", 1), dek)
        return dek, w, ref, ver

    def test_local_dev_stays_compatible_with_old_rows(self):
        old = kw.generate_wrapped_dek("secret", "d", 1)
        kms = LocalKms("secret")
        self.assertEqual(kw.unwrap_any("secret", kms, "local_dev", old[1], old[2], old[3], "d", 1), old[0])
        dek, w, ref, ver = kw.wrap_new_dek(kms, "local_dev", "d2", 1)
        self.assertEqual(kw.unwrap_dek("secret", w, ref, ver, "d2", 1), dek)


class ScanPolicy(unittest.TestCase):
    def r(self, s): return ScanResult(s, "e", "d")
    def test_matrix(self):
        self.assertTrue(decide(self.r(ScanStatus.INFECTED)).reject)
        self.assertEqual(decide(self.r(ScanStatus.CLEAN)).db_result, "CLEAN")
        self.assertEqual(decide(self.r(ScanStatus.NO_DETECTION_DEV)).db_result, "DEV_ONLY")
        a = decide(self.r(ScanStatus.PROVIDER_UNAVAILABLE), "allow_with_warning")
        self.assertEqual((a.db_result, a.doc_status, a.reject), ("PROVIDER_UNAVAILABLE", "UPLOADED", False))
        h = decide(self.r(ScanStatus.PROVIDER_UNAVAILABLE), "hold")
        self.assertEqual((h.db_result, h.doc_status), ("PROVIDER_UNAVAILABLE", "QUARANTINED"))

    def test_never_clean_when_clamd_down(self):
        import socket
        s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
        _, d = scan_bytes(ClamdScanner("127.0.0.1", port, timeout=1), b"x", "allow_with_warning")
        self.assertNotEqual(d.db_result, "CLEAN")


if __name__ == "__main__":
    unittest.main()
