"""Secure-link access goes through the real PDP; risk and recipient-session binding are real inputs."""
import unittest
from datetime import datetime, timedelta
from types import SimpleNamespace as N

from app.core.enums import Decision, Permission
from app.security.threat_detection import SecEvent
from app.services import link_access as la, recipient_gate as gate
from app.services.risk import _AUDIT_KIND, score_events

NOW = datetime(2026, 10, 3, 12, 0)
V, D = Permission.VIEW, Permission.DOWNLOAD


def link(**kw):
    base = dict(status="ACTIVE", reputation="NORMAL", binding_mode="NONE", requires_mfa=False,
                device_binding_required=False, allow_downloads=True, allow_print=False, allow_copy=False,
                valid_from=None, expires_at=NOW + timedelta(days=1), view_count=0, download_count=0,
                max_views=None, max_downloads=None, one_time_view=False, one_time_download=False)
    base.update(kw); return N(**base)


DOC = N(dlp_level="NONE")


def dec(l=None, action=V, doc=DOC, risk=0, verified=False):
    return la.decide_link_access(l or link(), doc, action, NOW, recipient_verified=verified, risk_score=risk)


class LinkPdp(unittest.TestCase):
    def test_valid_link_allowed(self):
        self.assertEqual((dec().decision, dec(action=D).decision), (Decision.ALLOW, Decision.ALLOW))

    def test_revoked_expired_notstarted_denied_even_with_valid_token(self):
        self.assertIn("LINK_REVOKED", dec(link(status="REVOKED")).reasons)
        self.assertIn("LINK_EXPIRED", dec(link(expires_at=NOW - timedelta(seconds=1))).reasons)
        self.assertIn("LINK_NOT_YET_VALID", dec(link(valid_from=NOW + timedelta(hours=1))).reasons)
        self.assertEqual(dec(link(status="WEIRD")).decision, Decision.DENY)          # unknown status fails closed

    def test_download_not_granted(self):
        d = dec(link(allow_downloads=False), D); self.assertEqual(d.decision, Decision.DENY); self.assertIn("PERMISSION_NOT_GRANTED", d.reasons)

    def test_recipient_binding_required(self):
        l = link(binding_mode="EMAIL_OTP")
        self.assertEqual(dec(l, verified=False).decision, Decision.VERIFY)
        self.assertEqual(dec(l, verified=True).decision, Decision.ALLOW)

    def test_limits(self):
        self.assertIn("VIEW_LIMIT_REACHED", dec(link(max_views=2, view_count=2)).reasons)
        self.assertIn("ONE_TIME_LINK_USED", dec(link(one_time_download=True, download_count=1), D).reasons)

    def test_risk_drives_decision(self):
        self.assertEqual(dec(risk=10).decision, Decision.ALLOW)
        self.assertEqual(dec(risk=60).decision, Decision.VERIFY)          # HIGH needs MFA, none available on links
        self.assertEqual(dec(risk=80).decision, Decision.DENY)            # CRITICAL

    def test_reputation(self):
        self.assertEqual(dec(link(reputation="ABUSED")).decision, Decision.DENY)
        self.assertEqual(dec(link(reputation="SUSPICIOUS")).decision, Decision.VERIFY)
        self.assertEqual(dec(link(reputation="???")).decision, Decision.VERIFY)

    def test_unenforceable_factors_fail_closed(self):
        self.assertEqual(dec(link(requires_mfa=True)).decision, Decision.VERIFY)
        self.assertEqual(dec(link(device_binding_required=True)).decision, Decision.VERIFY)

    def test_dlp_high_blocks_download_and_needs_more(self):
        self.assertEqual(dec(doc=N(dlp_level="HIGH"), action=D, verified=True).decision, Decision.DENY)
        self.assertEqual(dec(doc=N(dlp_level="BOGUS")).decision, Decision.VERIFY)   # unknown level -> strictest

    def test_enforce(self):
        self.assertEqual(la.enforce(dec(), V), (True, ""))
        ok, why = la.enforce(dec(link(status="REVOKED")), V); self.assertFalse(ok); self.assertIn("LINK_REVOKED", why)
        ok, _ = la.enforce(dec(risk=60), V); self.assertFalse(ok)                 # VERIFY is not a pass


class RiskInputs(unittest.TestCase):
    def test_every_mapped_action_is_a_real_audit_action(self):
        import pathlib, re
        src = "\n".join(p.read_text() for p in pathlib.Path("app").rglob("*.py"))
        src += "\n".join(p.read_text() for p in pathlib.Path("app").rglob("*.py"))
        for action in ("ACCESS_DENIED", "SECURE_LINK_DENIED", "SECURE_LINK_PASSWORD_FAIL",
                       "SECURE_LINK_RECIPIENT_CODE_FAIL", "DOCUMENT_UPLOAD"):
            self.assertIn(f'"{action}"', src)
        for a in ("ACCESS_DENIED", "SECURE_LINK_DENIED", "SECURE_LINK_PASSWORD_FAIL", "SECURE_LINK_RECIPIENT_CODE_FAIL"):
            self.assertIn(a, _AUDIT_KIND)

    def test_failures_raise_score_from_real_events(self):
        ev = [SecEvent(id=f"e{i}", kind=_AUDIT_KIND["SECURE_LINK_PASSWORD_FAIL"], at=NOW + timedelta(seconds=i),
                       user_id="link1", ip="1.2.3.4") for i in range(6)]
        r = score_events(ev); self.assertGreaterEqual(r["score"], 25); self.assertTrue(r["reasons"][0]["evidence_ids"])
        self.assertEqual(score_events([])["score"], 0)

    def test_denial_burst_scores(self):
        ev = [SecEvent(id=f"d{i}", kind=_AUDIT_KIND["SECURE_LINK_DENIED"], at=NOW + timedelta(seconds=i),
                       user_id="link1", ip="9.9.9.9") for i in range(11)]
        self.assertGreater(score_events(ev)["score"], 0)

    def test_score_feeds_pdp_end_to_end(self):
        ev = [SecEvent(id=f"e{i}", kind="OTP_FAILED", at=NOW + timedelta(seconds=i), user_id="l", ip="i") for i in range(6)]
        s = score_events(ev)["score"]
        self.assertNotEqual(dec(risk=s + 60).decision, Decision.ALLOW)


class RecipientSessionBinding(unittest.TestCase):
    M = b"m" * 32

    def test_cookie_bound_to_browser(self):
        c = gate.issue_session(self.M, "L", "R", binding=gate.client_binding("Chrome/1"))
        self.assertEqual(gate.session_recipient(self.M, "L", c, binding=gate.client_binding("Chrome/1")), "R")
        self.assertIsNone(gate.session_recipient(self.M, "L", c, binding=gate.client_binding("Firefox/9")))
        self.assertIsNone(gate.session_recipient(self.M, "L", c))               # unbound read of a bound cookie fails

    def test_cookie_not_valid_on_other_link_or_recipient(self):
        c = gate.issue_session(self.M, "L", "R", binding="b")
        self.assertIsNone(gate.session_recipient(self.M, "OTHER", c, binding="b"))
        rid, exp, sig = c.split(".")
        self.assertIsNone(gate.session_recipient(self.M, "L", f"R2.{exp}.{sig}", binding="b"))

    def test_pending_token_cannot_be_replayed_as_session(self):
        p = gate.issue_pending(self.M, "L", "R")
        self.assertIsNone(gate.session_recipient(self.M, "L", p))

    def test_legacy_unbound_still_works(self):
        c = gate.issue_session(self.M, "L", "R"); self.assertEqual(gate.session_recipient(self.M, "L", c), "R")


if __name__ == "__main__":
    unittest.main()
