import unittest
from types import SimpleNamespace as R
from app.services.audit import GENESIS, chain_hash, event_payload, rows_to_records, verify_chain


class VerifyScriptShape(unittest.TestCase):
    def test_script_uses_real_model_fields(self):
        import pathlib, re
        src = pathlib.Path("scripts/verify_audit.py").read_text()
        self.assertNotIn("prev_entry_hash", src)                      # the model column is prev_hash
        cols = pathlib.Path("app/models/audit.py").read_text()
        self.assertIn("prev_hash", cols)

    def test_writer_and_verifier_agree(self):
        d = {"a": 1}; h = chain_hash(GENESIS, event_payload(1, "X", "u", "document", "d", d))
        row = R(sequence_number=1, action="X", user_id="u", resource_type="document", resource_id="d",
                details=d, prev_hash=GENESIS, entry_hash=h)
        self.assertTrue(verify_chain(rows_to_records([row])).ok)


if __name__ == "__main__":
    unittest.main()
