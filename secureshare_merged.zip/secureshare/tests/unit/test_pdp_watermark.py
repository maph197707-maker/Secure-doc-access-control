import unittest
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from PIL import Image, ImageChops
from app.core.enums import Decision as D, DlpLevel, Permission as P, RiskLevel
from app.services.policy_engine import (AccessContext, Principal, Binding, LinkStatus, Reputation, evaluate,
                                        policy_snapshot_hash)
from app.services.watermark import apply_watermark, watermark_lines, ImageTooLarge
import app.services.watermark as wm

NOW = datetime(2026, 10, 1, 12, 0, tzinfo=timezone.utc)


def base(**kw):
    """A fully verified recipient who may VIEW: the happy path. Tests then break exactly one thing."""
    d = dict(action=P.VIEW, now=NOW, principal=Principal.RECIPIENT, granted=frozenset({P.VIEW}),
             link_status=LinkStatus.ACTIVE, binding_required=True, binding=Binding.VERIFIED,
             otp_required=True, otp_verified=True, device_required=True, device_trusted=True,
             expires_at=NOW + timedelta(days=1), max_views=3, policy_id="p1", policy_version=2, correlation_id="c1")
    d.update(kw)
    return AccessContext(**d)


class PdpTests(unittest.TestCase):
    def check(self, ctx, decision, reason=None):
        r = evaluate(ctx)
        self.assertEqual(r.decision, decision, r.reasons)
        if reason: self.assertIn(reason, r.reasons)
        return r

    def test_allow_and_metadata(self):
        r = self.check(base(), D.ALLOW)
        self.assertEqual((r.policy_id, r.policy_version, r.correlation_id), ("p1", 2, "c1"))

    def test_default_deny_and_link_holder_is_not_access(self):
        self.check(AccessContext(action=P.VIEW, now=NOW), D.DENY, "AUTHENTICATION_REQUIRED")
        r = self.check(AccessContext(action=P.VIEW, now=NOW, link_status=LinkStatus.ACTIVE, granted=frozenset({P.VIEW})),
                       D.VERIFY, "IDENTITY_NOT_ESTABLISHED")
        self.assertIn("VERIFY_IDENTITY", r.required_actions)

    def test_denials(self):
        self.check(base(link_status=LinkStatus.REVOKED), D.DENY, "LINK_REVOKED")
        self.check(base(link_status=LinkStatus.EXPIRED), D.DENY, "LINK_EXPIRED")
        self.check(base(expires_at=NOW - timedelta(seconds=1)), D.DENY, "LINK_EXPIRED")
        self.check(base(valid_from=NOW + timedelta(hours=1)), D.DENY, "LINK_NOT_YET_VALID")
        self.check(base(binding=Binding.FAILED), D.DENY, "RECIPIENT_BINDING_FAILED")
        self.check(base(policy_active=False), D.DENY, "POLICY_REVOKED")
        self.check(base(granted=frozenset()), D.DENY, "PERMISSION_NOT_GRANTED")
        self.check(base(views_used=3), D.DENY, "VIEW_LIMIT_REACHED")
        self.check(base(one_time=True, views_used=1), D.DENY, "ONE_TIME_LINK_USED")
        self.check(base(action=P.DOWNLOAD, granted=frozenset({P.DOWNLOAD}), max_downloads=1, downloads_used=1),
                   D.DENY, "DOWNLOAD_LIMIT_REACHED")
        self.check(base(reputation=Reputation.ABUSED), D.DENY, "LINK_ABUSED")
        self.check(base(risk_level=RiskLevel.CRITICAL), D.DENY, "RISK_CRITICAL")
        self.check(base(allowed_hours=(9, 11)), D.DENY, "OUTSIDE_ALLOWED_TIME_WINDOW")
        self.check(base(allowed_hours=(22, 14)), D.ALLOW)  # overnight window wraps

    def test_verify_paths(self):
        self.check(base(binding=Binding.PENDING), D.VERIFY, "RECIPIENT_NOT_VERIFIED")
        self.check(base(otp_verified=False), D.VERIFY, "OTP_REQUIRED")
        self.check(base(device_trusted=False), D.VERIFY, "DEVICE_NOT_TRUSTED")
        self.check(base(mfa_required=True), D.VERIFY, "MFA_REQUIRED")
        self.check(base(reputation=Reputation.SUSPICIOUS), D.VERIFY, "LINK_SUSPICIOUS")
        self.check(base(risk_level=RiskLevel.HIGH), D.VERIFY, "RISK_HIGH")

    def test_precedence_deny_beats_verify(self):
        self.check(base(link_status=LinkStatus.REVOKED, otp_verified=False, mfa_required=True), D.DENY)

    def test_high_risk_with_mfa_is_restricted_not_allowed(self):
        r = self.check(base(risk_level=RiskLevel.HIGH, mfa_verified=True), D.RESTRICT)
        self.assertIs(r.restrictions["download"], False)

    def test_dlp_high_requires_mfa_and_restricts(self):
        self.check(base(dlp_level=DlpLevel.HIGH), D.VERIFY, "MFA_REQUIRED")
        r = self.check(base(dlp_level=DlpLevel.CRITICAL, mfa_verified=True), D.RESTRICT)
        self.assertTrue(r.restrictions["watermark"]); self.assertIs(r.restrictions["download"], False)
        self.assertIs(r.restrictions["print"], False); self.assertTrue(r.restrictions["raise_alert"])
        self.check(base(dlp_level=DlpLevel.HIGH, mfa_verified=True, action=P.DOWNLOAD, granted=frozenset({P.DOWNLOAD}),
                        max_downloads=5), D.DENY, "DLP_DOWNLOAD_BLOCKED")
        self.check(base(dlp_level=DlpLevel.HIGH, mfa_verified=True, action=P.COPY, granted=frozenset({P.COPY})),
                   D.DENY, "DLP_ACTION_BLOCKED")
        self.check(base(dlp_level=DlpLevel.HIGH, mfa_verified=True, action=P.DOWNLOAD, granted=frozenset({P.DOWNLOAD}),
                        max_downloads=5, dlp_allow_download=True), D.RESTRICT)

    def test_user_paths(self):
        owner = AccessContext(action=P.VIEW, now=NOW, principal=Principal.USER, session_active=True,
                              email_verified=True, is_owner=True)
        self.check(owner, D.ALLOW)
        self.check(replace(owner, session_active=False), D.DENY, "SESSION_INVALID")
        self.check(replace(owner, email_verified=False), D.VERIFY, "EMAIL_NOT_VERIFIED")
        other = replace(owner, is_owner=False)
        self.check(other, D.DENY, "RBAC_PERMISSION_MISSING")
        self.check(replace(other, role_permissions=frozenset({"DOCUMENT_VIEW"})), D.DENY, "PERMISSION_NOT_GRANTED")
        self.check(replace(other, role_permissions=frozenset({"DOCUMENT_VIEW"}), granted=frozenset({P.VIEW})), D.ALLOW)

    def test_deterministic_and_snapshot_hash(self):
        self.assertEqual(evaluate(base()), evaluate(base()))
        h = policy_snapshot_hash({"a": 1, "b": [1, 2]})
        self.assertEqual(h, policy_snapshot_hash({"b": [1, 2], "a": 1}))
        self.assertNotEqual(h, policy_snapshot_hash({"a": 2, "b": [1, 2]}))


class WatermarkTests(unittest.TestCase):
    def test_burns_text_keeps_size(self):
        img = Image.new("RGB", (400, 500), "white")
        lines = watermark_lines("jane@example.com", "s" * 16, "d" * 16, NOW, "confidential")
        self.assertIn("CONFIDENTIAL", lines[0]); self.assertIn("jane@example.com", lines[1])
        out = apply_watermark(img, lines)
        self.assertEqual(out.size, img.size)
        self.assertIsNotNone(ImageChops.difference(out, img).getbbox())

    def test_pixel_cap(self):
        old = wm.MAX_PIXELS; wm.MAX_PIXELS = 100
        try:
            with self.assertRaises(ImageTooLarge): apply_watermark(Image.new("RGB", (20, 20)), ["x"])
        finally:
            wm.MAX_PIXELS = old


if __name__ == "__main__":
    unittest.main()
