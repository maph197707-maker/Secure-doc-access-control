import unittest
from app.services.notify_fanout import Recipient, fan_out, plan, SENT, SKIPPED, FAILED, UNAVAILABLE, SenderUnavailable

R = Recipient("u1", "a@b.co", "+919999999999", True, True, True, True)


class FanOut(unittest.TestCase):
    def run_(self, r=R, t="ACCESS_REQUEST", email=None, sms=None):
        log = []
        out = fan_out(r, t, "T", "M", in_app=lambda *a: log.append(("in_app",)),
                      email=email or (lambda *a: log.append(("email", a[0]))),
                      sms=sms or (lambda *a: log.append(("sms", a[0]))))
        return {o.channel: o for o in out}, log

    def test_all_channels(self):
        o, log = self.run_(); self.assertTrue(all(x.status == SENT for x in o.values()))
        self.assertEqual([l[0] for l in log], ["in_app", "email", "sms"])

    def test_non_external_type_in_app_only(self):
        o, _ = self.run_(t="SHARE_UPDATED"); self.assertEqual((o["in_app"].status, o["email"].status, o["sms"].status), (SENT, SKIPPED, SKIPPED))

    def test_unverified_contacts_never_used(self):
        o, log = self.run_(Recipient("u", "a@b.co", "+91x", False, False, True, True)); self.assertEqual(log, [("in_app",)])
        self.assertEqual(o["email"].detail, "no verified email")

    def test_muted(self):
        o, _ = self.run_(Recipient("u", "a@b.co", None, True, False, True, False, frozenset({"ACCESS_REQUEST"})))
        self.assertEqual(o["in_app"].status, SKIPPED)

    def test_failure_isolated_and_unavailable_reported(self):
        def boom(*a): raise RuntimeError("smtp down")
        def na(*a): raise SenderUnavailable("SMS provider not configured")
        o, _ = self.run_(email=boom, sms=na)
        self.assertEqual((o["in_app"].status, o["email"].status, o["sms"].status), (SENT, FAILED, UNAVAILABLE))
        self.assertNotIn("smtp down", o["email"].detail)   # no raw exception text leaked

    def test_no_sender_is_unavailable_not_sent(self):
        out = {o.channel: o for o in fan_out(R, "SECURITY_ALERT", "T", "M", in_app=lambda *a: None)}
        self.assertEqual((out["email"].status, out["sms"].status), (UNAVAILABLE, UNAVAILABLE))


if __name__ == "__main__":
    unittest.main()
