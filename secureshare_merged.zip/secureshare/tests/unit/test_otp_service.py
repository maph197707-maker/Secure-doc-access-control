"""OtpService against a real (SQLite) database: generation, hashing, persistence, verification,
expiry, attempts, cooldown, one-time use, quotas, provider failure and audit hygiene."""
from __future__ import annotations

import re
from datetime import timedelta

import pytest
from sqlalchemy import select, update

from app.core.exceptions import DeliveryError, ProviderUnavailableError, RateLimitExceededError
from app.integrations import errors as E
from app.models.audit import AuditLog
from app.models.otp import DELIVERY_FAILED, PENDING, SUPERSEDED, VERIFIED, OtpChallenge
from app.services import otp as o
from app.services.otp import OtpPurpose, OtpResult, OtpService

DEST = "bob@example.test"


class Mailbox:
    """What the provider receives: the ONLY place the plaintext code is visible."""
    def __init__(self, fail: Exception | None = None):
        self.codes: list[str] = []
        self.fail = fail

    def __call__(self, code: str, minutes: int):
        if self.fail:
            raise self.fail
        self.codes.append(code)


async def _send(svc, box, *, subject="u1", dest=DEST, purpose=OtpPurpose.EMAIL_VERIFY, channel="email", **kw):
    return await svc.send(purpose=purpose, subject=subject, destination=dest, channel=channel, deliver=box, **kw)


async def _verify(svc, code, *, subject="u1", dest=DEST, purpose=OtpPurpose.EMAIL_VERIFY):
    return await svc.verify(purpose=purpose, subject=subject, destination=dest, code=code)


def _wrong(code: str) -> str:
    return "000000" if code != "000000" else "111111"


async def _rows(db) -> list[OtpChallenge]:
    return list((await db.execute(select(OtpChallenge).order_by(OtpChallenge.created_at))).scalars())


async def _skip_cooldown(db):
    await db.execute(update(OtpChallenge).values(resend_available_at=o.utcnow() - timedelta(seconds=1)))
    await db.commit()


# ── generation & hashing ─────────────────────────────────────────────────────
def test_code_generation_is_six_digits_and_varies():
    codes = {o.generate_code() for _ in range(200)}
    assert all(re.fullmatch(r"\d{6}", c) for c in codes)
    assert len(codes) > 150                                           # not constant / not a tiny space


def test_code_generation_uses_the_secrets_module(monkeypatch):
    calls = []
    monkeypatch.setattr(o.secrets, "choice", lambda alphabet: calls.append(1) or "7")
    assert o.generate_code() == "777777" and len(calls) == 6


def test_hash_is_keyed_deterministic_and_bound_to_the_challenge():
    k1, k2 = o.derive_key("a" * 32), o.derive_key("b" * 32)
    h = o.hash_code(k1, "c1", "123456")
    assert h == o.hash_code(k1, "c1", "123456") and re.fullmatch(r"[0-9a-f]{64}", h)
    assert h != o.hash_code(k2, "c1", "123456")                       # other server key
    assert h != o.hash_code(k1, "c2", "123456")                       # other challenge
    assert h != o.hash_code(k1, "c1", "123457")
    assert "123456" not in h


def test_normalize_code_accepts_only_six_ascii_digits():
    assert o.normalize_code(" 123 456 ") == "123456" and o.normalize_code("123-456") == "123456"
    for bad in (None, "", "12345", "1234567", "abcdef", "12345a", "١٢٣٤٥٦"):
        assert o.normalize_code(bad) is None


# ── persistence ──────────────────────────────────────────────────────────────
@pytest.mark.anyio
async def test_only_the_hash_is_stored_with_expiry_attempts_and_cooldown(db):
    svc, box = OtpService(db), Mailbox()
    receipt = await _send(svc, box); await db.commit()
    (row,) = await _rows(db)
    code = box.codes[0]
    assert row.status == PENDING and row.attempt_count == 0 and row.max_attempts == svc.settings.otp_max_attempts
    assert row.otp_hash == o.hash_code(svc._key, row.id, code) and code not in row.otp_hash
    assert row.expires_at > o.utcnow() and row.resend_available_at > o.utcnow() and row.sent_at is not None
    for value in vars(row).values():                                   # no column holds the code or the raw address
        assert str(value) != code and DEST not in str(value)
    assert receipt.destination_hint == "b**@example.test" and receipt.expires_in == 600 and receipt.resend_after == 30


# ── verification ─────────────────────────────────────────────────────────────
@pytest.mark.anyio
async def test_correct_code_verifies_once_and_marks_the_row(db):
    svc, box = OtpService(db), Mailbox()
    await _send(svc, box); await db.commit()
    assert await _verify(svc, box.codes[0]) is OtpResult.OK
    await db.commit()
    (row,) = await _rows(db)
    assert row.status == VERIFIED and row.verified_at is not None


@pytest.mark.anyio
async def test_wrong_code_is_rejected_and_the_attempt_is_persisted(db):
    svc, box = OtpService(db), Mailbox()
    await _send(svc, box); await db.commit()
    assert await _verify(svc, _wrong(box.codes[0])) is OtpResult.WRONG
    await db.rollback()                                                # even if the caller's request fails
    assert (await _rows(db))[0].attempt_count == 1
    assert await _verify(svc, box.codes[0]) is OtpResult.OK            # the right code still works


@pytest.mark.anyio
async def test_malformed_input_counts_as_wrong(db):
    svc, box = OtpService(db), Mailbox()
    await _send(svc, box); await db.commit()
    for junk in ("", "abc", "12345", "1234567"):           # 4 < max attempts (5)
        assert await _verify(svc, junk) is OtpResult.WRONG


@pytest.mark.anyio
async def test_expired_code_is_rejected(db):
    svc, box = OtpService(db), Mailbox()
    await _send(svc, box); await db.commit()
    await db.execute(update(OtpChallenge).values(expires_at=o.utcnow() - timedelta(seconds=1))); await db.commit()
    assert await _verify(svc, box.codes[0]) is OtpResult.EXPIRED
    assert await _verify(svc, box.codes[0]) is OtpResult.EXPIRED       # stays dead


@pytest.mark.anyio
async def test_maximum_attempts_lock_even_the_correct_code(db):
    svc, box = OtpService(db), Mailbox()
    await _send(svc, box); await db.commit()
    results = [await _verify(svc, _wrong(box.codes[0])) for _ in range(svc.settings.otp_max_attempts)]
    assert results[:-1] == [OtpResult.WRONG] * (svc.settings.otp_max_attempts - 1) and results[-1] is OtpResult.LOCKED
    assert await _verify(svc, box.codes[0]) is OtpResult.LOCKED
    assert (await _rows(db))[0].attempt_count == svc.settings.otp_max_attempts   # no free guesses beyond the limit


@pytest.mark.anyio
async def test_a_used_code_cannot_be_used_again(db):
    svc, box = OtpService(db), Mailbox()
    await _send(svc, box); await db.commit()
    assert await _verify(svc, box.codes[0]) is OtpResult.OK; await db.commit()
    assert await _verify(svc, box.codes[0]) is OtpResult.USED
    assert await _verify(svc, _wrong(box.codes[0])) is OtpResult.USED


@pytest.mark.anyio
async def test_one_time_use_holds_if_two_requests_race(db):
    """Both requests passed the checks; only the one whose conditional UPDATE wins consumes the code."""
    svc, box = OtpService(db), Mailbox()
    await _send(svc, box); await db.commit()
    row = (await _rows(db))[0]
    first = await db.execute(update(OtpChallenge).where(OtpChallenge.id == row.id, OtpChallenge.status == PENDING)
                             .values(status=VERIFIED))
    second = await db.execute(update(OtpChallenge).where(OtpChallenge.id == row.id, OtpChallenge.status == PENDING)
                              .values(status=VERIFIED))
    assert (first.rowcount, second.rowcount) == (1, 0)


@pytest.mark.anyio
async def test_no_challenge_means_not_found_and_scoping_is_strict(db):
    svc, box = OtpService(db), Mailbox()
    assert await _verify(svc, "123456") is OtpResult.NOT_FOUND
    await _send(svc, box); await db.commit()
    code = box.codes[0]
    assert await _verify(svc, code, subject="u2") is OtpResult.NOT_FOUND                 # other user
    assert await _verify(svc, code, dest="eve@example.test") is OtpResult.NOT_FOUND      # other address
    assert await _verify(svc, code, purpose=OtpPurpose.PHONE_VERIFY) is OtpResult.NOT_FOUND
    assert await _verify(svc, code) is OtpResult.OK


# ── resend, cooldown, quotas ─────────────────────────────────────────────────
@pytest.mark.anyio
async def test_resend_cooldown_is_enforced_and_then_released(db):
    svc, box = OtpService(db), Mailbox()
    await _send(svc, box); await db.commit()
    with pytest.raises(RateLimitExceededError) as exc:
        await _send(svc, box)
    assert 1 <= exc.value.retry_after <= 31 and len(box.codes) == 1                       # nothing was sent
    await _skip_cooldown(db)
    await _send(svc, box); await db.commit()
    assert len(box.codes) == 2


@pytest.mark.anyio
async def test_resend_supersedes_the_previous_code(db):
    svc, box = OtpService(db), Mailbox()
    await _send(svc, box); await db.commit(); await _skip_cooldown(db)
    await _send(svc, box); await db.commit()
    old, new = box.codes
    rows = await _rows(db)
    assert [r.status for r in rows] == [SUPERSEDED, PENDING]
    if old != new:
        assert await _verify(svc, old) is OtpResult.WRONG                                # old code is dead
    assert await _verify(svc, new) is OtpResult.OK


@pytest.mark.anyio
async def test_hourly_destination_quota(db):
    svc, box = OtpService(db), Mailbox()
    for _ in range(svc.settings.otp_max_sends_per_hour):
        await _send(svc, box); await db.commit(); await _skip_cooldown(db)
    with pytest.raises(RateLimitExceededError, match="Too many codes"):
        await _send(svc, box)
    assert len(box.codes) == svc.settings.otp_max_sends_per_hour
    # a different destination for another subject is unaffected
    await _send(svc, box, subject="u9", dest="amy@example.test"); await db.commit()


@pytest.mark.anyio
async def test_sms_challenge_uses_the_same_rules(db):
    svc, box = OtpService(db), Mailbox()
    await _send(svc, box, dest="+919876543210", channel="sms", purpose=OtpPurpose.PHONE_VERIFY); await db.commit()
    assert (await _rows(db))[0].destination_hint == "+91*******210"
    assert await _verify(svc, box.codes[0], dest="+919876543210", purpose=OtpPurpose.PHONE_VERIFY) is OtpResult.OK


# ── provider failure ─────────────────────────────────────────────────────────
@pytest.mark.anyio
@pytest.mark.parametrize("reason,status,exc_type", [
    (E.AUTH, 503, ProviderUnavailableError), (E.CONFIG, 503, ProviderUnavailableError),
    (E.RATE_LIMITED, 503, ProviderUnavailableError), (E.RECIPIENT, 422, DeliveryError),
    (E.TIMEOUT, 502, DeliveryError), (E.UNAVAILABLE, 502, DeliveryError), (E.NETWORK, 502, DeliveryError)])
async def test_provider_failure_maps_to_a_backend_error_and_kills_the_code(db, reason, status, exc_type):
    svc = OtpService(db)
    box = Mailbox(fail=E.DeliveryFailure(reason, "SECRET-PROVIDER-DETAIL"))
    with pytest.raises(exc_type) as exc:
        await _send(svc, box, user_id=None, ip="1.2.3.4")
    assert exc.value.status_code == status and exc.value.reason == reason
    assert "SECRET-PROVIDER-DETAIL" not in exc.value.message
    (row,) = await _rows(db)
    assert row.status == DELIVERY_FAILED and row.sent_at is None
    # a code nobody received can never verify, and does not lock the user out of retrying immediately
    assert await _verify(svc, "123456") is OtpResult.NOT_FOUND
    ok = Mailbox(); await _send(svc, ok); await db.commit()
    assert await _verify(svc, ok.codes[0]) is OtpResult.OK


@pytest.mark.anyio
async def test_unexpected_provider_bug_is_also_contained(db):
    svc = OtpService(db)
    with pytest.raises(DeliveryError) as exc:
        await _send(svc, Mailbox(fail=RuntimeError("boom with password=hunter2")))
    assert "hunter2" not in exc.value.message and (await _rows(db))[0].status == DELIVERY_FAILED


@pytest.mark.anyio
async def test_rollback_on_failure_discards_the_callers_pending_work(db):
    from app.models.user import User
    svc = OtpService(db)
    db.add(User(email="half@example.test", full_name="H", hashed_password="x", status="PENDING_VERIFICATION"))
    await db.flush()
    with pytest.raises(DeliveryError):
        await _send(svc, Mailbox(fail=E.DeliveryFailure(E.TIMEOUT)), rollback_on_failure=True)
    assert (await db.execute(select(User).where(User.email == "half@example.test"))).scalar_one_or_none() is None
    assert await _rows(db) == []


# ── audit hygiene ────────────────────────────────────────────────────────────
@pytest.mark.anyio
async def test_audit_events_exist_and_never_contain_codes_or_raw_destinations(db):
    svc, box = OtpService(db), Mailbox()
    await _send(svc, box, user_id=None, ip="9.9.9.9"); await db.commit()
    code = box.codes[0]
    await _verify(svc, _wrong(code)); await _verify(svc, code); await db.commit(); await _verify(svc, code)
    with pytest.raises(DeliveryError):
        await _skip_cooldown(db); await _send(svc, Mailbox(fail=E.DeliveryFailure(E.AUTH)))
    await _send(svc, box); await db.commit()
    with pytest.raises(RateLimitExceededError):                         # immediate resend -> cooldown block
        await _send(svc, box)
    logs = list((await db.execute(select(AuditLog))).scalars())
    actions = [l.action for l in logs]
    for expected in (o.AUDIT_SENT, o.AUDIT_VERIFIED, o.AUDIT_VERIFY_FAILED, o.AUDIT_DELIVERY_FAILED, o.AUDIT_SEND_BLOCKED):
        assert expected in actions, expected
    blob = " ".join(f"{l.action} {l.details} {l.resource_id}" for l in logs)
    assert code not in blob and DEST not in blob and "otp_hash" not in blob
    failed = next(l for l in logs if l.action == o.AUDIT_DELIVERY_FAILED)
    assert failed.details["reason"] == E.AUTH and failed.details["channel"] == "email"


@pytest.mark.anyio
async def test_purge_removes_only_old_challenges(db):
    svc, box = OtpService(db), Mailbox()
    await _send(svc, box); await db.commit()
    assert await svc.purge(older_than_days=7) == 0
    await db.execute(update(OtpChallenge).values(created_at=o.utcnow() - timedelta(days=8))); await db.commit()
    assert await svc.purge(older_than_days=7) == 1
