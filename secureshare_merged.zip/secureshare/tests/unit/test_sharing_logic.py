"""Offline tests (no SQLAlchemy needed): key wrapping + share-grant decisions through the real PDP."""
import unittest
from datetime import timedelta
from types import SimpleNamespace as NS

from app.core.enums import Decision, DlpLevel, Permission
from app.crypto.envelope import KeyError_
from app.services import grants_logic as gl
from app.services import key_wrap as kw

NOW = gl.utcnow()
USER_PERMS = ["DOCUMENT_VIEW", "DOCUMENT_DOWNLOAD", "DOCUMENT_SHARE"]


def grant(perms=("VIEW", "DOWNLOAD"), exp=None, revoked=None):
    return NS(permissions=list(perms), expires_at=exp, revoked_at=revoked)


def run(action, grants, owner=False, role=USER_PERMS, **kw_):
    return gl.decide(action=action, now=NOW, is_owner=owner, user_status_active=True,
                     email_verified=True, role_permissions=role, grants=grants,
                     dlp_level=DlpLevel.NONE, **kw_)


class KeyWrapTests(unittest.TestCase):
    def test_roundtrip_and_aad_binding(self):
        dek, wrapped, ref, ver = kw.generate_wrapped_dek("secret", "doc1", 1)
        self.assertEqual(len(dek), 32)
        self.assertEqual(kw.unwrap_dek("secret", wrapped, ref, ver, "doc1", 1), dek)
        with self.assertRaises(KeyError_):
            kw.unwrap_dek("secret", wrapped, ref, ver, "other-doc", 1)
        with self.assertRaises(KeyError_):
            kw.unwrap_dek("wrong-secret", wrapped, ref, ver, "doc1", 1)

    def test_each_document_gets_distinct_dek(self):
        a = kw.generate_wrapped_dek("s", "d1", 1)[0]
        b = kw.generate_wrapped_dek("s", "d2", 1)[0]
        self.assertNotEqual(a, b)

    def test_legacy_xor_rows_still_readable(self):
        import base64, hashlib, os
        dek, master = os.urandom(32), hashlib.sha256(b"secret").digest()
        wrapped = base64.b64encode(bytes(a ^ b for a, b in zip(dek, master))).decode()
        self.assertEqual(kw.unwrap_dek("secret", wrapped, "master_v1", "1", "d", 1), dek)
        self.assertTrue(kw.needs_rewrap("master_v1"))
        self.assertFalse(kw.needs_rewrap(kw.KEY_REF_GCM))


class GrantInputTests(unittest.TestCase):
    def test_normalize(self):
        self.assertEqual(gl.normalize_permissions(["download"]), ["VIEW", "DOWNLOAD"])
        with self.assertRaises(gl.GrantInputError):
            gl.normalize_permissions(["DELETE"])
        with self.assertRaises(gl.GrantInputError):
            gl.normalize_permissions(["bogus"])
        with self.assertRaises(gl.GrantInputError):
            gl.normalize_permissions([])

    def test_expiry_must_be_future(self):
        with self.assertRaises(gl.GrantInputError):
            gl.validate_expiry(NOW - timedelta(seconds=1), NOW)
        self.assertIsNone(gl.validate_expiry(None, NOW))


class DecisionTests(unittest.TestCase):
    def test_owner_allowed(self):
        self.assertEqual(run(Permission.DOWNLOAD, [], owner=True).decision.decision, Decision.ALLOW)

    def test_stranger_denied(self):
        o = run(Permission.VIEW, [])
        self.assertEqual(o.decision.decision, Decision.DENY)
        self.assertIn("PERMISSION_NOT_GRANTED", o.reasons)

    def test_live_grant_allows_view_and_download(self):
        g = [grant(exp=NOW + timedelta(hours=1))]
        self.assertTrue(run(Permission.VIEW, g).allowed)
        self.assertTrue(run(Permission.DOWNLOAD, g).allowed)

    def test_view_only_grant_cannot_download(self):
        self.assertFalse(run(Permission.DOWNLOAD, [grant(perms=("VIEW",))]).allowed)

    def test_revoked_denied_immediately(self):
        o = run(Permission.DOWNLOAD, [grant(revoked=NOW)])
        self.assertEqual(o.decision.decision, Decision.DENY)
        self.assertIn("SHARE_REVOKED", o.reasons)

    def test_expired_denied(self):
        o = run(Permission.VIEW, [grant(exp=NOW - timedelta(seconds=1))])
        self.assertFalse(o.allowed)
        self.assertIn("SHARE_EXPIRED", o.reasons)

    def test_revoke_wins_over_other_live_grant_absent(self):
        # one revoked + one expired -> neither live
        o = run(Permission.VIEW, [grant(revoked=NOW), grant(exp=NOW - timedelta(days=1))])
        self.assertFalse(o.allowed)

    def test_rbac_still_applies_to_grantee(self):
        # EDIT granted on the share, but the role lacks DOCUMENT_EDIT -> DENY (RBAC AND ABAC)
        o = run(Permission.EDIT, [grant(perms=("VIEW", "EDIT"))])
        self.assertIn("RBAC_PERMISSION_MISSING", o.reasons)
        self.assertFalse(o.allowed)

    def test_critical_risk_denies_even_with_live_grant(self):
        from app.core.enums import RiskLevel
        o = run(Permission.VIEW, [grant()], risk_score=95, risk_level=RiskLevel.CRITICAL)
        self.assertFalse(o.allowed)

    def test_high_risk_never_grants_without_a_share(self):
        from app.core.enums import RiskLevel
        o = run(Permission.VIEW, [], risk_level=RiskLevel.LOW, risk_score=0)
        self.assertFalse(o.allowed)


if __name__ == "__main__":
    unittest.main()
