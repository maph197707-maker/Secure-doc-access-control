from scripts import doctor

def test_python_ok():
    assert doctor.check_python() == []

def test_env_template_has_placeholders():
    assert "__GENERATE__" in (doctor.ROOT / ".env.example").read_text(encoding="utf-8")

def test_port_helper_returns_bool():
    assert isinstance(doctor.port_free(65000), bool)
