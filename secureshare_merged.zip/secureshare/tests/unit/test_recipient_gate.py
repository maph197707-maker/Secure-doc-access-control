"""Recipient-bound links: claim -> code, backed by the database-persisted OTP service. Also the signed
cookie helpers and recipient validation (pure logic)."""
import re
from datetime import timedelta

import pytest
from sqlalchemy import select, update

from app.integrations import errors as E
from app.integrations.email import EmailDeliveryError, EmailProvider, EmailService
from app.integrations.sms import SMSService
from app.integrations.state import InMemoryStateStore
from app.models.otp import OtpChallenge
from app.services import otp
from app.services import recipient_gate as g
from app.services.otp import OtpService
from tests.support.providers import RecordingEmailProvider, RecordingSMSProvider

M = b"m" * 32
RECS = [g.RecipientRef("r1", "bob@example.test", "+919876543210"), g.RecipientRef("r2", "amy@example.test", None)]


class Clock:
    t = 1000.0
    def __call__(self): return self.t


def make_env():
    mail, sms = RecordingEmailProvider(), RecordingSMSProvider()
    clock = Clock()
    return clock, InMemoryStateStore(clock), mail, sms, EmailService(mail, "no@x.test"), SMSService(sms, "+91")


async def do_claim(db, st, em, sms, mode, typed="bob@example.test", ip="1.1.1.1", link="L1"):
    return await g.claim(OtpService(db), st, link_id=link, mode=mode, ip=ip, typed_email=typed, recipients=RECS,
                         master=M, email=em, sms=sms)


async def check(db, mode, code, rec=RECS[0], link="L1"):
    return await g.check_code(OtpService(db), link_id=link, mode=mode, rec=rec, code=code)


def _wrong(code): return "000000" if code != "000000" else "111111"


@pytest.mark.anyio
async def test_email_flow_end_to_end(db):
    _, st, mail, _, em, sms = make_env()
    out = await do_claim(db, st, em, sms, g.MODE_EMAIL, " Bob@Example.Test ")
    assert out.delivered and mail.sent[-1]["To"] == "bob@example.test"
    assert g.read_pending(M, "L1", out.pending) == "r1"
    assert await check(db, g.MODE_EMAIL, mail.code_for("bob@example.test")) is otp.OtpResult.OK
    assert g.session_recipient(M, "L1", g.issue_session(M, "L1", "r1")) == "r1"


@pytest.mark.anyio
async def test_phone_flow_sends_to_the_number_on_file_only(db):
    _, st, mail, smsbox, em, sms = make_env()
    out = await do_claim(db, st, em, sms, g.MODE_PHONE)
    assert out.delivered and smsbox.sent[-1][0] == "+919876543210" and mail.sent == []
    assert await check(db, g.MODE_PHONE, smsbox.code_for("+919876543210")) is otp.OtpResult.OK


@pytest.mark.anyio
async def test_the_code_is_persisted_hashed_not_in_clear(db):
    _, st, mail, _, em, sms = make_env()
    await do_claim(db, st, em, sms, g.MODE_EMAIL)
    code = mail.code_for("bob@example.test")
    (row,) = (await db.execute(select(OtpChallenge))).scalars().all()
    assert code not in str(vars(row)) and "bob@example.test" not in str(vars(row)) and row.status == "PENDING"


@pytest.mark.anyio
async def test_no_oracle_nonmatching_email_looks_identical_and_sends_nothing(db):
    _, st, mail, _, em, sms = make_env()
    hit = await do_claim(db, st, em, sms, g.MODE_EMAIL, "bob@example.test", ip="2.2.2.2")
    miss = await do_claim(db, st, em, sms, g.MODE_EMAIL, "mallory@evil.test", ip="3.3.3.3")
    assert (hit.status, hit.message) == (miss.status, miss.message)
    assert miss.pending is None and not miss.delivered and len(mail.sent) == 1


@pytest.mark.anyio
async def test_phone_mode_without_phone_on_file_sends_nothing(db):
    _, st, mail, smsbox, em, sms = make_env()
    out = await do_claim(db, st, em, sms, g.MODE_PHONE, "amy@example.test")
    assert not out.delivered and smsbox.sent == [] and mail.sent == []


@pytest.mark.anyio
async def test_unconfigured_channel_is_not_delivered_and_never_faked(db):
    _, st, _, _, _, _ = make_env()
    assert not (await do_claim(db, st, None, None, g.MODE_EMAIL)).delivered
    assert not (await do_claim(db, st, None, None, g.MODE_PHONE)).delivered
    assert (await db.execute(select(OtpChallenge))).scalars().all() == []


@pytest.mark.anyio
async def test_provider_failure_is_generic_for_the_visitor_audited_and_retryable(db):
    _, st, mail, _, em, sms = make_env()
    mail.fail_with = E.TIMEOUT
    out = await do_claim(db, st, em, sms, g.MODE_EMAIL)
    assert out.message == g.GENERIC_SENT and not out.delivered
    mail.fail_with = None
    assert (await do_claim(db, st, em, sms, g.MODE_EMAIL)).delivered           # the failed attempt left no cooldown
    from app.models.audit import AuditLog
    actions = [a for (a,) in (await db.execute(select(AuditLog.action))).all()]
    assert "OTP_DELIVERY_FAILED" in actions and "OTP_SENT" in actions


@pytest.mark.anyio
async def test_wrong_codes_lock_and_the_correct_code_then_fails(db):
    _, st, mail, _, em, sms = make_env()
    await do_claim(db, st, em, sms, g.MODE_EMAIL); real = mail.code_for("bob@example.test")
    results = [await check(db, g.MODE_EMAIL, _wrong(real)) for _ in range(5)]
    assert results[-1] is otp.OtpResult.LOCKED
    assert await check(db, g.MODE_EMAIL, real) is otp.OtpResult.LOCKED


@pytest.mark.anyio
async def test_expired_and_replayed_codes_fail(db):
    _, st, mail, _, em, sms = make_env()
    await do_claim(db, st, em, sms, g.MODE_EMAIL); code = mail.code_for("bob@example.test")
    assert await check(db, g.MODE_EMAIL, code) is otp.OtpResult.OK; await db.commit()
    assert await check(db, g.MODE_EMAIL, code) is otp.OtpResult.USED
    await db.execute(update(OtpChallenge).values(status="PENDING", verified_at=None,
                                                 expires_at=otp.utcnow() - timedelta(seconds=1))); await db.commit()
    assert await check(db, g.MODE_EMAIL, code) is otp.OtpResult.EXPIRED


@pytest.mark.anyio
async def test_code_for_one_link_or_recipient_does_not_work_for_another(db):
    _, st, mail, _, em, sms = make_env()
    await do_claim(db, st, em, sms, g.MODE_EMAIL, link="L1"); code = mail.code_for("bob@example.test")
    assert await check(db, g.MODE_EMAIL, code, link="L2") is otp.OtpResult.NOT_FOUND
    assert await check(db, g.MODE_EMAIL, code, rec=RECS[1]) is otp.OtpResult.NOT_FOUND


@pytest.mark.anyio
async def test_claim_throttles(db):
    c, st, _, _, em, sms = make_env()
    for i in range(10):
        assert (await do_claim(db, st, em, sms, g.MODE_EMAIL, f"x{i}@evil.test")).status is g.ClaimStatus.SENT
    assert (await do_claim(db, st, em, sms, g.MODE_EMAIL, "x@evil.test")).status is g.ClaimStatus.THROTTLED
    assert (await do_claim(db, st, em, sms, g.MODE_EMAIL, "y@evil.test", ip="9.9.9.9")).status is g.ClaimStatus.SENT
    c.t += 901
    assert (await do_claim(db, st, em, sms, g.MODE_EMAIL, "x@evil.test")).status is g.ClaimStatus.SENT


@pytest.mark.anyio
async def test_link_wide_throttle_stops_ip_rotation(db):
    _, st, _, _, em, sms = make_env()
    statuses = [(await do_claim(db, st, em, sms, g.MODE_EMAIL, "z@evil.test", ip=f"10.0.0.{i}")).status for i in range(31)]
    assert statuses[-1] is g.ClaimStatus.THROTTLED


def test_cookie_tamper_expiry_cross_link_and_label_confusion():
    pending = g.issue_pending(M, "L1", "r1", now=1000)
    assert g.read_pending(M, "L1", pending, now=1100) == "r1"
    assert g.read_pending(M, "L1", pending, now=1000 + g.PENDING_TTL + 1) is None
    assert g.read_pending(M, "L2", pending, now=1100) is None
    assert g.session_recipient(M, "L1", pending, now=1100) is None            # pending != session
    sess = g.issue_session(M, "L1", "r1", now=1000)
    assert g.read_pending(M, "L1", sess, now=1100) is None
    rid, exp, sig = sess.split(".")
    for forged in (f"r2.{exp}.{sig}", f"{rid}.{int(exp) + 9999}.{sig}", f"{rid}.{exp}.{'0' * 64}", "", None, "a.b", "r1.x.y"):
        assert g.session_recipient(M, "L1", forged, now=1100) is None
    assert g.session_recipient(b"x" * 32, "L1", sess, now=1100) is None


def test_clean_recipient_rules():
    c = g.clean_recipients
    assert c([{"email": " Bob@X.test ", "phone": "98765 43210"}], g.MODE_PHONE) == [{"email": "bob@x.test", "phone": "+919876543210"}]
    assert c([{"email": "a@x.test"}, {"email": "A@x.test"}], g.MODE_EMAIL) == [{"email": "a@x.test", "phone": None}]
    assert c([], g.MODE_NONE) == []
    for rcpts, mode in (([], g.MODE_EMAIL), ([{"email": "a@x.test"}], g.MODE_PHONE), ([{"email": "nope"}], g.MODE_NONE),
                        ([{"email": "a b@x.test"}], g.MODE_NONE), ([{"email": "a@x.test", "phone": "12"}], g.MODE_NONE),
                        ([{"email": "a@x.test"}], "ROT13")):
        with pytest.raises(g.RecipientError):
            c(rcpts, mode)
