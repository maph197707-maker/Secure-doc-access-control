"""Guest login and sign-up WITHOUT email delivery; email/phone verified later from /profile.

Everything runs through the real app. Only the delivery transport is the recording test provider
(conftest) or, where a test says so, absent (SMTP not configured => honest 503, never a fake send)."""
from __future__ import annotations

import re

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy import select

from app.config.settings import get_settings
from app.db.session import AsyncSessionLocal, create_tables, drop_tables
from app.integrations import factory
from app.main import app
from app.models.user import User
from scripts.seed_roles import seed_roles
from tests.support import providers

BASE = "http://localhost:8000"
PW = "StrongPassword123!"
pytestmark = pytest.mark.deferred_verification


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables(); await create_tables(); await seed_roles()
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


@pytest.fixture
def no_email(monkeypatch):
    monkeypatch.setattr(factory, "get_email_service", lambda: None)


def _client() -> AsyncClient:
    return AsyncClient(transport=ASGITransport(app=app), base_url=BASE)


def _csrf(html: str) -> str:
    return re.search(r'name="csrf_token"\s+value="([^"]+)"', html).group(1)


async def _post(c: AsyncClient, path: str, page: str, **data):
    tok = _csrf((await c.get(page)).text)
    return await c.post(path, data={"csrf_token": tok, **data}, follow_redirects=False)


async def _user(email: str) -> User:
    async with AsyncSessionLocal() as s:
        return (await s.execute(select(User).where(User.email == email))).scalar_one()


async def _register_web(c: AsyncClient, email="sam@example.com", phone="+919876543210"):
    return await _post(c, "/register", "/register", email=email, password=PW, full_name="Sam Tester", phone=phone)


# ── guest login ──────────────────────────────────────────────────────────────
@pytest.mark.anyio
async def test_guest_button_is_offered_and_logs_in_with_no_email_configured(no_email):
    async with _client() as c:
        for page in ("/login", "/register"):
            assert "Continue as guest" in (await c.get(page)).text
        r = await _post(c, "/guest-login", "/login")
        assert r.status_code == 303 and r.headers["location"] == "/dashboard"
        dash = await c.get("/dashboard")
        assert dash.status_code == 200 and "temporary guest account" in dash.text
        prof = await c.get("/profile")
        assert prof.status_code == 200 and "Guest" in prof.text and "Send verification code" not in prof.text


@pytest.mark.anyio
async def test_guest_is_a_real_account_upload_encrypt_share_download(no_email):
    """Not a demo: real user row, real encrypted upload, real secure link, real audit entry."""
    async with _client() as c:
        g = await c.post("/api/v1/auth/guest")
        assert g.status_code == 200, g.text
        c.cookies.clear()                       # API calls below authenticate by Bearer token only
        c.headers["Authorization"] = f"Bearer {g.json()['access_token']}"
        body = b"guest document body 9c1e\n" * 40
        up = await c.post("/api/v1/documents", files={"file": ("guest.txt", body, "text/plain")})
        assert up.status_code == 201, up.text
        doc = up.json()["id"]
        assert (await c.get(f"/api/v1/documents/{doc}/download")).content == body
        link = await c.post("/api/v1/links", json={"document_id": doc})
        assert link.status_code in (200, 201), link.text
        listed = await c.get("/api/v1/documents")
        assert listed.status_code == 200 and doc in listed.text
    async with AsyncSessionLocal() as s:
        u = (await s.execute(select(User).where(User.email.like("guest-%@guest.example.com")))).scalar_one()
        assert u.status == "ACTIVE" and u.role == "USER"          # never an admin


@pytest.mark.anyio
async def test_guest_can_log_out_and_each_guest_is_separate(no_email):
    async with _client() as a, _client() as b:
        assert (await _post(a, "/guest-login", "/login")).status_code == 303
        assert (await _post(b, "/guest-login", "/login")).status_code == 303
        async with AsyncSessionLocal() as s:
            assert len((await s.execute(select(User))).scalars().all()) == 2
        await a.post("/logout", data={"csrf_token": _csrf((await a.get("/dashboard")).text)})
        assert (await a.get("/dashboard", follow_redirects=False)).status_code == 303
        assert (await b.get("/dashboard")).status_code == 200


@pytest.mark.anyio
async def test_guest_login_works_in_production_by_default_and_can_be_switched_off(monkeypatch):
    st = get_settings()
    monkeypatch.setattr(st, "app_env", "production")
    async with _client() as c:
        assert (await _post(c, "/guest-login", "/login")).status_code == 303
    monkeypatch.setattr(st, "guest_login_enabled", False)
    async with _client() as c:
        assert "Continue as guest" not in (await c.get("/login")).text
        r = await c.post("/guest-login", data={"csrf_token": _csrf((await c.get("/login")).text)})
        assert r.status_code == 403


@pytest.mark.anyio
async def test_guest_cannot_request_or_fake_email_verification():
    async with _client() as c:
        await _post(c, "/guest-login", "/login")
        tok = _csrf((await c.get("/profile")).text)
        r = await c.post("/profile/email/send", data={"csrf_token": tok})
        assert r.status_code == 400 and not providers.OUTBOX.email.sent
        r = await c.post("/profile/email/verify", data={"csrf_token": tok, "code": "123456"})
        assert r.status_code == 400
    async with AsyncSessionLocal() as s:
        u = (await s.execute(select(User))).scalar_one()
    # the guest placeholder address is flagged verified only so shares work; it is never mailed
    assert u.email.endswith("@guest.example.com")


# ── sign-up without email delivery ───────────────────────────────────────────
@pytest.mark.anyio
async def test_signup_works_with_no_email_configured_and_signs_in(no_email):
    async with _client() as c:
        r = await _register_web(c)
        assert r.status_code == 303 and r.headers["location"] == "/dashboard"
        assert (await c.get("/dashboard")).status_code == 200
    u = await _user("sam@example.com")
    assert u.status == "ACTIVE" and u.email_verified is False and u.phone_verified is False
    assert u.phone == "+919876543210"
    assert not providers.OUTBOX.email.sent and not providers.OUTBOX.sms.sent      # nothing was sent


@pytest.mark.anyio
async def test_signup_api_201_without_email_provider(no_email):
    async with _client() as c:
        r = await c.post("/api/v1/auth/register", json={"email": "api@example.com", "password": PW, "full_name": "Api"})
        assert r.status_code == 201 and r.json()["verification_required"] is False
        login = await c.post("/api/v1/auth/login", json={"email": "api@example.com", "password": PW})
        assert login.status_code == 200 and login.json()["user"]["email_verified"] is False


@pytest.mark.anyio
async def test_reserved_guest_domain_cannot_be_registered(no_email):
    async with _client() as c:
        r = await c.post("/api/v1/auth/register",
                         json={"email": "x@guest.example.com", "password": PW, "full_name": "Fake Guest"})
        assert r.status_code == 422 and "reserved" in r.text


# ── verify later in /profile ─────────────────────────────────────────────────
@pytest.mark.anyio
async def test_profile_says_email_unavailable_instead_of_faking_when_smtp_missing(no_email):
    async with _client() as c:
        await _register_web(c)
        page = (await c.get("/profile")).text
        assert "Not verified" in page and "Email delivery is not configured" in page
        tok = _csrf(page)
        r = await c.post("/profile/email/send", data={"csrf_token": tok})
        assert r.status_code == 503 and "not configured" in r.text.lower()
    assert (await _user("sam@example.com")).email_verified is False


@pytest.mark.anyio
async def test_profile_email_verification_end_to_end():
    async with _client() as c:
        await _register_web(c)
        assert "Your email is not verified yet" in (await c.get("/dashboard")).text      # dashboard nudge
        tok = _csrf((await c.get("/profile")).text)
        sent = await c.post("/profile/email/send", data={"csrf_token": tok})
        assert sent.status_code == 200 and "verification code was sent" in sent.text
        code = providers.OUTBOX.email.code_for("sam@example.com")
        bad = await c.post("/profile/email/verify", data={"csrf_token": tok, "code": "000000" if code != "000000" else "111111"})
        assert bad.status_code == 400 and (await _user("sam@example.com")).email_verified is False
        ok = await c.post("/profile/email/verify", data={"csrf_token": tok, "code": code})
        assert ok.status_code == 200 and "Email verified" in ok.text
        replay = await c.post("/profile/email/verify", data={"csrf_token": tok, "code": code})
        assert replay.status_code == 400                                                   # one-time code
        assert "Verified" in (await c.get("/profile")).text
    assert (await _user("sam@example.com")).email_verified is True


@pytest.mark.anyio
async def test_profile_phone_verification_end_to_end_via_verify_phone():
    async with _client() as c:
        await _register_web(c, phone="+919876543210")
        tok = _csrf((await c.get("/verify-phone")).text)
        sent = await c.post("/verify-phone", data={"csrf_token": tok, "action": "send", "phone": "+919876543210"})
        assert sent.status_code == 200
        code = providers.OUTBOX.sms.code_for("+919876543210")
        ok = await c.post("/verify-phone", data={"csrf_token": tok, "action": "verify", "code": code})
        assert ok.status_code == 200 and "Phone verified" in ok.text
    assert (await _user("sam@example.com")).phone_verified is True


@pytest.mark.anyio
async def test_profile_requires_login():
    async with _client() as c:
        r = await c.get("/profile", follow_redirects=False)
        assert r.status_code == 303 and r.headers["location"].startswith("/login")


@pytest.mark.anyio
async def test_profile_phone_otp_inline_add_send_verify_and_change_resets():
    async with _client() as c:
        await _register_web(c, phone="")                       # no phone at sign-up
        tok = _csrf((await c.get("/profile")).text)
        sent = await c.post("/profile/phone/send", data={"csrf_token": tok, "phone": "+919876543210"})
        assert sent.status_code == 200 and "Code sent to" in sent.text
        code = providers.OUTBOX.sms.code_for("+919876543210")
        wrong = "000000" if code != "000000" else "111111"
        assert (await c.post("/profile/phone/verify", data={"csrf_token": tok, "code": wrong})).status_code == 401
        assert (await _user("sam@example.com")).phone_verified is False
        ok = await c.post("/profile/phone/verify", data={"csrf_token": tok, "code": code})
        assert ok.status_code == 200 and "Phone verified" in ok.text
        assert (await _user("sam@example.com")).phone_verified is True
        assert (await c.post("/profile/phone/verify", data={"csrf_token": tok, "code": code})).status_code == 400   # one-time
        # changing the number makes it unverified again until the new one is proven
        await c.post("/profile/phone/send", data={"csrf_token": tok, "phone": "+919123456789"})
    u = await _user("sam@example.com")
    assert u.phone == "+919123456789" and u.phone_verified is False


@pytest.mark.anyio
async def test_profile_phone_unavailable_without_sms_provider_never_marks_verified(monkeypatch):
    monkeypatch.setattr(factory, "get_sms_service", lambda: None)
    async with _client() as c:
        await _register_web(c, phone="+919876543210")
        tok = _csrf((await c.get("/profile")).text)
        r = await c.post("/profile/phone/send", data={"csrf_token": tok, "phone": "+919876543210"})
        assert r.status_code == 503 and "no SMS provider" in r.text
    assert (await _user("sam@example.com")).phone_verified is False


@pytest.mark.anyio
async def test_fresh_install_without_seeded_roles_still_gives_guest_and_signup_a_user_role():
    """Regression: roles used to be seeded only by tests/CLI, so a brand-new database made role-less
    users and the guest API crashed. App startup now seeds them (idempotent)."""
    await drop_tables(); await create_tables()                # empty schema, NO seed_roles()
    async with app.router.lifespan_context(app):
        async with _client() as c:
            g = await c.post("/api/v1/auth/guest")
            assert g.status_code == 200, g.text
            assert [r["name"] for r in g.json()["user"]["roles"]] == ["USER"]
            c.cookies.clear()
            r = await c.post("/api/v1/auth/register", json={"email": "new@example.com", "password": PW, "full_name": "New"})
            assert r.status_code == 201 and [x["name"] for x in r.json()["user"]["roles"]] == ["USER"]


@pytest.mark.anyio
async def test_setup_db_script_is_idempotent():
    from scripts.setup_db import main
    assert await main() == 0 and await main() == 0


@pytest.mark.asyncio
async def test_landing_page_offers_login_and_guest():
    """First page: Login link + 'Continue as guest' form posting to /guest-login with a CSRF token."""
    async with AsyncClient(transport=ASGITransport(app=app), base_url=BASE) as c:
        r = await c.get("/")
        assert r.status_code == 200
        assert 'href="/login"' in r.text
        assert 'action="/guest-login"' in r.text and "Continue as guest" in r.text
        token = c.cookies.get("ss_csrf") or ""
        g = await c.post("/guest-login", data={"csrf_token": token}, follow_redirects=False)
        assert g.status_code == 303 and g.headers["location"] == "/dashboard"
