"""Integration tests for web HTML authentication forms and safe redirects."""
from __future__ import annotations

import re
import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from app.config.constants import COOKIE_SESSION
from app.db.session import create_tables, drop_tables
from app.main import app
from scripts.seed_roles import seed_roles


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables()
    await create_tables()
    await seed_roles()
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


def extract_csrf(html: str) -> str:
    m = re.search(r'name="csrf_token"\s+value="([^"]+)"', html)
    if m:
        return m.group(1)
    m = re.search(r'data-csrf="([^"]+)"', html)
    if m:
        return m.group(1)
    return "demo"


@pytest.mark.anyio
async def test_web_registration_and_login_flow():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client:
        # 1. GET /register
        reg_page = await client.get("/register")
        assert reg_page.status_code == 200
        assert "Create Account" in reg_page.text or "Secure Registration" in reg_page.text
        csrf_tok = extract_csrf(reg_page.text)

        # 2. POST /register
        reg_resp = await client.post(
            "/register",
            data={
                "csrf_token": csrf_tok,
                "email": "dave@example.com",
                "password": "DavePassword123!",
                "full_name": "Dave Tester",
            },
            follow_redirects=False,
        )
        assert reg_resp.status_code == 303
        assert "/verify-email" in reg_resp.headers["location"]

        # 3. GET /login; signing in BEFORE the emailed code is verified is refused
        login_page = await client.get("/login")
        assert login_page.status_code == 200
        csrf_tok = extract_csrf(login_page.text)
        early = await client.post("/login", data={"csrf_token": csrf_tok, "email": "dave@example.com",
                                                  "password": "DavePassword123!"}, follow_redirects=False)
        assert early.status_code == 400 and "verify your email" in early.text.lower()
        assert COOKIE_SESSION not in early.cookies
        from tests.support.providers import last_email_code
        ver = await client.post("/verify-email", data={"csrf_token": csrf_tok, "email": "dave@example.com",
                                                       "code": last_email_code()})
        assert ver.status_code == 200

        # 4. POST /login with bad password displays error
        bad_login = await client.post(
            "/login",
            data={
                "csrf_token": csrf_tok,
                "email": "dave@example.com",
                "password": "WrongPassword!",
            },
        )
        assert bad_login.status_code == 400
        assert "Invalid email or password" in bad_login.text

        # 5. POST /login with correct password and open redirect attempt
        good_login = await client.post(
            "/login",
            data={
                "csrf_token": csrf_tok,
                "email": "dave@example.com",
                "password": "DavePassword123!",
                "next": "https://evil-hacker.com/steal",
            },
            follow_redirects=False,
        )
        assert good_login.status_code == 303
        # Safe redirect rule: open redirect prevented, defaults to /dashboard
        assert good_login.headers["location"] == "/dashboard"
        assert COOKIE_SESSION in good_login.cookies

        # 6. Logout
        logout_resp = await client.post(
            "/logout",
            data={"csrf_token": client.cookies.get("ss_csrf", csrf_tok)},
            follow_redirects=False,
        )
        assert logout_resp.status_code == 303
        assert logout_resp.headers["location"] == "/login"
