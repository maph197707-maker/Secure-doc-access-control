"""Google / Microsoft sign-in through the real routes: /oauth/<p> -> provider -> /oauth/<p>/callback ->
user created/linked -> session cookie -> /dashboard. Only the provider's HTTP endpoints are faked."""
from __future__ import annotations

import base64
import json
import re
import urllib.parse

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from app.config.constants import COOKIE_SESSION
from app.config.settings import get_settings
from app.db.session import create_tables, drop_tables
from app.integrations import oauth
from app.main import app
from scripts.seed_roles import seed_roles

pytestmark = pytest.mark.deferred_verification


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables(); await create_tables(); await seed_roles()
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


@pytest.fixture
def idp(monkeypatch):
    """Fake Google/Microsoft: token + userinfo endpoints answered in-process."""
    s = get_settings()
    for k, v in dict(google_client_id="gid", google_client_secret="gsec",
                     microsoft_client_id="mid", microsoft_client_secret="msec").items():
        monkeypatch.setattr(s, k, v)
    box = {"info": {"sub": "g-123", "email": "Gina@Example.com", "email_verified": True, "name": "Gina G"}, "id_claims": None}

    def transport(method, url, headers, body):
        if url.endswith("/token"):
            tok = {"access_token": "AT"}
            if box["id_claims"] is not None:
                tok["id_token"] = "h." + base64.urlsafe_b64encode(json.dumps(box["id_claims"]).encode()).decode().rstrip("=") + ".s"
            return 200, json.dumps(tok)
        return 200, json.dumps(box["info"])
    monkeypatch.setattr(oauth, "default_transport", lambda: transport)
    return box


def client():
    return AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000")


async def start(c, provider="google"):
    r = await c.get(f"/oauth/{provider}", follow_redirects=False)
    assert r.status_code == 303, r.text
    loc = urllib.parse.urlparse(r.headers["location"])
    q = dict(urllib.parse.parse_qsl(loc.query))
    return loc, q


@pytest.mark.anyio
async def test_google_full_flow_creates_user_and_dashboard(idp):
    async with client() as c:
        loc, q = await start(c)
        assert loc.netloc == "accounts.google.com" and q["code_challenge_method"] == "S256"
        assert q["redirect_uri"] == "http://localhost:8000/oauth/google/callback"
        r = await c.get("/oauth/google/callback", params={"code": "C", "state": q["state"]}, follow_redirects=False)
        assert r.status_code == 303 and r.headers["location"] == "/dashboard" and COOKIE_SESSION in c.cookies
        assert (await c.get("/dashboard")).status_code == 200
        # same state cannot be replayed
        r = await c.get("/oauth/google/callback", params={"code": "C", "state": q["state"]}, follow_redirects=False)
        assert r.status_code == 400
    # second sign-in with the same identity -> same account (no duplicate)
    async with client() as c2:
        _, q = await start(c2)
        r = await c2.get("/oauth/google/callback", params={"code": "C", "state": q["state"]}, follow_redirects=False)
        assert r.status_code == 303
    from sqlalchemy import func, select
    from app.db.session import AsyncSessionLocal
    from app.models.oauth_account import OAuthAccount
    from app.models.user import User
    async with AsyncSessionLocal() as db:
        assert (await db.execute(select(func.count()).select_from(User))).scalar() == 1
        assert (await db.execute(select(func.count()).select_from(OAuthAccount))).scalar() == 1
        u = (await db.execute(select(User))).scalar_one()
        assert u.email == "gina@example.com" and u.email_verified and u.status == "ACTIVE"


@pytest.mark.anyio
async def test_microsoft_consumer_account(idp):
    idp["info"] = {"sub": "m-1", "email": "mike@outlook.com", "name": "Mike"}
    idp["id_claims"] = {"tid": oauth.MS_CONSUMER_TENANT}
    async with client() as c:
        loc, q = await start(c, "microsoft")
        assert "login.microsoftonline.com" in loc.netloc
        r = await c.get("/oauth/microsoft/callback", params={"code": "C", "state": q["state"]}, follow_redirects=False)
        assert r.status_code == 303 and COOKIE_SESSION in c.cookies
        assert (await c.get("/dashboard")).status_code == 200


@pytest.mark.anyio
async def test_state_must_match_browser_cookie_and_errors_are_handled(idp):
    async with client() as c:
        _, q = await start(c)
    async with client() as attacker_victim:                  # different browser: no ss_oauth cookie
        r = await attacker_victim.get("/oauth/google/callback", params={"code": "C", "state": q["state"]})
        assert r.status_code == 400 and COOKIE_SESSION not in attacker_victim.cookies
    async with client() as c:
        r = await c.get("/oauth/google/callback", params={"error": "access_denied", "state": "x"})
        assert r.status_code == 400 and "cancelled" in r.text
        r = await c.get("/oauth/google/callback", params={"code": "C", "state": "forged"})
        assert r.status_code == 400


@pytest.mark.anyio
async def test_unconfigured_and_unknown_provider(monkeypatch):
    s = get_settings()
    monkeypatch.setattr(s, "google_client_id", "")
    async with client() as c:
        assert (await c.get("/oauth/google")).status_code == 404
        assert (await c.get("/oauth/facebook")).status_code == 404


@pytest.mark.anyio
async def test_unverified_google_email_rejected_and_preregistered_account_neutralised(idp):
    async with client() as c:
        idp["info"]["email_verified"] = False
        _, q = await start(c)
        r = await c.get("/oauth/google/callback", params={"code": "C", "state": q["state"]})
        assert r.status_code == 400 and COOKIE_SESSION not in c.cookies
    # attacker pre-registers the victim's address with a known password, victim then signs in with Google
    async with client() as a:
        t = re.search(r'name="csrf_token"\s+value="([^"]+)"', (await a.get("/register")).text).group(1)
        r = await a.post("/register", data={"csrf_token": t, "email": "gina@example.com", "password": "Attacker-Pass123!",
                                            "full_name": "Eve"}, follow_redirects=False)
        assert r.status_code == 303
    idp["info"]["email_verified"] = True
    async with client() as v:
        _, q = await start(v)
        r = await v.get("/oauth/google/callback", params={"code": "C", "state": q["state"]}, follow_redirects=False)
        assert r.status_code == 303
    async with client() as a2:                                # the attacker's password no longer works
        t = re.search(r'name="csrf_token"\s+value="([^"]+)"', (await a2.get("/login")).text).group(1)
        r = await a2.post("/login", data={"csrf_token": t, "email": "gina@example.com", "password": "Attacker-Pass123!"})
        assert r.status_code == 400
