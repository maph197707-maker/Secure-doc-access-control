"""Test database migrations and verify model-vs-migration drift."""
import pytest
from pathlib import Path
from alembic.config import Config
from alembic import command
from alembic.autogenerate import compare_metadata
from alembic.runtime.migration import MigrationContext
from sqlalchemy import create_engine
from app.db.base import Base
from app.config.settings import get_settings
import app.models  # noqa: F401

ROOT = Path(__file__).resolve().parents[2]


def test_migrations_and_drift():
    """Verify that models match the current database migration schema with no drift."""
    settings = get_settings()
    # Use sync sqlite connection for alembic context compare
    db_file = ROOT / "test_migration_drift.db"
    if db_file.exists():
        db_file.unlink()

    async_url = f"sqlite+aiosqlite:///{db_file}"
    sync_url = f"sqlite:///{db_file}"
    alembic_cfg = Config(str(ROOT / "alembic.ini"))
    alembic_cfg.attributes["sqlalchemy_url"] = async_url

    # 1. Run migrations upgrade head, then downgrade base, then upgrade head again
    command.upgrade(alembic_cfg, "head")
    command.downgrade(alembic_cfg, "base")
    command.upgrade(alembic_cfg, "head")

    # 2. Check for drift against Base.metadata
    engine = create_engine(sync_url)
    with engine.connect() as conn:
        ctx = MigrationContext.configure(conn, opts={"render_as_batch": True})
        diff = compare_metadata(ctx, Base.metadata)

    engine.dispose()
    if db_file.exists():
        db_file.unlink()

    # Diff should be empty (no added/dropped tables, columns, indexes)
    # Filter out known harmless sqlite type differences if any
    structural_diffs = [
        d for d in diff 
        if d[0] in ("add_table", "remove_table", "add_column", "remove_column")
    ]
    assert structural_diffs == [], f"Detected schema drift: {structural_diffs}"
