"""Optional two-factor sign-in end to end (WRITTEN, NOT RUN in the authoring sandbox: needs FastAPI/SQLAlchemy).
Sign-up needs no OTP; MFA is an opt-in from /settings/security; login then asks for the code."""
from __future__ import annotations

import re

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from app.config.constants import COOKIE_SESSION
from app.db.session import create_tables, drop_tables
from app.main import app
from app.services import mfa
from scripts.seed_roles import seed_roles

pytestmark = pytest.mark.deferred_verification
PW = "MfaPassword123!"


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables()
    await create_tables()
    await seed_roles()
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


def csrf(html: str) -> str:
    m = re.search(r'name="csrf_token"\s+value="([^"]+)"', html)
    return m.group(1) if m else "demo"


@pytest.mark.anyio
async def test_mfa_is_optional_then_enforced_at_login():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000") as c:
        # sign-up without any OTP -> signed in
        t = csrf((await c.get("/register")).text)
        r = await c.post("/register", data={"csrf_token": t, "email": "mia@example.com", "password": PW,
                                            "full_name": "Mia Tester"}, follow_redirects=False)
        assert r.status_code == 303 and COOKIE_SESSION in c.cookies

        # opt in
        page = await c.get("/settings/security")
        assert page.status_code == 200 and "Set up authenticator app" in page.text
        start = await c.post("/settings/security/mfa/start", data={"csrf_token": csrf(page.text)})
        secret = re.search(r"<code>([A-Z2-7]{16,})</code>", start.text).group(1)
        bad = await c.post("/settings/security/mfa/enable", data={"csrf_token": csrf(start.text), "code": "000000"})
        assert bad.status_code == 400
        ok = await c.post("/settings/security/mfa/enable",
                          data={"csrf_token": csrf(start.text), "code": mfa.totp_at(secret)})
        assert ok.status_code == 200 and "Recovery codes" in ok.text
        recovery = re.findall(r"<code>([0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4})</code>", ok.text)
        assert len(recovery) == 10

        # logout, login: password alone no longer gives a session
        await c.post("/logout", data={"csrf_token": c.cookies.get("ss_csrf", "demo")})
        c.cookies.delete(COOKIE_SESSION)
        t = csrf((await c.get("/login")).text)
        step1 = await c.post("/login", data={"csrf_token": t, "email": "mia@example.com", "password": PW},
                             follow_redirects=False)
        assert step1.status_code == 303 and step1.headers["location"] == "/mfa"
        assert COOKIE_SESSION not in step1.cookies
        assert (await c.get("/dashboard", follow_redirects=False)).status_code == 303   # still signed out

        # wrong code, then a recovery code (works once)
        m = await c.get("/mfa")
        assert (await c.post("/mfa", data={"csrf_token": csrf(m.text), "code": "111111"})).status_code == 400
        done = await c.post("/mfa", data={"csrf_token": csrf(m.text), "code": recovery[0]}, follow_redirects=False)
        assert done.status_code == 303 and COOKIE_SESSION in c.cookies
        assert (await c.get("/dashboard")).status_code == 200


@pytest.mark.anyio
async def test_account_without_mfa_logs_in_with_password_only():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000") as c:
        t = csrf((await c.get("/register")).text)
        await c.post("/register", data={"csrf_token": t, "email": "nia@example.com", "password": PW,
                                        "full_name": "Nia"}, follow_redirects=False)
        await c.post("/logout", data={"csrf_token": c.cookies.get("ss_csrf", "demo")})
        c.cookies.delete(COOKIE_SESSION)
        t = csrf((await c.get("/login")).text)
        r = await c.post("/login", data={"csrf_token": t, "email": "nia@example.com", "password": PW},
                         follow_redirects=False)
        assert r.status_code == 303 and r.headers["location"] == "/dashboard"
