import io, tempfile, unittest, zipfile
from pathlib import Path
from app.security.validators import validate_upload, normalize_filename, UploadRejected
from app.security.archive_safety import check_ooxml, UnsafeArchive
from app.security.path_security import safe_join, PathViolation, new_internal_name
from app.integrations.malware import LocalDevelopmentMalwareScanner, UnavailableScanner, ScanStatus, EICAR

MAX = 10 * 1024 * 1024


def ooxml(kind="docx", extra=None):
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", "<x/>"); z.writestr({"docx": "word/document.xml"}[kind], "<d/>")
        for n, d in (extra or {}).items(): z.writestr(n, d)
    return b


class ValidatorTests(unittest.TestCase):
    def ok(self, name, head, size=100):
        return validate_upload(name, head, size, max_bytes=MAX)

    def test_valid_types(self):
        self.assertEqual(self.ok("a.pdf", b"%PDF-1.7 ...").family, "pdf")
        self.assertEqual(self.ok("a.PNG", b"\x89PNG\r\n\x1a\n....").ext, "png")
        self.assertEqual(self.ok("a.jpg", b"\xff\xd8\xff\xe0").family, "jpeg")
        self.assertEqual(self.ok("a.csv", b"a,b\n1,2\n").family, "text")
        self.assertEqual(self.ok("a.docx", b"PK\x03\x04..").family, "zip")

    def test_rejections(self):
        cases = [("a.exe", b"MZ\x90", "TYPE_NOT_ALLOWED"), ("a.pdf", b"MZ\x90\x00", "CONTENT_MISMATCH"),
                 ("a.png", b"%PDF-1.4", "CONTENT_MISMATCH"), ("a.txt", b"\x00\x01\x02", "CONTENT_MISMATCH"),
                 ("noext", b"abc", "BAD_FILENAME"), ("CON.txt", b"abc", "BAD_FILENAME")]
        for name, head, code in cases:
            with self.assertRaises(UploadRejected) as cm:
                self.ok(name, head)
            self.assertEqual(cm.exception.code, code, name)
        with self.assertRaises(UploadRejected) as cm: self.ok("a.pdf", b"%PDF-", size=MAX + 1)
        self.assertEqual(cm.exception.code, "TOO_LARGE")
        with self.assertRaises(UploadRejected) as cm: self.ok("a.pdf", b"", size=0)
        self.assertEqual(cm.exception.code, "EMPTY_FILE")

    def test_filename_normalisation(self):
        self.assertEqual(normalize_filename("../../etc/passwd.txt"), "passwd.txt")
        self.assertEqual(normalize_filename("C:\\x\\evil<>.pdf"), "evil__.pdf")
        self.assertEqual(normalize_filename("a\x00b.pdf"), "ab.pdf")
        self.assertNotIn("/", normalize_filename("a/b.pdf"))


class ArchiveTests(unittest.TestCase):
    def test_valid_docx_passes(self):
        check_ooxml(ooxml(), "docx")

    def test_zip_bomb_rejected(self):
        b = ooxml(extra={"word/bomb.bin": b"\0" * (30 * 1024 * 1024)})
        with self.assertRaises(UnsafeArchive): check_ooxml(b, "docx", max_uncompressed=10 * 1024 * 1024)
        with self.assertRaises(UnsafeArchive): check_ooxml(b, "docx", max_ratio=50)

    def test_traversal_and_wrong_kind_and_garbage(self):
        with self.assertRaises(UnsafeArchive): check_ooxml(ooxml(extra={"../evil": "x"}), "docx")
        with self.assertRaises(UnsafeArchive): check_ooxml(ooxml(), "xlsx")
        with self.assertRaises(UnsafeArchive): check_ooxml(io.BytesIO(b"PK\x03\x04junk"), "docx")


class PathTests(unittest.TestCase):
    def test_traversal_and_symlink(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            for bad in ("../x", "a/b", "..", "/etc/passwd", "a\\b", "", "x\x00y"):
                with self.assertRaises(PathViolation, msg=bad): safe_join(root, bad)
            name = new_internal_name()
            self.assertEqual(safe_join(root, name).parent, root.resolve())
            try:
                (root / "link").symlink_to("/etc")
                with self.assertRaises(PathViolation): safe_join(root, "link")
            except OSError:
                pass  # Windows unprivileged symlink creation


class MalwareTests(unittest.TestCase):
    def test_statuses_never_claim_clean(self):
        s = LocalDevelopmentMalwareScanner()
        self.assertEqual(s.scan(b"hello").status, ScanStatus.NO_DETECTION_DEV)
        self.assertEqual(s.scan(b"x" + EICAR).status, ScanStatus.INFECTED)
        self.assertEqual(UnavailableScanner().scan(b"x").status, ScanStatus.PROVIDER_UNAVAILABLE)


if __name__ == "__main__":
    unittest.main()
