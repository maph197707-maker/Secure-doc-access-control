"""ClamdScanner against a fake clamd server speaking the real INSTREAM wire protocol."""
import socket, struct, threading, unittest
from types import SimpleNamespace
from app.integrations.malware import ClamdScanner, ScanStatus, EICAR, build_scanner, LocalDevelopmentMalwareScanner, UnavailableScanner


class FakeClamd:
    def __init__(self, reply=None):
        self.srv = socket.socket(); self.srv.bind(("127.0.0.1", 0)); self.srv.listen(1)
        self.port = self.srv.getsockname()[1]; self.reply = reply; self.received = b""
        threading.Thread(target=self._run, daemon=True).start()

    def _recv(self, c, n):
        b = b""
        while len(b) < n:
            p = c.recv(n - len(b))
            if not p: raise EOFError
            b += p
        return b

    def _run(self):
        c, _ = self.srv.accept()
        self.srv.close()
        with c:
            cmd = self._recv(c, 10)
            if cmd == b"zPING\0"[:10] or cmd.startswith(b"zPING"):
                c.sendall(b"PONG\0"); return
            assert cmd == b"zINSTREAM\0"
            while True:
                (n,) = struct.unpack("!I", self._recv(c, 4))
                if n == 0: break
                self.received += self._recv(c, n)
            if self.reply is None:
                self.reply = b"stream: Eicar-Test-Signature FOUND\0" if b"EICAR-STANDARD" in self.received else b"stream: OK\0"
            c.sendall(self.reply)


class ClamdTests(unittest.TestCase):
    def test_clean_and_chunking(self):
        f = FakeClamd(); data = b"a" * (200 * 1024)
        r = ClamdScanner("127.0.0.1", f.port).scan(data)
        self.assertEqual(r.status, ScanStatus.CLEAN); self.assertEqual(f.received, data)

    def test_infected(self):
        f = FakeClamd(); r = ClamdScanner("127.0.0.1", f.port).scan(EICAR)
        self.assertEqual(r.status, ScanStatus.INFECTED); self.assertIn("Eicar", r.detail)

    def test_error_reply_fails_closed(self):
        f = FakeClamd(b"INSTREAM size limit exceeded. ERROR\0")
        self.assertEqual(ClamdScanner("127.0.0.1", f.port).scan(b"x").status, ScanStatus.PROVIDER_UNAVAILABLE)

    def test_unreachable_is_unavailable_not_clean(self):
        s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
        self.assertEqual(ClamdScanner("127.0.0.1", port, timeout=1).scan(b"x").status, ScanStatus.PROVIDER_UNAVAILABLE)

    def test_oversize_not_scanned(self):
        self.assertEqual(ClamdScanner(max_bytes=3).scan(b"abcd").status, ScanStatus.PROVIDER_UNAVAILABLE)

    def test_factory(self):
        mk = lambda b: SimpleNamespace(malware_backend=b, clamav_host="h", clamav_port=1)
        self.assertIsInstance(build_scanner(mk("clamav")), ClamdScanner)
        self.assertIsInstance(build_scanner(mk("dev")), LocalDevelopmentMalwareScanner)
        self.assertIsInstance(build_scanner(mk("provider_unavailable")), UnavailableScanner)


if __name__ == "__main__":
    unittest.main()
