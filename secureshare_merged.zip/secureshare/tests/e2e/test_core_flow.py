"""Core flow, end to end, through the real app:
login -> upload -> validate -> encrypt -> store -> share -> recipient verification -> PDP check ->
view/download -> audit -> revoke -> denied.   Run: pytest tests/e2e/test_core_flow.py -v
Requires the project's declared dependencies (fastapi, sqlalchemy, httpx, pytest-asyncio ...)."""
from __future__ import annotations

import re
from pathlib import Path

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy import text

from app.config.settings import get_settings
from app.db.session import create_tables, drop_tables, engine
from app.main import app
from tests.support import providers
from tests.support.providers import last_email_code
from scripts.seed_roles import seed_roles
from tests.api.test_recipient_links import _bound_link, _code

BASE = "http://localhost:8000"
PW = "StrongPassword123!"
CONTENT = b"core-flow secret payload 7f3a\n" * 50


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables(); await create_tables(); await seed_roles()
    providers.OUTBOX.email.sent.clear()
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


def _client(**headers) -> AsyncClient:
    return AsyncClient(transport=ASGITransport(app=app), base_url=BASE, headers=headers)


async def _user(email: str) -> AsyncClient:
    c = _client()
    r = await c.post("/api/v1/auth/register", json={"email": email, "password": PW, "full_name": email.split("@")[0]})
    assert r.status_code == 201, r.text
    assert (await c.post("/api/v1/auth/verify-email", json={"email": email, "code": last_email_code()})).status_code == 200
    login = await c.post("/api/v1/auth/login", json={"email": email, "password": PW})
    assert login.status_code == 200, login.text
    c.cookies.clear(); c.headers["Authorization"] = f"Bearer {login.json()['access_token']}"
    return c


async def _audit_actions() -> list[str]:
    async with engine.begin() as conn:
        return [a for (a,) in (await conn.execute(text("SELECT action FROM audit_logs ORDER BY sequence_number"))).all()]


@pytest.mark.anyio
async def test_upload_is_validated_and_stored_encrypted():
    owner = await _user("owner@example.com")
    try:
        ok = await owner.post("/api/v1/documents", files={"file": ("m.txt", CONTENT, "text/plain")})
        assert ok.status_code == 201, ok.text
        # validation: a disallowed type and a lying extension are refused
        assert (await owner.post("/api/v1/documents", files={"file": ("evil.exe", b"MZ\x90\x00", "application/octet-stream")})).status_code in (400, 415, 422)
        # encryption at rest: no stored object contains the plaintext
        root = Path(get_settings().storage_root)
        blobs = [p for p in root.rglob("*") if p.is_file()]
        assert blobs and all(CONTENT[:20] not in p.read_bytes() for p in blobs)
        # round trip through the authorised API returns the original bytes
        assert (await owner.get(f"/api/v1/documents/{ok.json()['id']}/download")).content == CONTENT
        assert "DOCUMENT_UPLOAD" in await _audit_actions()
    finally:
        await owner.aclose()


@pytest.mark.anyio
async def test_recipient_verified_view_then_cookie_theft_unauthorised_and_revoke():
    owner = await _user("owner@example.com"); bob = _client(**{"User-Agent": "BobBrowser/1.0"})
    try:
        path = await _bound_link(owner, content=CONTENT, binding_mode="EMAIL_OTP", recipient_email="bob@example.com")
        csrf = "demo"
        # no verification -> no bytes
        assert (await bob.get(path + "/content")).status_code == 303
        await bob.get(path)
        hit = await bob.post(path + "/claim", data={"email": "bob@example.com", "csrf_token": csrf})
        pending = re.search(r'name="pending" value="([^"]+)"', hit.text).group(1)
        code = _code(providers.OUTBOX.email.sent[-1].get_content())
        assert (await bob.post(path + "/code", data={"code": code, "pending": pending, "csrf_token": csrf})).status_code == 303
        # verified recipient: PDP allows, bytes match
        r = await bob.get(path + "/content")
        assert r.status_code == 200 and r.content == CONTENT
        d = await bob.get(path + "/download")
        assert d.status_code == 200 and d.content == CONTENT

        # another browser/user holding a COPY of bob's cookies is refused (session is bound to the browser)
        thief = _client(**{"User-Agent": "MalloryBrowser/9.9"})
        for k, v in bob.cookies.items():
            thief.cookies.set(k, v)
        assert (await thief.get(path + "/content")).status_code == 303
        # an authenticated but unrelated user cannot read the document via the API either
        mallory = await _user("mallory@example.com")
        doc_id = (await owner.get("/api/v1/documents")).json()["items"][0]["id"]
        assert (await mallory.get(f"/api/v1/documents/{doc_id}/content")).status_code in (403, 404)
        await thief.aclose(); await mallory.aclose()

        # audit trail exists for the real events
        acts = await _audit_actions()
        assert {"SECURE_LINK_RECIPIENT_VERIFIED", "SECURE_LINK_VIEW", "SECURE_LINK_DENIED"} <= set(acts)

        # revoke -> immediate denial for the verified recipient
        links = (await owner.get("/api/v1/links")).json()
        link_id = (links["items"] if isinstance(links, dict) else links)[0]["id"]
        assert (await owner.delete(f"/api/v1/links/{link_id}")).status_code == 204
        assert (await bob.get(path + "/content")).status_code == 403
        assert "SECURE_LINK_REVOKE" in await _audit_actions()
    finally:
        await owner.aclose(); await bob.aclose()


@pytest.mark.anyio
async def test_pdp_decision_is_enforced_and_recorded_on_link_access():
    owner = await _user("owner@example.com"); anon = _client()
    try:
        doc_id = (await owner.post("/api/v1/documents", files={"file": ("m.txt", CONTENT, "text/plain")})).json()["id"]
        link = (await owner.post("/api/v1/links", json={"document_id": doc_id})).json()
        path = "/" + link["share_url"].split("/", 3)[3]
        assert (await anon.get(path + "/content")).status_code == 200
        async with engine.begin() as conn:
            det = " ".join(str(d) for (d,) in (await conn.execute(text("SELECT details FROM audit_logs WHERE action='SECURE_LINK_VIEW'"))).all())
        assert "ALLOW" in det and "risk_score" in det                      # decision + real risk were recorded
        # a link flagged ABUSED is refused by the PDP even though token/expiry/password are all fine
        async with engine.begin() as conn:
            await conn.execute(text("UPDATE secure_links SET reputation='ABUSED' WHERE id=:i"), {"i": link["id"]})
        assert (await anon.get(path + "/content")).status_code == 403
        # a link demanding MFA cannot be satisfied anonymously -> denied (fail closed), never silently opened
        link2 = (await owner.post("/api/v1/links", json={"document_id": doc_id})).json()
        async with engine.begin() as conn:
            await conn.execute(text("UPDATE secure_links SET requires_mfa=1 WHERE id=:i"), {"i": link2["id"]})
        assert (await anon.get("/" + link2["share_url"].split("/", 3)[3] + "/content")).status_code == 403
    finally:
        await owner.aclose(); await anon.aclose()


@pytest.mark.anyio
async def test_api_share_expired_and_revoked_access_denied():
    owner = await _user("owner@example.com"); guest = await _user("guest@example.com")
    try:
        doc_id = (await owner.post("/api/v1/documents", files={"file": ("m.txt", CONTENT, "text/plain")})).json()["id"]
        assert (await guest.get(f"/api/v1/documents/{doc_id}/content")).status_code in (403, 404)       # before share
        g = await owner.post("/api/v1/shares", json={"document_id": doc_id, "grantee_email": "guest@example.com", "permissions": ["VIEW"]})
        assert g.status_code == 201, g.text
        assert (await guest.get(f"/api/v1/documents/{doc_id}/content")).content == CONTENT
        assert (await guest.get(f"/api/v1/documents/{doc_id}/download")).status_code == 403              # VIEW only
        async with engine.begin() as conn:                                                               # expire it
            await conn.execute(text("UPDATE access_grants SET expires_at='2000-01-01 00:00:00' WHERE document_id=:d"), {"d": doc_id})
        assert (await guest.get(f"/api/v1/documents/{doc_id}/content")).status_code == 403
        async with engine.begin() as conn:                                                               # un-expire, then revoke
            await conn.execute(text("UPDATE access_grants SET expires_at=NULL WHERE document_id=:d"), {"d": doc_id})
        assert (await guest.get(f"/api/v1/documents/{doc_id}/content")).status_code == 200
        assert (await owner.delete(f"/api/v1/shares/{g.json()['id']}")).status_code in (200, 204)
        assert (await guest.get(f"/api/v1/documents/{doc_id}/content")).status_code == 403
        acts = await _audit_actions()
        assert "ACCESS_DENIED" in acts and "SHARE_CREATED" in acts
    finally:
        await owner.aclose(); await guest.aclose()
