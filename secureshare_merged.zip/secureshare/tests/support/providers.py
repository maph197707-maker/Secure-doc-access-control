"""TEST-ONLY delivery doubles. Nothing under app/ imports this module and no setting can select it:
production code only ever builds the real SMTP / Twilio providers. conftest.py swaps them in per test
so the suite never touches the network, and records every message so tests can read the code that a
real user would have received.
"""
from __future__ import annotations

import re
from email.message import EmailMessage

from app.integrations import errors as E
from app.integrations.email import EmailDeliveryError, EmailProvider
from app.integrations.sms import SMSDeliveryError, SMSProvider

_CODE = re.compile(r"\b(\d{6})\b")


class RecordingEmailProvider(EmailProvider):
    name = "recording-test"

    def __init__(self) -> None:
        self.sent: list[EmailMessage] = []
        self.fail_with: str | None = None          # a reason from app.integrations.errors

    def send(self, msg: EmailMessage) -> None:
        if self.fail_with:
            raise EmailDeliveryError(self.fail_with, "test failure")
        self.sent.append(msg)

    def to(self, addr: str) -> list[EmailMessage]:
        return [m for m in self.sent if m["To"] == addr]

    def code_for(self, addr: str) -> str:
        msgs = self.to(addr)
        assert msgs, f"no email was delivered to {addr}"
        return _CODE.search(msgs[-1].get_content()).group(1)


class RecordingSMSProvider(SMSProvider):
    name = "recording-test"

    def __init__(self) -> None:
        self.sent: list[tuple[str, str]] = []
        self.fail_with: str | None = None

    def send(self, to_e164: str, body: str) -> str:
        if self.fail_with:
            raise SMSDeliveryError(self.fail_with, "test failure")
        self.sent.append((to_e164, body))
        return f"SMtest{len(self.sent)}"

    def code_for(self, number: str) -> str:
        msgs = [b for t, b in self.sent if t == number]
        assert msgs, f"no SMS was delivered to {number}"
        return _CODE.search(msgs[-1]).group(1)


class Outbox:
    """Per-test handle on both recording providers."""
    def __init__(self) -> None:
        self.email = RecordingEmailProvider()
        self.sms = RecordingSMSProvider()

    def email_code(self, addr: str) -> str:
        return self.email.code_for(addr)

    def sms_code(self, number: str) -> str:
        return self.sms.code_for(number)


OUTBOX = Outbox()          # reset for every test by the autouse fixture in conftest.py
FAIL = E                   # re-export for tests: FAIL.AUTH, FAIL.TIMEOUT, ...


def last_email_code() -> str:
    """The code in the most recent email the app 'delivered' (what the user would read in their inbox)."""
    assert OUTBOX.email.sent, "no email was delivered"
    return _CODE.search(OUTBOX.email.sent[-1].get_content()).group(1)
