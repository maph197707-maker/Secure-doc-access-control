"""Security tests for Insecure Direct Object Reference (IDOR) protections."""
import io
import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from app.config.constants import COOKIE_CSRF, HEADER_CSRF_TOKEN
from app.db.session import create_tables, drop_tables
from app.main import app
from tests.support.providers import last_email_code
from scripts.seed_roles import seed_roles


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables()
    await create_tables()
    await seed_roles()
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


async def _register_and_login(client: AsyncClient, email: str, name: str) -> tuple[str, str]:
    reg = await client.post(
        "/api/v1/auth/register",
        json={"email": email, "password": "SecurePassword123!", "full_name": name},
    )
    otp = last_email_code()
    if otp:
        await client.post("/api/v1/auth/verify-email", json={"email": email, "code": otp})

    login = await client.post(
        "/api/v1/auth/login",
        json={"email": email, "password": "SecurePassword123!"},
    )
    token = login.json()["access_token"]
    me_resp = await client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
    user_id = me_resp.json()["id"]
    return token, user_id


@pytest.mark.anyio
async def test_idor_prevented_on_documents():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client_a, \
               AsyncClient(transport=transport, base_url="http://localhost:8000") as client_b:
        # Register User A (Alice) and User B (Bob)
        token_a, user_a_id = await _register_and_login(client_a, "alice@example.com", "Alice")
        token_b, user_b_id = await _register_and_login(client_b, "bob@example.com", "Bob")

        csrf_tok_a = client_a.cookies.get(COOKIE_CSRF) or "demo"
        csrf_tok_b = client_b.cookies.get(COOKIE_CSRF) or "demo"
        headers_a = {"Authorization": f"Bearer {token_a}", HEADER_CSRF_TOKEN: csrf_tok_a}
        headers_b = {"Authorization": f"Bearer {token_b}", HEADER_CSRF_TOKEN: csrf_tok_b}

        # Alice uploads a private document
        upload_resp = await client_a.post(
            "/api/v1/documents/upload",
            files={"file": ("alice_secrets.txt", io.BytesIO(b"Alice Top Secret Confidential Data"), "text/plain")},
            headers=headers_a,
        )
        assert upload_resp.status_code == 201
        doc_id = upload_resp.json()["id"]

        # Alice can view her own document
        alice_view = await client_a.get(f"/api/v1/documents/{doc_id}", headers=headers_a)
        assert alice_view.status_code == 200

        # Bob attempts to view Alice's document -> must be 403 or 404 (IDOR blocked)
        bob_view = await client_b.get(f"/api/v1/documents/{doc_id}", headers=headers_b)
        assert bob_view.status_code in (403, 404)

        # Bob attempts to download Alice's document -> must be 403 or 404
        bob_download = await client_b.get(f"/api/v1/documents/{doc_id}/download", headers=headers_b)
        assert bob_download.status_code in (403, 404)

        # Bob attempts to delete Alice's document -> must be 403 or 404
        bob_delete = await client_b.delete(f"/api/v1/documents/{doc_id}", headers=headers_b)
        assert bob_delete.status_code in (403, 404)

        # Verify Alice's document is still intact
        alice_check = await client_a.get(f"/api/v1/documents/{doc_id}", headers=headers_a)
        assert alice_check.status_code == 200
