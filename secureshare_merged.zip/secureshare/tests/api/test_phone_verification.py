"""Signed-in user proves a phone number by SMS: /verify-phone (send -> code -> verify), all decisions in the backend."""
from __future__ import annotations

import re
from datetime import timedelta

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy import select, update

from app.db.session import AsyncSessionLocal, create_tables, drop_tables
from app.integrations import errors as E
from app.integrations import factory
from app.main import app
from app.models.audit import AuditLog
from app.models.otp import OtpChallenge
from app.models.user import User
from app.services import otp as o
from scripts.seed_roles import seed_roles
from tests.support import providers
from tests.support.providers import last_email_code

EMAIL, PW, PHONE, E164 = "phone.user@example.com", "StrongPassword123!", "98765 43210", "+919876543210"


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables(); await create_tables(); await seed_roles()
    yield
    await drop_tables()


async def _signed_in() -> AsyncClient:
    c = AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000")
    assert (await c.post("/api/v1/auth/register", json={"email": EMAIL, "password": PW, "full_name": "Phone User"})).status_code == 201
    await c.post("/api/v1/auth/verify-email", json={"email": EMAIL, "code": last_email_code()})
    assert (await c.post("/api/v1/auth/login", json={"email": EMAIL, "password": PW})).status_code == 200
    return c


async def _post(c, **form):
    page = await c.get("/verify-phone")
    assert page.status_code == 200, page.text
    return await c.post("/verify-phone", data={"csrf_token": c.cookies.get("ss_csrf") or "demo", **form})


async def _user() -> User:
    async with AsyncSessionLocal() as s:
        return (await s.execute(select(User).where(User.email == EMAIL))).scalar_one()


async def _skip_cooldown():
    async with AsyncSessionLocal() as s:
        await s.execute(update(OtpChallenge).values(resend_available_at=o.utcnow() - timedelta(seconds=1))); await s.commit()


def _wrong(code): return "000000" if code != "000000" else "111111"


@pytest.mark.anyio
async def test_send_sms_then_verify_marks_the_phone_verified():
    c = await _signed_in()
    r = await _post(c, action="send", phone=PHONE)
    assert r.status_code == 200 and "Code sent to +91*******210" in r.text
    assert providers.OUTBOX.sms.sent[-1][0] == E164
    code = providers.OUTBOX.sms_code(E164)
    assert code not in r.text                                                    # never rendered back
    assert (await _user()).phone_verified is False
    r = await _post(c, action="verify", code=code)
    assert r.status_code == 200 and "Phone verified" in r.text
    u = await _user()
    assert u.phone == E164 and u.phone_verified is True
    async with AsyncSessionLocal() as s:
        audit = [a.action for a in (await s.execute(select(AuditLog))).scalars()]
    assert {"OTP_SENT", "OTP_VERIFIED", "PHONE_VERIFIED"} <= set(audit)
    await c.aclose()


@pytest.mark.anyio
async def test_wrong_code_lockout_replay_and_cooldown():
    c = await _signed_in()
    await _post(c, action="send", phone=PHONE)
    code = providers.OUTBOX.sms_code(E164)
    cd = await _post(c, action="send", phone=PHONE)                               # immediate resend
    assert cd.status_code == 429 and len(providers.OUTBOX.sms.sent) == 1
    for _ in range(4):
        assert (await _post(c, action="verify", code=_wrong(code))).status_code == 401
    assert (await _post(c, action="verify", code=_wrong(code))).status_code == 429       # locked
    assert (await _post(c, action="verify", code=code)).status_code == 429               # correct code refused
    assert (await _user()).phone_verified is False
    await _skip_cooldown()
    await _post(c, action="send", phone=PHONE)
    fresh = providers.OUTBOX.sms_code(E164)
    assert (await _post(c, action="verify", code=fresh)).status_code == 200
    replay = await _post(c, action="verify", code=fresh)
    assert replay.status_code == 400 and "already used" in replay.text
    await c.aclose()


@pytest.mark.anyio
async def test_a_code_is_bound_to_the_number_it_was_sent_to():
    c = await _signed_in()
    await _post(c, action="send", phone=PHONE); code = providers.OUTBOX.sms_code(E164)
    await _skip_cooldown()
    await _post(c, action="send", phone="+14155552671")                           # user switches number
    u = await _user()
    assert u.phone == "+14155552671" and u.phone_verified is False
    assert (await _post(c, action="verify", code=code)).status_code in (400, 401)  # old number's code is useless
    assert (await _user()).phone_verified is False
    await c.aclose()


@pytest.mark.anyio
@pytest.mark.parametrize("reason,status", [(E.TIMEOUT, 502), (E.AUTH, 503), (E.RECIPIENT, 422), (E.RATE_LIMITED, 503)])
async def test_sms_provider_failure_is_reported_audited_and_not_claimed_sent(reason, status):
    c = await _signed_in()
    providers.OUTBOX.sms.fail_with = reason
    r = await _post(c, action="send", phone=PHONE)
    assert r.status_code == status and "Code sent" not in r.text
    async with AsyncSessionLocal() as s:
        failed = [a for a in (await s.execute(select(AuditLog))).scalars() if a.action == "OTP_DELIVERY_FAILED"]
    assert len(failed) == 1 and failed[0].details["reason"] == reason and failed[0].details["channel"] == "sms"
    providers.OUTBOX.sms.fail_with = None
    assert (await _post(c, action="send", phone=PHONE)).status_code == 200        # retry works at once
    await c.aclose()


@pytest.mark.anyio
async def test_unconfigured_sms_is_unavailable(monkeypatch):
    c = await _signed_in()
    monkeypatch.setattr(factory, "get_sms_service", lambda: None)
    r = await _post(c, action="send", phone=PHONE)
    assert r.status_code == 503 and "no SMS provider" in r.text and providers.OUTBOX.sms.sent == []
    await c.aclose()


@pytest.mark.anyio
async def test_requires_login():
    c = AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000")
    r = await c.get("/verify-phone")
    assert r.status_code == 303 and r.headers["location"].startswith("/login")
    await c.aclose()
