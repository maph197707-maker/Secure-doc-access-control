"""DLP end to end over the real app: upload -> extraction -> findings -> level/classification -> block."""
import io
import zipfile

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy import select

from app.config.constants import COOKIE_CSRF, HEADER_CSRF_TOKEN
from app.config.settings import get_settings
from app.db.session import AsyncSessionLocal, create_tables, drop_tables
from app.main import app
from app.models.audit import AuditLog
from app.models.document import Document
from scripts.seed_roles import seed_roles
from tests.support.providers import last_email_code

PW = "SecurePassword123!"
SENSITIVE = b"Customer card 4111 1111 1111 1111, contact alice@example.com, PAN ABCPD1234E."


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables(); await create_tables(); await seed_roles()
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


async def _user(client, email):
    await client.post("/api/v1/auth/register", json={"email": email, "password": PW, "full_name": email.split("@")[0]})
    otp = last_email_code()
    if otp:
        await client.post("/api/v1/auth/verify-email", json={"email": email, "code": otp})
    tok = (await client.post("/api/v1/auth/login", json={"email": email, "password": PW})).json()["access_token"]
    return {"Authorization": f"Bearer {tok}", HEADER_CSRF_TOKEN: client.cookies.get(COOKIE_CSRF) or "demo"}


async def _upload(client, h, name, data, **form):
    return await client.post("/api/v1/documents/upload", headers=h, data=form,
                             files={"file": (name, io.BytesIO(data), "application/octet-stream")})


def _docx(text: str) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("[Content_Types].xml", "<Types/>")
        z.writestr("word/document.xml", f"<w:document><w:body><w:p><w:r><w:t>{text}</w:t></w:r></w:p></w:body></w:document>")
        z.writestr("docProps/core.xml", "<cp><dc:title>Quarterly</dc:title><dc:creator>Bob</dc:creator></cp>")
    return buf.getvalue()


@pytest.mark.anyio
async def test_upload_detects_sensitive_data_and_escalates():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000") as c:
        h = await _user(c, "alice@example.com")
        r = await _upload(c, h, "customers.txt", SENSITIVE, classification="INTERNAL")
        assert r.status_code == 201
        body = r.json()
        assert body["dlp_level"] == "CRITICAL"
        doc_id = body["id"]

        f = await c.get(f"/api/v1/dlp/documents/{doc_id}/findings", headers=h)
        assert f.status_code == 200
        data = f.json()
        assert data["classification"] == "RESTRICTED"            # raised from INTERNAL, never lowered
        names = {x["rule"] for x in data["findings"]}
        assert {"credit_card", "pan_card", "email_address"} <= names
        assert "4111 1111" not in f.text and "alice@example" not in f.text   # masked only
        assert data["analysis"]["status"] == "COMPLETED"

        async with AsyncSessionLocal() as s:
            acts = {a.action for a in (await s.execute(select(AuditLog))).scalars()}
        assert "DLP_FINDING" in acts


@pytest.mark.anyio
async def test_clean_document_is_none_and_classification_untouched():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000") as c:
        h = await _user(c, "alice@example.com")
        r = await _upload(c, h, "notes.txt", b"Meeting at noon about the roadmap.", classification="PUBLIC")
        assert r.json()["dlp_level"] == "NONE"
        f = (await c.get(f"/api/v1/dlp/documents/{r.json()['id']}/findings", headers=h)).json()
        assert f["findings"] == [] and f["classification"] == "PUBLIC"


@pytest.mark.anyio
async def test_docx_text_is_extracted_and_scanned():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000") as c:
        h = await _user(c, "alice@example.com")
        r = await _upload(c, h, "report.docx", _docx("Card 4111 1111 1111 1111"))
        assert r.status_code == 201 and r.json()["dlp_level"] == "CRITICAL"


@pytest.mark.anyio
async def test_unreadable_type_is_reported_unsupported_not_clean():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000") as c:
        h = await _user(c, "alice@example.com")
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("a.txt", "hello")
        r = await _upload(c, h, "bundle.zip", buf.getvalue())
        assert r.status_code == 201
        f = (await c.get(f"/api/v1/dlp/documents/{r.json()['id']}/findings", headers=h)).json()
        assert f["analysis"]["status"] == "UNSUPPORTED"


@pytest.mark.anyio
async def test_findings_and_rescan_are_owner_only_and_summary_admin_only():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000") as a, \
               AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000") as b:
        ha, hb = await _user(a, "alice@example.com"), await _user(b, "bob@example.com")
        doc_id = (await _upload(a, ha, "c.txt", SENSITIVE)).json()["id"]
        assert (await b.get(f"/api/v1/dlp/documents/{doc_id}/findings", headers=hb)).status_code in (403, 404)
        assert (await b.post(f"/api/v1/dlp/documents/{doc_id}/rescan", headers=hb)).status_code in (403, 404)
        assert (await b.get("/api/v1/dlp/summary", headers=hb)).status_code == 403
        rs = await a.post(f"/api/v1/dlp/documents/{doc_id}/rescan", headers=ha)
        assert rs.status_code == 200 and rs.json()["dlp_level"] == "CRITICAL"
        assert len(rs.json()["findings"]) == len({x["rule"] for x in rs.json()["findings"]})   # replaced, not duplicated


@pytest.mark.anyio
async def test_stateless_scan_endpoint_and_auth_required():
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000") as c:
        assert (await c.post("/api/v1/dlp/scan", json={"text": "x"})).status_code in (401, 403)
        h = await _user(c, "alice@example.com")
        r = await c.post("/api/v1/dlp/scan", json={"text": "ssn 123-45-6789"}, headers=h)
        assert r.status_code == 200 and r.json()["level"] == "CRITICAL"


@pytest.mark.anyio
async def test_configured_block_rejects_upload_stores_nothing_and_audits(monkeypatch):
    monkeypatch.setattr(get_settings(), "dlp_block_threshold", "CRITICAL")
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000") as c:
        h = await _user(c, "alice@example.com")
        r = await _upload(c, h, "customers.txt", SENSITIVE)
        assert r.status_code in (400, 422)
        assert "data-loss-prevention" in r.text
        ok = await _upload(c, h, "fine.txt", b"harmless text")
        assert ok.status_code == 201
    async with AsyncSessionLocal() as s:
        docs = (await s.execute(select(Document))).scalars().all()
        acts = [a.action for a in (await s.execute(select(AuditLog))).scalars()]
    assert [d.original_filename for d in docs] == ["fine.txt"]
    assert "DLP_BLOCKED" in acts                  # committed even though the request failed
