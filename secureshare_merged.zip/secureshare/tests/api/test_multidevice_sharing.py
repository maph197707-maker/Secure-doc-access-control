"""End-to-end: Device A (owner) shares -> Device B downloads -> A revokes -> B is denied -> audit.

Two independent HTTP clients stand in for two devices talking to the same server. Bearer tokens
are used (cookies cleared) so CSRF does not apply. NOT YET RUN in the authoring sandbox
(no sqlalchemy/fastapi installed there) - run: pytest tests/api/test_multidevice_sharing.py -v
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from app.db.session import create_tables, drop_tables
from app.main import app
from tests.support.providers import last_email_code
from scripts.seed_roles import seed_roles

BASE = "http://localhost:8000"
CONTENT = b"top secret quarterly numbers\n" * 50


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables(); await create_tables(); await seed_roles()
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


async def _device(email: str, name: str) -> AsyncClient:
    c = AsyncClient(transport=ASGITransport(app=app), base_url=BASE)
    pw = "StrongPassword123!"
    r = await c.post("/api/v1/auth/register", json={"email": email, "password": pw, "full_name": name})
    assert r.status_code == 201, r.text
    v = await c.post("/api/v1/auth/verify-email", json={"email": email, "code": last_email_code()})
    assert v.status_code == 200, v.text
    login = await c.post("/api/v1/auth/login", json={"email": email, "password": pw})
    assert login.status_code == 200, login.text
    token = login.json()["access_token"]
    c.cookies.clear()
    c.headers["Authorization"] = f"Bearer {token}"
    return c


@pytest.mark.anyio
async def test_share_download_revoke_denied_and_audited():
    a = await _device("owner@example.com", "Olivia Owner")
    b = await _device("bob@example.com", "Bob Recipient")
    try:
        up = await a.post("/api/v1/documents", files={"file": ("report.txt", CONTENT, "text/plain")})
        assert up.status_code == 201, up.text
        doc_id = up.json()["id"]

        # B cannot touch it before sharing
        assert (await b.get(f"/api/v1/documents/{doc_id}/download")).status_code == 403

        exp = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        sh = await a.post("/api/v1/shares", json={"document_id": doc_id, "grantee_email": "bob@example.com",
                                                  "permissions": ["VIEW", "DOWNLOAD"], "expires_at": exp})
        assert sh.status_code == 201, sh.text
        grant_id = sh.json()["id"]

        # B: notification + Shared With Me + bytes identical to what A uploaded
        notes = (await b.get("/api/v1/notifications")).json()
        assert any(n["type"] == "DOCUMENT_SHARED" for n in notes)
        swm = (await b.get("/api/v1/shares/with-me")).json()
        assert swm["total"] == 1 and swm["items"][0]["can_download"] is True
        dl = await b.get(f"/api/v1/documents/{doc_id}/download")
        assert dl.status_code == 200 and dl.content == CONTENT
        assert (await b.get(f"/api/v1/documents/{doc_id}/content")).status_code == 200

        # A: downgrade to view-only -> download denied, view still allowed
        assert (await a.patch(f"/api/v1/shares/{grant_id}", json={"permissions": ["VIEW"]})).status_code == 200
        assert (await b.get(f"/api/v1/documents/{doc_id}/download")).status_code == 403
        assert (await b.get(f"/api/v1/documents/{doc_id}/content")).status_code == 200

        # A revokes -> B's very next request is denied; no logout needed
        assert (await a.delete(f"/api/v1/shares/{grant_id}")).status_code == 200
        assert (await b.get(f"/api/v1/documents/{doc_id}/content")).status_code == 403
        assert (await b.get(f"/api/v1/documents/{doc_id}/download")).status_code == 403
        assert (await b.get("/api/v1/shares/with-me")).json()["items"][0]["status"] == "REVOKED"
        assert any(n["type"] == "ACCESS_REVOKED" for n in (await b.get("/api/v1/notifications")).json())

        # a third user cannot revoke/modify someone else's share
        c = await _device("eve@example.com", "Eve")
        try:
            assert (await c.delete(f"/api/v1/shares/{grant_id}")).status_code == 404
        finally:
            await c.aclose()

        # public paths never serve documents
        for path in (f"/static/{doc_id}", f"/uploads/{doc_id}", f"/files/{doc_id}"):
            assert (await b.get(path)).status_code in (404, 405)
    finally:
        await a.aclose(); await b.aclose()


@pytest.mark.anyio
async def test_access_request_approval_flow():
    a = await _device("owner2@example.com", "Owner Two")
    b = await _device("req@example.com", "Requester")
    try:
        doc_id = (await a.post("/api/v1/documents", files={"file": ("n.txt", CONTENT, "text/plain")})).json()["id"]
        assert (await b.get(f"/api/v1/documents/{doc_id}/content")).status_code == 403
        rq = await b.post("/api/v1/access/requests", json={"document_id": doc_id, "requested_permissions": ["VIEW"]})
        assert rq.status_code == 201, rq.text
        assert (await b.post("/api/v1/access/requests", json={"document_id": doc_id})).status_code == 409
        assert any(n["type"] == "ACCESS_REQUEST" for n in (await a.get("/api/v1/notifications")).json())
        # requester cannot approve their own request
        rid = rq.json()["id"]
        assert (await b.post(f"/api/v1/access/requests/{rid}/review", json={"status": "APPROVED"})).status_code == 404
        assert (await a.post(f"/api/v1/access/requests/{rid}/review", json={"status": "bogus"})).status_code == 422
        ok = await a.post(f"/api/v1/access/requests/{rid}/review", json={"status": "APPROVED"})
        assert ok.status_code == 200, ok.text
        assert (await b.get(f"/api/v1/documents/{doc_id}/content")).status_code == 200
        assert (await a.post(f"/api/v1/access/requests/{rid}/review", json={"status": "REJECTED"})).status_code == 409
    finally:
        await a.aclose(); await b.aclose()
