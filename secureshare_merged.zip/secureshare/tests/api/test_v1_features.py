"""Integration tests for SecureShare API v1 endpoints: documents, links, simulator, signatures, dashboard."""
from __future__ import annotations

import io
import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from app.config.constants import COOKIE_CSRF, HEADER_CSRF_TOKEN
from app.db.session import create_tables, drop_tables
from app.main import app
from tests.support.providers import last_email_code
from scripts.seed_roles import seed_roles


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables()
    await create_tables()
    await seed_roles()
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


@pytest.mark.anyio
async def test_api_v1_health():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client:
        resp = await client.get("/api/v1/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] in ("healthy", "ok")
        assert data["database"] == "connected"


@pytest.mark.anyio
async def test_zero_trust_simulator():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client:
        # Register and login
        reg_resp = await client.post(
            "/api/v1/auth/register",
            json={"email": "sim_user@example.com", "password": "Password123!", "full_name": "Sim User"},
        )
        assert reg_resp.status_code == 201
        otp = last_email_code()
        if otp:
            await client.post("/api/v1/auth/verify-email", json={"email": "sim_user@example.com", "code": otp})

        login_resp = await client.post(
            "/api/v1/auth/login",
            json={"email": "sim_user@example.com", "password": "Password123!"},
        )
        assert login_resp.status_code == 200
        token = login_resp.json()["access_token"]
        csrf_tok = client.cookies.get(COOKIE_CSRF) or "demo"
        client.headers.update({
            "Authorization": f"Bearer {token}",
            HEADER_CSRF_TOKEN: csrf_tok,
        })

        # Policy simulation
        sim_payload = {
            "action": "VIEW",
            "principal": "USER",
            "session_active": True,
            "email_verified": True,
            "link_status": "ACTIVE",
            "risk_score": 10,
        }
        resp = await client.post("/api/v1/simulator/policy", json=sim_payload)
        assert resp.status_code == 200
        data = resp.json()
        assert data["decision"] in ("ALLOW", "RESTRICT")
        assert data["allowed"] is True

        # Attack scenario simulation
        atk_resp = await client.post("/api/v1/simulator/attack")
        assert atk_resp.status_code == 200
        atk_data = atk_resp.json()
        assert atk_data["total_scenarios"] >= 5
        assert atk_data["mitigated_count"] == atk_data["total_scenarios"]


@pytest.mark.anyio
async def test_documents_and_secure_links_lifecycle(tmp_path):
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client:
        # Register and login
        reg_resp = await client.post(
            "/api/v1/auth/register",
            json={"email": "doc_owner@example.com", "password": "Password123!", "full_name": "Doc Owner"},
        )
        assert reg_resp.status_code == 201
        otp = last_email_code()
        if otp:
            await client.post("/api/v1/auth/verify-email", json={"email": "doc_owner@example.com", "code": otp})

        login_resp = await client.post(
            "/api/v1/auth/login",
            json={"email": "doc_owner@example.com", "password": "Password123!"},
        )
        assert login_resp.status_code == 200
        token = login_resp.json()["access_token"]
        csrf_tok = client.cookies.get(COOKIE_CSRF) or "demo"
        client.headers.update({
            "Authorization": f"Bearer {token}",
            HEADER_CSRF_TOKEN: csrf_tok,
        })

        # 1. Upload a document
        file_content = b"%PDF-1.4\nTest PDF content for secure sharing"
        files = {"file": ("test_doc.pdf", io.BytesIO(file_content), "application/pdf")}
        data = {"display_name": "My Secure Test Doc"}

        up_resp = await client.post("/api/v1/documents", files=files, data=data)
        assert up_resp.status_code == 201
        doc = up_resp.json()
        doc_id = doc["id"]
        assert doc["display_name"] == "My Secure Test Doc"

        # 2. List documents
        list_resp = await client.get("/api/v1/documents")
        assert list_resp.status_code == 200
        docs = list_resp.json()["items"]
        assert len(docs) >= 1
        assert any(d["id"] == doc_id for d in docs)

        # 3. Create a secure share link
        link_payload = {
            "document_id": doc_id,
            "expires_in_hours": 48,
            "allow_downloads": True,
            "max_views": 5,
        }
        link_resp = await client.post("/api/v1/links", json=link_payload)
        assert link_resp.status_code == 201
        link = link_resp.json()
        assert link["document_id"] == doc_id
        assert link["share_url"] is not None

        # 4. List links
        links_list_resp = await client.get("/api/v1/links")
        assert links_list_resp.status_code == 200
        assert len(links_list_resp.json()) >= 1

        # 5. Sign the document
        sign_resp = await client.post(f"/api/v1/signatures/documents/{doc_id}/sign")
        assert sign_resp.status_code == 201
        sig = sign_resp.json()
        assert sig["verify_result"] is True

        # 6. Verify signature
        sig_id = sig["id"]
        ver_resp = await client.post(f"/api/v1/signatures/{sig_id}/verify")
        assert ver_resp.status_code == 200
        assert ver_resp.json()["verify_result"] is True

        # 7. Dashboard summary
        dash_resp = await client.get("/api/v1/dashboard/summary")
        assert dash_resp.status_code == 200
        dash_data = dash_resp.json()
        assert dash_data["metrics"]["total_documents"] >= 1
        assert dash_data["metrics"]["active_links"] >= 1
