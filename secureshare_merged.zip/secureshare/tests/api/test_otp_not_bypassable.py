"""OTP is an independent server-side step: a valid login session/token does NOT stand in for it.

Everything goes straight to the HTTP API (no frontend), so these also prove that UI success screens
decide nothing: the backend refuses on its own. Only the mail transport is a test double.
"""
from __future__ import annotations

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy import select

from app.db.session import AsyncSessionLocal, create_tables, drop_tables
from app.main import app
from app.models.user import User
from scripts.seed_roles import seed_roles
from tests.support import providers
from tests.support.providers import last_email_code

PW = "StrongPassword123!"
EMAIL = "pending.user@example.com"
OTHER = "someone.else@example.com"
CONTENT = b"otp-bypass probe payload\n" * 20


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables(); await create_tables(); await seed_roles()
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


def _client() -> AsyncClient:
    return AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000")


async def _register(c: AsyncClient, email: str) -> None:
    r = await c.post("/api/v1/auth/register", json={"email": email, "password": PW, "full_name": "Probe"})
    assert r.status_code == 201, r.text


async def _status(email: str) -> tuple[bool, str]:
    async with AsyncSessionLocal() as s:
        u = (await s.execute(select(User).where(User.email == email))).scalar_one()
        return u.email_verified, u.status


@pytest.mark.anyio
async def test_valid_login_token_without_otp_cannot_reach_protected_api():
    async with _client() as c:
        await _register(c, EMAIL)
        # Right password, unverified email: no session/token is issued at all.
        login = await c.post("/api/v1/auth/login", json={"email": EMAIL, "password": PW})
        assert login.status_code == 403, login.text
        assert "access_token" not in login.text
        assert (await c.post("/api/v1/documents", files={"file": ("p.txt", CONTENT, "text/plain")})).status_code in (401, 403)
        assert await _status(EMAIL) == (False, "PENDING_VERIFICATION")

        # Completing the real OTP step is what allows signing in.
        v = await c.post("/api/v1/auth/verify-email", json={"email": EMAIL, "code": last_email_code()})
        assert v.status_code == 200, v.text
        assert await _status(EMAIL) == (True, "ACTIVE")
        login = await c.post("/api/v1/auth/login", json={"email": EMAIL, "password": PW})
        assert login.status_code == 200, login.text
        c.cookies.clear()
        c.headers["Authorization"] = f"Bearer {login.json()['access_token']}"
        ok = await c.post("/api/v1/documents", files={"file": ("p.txt", CONTENT, "text/plain")})
        assert ok.status_code == 201, ok.text

@pytest.mark.anyio
async def test_a_code_issued_for_another_address_cannot_verify_this_account():
    async with _client() as c:
        await _register(c, EMAIL)
        await _register(c, OTHER)
        other_code = providers.OUTBOX.email.code_for(OTHER)
        # The code is bound to its own challenge + destination + subject: it is useless here.
        r = await c.post("/api/v1/auth/verify-email", json={"email": EMAIL, "code": other_code})
        assert r.status_code == 422, r.text
        assert await _status(EMAIL) == (False, "PENDING_VERIFICATION")
        assert await _status(OTHER) == (False, "PENDING_VERIFICATION")      # nor did it activate its owner


@pytest.mark.anyio
async def test_verify_email_does_not_reveal_whether_an_address_is_registered():
    async with _client() as c:
        await _register(c, EMAIL)
        wrong = "000000" if last_email_code() != "000000" else "111111"
        known = await c.post("/api/v1/auth/verify-email", json={"email": EMAIL, "code": wrong})
        unknown = await c.post("/api/v1/auth/verify-email", json={"email": "nobody@example.com", "code": wrong})
        assert known.status_code == unknown.status_code == 422
        # bodies also carry a per-request request_id, so compare the parts that could leak information
        ke, ue = known.json()["error"], unknown.json()["error"]
        assert (ke["code"], ke["message"]) == (ue["code"], ue["message"])
