"""Registration -> OTP created -> hashed OTP persisted -> email sent by the backend -> user enters the code ->
backend verifies -> contact marked verified. Run through the real app; only the transport is a test double
(tests/support/providers.py), plus one test that drives the real SMTP provider through a mock smtplib."""
from __future__ import annotations

from datetime import timedelta

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy import select, update

from app.db.session import AsyncSessionLocal, create_tables, drop_tables
from app.integrations import errors as E
from app.integrations import factory
from app.integrations.email import EmailService, SmtpEmailProvider
from app.main import app
from app.models.audit import AuditLog
from app.models.otp import OtpChallenge
from app.models.user import User
from app.services import otp as o
from scripts.seed_roles import seed_roles
from tests.support import providers
from tests.support.providers import last_email_code

PW = "StrongPassword123!"
EMAIL = "otp.user@example.com"


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables(); await create_tables(); await seed_roles()
    yield
    await drop_tables()


def _client() -> AsyncClient:
    return AsyncClient(transport=ASGITransport(app=app), base_url="http://localhost:8000")


async def _register(c, email=EMAIL):
    return await c.post("/api/v1/auth/register", json={"email": email, "password": PW, "full_name": "Otp User"})


async def _verify(c, code, email=EMAIL):
    return await c.post("/api/v1/auth/verify-email", json={"email": email, "code": code})


async def _skip_cooldown():
    async with AsyncSessionLocal() as s:
        await s.execute(update(OtpChallenge).values(resend_available_at=o.utcnow() - timedelta(seconds=1)))
        await s.commit()


async def _user(email=EMAIL) -> User | None:
    async with AsyncSessionLocal() as s:
        return (await s.execute(select(User).where(User.email == email))).scalar_one_or_none()


async def _audit(action=None):
    async with AsyncSessionLocal() as s:
        rows = list((await s.execute(select(AuditLog))).scalars())
    return [r for r in rows if action is None or r.action == action]


def _wrong(code): return "000000" if code != "000000" else "111111"


@pytest.mark.anyio
async def test_full_flow_register_send_persist_hashed_verify_activate_login():
    async with _client() as c:
        r = await _register(c)
        assert r.status_code == 201, r.text
        code = last_email_code()
        # delivered by the backend to the registered address, and never exposed to the client
        assert providers.OUTBOX.email.sent[-1]["To"] == EMAIL
        assert r.json()["otp_delivery"] == "email" and "sent to your email" in r.json()["message"]
        assert code not in r.text and "dev_otp" not in r.text
        # persisted: hash only, with expiry / attempts / cooldown, bound to this user + address
        async with AsyncSessionLocal() as s:
            (row,) = (await s.execute(select(OtpChallenge))).scalars().all()
        user = await _user()
        assert row.subject == user.id and row.status == "PENDING" and row.sent_at is not None
        assert row.otp_hash == o.hash_code(o.derive_key(__import__("app.config.settings", fromlist=["x"]).get_settings().master_secret), row.id, code)
        assert code not in str(vars(row)) and EMAIL not in str(vars(row))
        assert user.email_verified is False and user.status == "PENDING_VERIFICATION"
        # backend verification marks the contact verified
        v = await _verify(c, code)
        assert v.status_code == 200, v.text
        user = await _user()
        assert user.email_verified is True and user.status == "ACTIVE"
        assert (await c.post("/api/v1/auth/login", json={"email": EMAIL, "password": PW})).status_code == 200
        assert "OTP_SENT" in [a.action for a in await _audit()] and "OTP_VERIFIED" in [a.action for a in await _audit()]


@pytest.mark.anyio
async def test_the_frontend_cannot_verify_anything_a_wrong_code_never_activates():
    async with _client() as c:
        await _register(c)
        code = last_email_code()
        for payload in ({"code": _wrong(code)}, {"code": ""}, {"code": "abcdef"}):
            r = await c.post("/api/v1/auth/verify-email", json={"email": EMAIL, **payload})
            assert r.status_code == 422
        assert (await _user()).email_verified is False
        # tampering with extra fields does not help either
        r = await c.post("/api/v1/auth/verify-email", json={"email": EMAIL, "code": _wrong(code), "verified": True})
        assert r.status_code == 422 and (await _user()).email_verified is False


@pytest.mark.anyio
async def test_wrong_otp_then_locked_and_correct_code_refused_while_locked():
    async with _client() as c:
        await _register(c)
        code = last_email_code()
        for _ in range(4):
            assert (await _verify(c, _wrong(code))).status_code == 422
        assert (await _verify(c, _wrong(code))).status_code == 423          # 5th wrong attempt -> locked
        assert (await _verify(c, code)).status_code == 423                  # even the correct one
        assert (await _user()).email_verified is False
        await _skip_cooldown()
        assert (await c.post("/api/v1/auth/resend-verification", json={"email": EMAIL})).status_code == 200
        assert (await _verify(c, last_email_code())).status_code == 200      # a fresh code works


@pytest.mark.anyio
async def test_used_otp_cannot_be_replayed():
    async with _client() as c:
        await _register(c)
        code = last_email_code()
        assert (await _verify(c, code)).status_code == 200
        replay = await _verify(c, code)
        assert replay.status_code == 422 and "already used" in replay.text.lower()


@pytest.mark.anyio
async def test_expired_otp_rejected():
    async with _client() as c:
        await _register(c)
        code = last_email_code()
        async with AsyncSessionLocal() as s:
            await s.execute(update(OtpChallenge).values(expires_at=o.utcnow() - timedelta(seconds=1))); await s.commit()
        r = await _verify(c, code)
        assert r.status_code == 422 and "expired" in r.text.lower() and (await _user()).email_verified is False


@pytest.mark.anyio
async def test_resend_cooldown_new_code_supersedes_old():
    async with _client() as c:
        await _register(c)
        old = last_email_code(); n = len(providers.OUTBOX.email.sent)
        cd = await c.post("/api/v1/auth/resend-verification", json={"email": EMAIL})
        assert cd.status_code == 429 and "wait" in cd.text.lower() and len(providers.OUTBOX.email.sent) == n
        await _skip_cooldown()
        assert (await c.post("/api/v1/auth/resend-verification", json={"email": EMAIL})).status_code == 200
        assert len(providers.OUTBOX.email.sent) == n + 1
        new = last_email_code()
        if new != old:
            assert (await _verify(c, old)).status_code == 422
        assert (await _verify(c, new)).status_code == 200


@pytest.mark.anyio
async def test_resend_hourly_quota_is_enforced_from_the_database():
    async with _client() as c:
        await _register(c)
        statuses = []
        for _ in range(8):
            await _skip_cooldown()
            statuses.append((await c.post("/api/v1/auth/resend-verification", json={"email": EMAIL})).status_code)
        assert statuses[:4] == [200] * 4 and 429 in statuses
        assert len(providers.OUTBOX.email.sent) == 5                         # registration + 4 resends, then blocked


@pytest.mark.anyio
async def test_resend_reveals_nothing_about_unknown_or_verified_addresses():
    async with _client() as c:
        await _register(c)
        assert (await _verify(c, last_email_code())).status_code == 200
        n = len(providers.OUTBOX.email.sent)
        a = await c.post("/api/v1/auth/resend-verification", json={"email": EMAIL})            # verified
        b = await c.post("/api/v1/auth/resend-verification", json={"email": "ghost@example.com"})   # unknown
        assert a.status_code == b.status_code == 200 and a.json() == b.json() and len(providers.OUTBOX.email.sent) == n


@pytest.mark.anyio
@pytest.mark.parametrize("reason,status", [(E.TIMEOUT, 502), (E.UNAVAILABLE, 502), (E.RECIPIENT, 422),
                                           (E.AUTH, 503), (E.RATE_LIMITED, 503)])
async def test_provider_failure_on_register_is_a_backend_error_nothing_is_claimed_sent(reason, status):
    providers.OUTBOX.email.fail_with = reason
    async with _client() as c:
        r = await _register(c)
        assert r.status_code == status, r.text
        assert "has been sent" not in r.text and "dev_otp" not in r.text
        assert r.json()["error"]["code"] == "DELIVERY_FAILED"
        assert await _user() is None                                         # no half-created account
        async with AsyncSessionLocal() as s:
            assert (await s.execute(select(OtpChallenge))).scalars().all() == []
        failed = await _audit("OTP_DELIVERY_FAILED")
        assert len(failed) == 1 and failed[0].details["reason"] == reason and failed[0].details["channel"] == "email"
        # once the provider recovers the very same registration works
        providers.OUTBOX.email.fail_with = None
        assert (await _register(c)).status_code == 201
        assert (await _verify(c, last_email_code())).status_code == 200


@pytest.mark.anyio
async def test_unconfigured_email_fails_honestly_instead_of_faking_a_send(monkeypatch):
    monkeypatch.setattr(factory, "get_email_service", lambda: None)
    async with _client() as c:
        r = await _register(c)
        assert r.status_code == 503 and "not configured" in r.text.lower()
        assert await _user() is None and providers.OUTBOX.email.sent == []


@pytest.mark.anyio
async def test_resend_failure_leaves_no_live_code_and_does_not_lock_the_user_out():
    async with _client() as c:
        await _register(c)
        await _skip_cooldown()
        providers.OUTBOX.email.fail_with = E.TIMEOUT
        r = await c.post("/api/v1/auth/resend-verification", json={"email": EMAIL})
        assert r.status_code == 502 and "dev_otp" not in r.text
        providers.OUTBOX.email.fail_with = None
        assert (await c.post("/api/v1/auth/resend-verification", json={"email": EMAIL})).status_code == 200   # no cooldown stuck
        assert (await _verify(c, last_email_code())).status_code == 200


@pytest.mark.anyio
async def test_secrets_and_codes_never_reach_logs_or_audit(capsys):
    async with _client() as c:
        await _register(c)
        code = last_email_code()
        await _verify(c, _wrong(code)); await _verify(c, code)
    blob = " ".join(f"{a.action} {a.details} {a.resource_id}" for a in await _audit())
    out = capsys.readouterr()
    assert code not in blob and code not in out.out + out.err and EMAIL not in " ".join(
        str(a.details) for a in await _audit() if a.action.startswith("OTP_"))


class _FakeSMTP:
    sessions: list = []

    def __init__(self, host, port, **kw): self.s = {"host": host, "port": port, "steps": []}; self.sessions.append(self.s)
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def starttls(self, context=None): self.s["steps"].append("starttls")
    def login(self, u, p): self.s["steps"].append(("login", u, p))
    def send_message(self, m): self.s["steps"].append(("send", m["To"], m.get_content())); return {}


@pytest.mark.anyio
async def test_email_integration_through_the_real_smtp_provider_with_a_mock_transport(monkeypatch):
    _FakeSMTP.sessions = []
    svc = EmailService(SmtpEmailProvider("smtp.gmail.com", 587, "sender@gmail.com", "app password here",
                                         factory=_FakeSMTP), "sender@gmail.com", "SecureShare")
    monkeypatch.setattr(factory, "get_email_service", lambda: svc)
    async with _client() as c:
        r = await _register(c)
        assert r.status_code == 201, r.text
        (s,) = _FakeSMTP.sessions
        assert s["host"] == "smtp.gmail.com" and s["port"] == 587
        assert s["steps"][:2] == ["starttls", ("login", "sender@gmail.com", "apppasswordhere")]
        _, to, body = s["steps"][2]
        assert to == EMAIL
        code = body.split("code is ")[1][:6]
        assert (await _verify(c, code)).status_code == 200 and (await _user()).email_verified
