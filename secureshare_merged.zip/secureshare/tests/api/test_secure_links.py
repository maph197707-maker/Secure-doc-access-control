"""Encrypted secure-link flow: owner creates /view/<token> -> anonymous recipient opens it.

Covers: generation, ciphertext-at-rest, view/download streaming, password gate + lockout,
download limits, one-time view, revocation, expiry, and that only a keyed hash is stored.
NOT YET RUN in the authoring sandbox (no fastapi/sqlalchemy installed there).
Run:  pytest tests/api/test_secure_links.py -v
"""
from __future__ import annotations

import re

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy import text

from app.db.session import create_tables, drop_tables, engine
from app.main import app
from tests.support.providers import last_email_code
from scripts.seed_roles import seed_roles

BASE = "http://localhost:8000"
CONTENT = b"confidential board minutes\n" * 40


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables(); await create_tables(); await seed_roles()
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


async def _owner() -> tuple[AsyncClient, str]:
    c = AsyncClient(transport=ASGITransport(app=app), base_url=BASE)
    pw = "StrongPassword123!"
    r = await c.post("/api/v1/auth/register", json={"email": "owner@example.com", "password": pw, "full_name": "Owner"})
    assert r.status_code == 201, r.text
    assert (await c.post("/api/v1/auth/verify-email", json={"email": "owner@example.com", "code": last_email_code()})).status_code == 200
    login = await c.post("/api/v1/auth/login", json={"email": "owner@example.com", "password": pw})
    c.cookies.clear()
    c.headers["Authorization"] = f"Bearer {login.json()['access_token']}"
    up = await c.post("/api/v1/documents", files={"file": ("minutes.txt", CONTENT, "text/plain")})
    assert up.status_code == 201, up.text
    return c, up.json()["id"]


def _anon() -> AsyncClient:
    """A second device: no session, no auth header. Only the link."""
    return AsyncClient(transport=ASGITransport(app=app), base_url=BASE)


def _path(url: str) -> str:
    return "/" + url.split("/", 3)[3]


@pytest.mark.anyio
async def test_link_generated_opens_streams_and_hash_only_stored():
    a, doc_id = await _owner(); b = _anon()
    try:
        r = await a.post("/api/v1/links", json={"document_id": doc_id})
        assert r.status_code == 201, r.text
        url = r.json()["share_url"]
        assert url.startswith("http") and "/view/" in url
        token = url.rsplit("/", 1)[1]
        assert len(token) >= 40

        page = await b.get(_path(url))
        assert page.status_code == 200 and "minutes.txt" in page.text
        assert (await b.get(_path(url) + "/content")).content == CONTENT
        assert (await b.get(_path(url) + "/download")).content == CONTENT

        # raw token must never be persisted; the file on disk is ciphertext
        async with engine.begin() as conn:
            rows = (await conn.execute(text("SELECT token_hash, token_prefix FROM secure_links"))).all()
            assert rows and all(token not in str(v) for row in rows for v in row)
            paths = [p for (p,) in (await conn.execute(text("SELECT storage_path FROM document_versions"))).all()]
        import os
        from app.config.settings import get_settings
        from app.integrations.storage import build_storage_service
        store = build_storage_service(get_settings())
        assert paths
        for p in paths:                                   # row holds the storage key (legacy rows: a path)
            assert CONTENT[:20] not in store.read(os.path.basename(p))
    finally:
        await a.aclose(); await b.aclose()


@pytest.mark.anyio
async def test_password_gate_wrong_right_and_lockout():
    a, doc_id = await _owner(); b = _anon()
    try:
        r = await a.post("/api/v1/links", json={"document_id": doc_id, "requires_password": True, "password": "s3cret-pass"})
        path = _path(r.json()["share_url"])
        assert "protected" in (await b.get(path)).text.lower()
        assert (await b.get(path + "/content")).status_code in (303, 307)      # no cookie -> bounced to gate
        csrf = b.cookies.get("ss_csrf") or "demo"
        bad = await b.post(path, data={"password": "nope", "csrf_token": csrf})
        assert bad.status_code in (401, 403)
        good = await b.post(path, data={"password": "s3cret-pass", "csrf_token": csrf})
        assert good.status_code == 303
        assert (await b.get(path + "/content")).content == CONTENT
        # a password link requested without a password is rejected, not silently unprotected
        assert (await a.post("/api/v1/links", json={"document_id": doc_id, "requires_password": True})).status_code in (400, 422)
        # brute force: 5 failures lock the link even for the right password
        c = _anon()
        for _ in range(5):
            await c.post(path, data={"password": "x", "csrf_token": "demo"})
        locked = await c.post(path, data={"password": "s3cret-pass", "csrf_token": "demo"})
        assert locked.status_code in (403, 429)
        await c.aclose()
    finally:
        await a.aclose(); await b.aclose()


@pytest.mark.anyio
async def test_limits_one_time_revoke_expiry_and_download_flag():
    a, doc_id = await _owner(); b = _anon()
    try:
        # max 1 download
        p1 = _path((await a.post("/api/v1/links", json={"document_id": doc_id, "max_downloads": 1})).json()["share_url"])
        assert (await b.get(p1 + "/download")).status_code == 200
        assert (await b.get(p1 + "/download")).status_code == 403
        # one-time view
        p2 = _path((await a.post("/api/v1/links", json={"document_id": doc_id, "one_time_view": True})).json()["share_url"])
        assert (await b.get(p2 + "/content")).status_code == 200
        assert (await b.get(p2 + "/content")).status_code == 403
        # downloads disabled
        p3 = _path((await a.post("/api/v1/links", json={"document_id": doc_id, "allow_downloads": False})).json()["share_url"])
        assert (await b.get(p3 + "/content")).status_code == 200
        assert (await b.get(p3 + "/download")).status_code == 403
        # revoke -> immediate denial
        l4 = (await a.post("/api/v1/links", json={"document_id": doc_id})).json()
        p4 = _path(l4["share_url"])
        assert (await b.get(p4 + "/content")).status_code == 200
        assert (await a.delete(f"/api/v1/links/{l4['id']}")).status_code == 204
        assert (await b.get(p4 + "/content")).status_code == 403
        # expiry
        l5 = (await a.post("/api/v1/links", json={"document_id": doc_id})).json()
        async with engine.begin() as conn:
            await conn.execute(text("UPDATE secure_links SET expires_at = '2000-01-01 00:00:00' WHERE id = :i"), {"i": l5["id"]})
        assert (await b.get(_path(l5["share_url"]) + "/content")).status_code == 403
        # garbage token and non-owner creation
        assert (await b.get("/view/not-a-real-token")).status_code == 404
        e = _anon()
        assert (await e.post("/api/v1/links", json={"document_id": doc_id})).status_code == 401
        await e.aclose()
        # every step audited, with no secrets in the log
        async with engine.begin() as conn:
            acts = {x for (x,) in (await conn.execute(text("SELECT action FROM audit_logs"))).all()}
            blob = " ".join(str(d) for (d,) in (await conn.execute(text("SELECT details FROM audit_logs"))).all())
        assert {"SECURE_LINK_CREATE", "SECURE_LINK_VIEW", "SECURE_LINK_DOWNLOAD", "SECURE_LINK_REVOKE", "SECURE_LINK_DENIED"} <= acts
        assert "s3cret" not in blob
    finally:
        await a.aclose(); await b.aclose()


@pytest.mark.anyio
async def test_lan_host_accepted_in_dev_and_link_uses_it():
    a, doc_id = await _owner()
    try:
        r = await a.post("/api/v1/links", json={"document_id": doc_id}, headers={"host": "192.168.1.50:8000"})
        assert r.status_code == 201, r.text
        assert r.json()["share_url"].startswith("http://192.168.1.50:8000/view/")
        bad = await a.get("/health", headers={"host": "evil.example.com"})
        assert bad.status_code == 400                                          # public hostnames still blocked
    finally:
        await a.aclose()


@pytest.mark.anyio
async def test_share_url_is_https_outside_dev_and_token_is_opaque(monkeypatch):
    """Outside dev a link must be https://; the raw token is random and only its keyed hash is stored."""
    from types import SimpleNamespace
    from app.services import link_urls
    fake = SimpleNamespace(public_base_url="https://docs.example.com", is_dev=False)
    monkeypatch.setattr(link_urls, "get_settings", lambda: fake)
    req = SimpleNamespace(headers={"host": "evil.test"}, url=SimpleNamespace(scheme="http"))
    url = link_urls.share_url(req, "tok_ABC")
    assert url == "https://docs.example.com/view/tok_ABC"
    fake.public_base_url = "http://docs.example.com"
    with pytest.raises(RuntimeError):
        link_urls.share_url(req, "tok_ABC")
