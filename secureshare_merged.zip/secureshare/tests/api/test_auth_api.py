"""Integration and API tests for authentication, sessions, and security middleware."""
from __future__ import annotations

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from app.config.constants import COOKIE_SESSION, HEADER_REQUEST_ID
from app.db.session import create_tables, drop_tables
from app.main import app
from tests.support.providers import last_email_code
from scripts.seed_roles import seed_roles


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables()
    await create_tables()
    await seed_roles()
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


@pytest.mark.anyio
async def test_health_check():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client:
        resp = await client.get("/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"


@pytest.mark.anyio
async def test_service_worker_is_served_with_root_scope():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client:
        resp = await client.get("/service-worker.js")
        assert resp.status_code == 200
        assert resp.headers["service-worker-allowed"] == "/"
        assert "secureshare-shell-v1" in resp.text


@pytest.mark.anyio
async def test_security_headers_and_request_id():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client:
        resp = await client.get("/health")
        assert HEADER_REQUEST_ID in resp.headers
        assert resp.headers["X-Content-Type-Options"] == "nosniff"
        assert resp.headers["X-Frame-Options"] == "DENY"
        assert "Content-Security-Policy" in resp.headers


@pytest.mark.anyio
async def test_host_guard_rejection():
    transport = ASGITransport(app=app)
    # Request with malicious host
    async with AsyncClient(transport=transport, base_url="http://evil.com:8000") as client:
        resp = await client.get("/health", headers={"Host": "evil-attacker.com"})
        assert resp.status_code == 400


@pytest.mark.anyio
async def test_registration_and_email_verification():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client:
        # 1. Register
        reg_data = {
            "email": "alice@example.com",
            "password": "StrongPassword123!",
            "full_name": "Alice Tester",
        }
        resp = await client.post("/api/v1/auth/register", json=reg_data)
        assert resp.status_code == 201
        data = resp.json()
        assert data["user"]["email"] == "alice@example.com"
        assert "dev_otp" not in data and "otp" not in data        # the code never appears in a response
        otp_code = last_email_code()

        # 2. Duplicate registration fails with 409
        dup_resp = await client.post("/api/v1/auth/register", json=reg_data)
        assert dup_resp.status_code == 409

        # 3. Weak password fails
        weak_resp = await client.post(
            "/api/v1/auth/register",
            json={"email": "bob@example.com", "password": "weak", "full_name": "Bob"},
        )
        assert weak_resp.status_code in (400, 422)

        # 4. Verify email with wrong code fails
        bad_verify = await client.post(
            "/api/v1/auth/verify-email",
            json={"email": "alice@example.com", "code": "000000"},
        )
        assert bad_verify.status_code in (400, 422)

        # 5. Verify email with correct OTP succeeds
        verify_resp = await client.post(
            "/api/v1/auth/verify-email",
            json={"email": "alice@example.com", "code": otp_code},
        )
        assert verify_resp.status_code == 200
        assert verify_resp.json()["status"] == "ok"


@pytest.mark.anyio
async def test_login_me_logout_and_session_cookie():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client:
        # Register and verify
        reg_resp = await client.post(
            "/api/v1/auth/register",
            json={"email": "carol@example.com", "password": "CarolPassword123!", "full_name": "Carol T"},
        )
        otp_code = last_email_code()
        await client.post("/api/v1/auth/verify-email", json={"email": "carol@example.com", "code": otp_code})

        # Login
        login_resp = await client.post(
            "/api/v1/auth/login",
            json={"email": "carol@example.com", "password": "CarolPassword123!"},
        )
        assert login_resp.status_code == 200
        login_data = login_resp.json()
        token = login_data["access_token"]
        assert token
        assert COOKIE_SESSION in login_resp.cookies

        # Access /me with Bearer token
        me_resp = await client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
        assert me_resp.status_code == 200
        assert me_resp.json()["email"] == "carol@example.com"

        # Access /me using session cookie
        me_cookie_resp = await client.get("/api/v1/auth/me")
        assert me_cookie_resp.status_code == 200
        assert me_cookie_resp.json()["email"] == "carol@example.com"

        # List sessions
        sess_resp = await client.get("/api/v1/sessions")
        assert sess_resp.status_code == 200
        sessions = sess_resp.json()
        assert len(sessions) >= 1
        assert sessions[0]["is_current"] is True

        # Logout with CSRF token from cookie
        csrf_tok = client.cookies.get("ss_csrf", "")
        logout_resp = await client.post("/api/v1/auth/logout", headers={"X-CSRF-Token": csrf_tok})
        assert logout_resp.status_code == 200

        # After logout, accessing /me fails with 401
        after_resp = await client.get("/api/v1/auth/me")
        assert after_resp.status_code == 401


@pytest.mark.anyio
async def test_escalating_lockout_on_failed_logins():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client:
        # Register user
        reg_resp = await client.post(
            "/api/v1/auth/register",
            json={"email": "target@example.com", "password": "SecurePassword123!", "full_name": "Target"},
        )
        otp_code = last_email_code()
        await client.post("/api/v1/auth/verify-email", json={"email": "target@example.com", "code": otp_code})

        # 4 wrong attempts should return 401
        for _ in range(4):
            resp = await client.post(
                "/api/v1/auth/login",
                json={"email": "target@example.com", "password": "WrongPassword123!"},
            )
            assert resp.status_code == 401

        # 5th wrong attempt triggers lockout (423 status code)
        resp5 = await client.post(
            "/api/v1/auth/login",
            json={"email": "target@example.com", "password": "WrongPassword123!"},
        )
        assert resp5.status_code == 423
        assert "locked" in resp5.json()["error"]["message"].lower()

        # Even with correct password, login is blocked while locked
        blocked_resp = await client.post(
            "/api/v1/auth/login",
            json={"email": "target@example.com", "password": "SecurePassword123!"},
        )
        assert blocked_resp.status_code == 423


@pytest.mark.anyio
async def test_password_reset_flow():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client:
        # Register user
        reg_resp = await client.post(
            "/api/v1/auth/register",
            json={"email": "reset@example.com", "password": "OldPassword123!", "full_name": "Reset User"},
        )
        otp_code = last_email_code()
        await client.post("/api/v1/auth/verify-email", json={"email": "reset@example.com", "code": otp_code})

        # Request reset
        req_resp = await client.post("/api/v1/auth/forgot-password", json={"email": "reset@example.com"})
        assert req_resp.status_code == 200
        reset_token = req_resp.json()["dev_token"]
        assert reset_token

        # Reset password
        confirm_resp = await client.post(
            "/api/v1/auth/reset-password",
            json={
                "email": "reset@example.com",
                "token": reset_token,
                "new_password": "NewStrongPassword123!",
            },
        )
        assert confirm_resp.status_code == 200

        # Login with old password fails
        old_login = await client.post(
            "/api/v1/auth/login",
            json={"email": "reset@example.com", "password": "OldPassword123!"},
        )
        assert old_login.status_code == 401

        # Login with new password succeeds
        new_login = await client.post(
            "/api/v1/auth/login",
            json={"email": "reset@example.com", "password": "NewStrongPassword123!"},
        )
        assert new_login.status_code == 200


@pytest.mark.anyio
async def test_guest_login_gives_working_session_without_registration(monkeypatch):
    from app.config.settings import get_settings
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client:
        r = await client.post("/api/v1/auth/guest")
        assert r.status_code == 200
        assert r.json()["user"]["email"].startswith("guest-")
        me = await client.get("/api/v1/auth/me")
        assert me.status_code == 200 and me.json()["email_verified"] is True

        monkeypatch.setattr(get_settings(), "guest_login_enabled", False)
        off = await client.post("/api/v1/auth/guest")
        assert off.status_code == 403
