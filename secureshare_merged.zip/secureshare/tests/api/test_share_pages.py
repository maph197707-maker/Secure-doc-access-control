"""Web pages for secure links: sign-in required, 4-step wizard -> real link -> recipient opens it,
details/rotate/revoke, and the admin database page. Run: pytest tests/api/test_share_pages.py -v
(NOT YET RUN in the authoring sandbox.)"""
from __future__ import annotations

import re

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from app.db.session import create_tables, drop_tables
from app.main import app
from tests.support.providers import last_email_code
from scripts.seed_roles import seed_roles

BASE = "http://localhost:8000"
CONTENT = b"wizard document body\n" * 30


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables(); await create_tables(); await seed_roles()
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


async def _user(email="owner@example.com") -> AsyncClient:
    c = AsyncClient(transport=ASGITransport(app=app), base_url=BASE)
    r = await c.post("/api/v1/auth/register", json={"email": email, "password": "StrongPassword123!", "full_name": "Olivia Owner"})
    assert r.status_code == 201, r.text
    await c.post("/api/v1/auth/verify-email", json={"email": email, "code": last_email_code()})
    login = await c.post("/api/v1/auth/login", json={"email": email, "password": "StrongPassword123!"})
    c.cookies.clear()
    c.headers["Authorization"] = f"Bearer {login.json()['access_token']}"
    return c


def _key(html: str) -> str:
    return re.search(r'name="idempotency_key" value="([0-9a-f]+)"', html).group(1)


@pytest.mark.anyio
async def test_shares_requires_login():
    anon = AsyncClient(transport=ASGITransport(app=app), base_url=BASE)
    for path in ("/shares", "/shares/create"):
        r = await anon.get(path)
        assert r.status_code == 303 and r.headers["location"].startswith("/login")
    await anon.aclose()


@pytest.mark.anyio
async def test_wizard_creates_working_link_then_rotate_and_revoke():
    a = await _user()
    b = AsyncClient(transport=ASGITransport(app=app), base_url=BASE)
    try:
        doc_id = (await a.post("/api/v1/documents", files={"file": ("w.txt", CONTENT, "text/plain")})).json()["id"]
        page = await a.get("/shares/create")
        assert page.status_code == 200 and "w.txt" in page.text            # document picker lists it
        key = _key(page.text)
        post = lambda step, **f: a.post("/shares/create", data={"csrf_token": "demo", "idempotency_key": key, "step": step, **f})
        s1 = await post(1, document_id=doc_id); assert s1.status_code == 200 and "Security Options" in s1.text
        bad = await post(2, password_protect="on", link_password="")        # validation, not a crash
        assert bad.status_code == 400 and "password" in bad.text.lower()
        s2 = await post(2, allow_download="on", link_expiry="on"); assert s2.status_code == 200 and "Recipient" in s2.text
        s3 = await post(3, recipient_email="bob@example.com"); assert s3.status_code == 200
        done = await post(4)
        assert done.status_code == 200 and "Secure Link Generated" in done.text
        url = re.search(r'value="(http[^"]+/view/[^"]+)"', done.text).group(1)
        path = "/" + url.split("/", 3)[3]
        assert (await b.get(path + "/download")).content == CONTENT        # anonymous recipient, real bytes
        assert (await post(4)).status_code == 303                           # draft consumed: no duplicate link

        lst = await a.get("/shares"); assert "w.txt" in lst.text
        link_id = (await a.get("/api/v1/links")).json()[0]["id"]
        det = await a.get(f"/shares/{link_id}"); assert det.status_code == 200 and url not in det.text   # shown once only
        rot = await a.post(f"/shares/{link_id}/rotate", data={"csrf_token": "demo"})
        new_url = re.search(r'value="(http[^"]+/view/[^"]+)"', rot.text).group(1)
        assert new_url != url
        assert (await b.get(path + "/content")).status_code in (403, 404)   # old token dead immediately
        assert (await b.get("/" + new_url.split("/", 3)[3] + "/content")).content == CONTENT
        await a.post(f"/shares/{link_id}/revoke", data={"csrf_token": "demo"})
        assert (await b.get("/" + new_url.split("/", 3)[3] + "/content")).status_code == 403
    finally:
        await a.aclose(); await b.aclose()


@pytest.mark.anyio
async def test_wizard_uploads_new_file_and_preserves_draft_on_back():
    a = await _user("upload-owner@example.com")
    try:
        page = await a.get("/shares/create")
        key = _key(page.text)
        s1 = await a.post(
            "/shares/create",
            data={"csrf_token": "demo", "idempotency_key": key, "step": "1"},
            files={"file": ("fresh.txt", CONTENT, "text/plain")},
        )
        assert s1.status_code == 200, s1.text
        assert "Security Options" in s1.text
        assert f"key={key}" in s1.text

        back = await a.get(f"/shares/create?step=1&key={key}")
        assert back.status_code == 200
        assert "fresh.txt" in back.text
    finally:
        await a.aclose()


@pytest.mark.anyio
async def test_cannot_see_or_revoke_someone_elses_link():
    a = await _user(); e = await _user("eve@example.com")
    try:
        doc_id = (await a.post("/api/v1/documents", files={"file": ("w.txt", CONTENT, "text/plain")})).json()["id"]
        link_id = (await a.post("/api/v1/links", json={"document_id": doc_id})).json()["id"]
        assert (await e.get(f"/shares/{link_id}")).status_code == 404
        await e.post(f"/shares/{link_id}/revoke", data={"csrf_token": "demo"})
        assert (await a.get("/api/v1/links")).json()[0]["status"] == "ACTIVE"
    finally:
        await a.aclose(); await e.aclose()


@pytest.mark.anyio
async def test_admin_database_status_is_admin_only_and_leaks_no_secret():
    u = await _user()
    try:
        assert (await u.get("/admin/database")).status_code == 403
        assert (await u.get("/api/v1/admin/system/database")).status_code == 403
    finally:
        await u.aclose()
