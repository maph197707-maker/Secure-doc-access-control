"""Routes that used to 404 (18 admin pages, 7 user pages, /passkey, /verify-identity) plus the nested
folder browser. NOT YET RUN: the authoring sandbox had no FastAPI/pytest. Run:
    pytest tests/api/test_folders_and_pages.py -v
"""
from __future__ import annotations

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from app.db.session import create_tables, drop_tables
from app.main import app
from app.web.admin_pages import PAGES
from scripts.create_admin import create_or_promote_admin
from scripts.seed_roles import seed_roles
from tests.support.providers import last_email_code

BASE = "http://localhost:8000"
PW = "StrongPassword123!"
ADMIN_SLUGS = list(PAGES)
USER_PAGES = ["/shared-with-me", "/access-requests", "/signatures", "/signatures/verify", "/security/risk",
              "/security/alerts", "/folders", "/passkey"]


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables(); await create_tables(); await seed_roles()
    await create_or_promote_admin("admin@example.com", "AdminPass123!", "Admin User")
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


async def _login(email: str, password: str, register: bool) -> AsyncClient:
    c = AsyncClient(transport=ASGITransport(app=app), base_url=BASE)
    if register:
        r = await c.post("/api/v1/auth/register", json={"email": email, "password": password, "full_name": "Test Person"})
        assert r.status_code == 201, r.text
        await c.post("/api/v1/auth/verify-email", json={"email": email, "code": last_email_code()})
    login = await c.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert login.status_code == 200, login.text
    c.cookies.clear()
    c.headers["Authorization"] = f"Bearer {login.json()['access_token']}"
    return c


def test_every_admin_page_is_registered_in_the_route_table():
    from app.web.route_table import is_known_route
    assert len(ADMIN_SLUGS) == 18
    for slug in ADMIN_SLUGS:
        assert is_known_route(f"/admin/{slug}"), slug
        assert any(getattr(r, "path", "") == f"/admin/{slug}" for r in app.routes), f"/admin/{slug} not mounted"


@pytest.mark.anyio
@pytest.mark.parametrize("slug", ADMIN_SLUGS)
async def test_admin_page_ok_for_admin_403_for_user_redirect_for_anon(slug):
    admin = await _login("admin@example.com", "AdminPass123!", register=False)
    r = await admin.get(f"/admin/{slug}")
    assert r.status_code == 200, f"{slug}: {r.status_code} {r.text[:300]}"
    user = await _login("plain@example.com", PW, register=True)
    assert (await user.get(f"/admin/{slug}")).status_code == 403
    anon = AsyncClient(transport=ASGITransport(app=app), base_url=BASE)
    a = await anon.get(f"/admin/{slug}", follow_redirects=False)
    assert a.status_code == 303 and a.headers["location"].startswith("/login")


@pytest.mark.anyio
@pytest.mark.parametrize("path", USER_PAGES)
async def test_user_pages_load(path):
    u = await _login("u1@example.com", PW, register=True)
    r = await u.get(path)
    assert r.status_code == 200, f"{path}: {r.status_code} {r.text[:300]}"
    anon = AsyncClient(transport=ASGITransport(app=app), base_url=BASE)
    if path != "/passkey":
        assert (await anon.get(path, follow_redirects=False)).status_code == 303


@pytest.mark.anyio
async def test_passkey_is_honestly_unavailable():
    c = AsyncClient(transport=ASGITransport(app=app), base_url=BASE)
    assert "PROVIDER_UNAVAILABLE" in (await c.get("/passkey")).text
    assert (await c.post("/passkey", data={"csrf_token": "demo"})).status_code == 501


@pytest.mark.anyio
async def test_folder_tree_create_rename_move_delete_and_document_move():
    import re
    u = await _login("owner@example.com", PW, register=True)
    post = lambda p, **f: u.post(p, data={"csrf_token": "demo", **f}, follow_redirects=False)
    assert (await post("/folders/create", name="Taxes")).status_code == 303
    page = (await u.get("/folders")).text
    taxes = re.search(r'href="/folders/([0-9a-f-]{36})"', page).group(1)
    assert (await post("/folders/create", name="2025", parent_id=taxes)).status_code == 303
    assert "2025" in (await u.get(f"/folders/{taxes}")).text
    # duplicate (case-insensitive) is refused, not 500
    dup = await post("/folders/create", name="taxes")
    assert dup.status_code == 400
    # bad names are refused
    assert (await post("/folders/create", name="a/b")).status_code == 400
    # cannot move a folder into its own descendant
    child = re.search(r'href="/folders/([0-9a-f-]{36})"', (await u.get(f"/folders/{taxes}")).text).group(1)
    assert (await post(f"/folders/{taxes}/move", parent_id=child)).status_code == 400
    # rename, then delete the parent: the child survives at the top level
    assert (await post(f"/folders/{taxes}/rename", name="Tax Files")).status_code == 303
    assert (await post(f"/folders/{taxes}/delete")).status_code == 303
    top = (await u.get("/folders")).text
    assert "2025" in top and "Tax Files" not in top
    # a stranger cannot see or touch it
    other = await _login("other@example.com", PW, register=True)
    assert (await other.get(f"/folders/{child}")).status_code == 404
    assert (await other.post(f"/folders/{child}/delete", data={"csrf_token": "demo"})).status_code == 404
