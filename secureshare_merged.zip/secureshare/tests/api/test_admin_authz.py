"""Tests for Admin role authorization and access control."""
import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from app.config.constants import COOKIE_CSRF, HEADER_CSRF_TOKEN
from app.core.enums import RoleName
from app.db.session import create_tables, drop_tables
from app.main import app
from tests.support.providers import last_email_code
from scripts.create_admin import create_or_promote_admin
from scripts.seed_roles import seed_roles


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables()
    await create_tables()
    await seed_roles()
    await create_or_promote_admin("admin@example.com", "AdminPass123!", "Admin User")
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


@pytest.mark.anyio
async def test_admin_endpoints_require_admin_role():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client:
        # 1. Register a standard user
        reg_resp = await client.post(
            "/api/v1/auth/register",
            json={"email": "standard@example.com", "password": "UserPass123!", "full_name": "Standard User"},
        )
        assert reg_resp.status_code == 201
        otp = last_email_code()
        if otp:
            await client.post("/api/v1/auth/verify-email", json={"email": "standard@example.com", "code": otp})

        # 2. Login as standard user
        user_login = await client.post(
            "/api/v1/auth/login",
            json={"email": "standard@example.com", "password": "UserPass123!"},
        )
        assert user_login.status_code == 200
        user_token = user_login.json()["access_token"]

        # Standard user attempting /api/v1/admin/users -> 403 Forbidden
        denied_resp = await client.get(
            "/api/v1/admin/users",
            headers={"Authorization": f"Bearer {user_token}"},
        )
        assert denied_resp.status_code == 403

        # 3. Login as admin (clear user session cookie first)
        client.cookies.clear()
        admin_login = await client.post(
            "/api/v1/auth/login",
            json={"email": "admin@example.com", "password": "AdminPass123!"},
        )
        assert admin_login.status_code == 200
        admin_token = admin_login.json()["access_token"]

        # Admin user accessing /api/v1/admin/users -> 200 OK
        allowed_resp = await client.get(
            "/api/v1/admin/users",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        assert allowed_resp.status_code == 200
        users = allowed_resp.json()
        assert any(u["email"] == "standard@example.com" for u in users)
        assert any(u["email"] == "admin@example.com" for u in users)


@pytest.mark.anyio
async def test_admin_suspend_and_reactivate_user():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client:
        # Register standard user
        reg = await client.post(
            "/api/v1/auth/register",
            json={"email": "target@example.com", "password": "Password123!", "full_name": "Target"},
        )
        otp = last_email_code()
        if otp:
            await client.post("/api/v1/auth/verify-email", json={"email": "target@example.com", "code": otp})

        target_id = reg.json()["user"]["id"]

        # Login admin
        admin_login = await client.post(
            "/api/v1/auth/login",
            json={"email": "admin@example.com", "password": "AdminPass123!"},
        )
        admin_token = admin_login.json()["access_token"]
        csrf_tok = client.cookies.get(COOKIE_CSRF) or "demo"
        headers = {"Authorization": f"Bearer {admin_token}", HEADER_CSRF_TOKEN: csrf_tok}

        # Suspend user
        suspend_resp = await client.post(f"/api/v1/admin/users/{target_id}/suspend", headers=headers)
        assert suspend_resp.status_code == 200

        # Attempt to login as suspended user (clear cookies first)
        client.cookies.clear()
        suspended_login = await client.post(
            "/api/v1/auth/login",
            json={"email": "target@example.com", "password": "Password123!"},
        )
        assert suspended_login.status_code == 403 or "suspended" in suspended_login.text.lower()

        # Login admin again to activate user
        admin_login = await client.post(
            "/api/v1/auth/login",
            json={"email": "admin@example.com", "password": "AdminPass123!"},
        )
        admin_token = admin_login.json()["access_token"]
        csrf_tok = client.cookies.get(COOKIE_CSRF) or "demo"
        headers = {"Authorization": f"Bearer {admin_token}", HEADER_CSRF_TOKEN: csrf_tok}

        act_resp = await client.post(f"/api/v1/admin/users/{target_id}/activate", headers=headers)
        assert act_resp.status_code == 200

        # Login again should now succeed
        client.cookies.clear()
        ok_login = await client.post(
            "/api/v1/auth/login",
            json={"email": "target@example.com", "password": "Password123!"},
        )
        assert ok_login.status_code == 200
