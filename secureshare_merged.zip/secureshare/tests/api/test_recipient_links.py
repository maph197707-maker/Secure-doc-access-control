"""Recipient-bound links end to end: wizard -> /view/{token} asks the visitor to prove who they are ->
claim (email) -> code (email or SMS) -> signed cookie -> document bytes.
Run: pytest tests/api/test_recipient_links.py -v
Delivery goes through the recording test providers (tests/support/providers.py); the OTP flow itself is real."""
from __future__ import annotations

import re

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

from app.db.session import create_tables, drop_tables
from app.main import app
from tests.support import providers
from tests.support.providers import last_email_code
from scripts.seed_roles import seed_roles

from datetime import datetime, timedelta  # noqa: E402

_DAY = (datetime.utcnow() + timedelta(days=60)).date().isoformat()
_FUTURE_IST = f"{_DAY}T10:00"          # wizard value, read in Asia/Kolkata
_FUTURE_UTC = f"{_DAY}T04:30"          # same instant in UTC

BASE = "http://localhost:8000"
CONTENT = b"bound document body\n" * 30


@pytest_asyncio.fixture(autouse=True)
async def init_db():
    await drop_tables(); await create_tables(); await seed_roles()
    providers.OUTBOX.email.sent.clear(); providers.OUTBOX.sms.sent.clear()
    yield
    await drop_tables()


@pytest.fixture
def anyio_backend():
    return "asyncio"


async def _owner() -> AsyncClient:
    c = AsyncClient(transport=ASGITransport(app=app), base_url=BASE)
    email = "owner@example.com"
    r = await c.post("/api/v1/auth/register", json={"email": email, "password": "StrongPassword123!", "full_name": "Olivia Owner"})
    assert r.status_code == 201, r.text
    await c.post("/api/v1/auth/verify-email", json={"email": email, "code": last_email_code()})
    login = await c.post("/api/v1/auth/login", json={"email": email, "password": "StrongPassword123!"})
    c.cookies.clear()
    c.headers["Authorization"] = f"Bearer {login.json()['access_token']}"
    return c


async def _bound_link(a: AsyncClient, content: bytes | None = None, **step3) -> str:
    """Create a recipient-bound link through the real wizard; returns the /view/<token> path."""
    _body = content if content is not None else CONTENT
    doc_id = (await a.post("/api/v1/documents", files={"file": ("b.txt", _body, "text/plain")})).json()["id"]
    page = await a.get("/shares/create")
    key = re.search(r'name="idempotency_key" value="([0-9a-f]+)"', page.text).group(1)
    post = lambda step, **f: a.post("/shares/create", data={"csrf_token": "demo", "idempotency_key": key, "step": step, **f})
    assert (await post(1, document_id=doc_id)).status_code == 200
    assert (await post(2, allow_download="on", link_expiry="on", expires_at=_FUTURE_IST, tz="Asia/Kolkata")).status_code == 200
    r3 = await post(3, **step3)
    assert r3.status_code == 200, r3.text
    done = await post(4)
    providers.OUTBOX.email.sent.clear(); providers.OUTBOX.sms.sent.clear()   # drop the owner's registration OTP mail
    url = re.search(r'value="(http[^"]+/view/[^"]+)"', done.text).group(1)
    return "/" + url.split("/", 3)[3]


def _code(box) -> str:
    return re.search(r"code is (\d{6})", box).group(1)


@pytest.mark.anyio
async def test_email_bound_link_requires_the_recipient_code():
    a = await _owner(); b = AsyncClient(transport=ASGITransport(app=app), base_url=BASE)
    try:
        path = await _bound_link(a, binding_mode="EMAIL_OTP", recipient_email="bob@example.com")
        page = await b.get(path)
        assert page.status_code == 200 and "Verify it" in page.text
        for sub in ("/content", "/download"):                          # no bytes without verification
            r = await b.get(path + sub); assert r.status_code == 303 and r.headers["location"] == path
        csrf = b.cookies.get("ss_csrf") or "demo"

        miss = await b.post(path + "/claim", data={"email": "mallory@evil.test", "csrf_token": csrf})
        assert miss.status_code == 200 and not providers.OUTBOX.email.sent          # nothing sent, same page
        forged = await b.post(path + "/code", data={"code": "123456", "pending": "", "csrf_token": csrf})
        assert forged.status_code == 400

        hit = await b.post(path + "/claim", data={"email": "Bob@Example.com", "csrf_token": csrf})
        assert hit.status_code == 200 and len(providers.OUTBOX.email.sent) == 1
        assert providers.OUTBOX.email.sent[-1]["To"] == "bob@example.com"
        pending = re.search(r'name="pending" value="([^"]+)"', hit.text).group(1)
        code = _code(providers.OUTBOX.email.sent[-1].get_content())
        bad = "000000" if code != "000000" else "111111"
        assert (await b.post(path + "/code", data={"code": bad, "pending": pending, "csrf_token": csrf})).status_code == 401
        ok = await b.post(path + "/code", data={"code": code, "pending": pending, "csrf_token": csrf})
        assert ok.status_code == 303
        assert (await b.get(path + "/download")).content == CONTENT            # cookie now unlocks it

        other = AsyncClient(transport=ASGITransport(app=app), base_url=BASE)   # a different browser stays locked out
        assert (await other.get(path + "/download")).status_code == 303
        await other.aclose()
    finally:
        await a.aclose(); await b.aclose()


@pytest.mark.anyio
async def test_phone_bound_link_texts_the_number_on_file():
    a = await _owner(); b = AsyncClient(transport=ASGITransport(app=app), base_url=BASE)
    try:
        path = await _bound_link(a, binding_mode="PHONE_OTP", recipient_email="bob@example.com", recipient_phone="98765 43210")
        csrf = b.cookies.get("ss_csrf") or "demo"
        await b.get(path)
        hit = await b.post(path + "/claim", data={"email": "bob@example.com", "csrf_token": csrf})
        assert providers.OUTBOX.sms.sent[-1][0] == "+919876543210" and not providers.OUTBOX.email.sent
        pending = re.search(r'name="pending" value="([^"]+)"', hit.text).group(1)
        code = _code(providers.OUTBOX.sms.sent[-1][1])
        assert (await b.post(path + "/code", data={"code": code, "pending": pending, "csrf_token": csrf})).status_code == 303
        assert (await b.get(path + "/content")).content == CONTENT
    finally:
        await a.aclose(); await b.aclose()


@pytest.mark.anyio
async def test_wizard_rejects_bound_mode_without_recipient_or_phone():
    a = await _owner()
    try:
        doc_id = (await a.post("/api/v1/documents", files={"file": ("b.txt", CONTENT, "text/plain")})).json()["id"]
        key = re.search(r'name="idempotency_key" value="([0-9a-f]+)"', (await a.get("/shares/create")).text).group(1)
        post = lambda step, **f: a.post("/shares/create", data={"csrf_token": "demo", "idempotency_key": key, "step": step, **f})
        await post(1, document_id=doc_id); await post(2, link_expiry="on")
        assert (await post(3, binding_mode="EMAIL_OTP", recipient_email="")).status_code == 400
        assert (await post(3, binding_mode="PHONE_OTP", recipient_email="b@example.com", recipient_phone="")).status_code == 400
        assert (await post(3, binding_mode="ROT13", recipient_email="b@example.com")).status_code == 400
    finally:
        await a.aclose()


@pytest.mark.anyio
async def test_wizard_expiry_is_read_in_the_chosen_timezone():
    a = await _owner()
    try:
        await _bound_link(a, binding_mode="NONE")                       # expires_at=<60 days out, 10:00> tz=Asia/Kolkata
        link = (await a.get("/api/v1/links")).json()[0]
        assert link["expires_at"].startswith(_FUTURE_UTC)               # 10:00 IST == 04:30 UTC (inside the 1-year cap)
    finally:
        await a.aclose()
