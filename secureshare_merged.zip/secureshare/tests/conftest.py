"""Shared pytest config.

Tests NEVER touch the developer database: DATABASE_URL points at a throw-away SQLite file that is
set before any `app` module is imported. The process-global state store (OTP cooldowns, rate
limits, lockouts) is reset before every test so tests cannot leak throttling state into each other.
"""
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

_TMP = tempfile.mkdtemp(prefix="secureshare-tests-")
os.environ["DATABASE_URL"] = f"sqlite+aiosqlite:///{Path(_TMP) / 'test.db'}"
os.environ["STORAGE_ROOT"] = str(Path(_TMP) / "storage" / "encrypted")
os.environ["QUARANTINE_ROOT"] = str(Path(_TMP) / "storage" / "quarantine")
os.environ["TEMP_ROOT"] = str(Path(_TMP) / "storage" / "temporary")
os.environ["PROCESSED_ROOT"] = str(Path(_TMP) / "storage" / "processed")
os.environ.setdefault("APP_ENV", "dev")
os.environ.setdefault("CSRF_ALLOW_DEMO_TOKEN", "true")   # tests post the literal token "demo"; never set outside tests

import pytest  # noqa: E402


@pytest.fixture(autouse=True)
def _fresh_state_store():
    """Clear the SAME store object in place (middleware keeps a reference to it)."""
    import app.integrations.state as state
    store = state.get_state_store()
    if hasattr(store, "clear"):
        store.clear()
    yield


@pytest.fixture(autouse=True)
def outbox(monkeypatch):
    """Route every delivery through recording test providers (no network). The app code path is the
    real one: AuthService -> OtpService -> EmailService/SMSService -> provider; only the transport is
    replaced. `tests.support.providers.OUTBOX` exposes what was "delivered" so tests can read codes."""
    from app.integrations import factory
    from app.integrations.email import EmailService
    from app.integrations.sms import SMSService
    from tests.support import providers

    box = providers.Outbox()
    providers.OUTBOX = box
    email = EmailService(box.email, "no-reply@test.invalid", "SecureShare")
    sms = SMSService(box.sms, "+91")
    monkeypatch.setattr(factory, "get_email_service", lambda: email)
    monkeypatch.setattr(factory, "get_sms_service", lambda: sms)
    return box


@pytest.fixture(autouse=True)
def signup_otp_required(request, monkeypatch):
    """The suite's existing flows register -> verify the emailed code. Production default is the
    opposite (sign-up needs no email; verify later in /profile): tests of that mode opt out with
    @pytest.mark.deferred_verification."""
    from app.config.settings import get_settings
    monkeypatch.setattr(get_settings(), "signup_email_verification_required",
                        request.node.get_closest_marker("deferred_verification") is None)


@pytest.fixture
def anyio_backend():
    return "asyncio"


import pytest_asyncio  # noqa: E402


@pytest_asyncio.fixture
async def db():
    """Fresh schema + seeded roles + one session, on the throw-away SQLite database."""
    from app.db.session import AsyncSessionLocal, create_tables, drop_tables
    from scripts.seed_roles import seed_roles
    await drop_tables(); await create_tables(); await seed_roles()
    async with AsyncSessionLocal() as session:
        yield session
    await drop_tables()
