@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Run install.bat first.
    pause
    exit /b 1
)
set "VPY=%CD%\.venv\Scripts\python.exe"
echo ===== 1/2  End-to-end self-check =====
"%VPY%" selfcheck.py
echo.
echo ===== 2/2  Automated test suite (takes about a minute) =====
"%VPY%" -m pytest tests -q -p no:cacheprovider --tb=short > pytest_report.txt 2>&1
powershell -NoProfile -Command "Get-Content pytest_report.txt -Tail 15"
echo.
echo Done. If anything FAILED, send me these two files:
echo     selfcheck_report.txt
echo     pytest_report.txt
pause
