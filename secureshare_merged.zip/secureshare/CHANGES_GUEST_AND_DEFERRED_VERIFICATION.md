# Guest login + verify-later sign-up

- **Guest login** (`POST /guest-login`, `POST /api/v1/auth/guest`): a real temporary USER account (DB row, session,
  encrypted uploads, secure links, audit). Now on in every environment; `GUEST_LOGIN_ENABLED=false` turns it off.
  Button on /login and /register; banner inside the app; rate-limited per IP.
- **Sign-up without email**: `SIGNUP_EMAIL_VERIFICATION_REQUIRED=false` (default). Account is ACTIVE and signed in at
  once; email and phone stay *unverified*. Production no longer needs SMTP unless that flag is true.
- **/profile** (new; the nav link used to 404): shows email + phone status, sends an email code on request, verifies it.
  Phone uses the existing /verify-phone. No SMTP/SMS configured => the page says so; nothing is ever marked verified
  without a real code. Dashboard/app banner nudges until both are verified.
- `@guest.example.com` is reserved (cannot be registered). Guests cannot request email codes.
- Tests: `tests/integration/test_guest_and_deferred_verification.py` (12). Legacy OTP-at-signup tests run with the flag on.

## Round 2
- **Fresh-install fix**: roles/permissions are now seeded at app startup. Before, a brand-new database produced
  role-less users and `POST /api/v1/auth/guest` crashed.
- **/profile**: email AND phone OTP both inline (send, verify, resend, change number resets verification).
  App banner deep-links to `/profile#email` / `#phone`.
- **install.bat** rewritten (Python 3.12+ detection incl. `py` launcher, .venv, deps, .env secrets, storage, DB + roles,
  optional admin with password prompt, optional tests) + **start.bat** (`start.bat lan` for Wi-Fi access).
  `scripts/setup_db.py` added; `create_admin` no longer has a built-in default password.
