# SecureShare 2.9.1: change log for encrypted secure links (+ supporting spec items)

Status key: **VERIFIED** = executed in the authoring sandbox. **WRITTEN** = code + tests written,
needs your `pip install` + `pytest` run (sandbox had no network, so FastAPI/SQLAlchemy could not run).

## Secure links (the original request)
| Item | Status |
|---|---|
| `/view/{token}` landing, password gate, `/content`, `/download` (app/web/share_flow.py) | WRITTEN |
| Atomic view/download limits, one-time view, expiry, revoke, rotate (services/secure_links.py) | WRITTEN |
| Password brute-force lockout (5 / 15 min), signed unlock cookie | cookie signing VERIFIED, rest WRITTEN |
| Real pages: `/shares`, `/shares/create` (4-step wizard, DB drafts, upload or pick doc), `/shares/{id}`, revoke, rotate, QR (app/web/user.py) | templates VERIFIED (render), routes WRITTEN |
| LAN-aware share URLs + dev-only LAN Host allowance | classifier VERIFIED, rest WRITTEN |
| Bugs fixed: `request: Any` in /share/finalize, silent unprotected password link, racy counters, wrong gate form action | WRITTEN |

## Spec items added in this pass
| Item | Status |
|---|---|
| SMS provider layer: Development / Twilio / MSG91 / Fast2SMS, E.164, prod guard | **VERIFIED** (5 tests executed) |
| DATABASE_URL normalisation (sqlite:/// , postgres(ql):// -> psycopg), pool args, ./data auto-create | normalisation **VERIFIED** |
| Alembic reads DATABASE_URL (SQLite or PostgreSQL) | WRITTEN |
| Admin DB status API + page (`/api/v1/admin/system/database`, `/admin/database`) | mask + template VERIFIED, rest WRITTEN |
| `scripts/lan_info.py`, `run demo` prints LAN URL | **VERIFIED** |
| `.env.example`, `requirements-postgres.txt`, docs (multi-device-demo, database-providers, sms) | done |

## 2.9.2 additions (this pass)
| Item | Status |
|---|---|
| `services/expiry.py`: wizard expiry read in the browser's timezone, DST gap/fold handled | **VERIFIED** (9 tests) |
| `RedisStateStore` + `build_state_store` (prod refuses missing Redis) | **VERIFIED** against a fake client (6 tests); not against a real Redis |
| `services/phone_otp.py`: SMS send/verify, per-number and per-account quotas | **VERIFIED** (9 tests) |
| `integrations/email.py`: console + SMTP senders | **VERIFIED** (6 tests, fake SMTP) |
| `services/recipient_gate.py`: claim/code logic, signed cookies, throttles | **VERIFIED** (11 tests) |
| Gating + `/view/{token}/claim`, `/code` routes (share_flow.py); wizard step 3/4 + timezone (user.py); `/verify-phone` | routes **WRITTEN**; templates **VERIFIED** (render + repo UI audit, 24+9 tests) |
| `tests/api/test_recipient_links.py` | **WRITTEN, NOT RUN** (needs FastAPI/SQLAlchemy/pytest) |

## Still NOT done (be aware)
- Device pairing (QR/code) and the S3 storage backend: need `2_9_full`, not touched.
- Nothing from this pass has run against FastAPI/SQLAlchemy/Redis/SMTP/an SMS vendor: the sandbox had no network.
  Run the commands below first; expect to fix small integration slips in the route code.
- Registration/login still do not require the phone OTP; `/verify-phone` is the page, not yet a gate.
- Dashboard, documents, analytics, security and admin pages other than `/shares*`, `/admin/database`
  and `/verify-phone` are still the sample-data pages in `app/web/showcase.py`.
- `alembic upgrade head` reproducing the current models was not checked (no model changes were made).
- `services/usage_counters.py` remains a tested standalone helper not used by the app.

## Run
    pip install -r requirements.txt -r requirements-dev.txt     # + requirements-postgres.txt for PostgreSQL
    pytest tests/unit tests/api/test_recipient_links.py tests/unit/test_sms_provider.py tests/api/test_secure_links.py tests/api/test_share_pages.py tests/api/test_multidevice_sharing.py -v
    python -m scripts.run demo
