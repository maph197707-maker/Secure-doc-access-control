# Changes: 404 pages, nested folders, admin fixes

**Status: written, compiled and template-rendered. NOT executed.** The authoring sandbox had no network, so
FastAPI, SQLAlchemy and pytest could not be installed. Run the suite before trusting any of this:

    pip install -r requirements-dev.txt
    pytest tests/api/test_folders_and_pages.py tests/unit -v
    pytest -q                                   # the whole suite

Checks that DID run here: every new Python file compiles; an AST pass found no undefined names or unused
imports; every model attribute used exists on its model; the new templates render under Jinja with
StrictUndefined, escape HTML, and contain no inline script/style; every link and form action in them is in
`app/web/route_table.py`; the route-shadowing check on the route table passes; and the 3 pure folder-rule
tests pass.

## New pages (previously 404)
* Admin (read-only, admin-only, metadata only): roles, permissions, documents, links, access, policies,
  security, security-events, risk, devices, sessions, analytics, usage, audit, attack-simulator,
  system-health, backup, reports. `app/web/admin_pages.py`, one data-driven table template.
* User: /shared-with-me, /access-requests (approve / reject), /signatures, /signatures/verify,
  /security/risk, /security/alerts (acknowledge), /documents/{id}/security. `app/web/user_pages.py`.
* /passkey: honest "unavailable" page (POST returns 501). Passkeys are not implemented.
* /verify-identity: TOTP step-up for a signed-in user (needs an authenticator app set up in
  /settings/security). The template text still says "OTP sent to your email"; that wording is wrong for TOTP.

## Folders ("advanced")
`/folders` browser with breadcrumbs, nested folders (max depth 16), create, rename, move (cycle, depth and
duplicate-name checks), delete (documents and sub-folders move up one level, nothing is destroyed), and
moving a document into any of your folders. Every query is owner-scoped; other people's folders are 404.
Actions are audit-logged. Code: `app/services/folder_store.py`, `app/web/folders.py`.
Not built: sharing a whole folder, folder-level permissions, drag and drop, bulk move, trash/restore.

## Fix
* `AdminService.set_user_role` assigned to a read-only property and would have crashed. It now replaces the
  user's roles row.

## Docs corrected
`docs/feature-matrix.md`, `docs/gap-report.md`, `COMPLETION_REPORT.md` claimed semantic search, an LLM
adapter and NER. Those files do not exist. The docs now say NOT IMPLEMENTED.

## Still open (not touched in this change)
* Notification fan-out is still dead code; lockouts, MFA changes, DLP/malware alerts and risk detections
  still create no notifications; risk detections are not saved as security alerts.
* Search covers only your own documents by filename; shared documents are not searchable.
* No LLM integration. The admin DLP rescan endpoint still lets an admin decrypt content.
* `httpx` is dev-only and FastAPI is unpinned. OAuth still accepts a missing `nonce`/`aud` claim.
* The earlier KMS, CSRF and Origin-check changes have no live test and the startup change has no test.
* /admin/backup shows a checklist only; no backup job exists.
