# Optional MFA login + Education / Health documents

Status: **VERIFIED** = executed in the authoring sandbox (no FastAPI/SQLAlchemy/pytest installed, no network).
**WRITTEN** = code complete, needs your `pip install` + `pytest` run.

| Item | Status |
|---|---|
| `users.totp_secret` (stored **encrypted**, AES-256-GCM bound to the user id) + `users.recovery_codes` (salted hashes) + Alembic `b3d2f7a8c914` | WRITTEN |
| `services/mfa.py`: `seal_secret` / `open_secret` / `looks_like_totp` | **VERIFIED** (6 tests, `tests/unit/test_mfa_seal.py`) |
| Login step 2: password ok + MFA on -> `/mfa` (no session yet); 6-digit code **or** single-use recovery code; replay + 5-try lockout | logic pieces VERIFIED, routes WRITTEN |
| `/settings/security`: set up authenticator (QR + manual key), first code proves it, 10 recovery codes shown once, new codes, turn off (password) | templates VERIFIED (render), routes WRITTEN |
| API: `POST /api/v1/auth/login` answers 401 `MFA_REQUIRED` (+ `challenge_id`); `POST /api/v1/auth/mfa/verify` finishes it | WRITTEN |
| `services/identity.py` fixed (wrong signature, unused) | WRITTEN |
| Upload categories **Education**, **Health**; doc types Certificate/marksheet, Medical record; classifier vocabulary for education | classifier VERIFIED, form WRITTEN |
| `tests/integration/test_mfa_login.py` (register without OTP -> opt in -> login needs code -> recovery code once) | WRITTEN, NOT RUN |

MFA is **never forced**: sign-up and login without it are unchanged (`SIGNUP_EMAIL_VERIFICATION_REQUIRED=false` stays the default).

## Not done
- Email/SMS code at login and new-device verification: the `/verify-identity` and `/passkey` pages are still demo-only.
- Real KMS (AWS/Azure/Vault) and HSM remain unverified; local development key provider is the only tested one.
- Run: `alembic upgrade head`, then `pytest tests/unit/test_mfa_seal.py tests/integration/test_mfa_login.py -v`.
