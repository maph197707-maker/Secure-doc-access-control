# Step 1-2 changes (sharing, authorization, key wrapping)

## Verified here (offline): `python -m unittest tests.unit.test_sharing_logic` -> 15 passed
Key wrapping (round-trip, AAD binding, distinct DEKs, legacy XOR readable) and grant decisions
through the real PDP (owner, stranger, view-only, revoked, expired, RBAC, critical risk).

## NOT verified (no sqlalchemy/fastapi in the authoring sandbox) - run on your machine:
    pip install -r requirements.txt
    pytest tests/api/test_multidevice_sharing.py -v
    pytest -q          # whole suite; compare with PROGRESS.md's "94 passed"

## What changed
- app/models/user.py: `User.role` / `User.is_admin` properties. Eight modules (access, dlp,
  signatures, recipients, alerts) read `user.role`, which did not exist -> AttributeError.
- app/services/key_wrap.py (new): AES-256-GCM DEK wrapping bound to doc id + version. Replaces
  XOR wrapping. Old rows (key_reference "master_v1") are still readable.
- app/services/documents.py: upload uses the new wrapping; `get_decrypted_content` replaced by
  `open_stream` (chunked decrypt, no full-file load). Upload itself still reads the whole file.
- app/services/grants_logic.py (new, pure): permission/expiry validation, grant state, PDP context.
- app/services/access_control.py (new): loads grants from DB on every request, calls the PDP,
  writes DOCUMENT_VIEW/DOWNLOAD or ACCESS_DENIED audit rows.
- app/api/v1/documents.py: `/download` (DOWNLOAD) and new `/content` (VIEW) both enforce the PDP.
- app/api/v1/shares.py (new): POST /shares, GET /shares/mine, GET /shares/with-me,
  PATCH /shares/{id}, DELETE /shares/{id} (revoke). Persisted, audited, notified.
- app/api/v1/access.py: create/review rewritten: owner-only approval, status validated, duplicate
  pending blocked, approval creates the grant, notifications + audit.
- app/services/notifications.py: implemented `notify()`.
- tests/unit/test_sharing_logic.py, tests/api/test_multidevice_sharing.py.

## Behaviour changes to be aware of
- Admins/superusers no longer read other users' document content or approve their access
  requests automatically (zero trust). Say if you want an admin override with mandatory audit.
- cryptography pin raised to >=44 (Argon2id in envelope.py).

## Still open
- Risk score passed to the PDP is a constant 0 (risk.py not wired to live audit events).
- Frontend pages (Shared With Me / My Shares) not built; only the API exists.
- Steps 3-5: SMS/phone OTP, PostgreSQL + admin DB status, LAN mode + docs, device pairing.
- Rotate the SECRET_KEY/MASTER_KEY that were in the shipped .env. Changing MASTER_KEY makes
  existing encrypted documents unreadable.
