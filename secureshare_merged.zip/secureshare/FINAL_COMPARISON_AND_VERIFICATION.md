# FINAL COMPARISON AND VERIFICATION

Main project: `secureshare_continued.zip` (user referred to it as `secureshare_continued(1).zip`; only one such file was uploaded).
Compared against: `secureshare_404_folders.zip` (ZIP 1) and `secureshare_continued_partial.zip` (ZIP 2).

## READ THIS FIRST: what was and was not verified

The authoring sandbox has **no network access**. `pip install` fails for everything, so **FastAPI, SQLAlchemy, pydantic, pytest, httpx and uvicorn were not available**. Consequences:

* The application was **never started**. No HTTP request was made. No database was created, migrated or queried.
* The real test suite (`pytest`) was **never run**. Roughly 370 test functions exist in `tests/`; none were executed under pytest.
* What WAS executed: `python -m compileall` over `app/` and `tests/`; a Jinja syntax parse of all 52 templates; a link audit of every literal internal `href`/`action` against `app/web/route_table.py`; and a **minimal pytest stand-in** (`/tmp/shim`, not shipped) that ran only tests importing nothing beyond the standard library, `cryptography` and `app.*` modules free of FastAPI/SQLAlchemy/pydantic. That is a weaker check than pytest.
* Therefore nothing below is marked PASS on the strength of "the file or route exists". Items that need the runtime are **INCOMPLETE**. The goal "every feature actually tested and working" is **NOT achieved in this session**. Run the commands in the last section on a machine with network access.

## 1. Components in ZIP 1 (404_folders) but missing from main (by file name)

12 files, all merged (copied only where absent; nothing in main was overwritten by this step):

`app/services/folder_store.py`, `app/web/folders.py`, `app/web/admin_pages.py`, `app/web/user_pages.py`, `app/web/auth_extra.py` (`/passkey`, `/verify-identity`), `app/templates/documents/folders.html`, `app/templates/admin/table.html`, `app/templates/user/table.html`, `tests/api/test_folders_and_pages.py`, `tests/unit/test_folder_rules_extra.py`, `tests/unit/test_kms_backends.py`, `CHANGES_404_AND_FOLDERS.md`.

## 2. Components in ZIP 2 (continued_partial) but missing from main

One file: `tests/unit/test_kms_backends.py` (byte-identical to the copy in ZIP 1). Restored.

## 3. Content-level differences (found by diffing files that exist in both)

A name-only diff hides these. Main had **lost hardening that both older ZIPs still contain** (both older ZIPs agree with each other on every file below). Main versions were backed up in `main_originals/` (build artefact, not part of the project; delete freely).

| File | Main had | Older ZIPs had | Action |
|---|---|---|---|
| `app/integrations/kms.py` | 64 lines, `local_dev` only | 259 lines: `AwsKms`, `VaultTransitKms`, `build_kms`, `kms_status`, context-bound wrapping | older version taken |
| `app/config/settings.py` | `kms_backend` limited to `local_dev` | `aws`/`vault`/... plus AWS/Vault settings, `csrf_allow_demo_token` dev-only validator | older version taken |
| `app/lifespan.py` | refused to start for any non-local KMS | builds the KMS at startup; unusable cloud KMS stops startup (no silent fallback to the dev key) | older version taken |
| `app/services/documents.py` | KMS outage raised `ValidationError` | KMS outage raises `ProviderUnavailableError` (503) on upload and on read | older version taken |
| `app/middleware/csrf.py` | token check only; "demo" token accepted whenever `is_dev` | adds Origin/Referer check; "demo" token only with `CSRF_ALLOW_DEMO_TOKEN` | older version taken |
| `app/middleware/security_headers.py` | basic headers | adds COOP, CORP, X-Permitted-Cross-Domain-Policies, `X-XSS-Protection: 0`, stricter Permissions-Policy, `no-store` on `/api/` | older version taken |
| `app/services/db_status.py` | probed on the request session (rollback expired ORM objects) | probes on a dedicated connection | older version taken |
| `app/web/admin.py` | non-admin silently redirected | real 403 page | older version taken |
| `app/services/admin.py` | `set_user_role` assigned to a read-only property (would crash) | replaces the `roles` rows | older version taken |
| `layouts/admin.html`, `layouts/app.html`, `documents/list.html`, `components.css` | no links to the new pages | nav links + styles for folders/shared/admin pages | older version taken |
| `requirements-cloud.txt`, `tests/conftest.py` | listed `hvac` | no `hvac` (Vault adapter uses the standard library); conftest sets `CSRF_ALLOW_DEMO_TOKEN` | older version taken |
| `app/web/user.py` | has a read-only `/admin/database` page | lacks it | **main kept** (newer) |
| `app/main.py`, `app/web/route_table.py` | lack folder/page routers and routes | have them | **merged by hand** (see 4) |

## 4. Components merged / conflicts resolved

* `app/main.py`: added the four routers (`folders`, `user_pages`, `auth_extra` before `admin_router`; `admin_pages` after). Main's existing routers and order are otherwise unchanged.
* `app/web/route_table.py`: added `/folders*`, `/documents/{id}/move`, `/access-requests/{id}/approve|reject`, `/security/alerts/{id}/acknowledge`. Main already listed the other new paths.
* Route overlap: the new admin pages (`/admin/roles`, ...) do not overlap main's `/admin`, `/admin/users*`, `/admin/configuration`, `/admin/database`. `/admin/database` is defined twice in main (`user.py` and `admin.py`); `user.py` is included first and wins. Left as-is; harmless but should be deduplicated.
* All symbols the merged files import were checked to exist in main by grep (`_auth`, `_render`, `AuditRepository.log_event`, `IdentityService.verify_totp`, `Session.step_up_verified_at`, `safe_redirect_url`, `get_csrf_token`, `build_env`, `Folder`/`Document` columns, `soft_delete`). `app/models/folder.py` is identical in all three ZIPs. **Existence was checked, behaviour was not run.**
* Not merged on purpose: nothing from the older ZIPs overwrote a file where main was newer.

## 5. Features fixed in this session (all UNEXECUTED, compile-checked only)

* Folders, 404 pages, `/passkey`, `/verify-identity`: wired in (see 1, 4).
* Cloud KMS adapters and 503-on-outage handling restored (see 3).
* **Notification fan-out was dead code** (`notify_fan_out` had no callers). Added `safe_notify` (runs in a SAVEPOINT, swallows errors, never blocks the triggering action) and called it on: MFA enabled, MFA disabled, account lockout. Not yet wired to: DLP/malware alerts, risk detections, link revocation, document share events.

## 6. Tests executed

| Run | Result |
|---|---|
| `compileall app tests` | OK |
| Jinja parse of 52 templates | 0 syntax errors |
| Template link audit vs `route_table.py` | 0 unknown internal links |
| `test_folder_rules_extra` (3 tests, shim) | 3 PASS |
| `test_kms_backends` (shim) | 5 PASS (AWS outage, AWS roundtrip + key_wrap integration, Vault network failure, Vault http/config refusal, Vault roundtrip + bad token); 1 FAIL only because `pydantic` is missing; 2 not run (need pytest fixtures: `test_aws_requires_key_id_and_credentials`, `test_documents_are_encrypted_with_the_kms_and_old_local_rows_still_open`) |
| All other `tests/unit` modules (shim) | 56 PASS / 4 FAIL / 10 not run overall; 7 modules could not import (`sqlalchemy`/`pydantic`). The 4 FAILs: three are `pydantic` missing; `test_email_provider::test_invalid_recipient_never_reaches_the_server` raised an AssertionError that I did **not** investigate (could be a shim or missing `email_validator` effect, could be real) |
| `tests/api`, `tests/integration`, `tests/security`, `tests/crypto`, `tests/e2e`, `tests/workers` | **NOT RUN** (need FastAPI/SQLAlchemy/pytest) |

## 7. Runtime and E2E verification

**None performed.** No server start, no DB migration, no HTTP request, no browser, no E2E. Every row in the status table below that depends on these is INCOMPLETE.

## 8. Status table

Legend: PASS = executed and observed working. FAIL = executed and failing. INCOMPLETE = code exists or was changed, not executed. CONFIG_REQUIRED = needs real credentials for the live test (adapter code present).

| Area | Status | Basis |
|---|---|---|
| Merge of the 12 missing files + wiring | INCOMPLETE | compiles, links resolve, templates parse; routes never served |
| Nested folders (create/rename/move/delete/breadcrumbs/doc move) | INCOMPLETE | pure rules PASS (3 tests, shim); DB layer and pages never run |
| Folder depth / cycle / duplicate validation | PASS (pure logic only) | `test_folder_rules_extra`, shim |
| Owner isolation on folders | INCOMPLETE | queries are owner-scoped by reading; pure check PASS; not exercised through HTTP |
| Admin extra pages (18, read-only) | INCOMPLETE | not served |
| Access-request, signatures, risk, alerts pages | INCOMPLETE | not served |
| `/verify-identity` | INCOMPLETE | works only as a TOTP check. **`step_up_verified_at` is written and never read anywhere**, so it gates nothing. Template text says "OTP sent to your email", which is wrong for TOTP |
| `/passkey` | INCOMPLETE | honest "unavailable" page; passkeys are NOT implemented |
| KMS AWS/Vault adapters (unit, fake transports) | PASS (5 tests, shim) | enforce context binding in fakes |
| KMS → DocumentService integration | INCOMPLETE | code restored; the two tests that exercise it were not run |
| AWS KMS live | CONFIG_REQUIRED | needs boto3 + AWS credentials; never contacted |
| Vault Transit live | CONFIG_REQUIRED | needs a Vault server and token; never contacted |
| CSRF + Origin check | INCOMPLETE | restored; no live test |
| Security headers | INCOMPLETE | restored; no response observed |
| MFA at login | INCOMPLETE | enforced in `auth.py` by reading; not run |
| MFA required by link / policy | **FAIL by inspection (not executed)** | `link_access.py` hard-codes `mfa_verified=False`, so a link with `requires_mfa` has no way to satisfy MFA. Not fixed |
| Zero-Trust PDP wiring | INCOMPLETE | called from `access_control`, `grants_logic`, `viewer`; never run |
| Notification fan-out | INCOMPLETE | now wired for 3 events; DLP/malware/risk/share events still not wired |
| Google OAuth / Microsoft OAuth | CONFIG_REQUIRED (live) / INCOMPLETE (flow) | flow code exists. Known weakness: a missing `nonce`/`aud` claim is accepted (`not in (None, ...)`). **Not fixed**: the integration test `test_oauth_web.py` (Microsoft case) sends an id_token without a nonce and would break; fixing needs the test to echo the nonce from the authorize URL |
| Semantic / document search | **NOT IMPLEMENTED** | `search.py` is lexical only and says so; shared documents are not searchable |
| Hosted LLM integration | **NOT IMPLEMENTED** | no adapter exists. Not built this session |
| Malware provider | INCOMPLETE / CONFIG_REQUIRED (live) | `integrations/malware.py` exists; not run |
| Upload → scan → hash → encrypt → store → view → download | INCOMPLETE | not run |
| Secure link → recipient verify → limits → revoke/rotate | INCOMPLETE | not run |
| RBAC/ABAC, risk engine → policy, DLP/OCR, signatures, audit chain, alerts, watermark, attack simulator, security score | INCOMPLETE | files exist; not run. Risk detections are not saved as security alerts (per `CHANGES_404_AND_FOLDERS.md`; not re-verified) |
| Frontend dead buttons / API connections | INCOMPLETE | only the literal-link audit was done; no JS/form behaviour was run |
| DB migrations (alembic) | INCOMPLETE | never run |
| `/admin/backup` | INCOMPLETE | checklist page only; no backup job exists |
| Full test suite | **INCOMPLETE** | not run |

## 9. Known open items (not fixed here)

1. Run the whole suite; expect failures in code paths changed in section 3 (CSRF Origin check, settings, lifespan).
2. Consume `step_up_verified_at` in the Zero-Trust decision; give links with `requires_mfa` a real step-up path.
3. OAuth: require `nonce` and `aud` when an ID token is returned, and update `test_oauth_web.py` to match.
4. Build semantic search and an LLM adapter (neither exists).
5. Wire `safe_notify` to DLP/malware/risk/share events; persist risk detections as alerts.
6. The admin DLP rescan endpoint may let an admin decrypt content (reported in the older change notes; not re-checked).
7. Remove the duplicate `/admin/database` route; pin FastAPI; move `httpx` to runtime if needed.

## 10. Commands to run on a machine with network access

```
pip install -r requirements-dev.txt
pytest tests/unit/test_kms_backends.py tests/unit/test_folder_rules_extra.py tests/api/test_folders_and_pages.py -v
pytest -q
uvicorn app.main:app --reload     # then click through /folders, /admin/*, /verify-identity, /passkey
```
