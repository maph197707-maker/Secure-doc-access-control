@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ========================================================
echo  SecureShare - Install and first-run setup
echo ========================================================
echo.

rem ---- 1. Find Python 3.12+ (python, then the py launcher) ----
set "PY="
python -c "import sys; sys.exit(0 if sys.version_info >= (3,12) else 1)" >nul 2>&1
if not errorlevel 1 set "PY=python"
if not defined PY (
    py -3.12 -c "import sys" >nul 2>&1
    if not errorlevel 1 set "PY=py -3.12"
)
if not defined PY (
    py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,12) else 1)" >nul 2>&1
    if not errorlevel 1 set "PY=py -3"
)
if not defined PY (
    echo [ERROR] Python 3.12 or newer was not found.
    echo         Install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH".
    pause
    exit /b 1
)
echo [1/7] Using: %PY%
%PY% --version

rem ---- 2. Virtual environment (reused if it already exists) ----
if not exist ".venv\Scripts\python.exe" (
    echo [2/7] Creating virtual environment .venv ...
    %PY% -m venv .venv
    if errorlevel 1 goto :fail
) else (
    echo [2/7] Reusing existing .venv
)
set "VPY=%CD%\.venv\Scripts\python.exe"

rem ---- 3. Dependencies ----
echo [3/7] Installing dependencies (needs internet) ...
"%VPY%" -m pip install --upgrade pip
if errorlevel 1 goto :fail
"%VPY%" -m pip install -r requirements.txt
if errorlevel 1 goto :fail
"%VPY%" -m pip install -r requirements-dev.txt
if errorlevel 1 goto :fail

rem ---- 4. .env with fresh random secrets (never overwrites an existing .env) ----
echo [4/7] Checking .env ...
"%VPY%" -c "from scripts import doctor; print('Created .env with fresh random secrets' if doctor.ensure_env() else '.env already exists - left unchanged')"
if errorlevel 1 goto :fail

rem ---- 5. Folders, database and roles ----
echo [5/7] Preparing storage folders, database and roles ...
if not exist "storage\encrypted" mkdir "storage\encrypted"
"%VPY%" -m scripts.setup_db
if errorlevel 1 goto :fail

rem ---- 6. Optional administrator ----
echo.
set "MAKEADMIN="
set /p MAKEADMIN="[6/7] Create an administrator account now? (y/N): "
if /i "%MAKEADMIN%"=="y" (
    set "ADMIN_EMAIL="
    set /p ADMIN_EMAIL="      Admin email: "
    if defined ADMIN_EMAIL (
        "%VPY%" -m scripts.create_admin --email "%ADMIN_EMAIL%"
    )
)

rem ---- 7. Optional test run ----
echo.
set "RUNTESTS="
set /p RUNTESTS="[7/7] Run the automated test suite now (about 1 minute)? (y/N): "
if /i "%RUNTESTS%"=="y" "%VPY%" -m pytest tests -q -p no:cacheprovider

echo.
echo ========================================================
echo  Setup complete.
echo    Start the app :  start.bat           (this PC only)
echo    Start for LAN :  start.bat lan       (other devices on your Wi-Fi)
echo    Then open     :  http://127.0.0.1:8000
echo.
echo  "Continue as guest" works immediately. Sign-up needs no email.
echo  Email and phone are verified later in Profile. To actually
echo  deliver codes, fill SMTP_* (email) and TWILIO_* (SMS) in .env.
echo  Check email:  .venv\Scripts\python -m scripts.test_email you@example.com
echo ========================================================
pause
exit /b 0

:fail
echo.
echo [ERROR] Setup stopped. Read the message above, fix it, and run install.bat again.
pause
exit /b 1
