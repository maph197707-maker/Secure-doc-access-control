# Sharing a secure link on WhatsApp / any platform

A link containing `localhost` or `127.0.0.1` only opens on YOUR computer. For another person to open it,
your SecureShare server must be reachable from the Internet over HTTPS. Easiest way (no hosting needed):

## Option A - Cloudflare quick tunnel (free, no account)
1. Install cloudflared (https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/).
2. Start SecureShare (`start.bat`), then in a second window:
       cloudflared tunnel --url http://localhost:8000
   It prints an address like  https://random-words.trycloudflare.com
3. Stop SecureShare, open `.env`, add (use YOUR printed address, no https:// in ALLOWED_HOSTS):
       PUBLIC_BASE_URL=https://random-words.trycloudflare.com
       ALLOWED_HOSTS=localhost,127.0.0.1,random-words.trycloudflare.com
4. Start SecureShare again. Links you create now start with that https address - paste them into WhatsApp.

(ngrok works the same way: `ngrok http 8000`, then use the https://....ngrok-free.app address.)

## Things to know (honest limits)
- Your PC, SecureShare and the tunnel must stay running while the recipient opens the link.
- Free tunnel addresses change every time you restart the tunnel. Links made with the old address stop
  working; update `.env` and create a new link.
- Recipient does NOT decrypt anything by hand. The server decrypts the file only after the link checks pass
  (not expired/revoked, view/download limits, permission, and recipient verification if you chose one).
- In the share wizard choose "No verification" for a link anyone with the URL can open, or a recipient
  mode (email/phone code) - code delivery only works after you configure SMTP_* / TWILIO_* in `.env`.
- For permanent use, deploy to a server with HTTPS (see docs/ and docker-compose.prod.yml) and set
  APP_ENV=production, PUBLIC_BASE_URL, SECRET_KEY, MASTER_SECRET, COOKIE_SECURE=true.

## Uploading folders
Zip the folder (right-click > Send to > Compressed folder) and upload the .zip. Supported types:
pdf, docx, xlsx, pptx, txt, csv, png, jpg, jpeg, gif, webp, zip, md, json, xml, rtf, odt, ods, odp. Max 50 MB each
(change MAX_UPLOAD_BYTES in .env). Executables (.exe, .bat, ...) are refused on purpose.
