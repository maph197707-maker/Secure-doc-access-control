# SecureShare

Secure document sharing with zero-trust access. See `docs/gap-report.md` and `PROGRESS.md` for the honest status of every module.

## Run the tests (works offline, no framework needed)
    python3 -m unittest discover -s tests -t .
(`tests/integration/test_migrations.py` additionally needs `pip install -e .[dev]`.)

## Install and run (Windows)
    install.bat        # venv, dependencies, .env with random secrets, database + roles, optional admin/tests
    start.bat          # http://127.0.0.1:8000        (start.bat lan = reachable from your Wi-Fi)

## Install and run (any OS)
    python -m venv .venv && source .venv/bin/activate    # Windows: .venv\Scripts\activate
    pip install -r requirements.txt -r requirements-dev.txt
    python -m scripts.setup_db && python -m scripts.run dev

## Accounts, guest login and verification
- **Continue as guest** (login + register pages): a real temporary account, no email or code.
- **Create account** needs no email delivery. Email and phone are verified afterwards in **Profile**
  (`/profile`): request a one-time code, enter it. Codes are hashed, expire, are attempt-limited and
  one-time. Without SMTP / Twilio configured the page says so and nothing is marked verified.
- Real delivery: set `SMTP_*` (email) and `TWILIO_*` (SMS) in `.env`; test with `python -m scripts.test_email you@example.com`.
- `SIGNUP_EMAIL_VERIFICATION_REQUIRED=true` brings back an email code at sign-up (needs SMTP).
