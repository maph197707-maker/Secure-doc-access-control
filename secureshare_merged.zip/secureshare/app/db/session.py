"""Async SQLAlchemy session factory and FastAPI dependency."""
from __future__ import annotations

import asyncio
from typing import AsyncGenerator

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from app.config.settings import get_settings

settings = get_settings()

# ── Engine ────────────────────────────────────────────────────────────────────
_connect_args: dict = {}
if settings.database_url.startswith("sqlite"):
    _connect_args = {"check_same_thread": False}

_pool_args: dict = {}
if not settings.database_url.startswith("sqlite"):
    # PostgreSQL (Supabase / Neon / any standard server): real connection pool.
    _pool_args = {"pool_size": settings.db_pool_size, "max_overflow": settings.db_max_overflow,
                  "pool_recycle": 1800}

engine = create_async_engine(
    settings.database_url,
    echo=settings.db_echo,
    connect_args=_connect_args,
    pool_pre_ping=True,
    **_pool_args,
)

# ── Session factory ────────────────────────────────────────────────────────────
AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False,
)


# ── FastAPI dependency ─────────────────────────────────────────────────────────
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with AsyncSessionLocal() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# ── SQLite pragmas ─────────────────────────────────────────────────────────────
async def _configure_sqlite(conn: object) -> None:
    """Enable WAL mode and foreign keys for SQLite connections."""
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import AsyncConnection

    if isinstance(conn, AsyncConnection):
        await conn.execute(text("PRAGMA journal_mode=WAL"))
        await conn.execute(text("PRAGMA foreign_keys=ON"))
        await conn.execute(text("PRAGMA busy_timeout=5000"))


async def create_tables() -> None:
    """Create all tables (used in tests and dev setup)."""
    from app.db.base import Base
    import app.models  # noqa: F401 — ensure all models are registered

    async with engine.begin() as conn:
        if settings.database_url.startswith("sqlite"):
            await conn.execute(__import__("sqlalchemy").text("PRAGMA journal_mode=WAL"))
            await conn.execute(__import__("sqlalchemy").text("PRAGMA foreign_keys=ON"))
        await conn.run_sync(Base.metadata.create_all)


async def drop_tables() -> None:
    """Drop all tables (tests only)."""
    from app.db.base import Base
    import app.models  # noqa: F401

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
