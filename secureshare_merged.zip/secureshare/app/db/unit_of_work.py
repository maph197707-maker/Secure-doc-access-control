"""Async Unit of Work pattern wrapping a SQLAlchemy AsyncSession."""
from __future__ import annotations

from types import TracebackType
from typing import Self

from sqlalchemy.ext.asyncio import AsyncSession

from app.db.session import AsyncSessionLocal


class AsyncUnitOfWork:
    """Context manager providing a transactional unit of work.

    Usage:
        async with AsyncUnitOfWork() as uow:
            result = await uow.session.execute(...)
            await uow.commit()
    """

    def __init__(self) -> None:
        self._session: AsyncSession | None = None

    async def __aenter__(self) -> Self:
        self._session = AsyncSessionLocal()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        if exc_type is not None:
            await self.rollback()
        await self._session.close()  # type: ignore[union-attr]

    @property
    def session(self) -> AsyncSession:
        if self._session is None:
            raise RuntimeError("UoW not entered — use 'async with AsyncUnitOfWork() as uow'")
        return self._session

    async def commit(self) -> None:
        await self.session.commit()

    async def rollback(self) -> None:
        await self.session.rollback()

    async def flush(self) -> None:
        await self.session.flush()
