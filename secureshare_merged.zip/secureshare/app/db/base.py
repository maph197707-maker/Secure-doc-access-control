"""SQLAlchemy 2.x async base with mixins for all SecureShare models."""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import Boolean, DateTime, Integer, String, text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def _now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _new_uuid() -> str:
    return str(uuid.uuid4())


class Base(DeclarativeBase):
    """SQLAlchemy 2.x declarative base."""
    type_annotation_map: dict[Any, Any] = {}


class UUIDMixin:
    """Primary key as String(36) UUID — compatible with both SQLite and PostgreSQL."""
    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=_new_uuid, index=True
    )


class TimestampMixin:
    """Auto-managed created_at / updated_at columns."""
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=_now, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=_now, onupdate=_now, nullable=False
    )


class SoftDeleteMixin:
    """Soft-delete support: is_deleted flag + deleted_at timestamp."""
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False, index=True)
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    def soft_delete(self) -> None:
        self.is_deleted = True
        self.deleted_at = _now()


class VersionMixin:
    """Optimistic locking version counter."""
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)


class AppBase(UUIDMixin, TimestampMixin, Base):
    """Base class combining UUID PK and timestamps. Use for most models."""
    __abstract__ = True
