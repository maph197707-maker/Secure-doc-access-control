"""FastAPI application factory for SecureShare."""
from __future__ import annotations

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.api.router import api_v1_router
from app.config.settings import get_settings
from app.core.error_handlers import register_error_handlers
from app.lifespan import lifespan
from app.middleware.access_log import AccessLogMiddleware
from app.middleware.csrf import CSRFMiddleware
from app.middleware.host_guard import HostGuardMiddleware
from app.middleware.rate_limit import RateLimitMiddleware
from app.middleware.request_id import RequestIDMiddleware
from app.middleware.security_headers import SecurityHeadersMiddleware
from app.web.account_phone import router as account_phone_router
from app.web.admin_pages import router as admin_pages_router
from app.web.auth_extra import router as auth_extra_router
from app.web.folders import router as folders_router
from app.web.user_pages import router as user_pages_router
from app.web.profile import router as profile_router
from app.web.admin import router as admin_router
from app.web.dashboard import router as dashboard_router
from app.web.dev import router as dev_router
from app.web.documents import router as documents_web_router
from app.web.mfa_pages import router as mfa_router
from app.web.public import router as public_router
from app.web.security_pages import router as security_pages_router
from app.web.share_flow import router as share_flow_router
from app.web.showcase import router as ui_router
from app.web.user import router as user_router
from app.web.templating import STATIC_DIR


def create_app() -> FastAPI:
    settings = get_settings()

    app = FastAPI(
        title="SecureShare",
        description="Secure Intelligent Document Sharing & Zero-Trust Access Platform",
        version="1.0.0",
        lifespan=lifespan,
    )

    # 1. Register global exception handlers
    register_error_handlers(app)

    # 2. Add middleware (executed in reverse order: HostGuard is outermost)
    app.add_middleware(RateLimitMiddleware)
    app.add_middleware(CSRFMiddleware)
    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(AccessLogMiddleware)
    app.add_middleware(RequestIDMiddleware)
    app.add_middleware(HostGuardMiddleware)

    # 3. Mount static files
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    @app.get("/service-worker.js", include_in_schema=False)
    async def service_worker() -> FileResponse:
        return FileResponse(
            STATIC_DIR / "service-worker.js",
            media_type="application/javascript",
            headers={"Service-Worker-Allowed": "/"},
        )

    # 4. Root health check
    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok", "mode": settings.app_mode}

    # 5. Routers (API & Web)
    app.include_router(api_v1_router)
    app.include_router(public_router)
    app.include_router(mfa_router)        # real /mfa login step + /settings/security (optional MFA)
    app.include_router(share_flow_router)
    app.include_router(user_router)       # real, database-backed /shares pages
    app.include_router(security_pages_router)  # /security/*, /settings/*, /about, /privacy, /terms
    app.include_router(documents_web_router)  # /home, /search, /documents/upload, /documents/{id}/...
    app.include_router(dashboard_router)  # real /dashboard, /documents, /analytics, /notifications
    app.include_router(account_phone_router)
    app.include_router(profile_router)       # real /profile: verify email + phone after sign-up
    app.include_router(folders_router)     # nested folders: /folders, /documents/{id}/move
    app.include_router(user_pages_router)  # /shared-with-me, /access-requests, /signatures, /security/risk|alerts
    app.include_router(auth_extra_router)  # /passkey (honest: unavailable), /verify-identity (TOTP step-up)
    app.include_router(admin_router)      # real /admin pages
    app.include_router(admin_pages_router) # read-only admin pages that used to 404
    app.include_router(dev_router)
    if settings.debug:
        # Sample-data UI prototypes. NEVER mounted in production, and never at the real paths.
        app.include_router(ui_router, prefix="/dev/showcase")

    return app


app = create_app()
