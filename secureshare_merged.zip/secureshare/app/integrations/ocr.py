"""OCR / text extraction providers. Status is explicit: COMPLETED, FAILED or PROVIDER_UNAVAILABLE.
Nothing reports COMPLETED unless text was actually extracted."""
from __future__ import annotations

import io
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from typing import Protocol

COMPLETED, FAILED, PROVIDER_UNAVAILABLE = "COMPLETED", "FAILED", "PROVIDER_UNAVAILABLE"
MAX_TEXT = 1_000_000


@dataclass(frozen=True)
class OcrResult:
    status: str
    text: str = ""
    engine: str = ""
    detail: str = ""


class OCRProvider(Protocol):
    def extract(self, data: bytes, filename: str, mime: str | None = None) -> OcrResult: ...


class LocalOCRProvider:
    """Plain text read directly; PDF text layer via poppler `pdftotext`; images via tesseract.
    Missing binaries -> PROVIDER_UNAVAILABLE (never a fake COMPLETED)."""

    def extract(self, data: bytes, filename: str, mime: str | None = None) -> OcrResult:
        name = filename.lower()
        if name.endswith((".txt", ".md", ".csv", ".log", ".json")) or (mime or "").startswith("text/"):
            try:
                return OcrResult(COMPLETED, data.decode("utf-8", "replace")[:MAX_TEXT], "plain-text")
            except Exception as exc:  # noqa: BLE001
                return OcrResult(FAILED, engine="plain-text", detail=exc.__class__.__name__)
        if name.endswith(".pdf") or data[:5] == b"%PDF-":
            return self._pdf(data)
        if name.endswith((".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".gif", ".webp")):
            return self._image(data)
        return OcrResult(PROVIDER_UNAVAILABLE, engine="local", detail="no extractor for this file type")

    def _run(self, argv: list[str], data: bytes, suffix: str) -> subprocess.CompletedProcess:
        with tempfile.NamedTemporaryFile(suffix=suffix) as tmp:    # removed on close
            tmp.write(data)
            tmp.flush()
            return subprocess.run([*argv[:1], tmp.name, *argv[1:]], capture_output=True, timeout=60, check=False)

    def _pdf(self, data: bytes) -> OcrResult:
        if not shutil.which("pdftotext"):
            return OcrResult(PROVIDER_UNAVAILABLE, engine="pdftotext", detail="poppler-utils not installed")
        try:
            p = self._run(["pdftotext", "-"], data, ".pdf")
        except (subprocess.TimeoutExpired, OSError) as exc:
            return OcrResult(FAILED, engine="pdftotext", detail=exc.__class__.__name__)
        text = p.stdout.decode("utf-8", "replace").strip()
        if p.returncode != 0:
            return OcrResult(FAILED, engine="pdftotext", detail="pdftotext failed")
        if not text:
            return OcrResult(FAILED, engine="pdftotext", detail="no text layer (scanned PDF needs image OCR)")
        return OcrResult(COMPLETED, text[:MAX_TEXT], "pdftotext")

    def _image(self, data: bytes) -> OcrResult:
        if not shutil.which("tesseract"):
            return OcrResult(PROVIDER_UNAVAILABLE, engine="tesseract", detail="tesseract not installed")
        try:
            from PIL import Image
            buf = io.BytesIO()
            Image.open(io.BytesIO(data)).convert("RGB").save(buf, "PNG")
            p = self._run(["tesseract", "stdout"], buf.getvalue(), ".png")
        except Exception as exc:  # noqa: BLE001
            return OcrResult(FAILED, engine="tesseract", detail=exc.__class__.__name__)
        text = p.stdout.decode("utf-8", "replace").strip()
        return OcrResult(COMPLETED, text[:MAX_TEXT], "tesseract") if text else OcrResult(
            FAILED, engine="tesseract", detail="no text recognised")


def get_ocr_provider() -> OCRProvider:
    return LocalOCRProvider()
