"""Single place that turns settings into delivery services. Callers use `factory.get_*_service()`
(attribute access on the module), so tests can substitute a recording transport with one monkeypatch.
Returns None when the channel is not configured - callers must then fail honestly, never fake a send."""
from __future__ import annotations

from app.config.settings import get_settings
from app.integrations.email import EmailConfigError, EmailService
from app.integrations.sms import SMSConfigError, SMSService


def get_email_service() -> EmailService | None:
    try:
        return EmailService.from_settings(get_settings())
    except EmailConfigError:
        return None


def get_sms_service() -> SMSService | None:
    try:
        return SMSService.from_settings(get_settings())
    except SMSConfigError:
        return None
