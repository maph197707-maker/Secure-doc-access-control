"""SMS delivery for one-time codes: SMSService -> SMSProvider -> TwilioSMSProvider.

Twilio Programmable Messaging is the single production provider
(POST https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/Messages.json, HTTP Basic auth with
Account SID + Auth Token, form fields To / Body and either From or MessagingServiceSid; success is
HTTP 201 with a message `sid`). Credentials come from the environment only. The code is generated and
verified by our backend (services/otp.py); Twilio only carries the message.

A send either returns the provider message id or raises SMSDeliveryError with a categorised `reason`.
Message bodies (which contain the code) and credentials are never logged. Stdlib only (urllib).
Test doubles live under tests/support and are never selected from configuration.
"""
from __future__ import annotations

import base64
import json
import re
import urllib.error
import urllib.parse
import urllib.request
from abc import ABC, abstractmethod
from typing import Callable

from app.integrations import errors as E

_E164 = re.compile(r"^\+[1-9]\d{7,14}$")
Transport = Callable[[urllib.request.Request, float], tuple[int, str]]

TWILIO_URL = "https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json"
# https://www.twilio.com/docs/api/errors -> our categories
_TWILIO_RECIPIENT = {21211, 21212, 21214, 21217, 21401, 21407, 21408, 21421, 21610, 21614, 21612, 21608, 63038}
_TWILIO_AUTH = {20003, 20404}
_TWILIO_RATE = {20429, 14107, 30022}


class SMSDeliveryError(E.DeliveryFailure):
    """The provider rejected or failed to send the message (see `.reason`)."""


class SMSConfigError(E.ProviderConfigError):
    """SMS is not configured."""


def normalize_phone(phone: str, default_country_code: str = "+91") -> str:
    """Return E.164 (+<country><number>) or raise ValueError. A bare national number gets the
    default country code (SMS_DEFAULT_COUNTRY_CODE)."""
    raw = re.sub(r"[\s\-().]", "", phone or "")
    if raw.startswith("00"):
        raw = "+" + raw[2:]
    if not raw.startswith("+"):
        digits = raw.lstrip("0") if len(raw) == 11 and raw.startswith("0") else raw
        raw = default_country_code + digits
    if not _E164.match(raw):
        raise ValueError("Enter the phone number with country code, e.g. +919876543210.")
    return raw


def mask_phone(phone: str) -> str:
    return f"{phone[:3]}{'*' * max(len(phone) - 6, 3)}{phone[-3:]}"


def _urllib_transport(req: urllib.request.Request, timeout: float) -> tuple[int, str]:
    """(status, body). HTTP error statuses are returned, not raised; network faults raise SMSDeliveryError."""
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:     # noqa: S310 (https URL enforced by caller)
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except TimeoutError:
        raise SMSDeliveryError(E.TIMEOUT, "sms timeout") from None
    except urllib.error.URLError as e:
        if isinstance(e.reason, TimeoutError):
            raise SMSDeliveryError(E.TIMEOUT, "sms timeout") from None
        raise SMSDeliveryError(E.NETWORK, "sms network error") from None
    except OSError:
        raise SMSDeliveryError(E.NETWORK, "sms network error") from None


class SMSProvider(ABC):
    name = "base"

    @abstractmethod
    def send(self, to_e164: str, body: str) -> str:
        """Send one SMS. Returns the provider message id. Raises SMSDeliveryError on failure."""


class TwilioSMSProvider(SMSProvider):
    name = "twilio"

    def __init__(self, account_sid: str, auth_token: str, *, from_number: str = "",
                 messaging_service_sid: str = "", timeout: float = 10, transport: Transport | None = None) -> None:
        if not (account_sid and auth_token and (from_number or messaging_service_sid)):
            raise SMSConfigError("TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN and TWILIO_FROM_NUMBER "
                                 "(or TWILIO_MESSAGING_SERVICE_SID) are required.")
        self.sid, self._token = account_sid, auth_token
        self.from_number, self.service_sid, self.timeout = from_number, messaging_service_sid, timeout
        self._transport = transport or _urllib_transport     # injection seam for tests

    def send(self, to_e164: str, body: str) -> str:
        form = {"To": to_e164, "Body": body}
        if self.service_sid:
            form["MessagingServiceSid"] = self.service_sid
        else:
            form["From"] = self.from_number
        auth = base64.b64encode(f"{self.sid}:{self._token}".encode()).decode()
        req = urllib.request.Request(
            TWILIO_URL.format(sid=urllib.parse.quote(self.sid, safe="")),
            data=urllib.parse.urlencode(form).encode(), method="POST",
            headers={"Authorization": f"Basic {auth}", "Content-Type": "application/x-www-form-urlencoded",
                     "Accept": "application/json"})
        status, text = self._transport(req, self.timeout)
        try:
            data = json.loads(text) if text else {}
        except ValueError:
            data = {}
        if status == 201 and data.get("sid") and data.get("status") not in ("failed", "undelivered"):
            return str(data["sid"])
        code = data.get("code") if isinstance(data.get("code"), int) else data.get("error_code")
        if status == 401 or code in _TWILIO_AUTH:
            raise SMSDeliveryError(E.AUTH, "twilio authentication failed")
        if status == 429 or code in _TWILIO_RATE:
            raise SMSDeliveryError(E.RATE_LIMITED, "twilio rate limited")
        if code in _TWILIO_RECIPIENT:
            raise SMSDeliveryError(E.RECIPIENT, f"twilio rejected recipient ({code})")
        if status >= 500:
            raise SMSDeliveryError(E.UNAVAILABLE, f"twilio http {status}")
        raise SMSDeliveryError(E.REJECTED, f"twilio http {status} code {code}")


class SMSService:
    """What the rest of the app calls."""

    def __init__(self, provider: SMSProvider, default_country_code: str = "+91") -> None:
        self.provider = provider
        self.cc = default_country_code

    @classmethod
    def from_settings(cls, st=None) -> "SMSService":
        if st is None:
            from app.config.settings import get_settings
            st = get_settings()
        if not st.sms_configured:
            raise SMSConfigError("SMS is not configured (TWILIO_* variables).")
        prov = TwilioSMSProvider(st.twilio_account_sid.strip(), st.twilio_auth_token.get_secret_value().strip(),
                                 from_number=st.twilio_from_number.strip(),
                                 messaging_service_sid=st.twilio_messaging_service_sid.strip(),
                                 timeout=st.sms_timeout_seconds)
        return cls(prov, st.sms_default_country_code)

    def send_otp(self, phone: str, code: str, minutes: int = 10) -> str:
        try:
            to = normalize_phone(phone, self.cc)
        except ValueError:
            raise SMSDeliveryError(E.RECIPIENT, "invalid phone number") from None
        return self.provider.send(to, f"Your SecureShare verification code is {code}. "
                                      f"It expires in {minutes} minutes. Do not share it.")
