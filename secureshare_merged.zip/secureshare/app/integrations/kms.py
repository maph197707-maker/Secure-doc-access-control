"""KeyManagementService abstraction.

Every backend implements the KeyProvider protocol from app.crypto.envelope (wrap/unwrap of a per-document
DEK, bound to document + version through the AAD), plus `status()`.

Backends
- local_dev : LocalDevelopmentKeyProvider; the KEK is derived from MASTER_SECRET. DEV ONLY.
- aws       : AWS KMS Encrypt/Decrypt (boto3). The AAD is sent as the KMS EncryptionContext, so a wrapped DEK
              copied onto another document/version fails to decrypt. Needs boto3 + credentials + KMS_AWS_KEY_ID.
- vault     : HashiCorp Vault Transit encrypt/decrypt over HTTPS. The AAD is the Transit `context`, so the
              transit key MUST be created with derived=true. Needs VAULT_ADDR + VAULT_TOKEN + VAULT_TRANSIT_KEY.
- azure/hsm : not implemented. Selecting them reports PROVIDER_UNAVAILABLE; nothing falls back to a local key.

A cloud backend that is not configured raises KmsUnavailable (PROVIDER_UNAVAILABLE) - it never silently uses
the development key. `status()` is configuration-only (no network). `selftest()` does one real wrap/unwrap
round trip against the provider and is what `scripts.doctor` / the admin System health page call.

VERIFICATION STATUS: the AWS and Vault adapters are unit-tested against fake clients/transports that follow the
documented request/response shapes. They have NOT been run against a live AWS account or Vault server.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable

from app.crypto.envelope import (KeyError_, KeyProvider, LocalDevelopmentKeyProvider,
                                 WrappedKey)

PROVIDER_UNAVAILABLE = "PROVIDER_UNAVAILABLE"
SUPPORTED_BACKENDS = ("local_dev", "aws", "vault", "azure", "hsm")


class KmsUnavailable(KeyError_):
    code = PROVIDER_UNAVAILABLE


@dataclass(frozen=True)
class KmsStatus:
    backend: str
    available: bool
    detail: str
    production_grade: bool
    live_verified: bool = False       # True only after selftest() succeeded in THIS process


def _unavailable(backend: str, why: str) -> KmsUnavailable:
    return KmsUnavailable(f"{backend}: {why}")


class LocalKms:
    """DEV key service. Delegates to LocalDevelopmentKeyProvider."""

    def __init__(self, master_secret: str) -> None:
        self._p = LocalDevelopmentKeyProvider(hashlib.sha256(master_secret.encode()).digest())
        self.label = self._p.label

    def current_version(self) -> int:
        return self._p.current_version()

    def wrap(self, dek: bytes, aad: bytes) -> WrappedKey:
        return self._p.wrap(dek, aad)

    def unwrap(self, wk: WrappedKey, aad: bytes) -> bytes:
        return self._p.unwrap(wk, aad)

    def rotate(self) -> int:
        return self._p.rotate()

    def status(self) -> KmsStatus:
        return KmsStatus("local_dev", True, "development key provider (KEK derived from MASTER_SECRET)", False)

    def selftest(self) -> KmsStatus:
        _roundtrip(self, "local_dev")
        return KmsStatus("local_dev", True, "round trip ok (development key provider)", False, True)


def _roundtrip(provider: KeyProvider, backend: str) -> None:
    dek, aad = os.urandom(32), b"dek|selftest|1"
    try:
        wk = provider.wrap(dek, aad)
        if provider.unwrap(wk, aad) != dek:
            raise KmsUnavailable(f"{backend}: round trip returned a different key")
        try:                                   # the context binding must actually be enforced
            provider.unwrap(wk, b"dek|other|1")
        except KeyError_:
            return
        raise KmsUnavailable(f"{backend}: wrapped key opened under a different context (binding not enforced)")
    except KmsUnavailable:
        raise
    except KeyError_ as exc:
        raise KmsUnavailable(f"{backend}: round trip failed ({type(exc).__name__})") from exc


def _ctx(aad: bytes) -> dict[str, str]:
    return {"app": "secureshare-dek", "aad": hashlib.sha256(aad).hexdigest()}


class AwsKms:
    """AWS KMS (symmetric key). `client` is injectable for tests; otherwise boto3 is imported lazily."""

    label = "AWS KMS"

    def __init__(self, key_id: str, region: str | None = None, client: Any | None = None) -> None:
        if not key_id:
            raise _unavailable("aws", "KMS_AWS_KEY_ID is not set")
        self._key_id = key_id
        self._region = region
        self._client = client
        if client is None:
            try:
                import boto3  # type: ignore[import-not-found]
            except ImportError as exc:
                raise _unavailable("aws", "boto3 is not installed (pip install -r requirements-cloud.txt)") from exc
            session = boto3.session.Session()
            if session.get_credentials() is None:
                raise _unavailable("aws", "no AWS credentials available")
            self._client = session.client("kms", region_name=region)

    def current_version(self) -> int:
        return 1                                   # AWS rotates the backing key material itself, transparently

    def wrap(self, dek: bytes, aad: bytes) -> WrappedKey:
        try:
            r = self._client.encrypt(KeyId=self._key_id, Plaintext=dek, EncryptionContext=_ctx(aad))
            blob = r["CiphertextBlob"]
        except Exception as exc:                   # noqa: BLE001 - botocore raises many types
            raise _unavailable("aws", f"encrypt failed ({type(exc).__name__})") from exc
        return WrappedKey(bytes(blob), 1, "AWS-KMS")

    def unwrap(self, wk: WrappedKey, aad: bytes) -> bytes:
        try:
            r = self._client.decrypt(CiphertextBlob=wk.wrapped, KeyId=self._key_id, EncryptionContext=_ctx(aad))
            return bytes(r["Plaintext"])
        except Exception as exc:                   # noqa: BLE001
            resp = getattr(exc, "response", None)
            code = (resp.get("Error") if isinstance(resp, dict) else None) or {}
            if code.get("Code") in ("InvalidCiphertextException", "IncorrectKeyException", "AccessDeniedException"):
                raise KeyError_("unwrap failed") from exc      # wrong context / wrong key: a key error, not an outage
            raise _unavailable("aws", f"decrypt failed ({type(exc).__name__})") from exc

    def status(self) -> KmsStatus:
        return KmsStatus("aws", True, f"AWS KMS key configured (region {self._region or 'default'}); not live-verified",
                         True)

    def selftest(self) -> KmsStatus:
        _roundtrip(self, "aws")
        return KmsStatus("aws", True, "round trip ok against AWS KMS", True, True)


Transport = Callable[[str, str, dict[str, str], bytes | None], tuple[int, str]]


def _urllib_transport(timeout: float) -> Transport:
    def call(method: str, url: str, headers: dict[str, str], body: bytes | None) -> tuple[int, str]:
        req = urllib.request.Request(url, data=body, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:      # noqa: S310 - scheme checked in __init__
                return r.status, r.read(1_000_000).decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            return e.code, e.read(10_000).decode("utf-8", "replace")
    return call


class VaultTransitKms:
    """HashiCorp Vault Transit. The transit key must be `derived=true`; the AAD is passed as `context`."""

    label = "HashiCorp Vault Transit"

    def __init__(self, addr: str, token: str, key_name: str, *, mount: str = "transit", namespace: str = "",
                 timeout: float = 5.0, transport: Transport | None = None) -> None:
        if not (addr and token and key_name):
            raise _unavailable("vault", "VAULT_ADDR, VAULT_TOKEN and VAULT_TRANSIT_KEY must all be set")
        parts = urllib.parse.urlsplit(addr)
        local = parts.hostname in ("localhost", "127.0.0.1", "::1")
        if parts.scheme != "https" and not (parts.scheme == "http" and local):
            raise _unavailable("vault", "VAULT_ADDR must be https:// (http only for localhost)")
        self._base = addr.rstrip("/")
        self._key, self._mount = key_name, mount.strip("/")
        self._headers = {"X-Vault-Token": token, "Content-Type": "application/json", "Accept": "application/json"}
        if namespace:
            self._headers["X-Vault-Namespace"] = namespace
        self._tx = transport or _urllib_transport(timeout)

    def _call(self, op: str, payload: dict[str, str]) -> dict[str, Any]:
        url = f"{self._base}/v1/{self._mount}/{op}/{urllib.parse.quote(self._key, safe='')}"
        try:
            status, text = self._tx("POST", url, self._headers, json.dumps(payload).encode())
        except Exception as exc:                   # noqa: BLE001 - network errors
            raise _unavailable("vault", f"request failed ({type(exc).__name__})") from exc
        if status in (400, 403):                   # bad context / ciphertext / policy: key error, not an outage
            raise KeyError_(f"vault rejected the {op} request")
        if status != 200:
            raise _unavailable("vault", f"HTTP {status}")
        try:
            return json.loads(text)["data"]
        except (ValueError, KeyError, TypeError) as exc:
            raise _unavailable("vault", "unexpected response") from exc

    def current_version(self) -> int:
        return 1

    def wrap(self, dek: bytes, aad: bytes) -> WrappedKey:
        data = self._call("encrypt", {"plaintext": base64.b64encode(dek).decode(),
                                      "context": base64.b64encode(aad).decode()})
        ct = str(data.get("ciphertext", ""))
        if not ct.startswith("vault:v"):
            raise _unavailable("vault", "unexpected ciphertext format")
        try:
            version = int(ct.split(":", 2)[1][1:])
        except ValueError:
            version = 1
        return WrappedKey(ct.encode(), version, "VAULT-TRANSIT")

    def unwrap(self, wk: WrappedKey, aad: bytes) -> bytes:
        data = self._call("decrypt", {"ciphertext": wk.wrapped.decode(),
                                      "context": base64.b64encode(aad).decode()})
        try:
            return base64.b64decode(str(data["plaintext"]), validate=True)
        except (KeyError, ValueError) as exc:
            raise _unavailable("vault", "unexpected plaintext format") from exc

    def status(self) -> KmsStatus:
        return KmsStatus("vault", True, f"Vault Transit key {self._key!r} configured; not live-verified", True)

    def selftest(self) -> KmsStatus:
        _roundtrip(self, "vault")
        return KmsStatus("vault", True, "round trip ok against Vault Transit", True, True)


def build_kms(settings) -> KeyProvider:  # noqa: ANN001
    """Return the configured key provider, or raise KmsUnavailable (PROVIDER_UNAVAILABLE)."""
    backend = settings.kms_backend
    if backend == "local_dev":
        return LocalKms(settings.master_secret)  # type: ignore[return-value]
    if backend == "aws":
        return AwsKms(getattr(settings, "kms_aws_key_id", ""), getattr(settings, "kms_aws_region", None) or None)  # type: ignore[return-value]
    if backend == "vault":
        token = getattr(settings, "vault_token", "")
        token = token.get_secret_value() if hasattr(token, "get_secret_value") else token
        return VaultTransitKms(getattr(settings, "vault_addr", ""), token, getattr(settings, "vault_transit_key", ""),
                               mount=getattr(settings, "vault_transit_mount", "transit"),
                               namespace=getattr(settings, "vault_namespace", ""),
                               timeout=float(getattr(settings, "vault_timeout_seconds", 5)))  # type: ignore[return-value]
    raise _unavailable(backend, "this key backend is not implemented in this release (use local_dev, aws or vault)")


def kms_status(settings) -> KmsStatus:  # noqa: ANN001
    """Configuration-only status for health pages. Never raises, never touches the network."""
    try:
        return build_kms(settings).status()  # type: ignore[attr-defined]
    except KmsUnavailable as exc:
        return KmsStatus(settings.kms_backend, False, f"{PROVIDER_UNAVAILABLE}: {exc}", False)
