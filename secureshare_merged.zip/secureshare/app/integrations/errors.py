"""Failure vocabulary shared by every delivery provider (email, SMS).

`reason` is a short machine-readable category that is safe to store in audit events and logs. It
never contains credentials, message bodies or one-time codes.
"""
from __future__ import annotations

# Categories (kept as plain strings so they serialise into audit details unchanged).
AUTH = "auth_failed"                  # provider rejected our credentials -> operator must fix config
CONFIG = "misconfigured"              # missing/invalid configuration detected before any network call
TIMEOUT = "timeout"
NETWORK = "network_error"
RATE_LIMITED = "provider_rate_limited"
RECIPIENT = "recipient_rejected"      # bad / unreachable / unverified destination
UNAVAILABLE = "provider_unavailable"  # 5xx, connection refused, server disconnected
REJECTED = "provider_rejected"        # any other refusal


class DeliveryFailure(Exception):
    """A provider could not deliver a message. Subclassed per channel."""

    def __init__(self, reason: str, message: str = "") -> None:
        super().__init__(message or reason)
        self.reason = reason


class ProviderConfigError(Exception):
    """A provider is mis-configured or not configured at all."""
