"""StateStore: short-lived shared state (rate limits, OTP attempts, lockouts).
InMemoryStateStore = single-process DEV store (LITE mode). RedisStateStore plugs in for FULL mode."""
from __future__ import annotations

import json
import threading
import time
from typing import Any, Callable, Protocol


class StateStore(Protocol):
    def incr(self, key: str, ttl: float) -> int: ...
    def ttl(self, key: str) -> float: ...
    def get(self, key: str) -> Any | None: ...
    def set(self, key: str, value: Any, ttl: float) -> None: ...
    def delete(self, key: str) -> None: ...


class InMemoryStateStore:
    label = "DEV: in-memory state (single process; not for multi-worker production)"

    def __init__(self, clock: Callable[[], float] = time.monotonic) -> None:
        self._d: dict[str, tuple[Any, float]] = {}
        self._lock = threading.Lock()
        self._clock = clock

    def clear(self) -> None:
        """Drop all keys (used by tests so throttling state cannot leak between cases)."""
        with self._lock:
            self._d.clear()

    def _live(self, key: str) -> tuple[Any, float] | None:
        item = self._d.get(key)
        if item and item[1] <= self._clock():
            del self._d[key]
            return None
        return item

    def incr(self, key: str, ttl: float) -> int:
        """Atomic increment; the TTL is set only when the key is created (fixed window)."""
        with self._lock:
            item = self._live(key)
            if item is None:
                self._d[key] = (1, self._clock() + ttl)
                return 1
            self._d[key] = (item[0] + 1, item[1])
            return item[0] + 1

    def ttl(self, key: str) -> float:
        with self._lock:
            item = self._live(key)
            return 0.0 if item is None else max(item[1] - self._clock(), 0.0)

    def get(self, key: str) -> Any | None:
        with self._lock:
            item = self._live(key)
            return None if item is None else item[0]

    def set(self, key: str, value: Any, ttl: float) -> None:
        with self._lock:
            self._d[key] = (value, self._clock() + ttl)

    def delete(self, key: str) -> None:
        with self._lock:
            self._d.pop(key, None)


class RedisStateStore:
    """Shared state for multi-worker deployments (FULL mode). Values are JSON; every key gets a TTL.

    Uses the synchronous redis-py client (calls are sub-millisecond on a local/LAN Redis). The
    client is injected so tests can use a fake; `from_url` builds the real one.
    """

    def __init__(self, client: Any, prefix: str = "ss:") -> None:
        self._r = client
        self._p = prefix
        self.label = "Redis state (shared across workers)"

    @classmethod
    def from_url(cls, url: str, prefix: str = "ss:") -> "RedisStateStore":
        import redis                                   # optional dependency: requirements-redis.txt
        client = redis.Redis.from_url(url, socket_timeout=2, socket_connect_timeout=2,
                                      decode_responses=True)
        client.ping()                                  # fail fast at startup, not on first request
        return cls(client, prefix)

    def _k(self, key: str) -> str:
        return self._p + key

    @staticmethod
    def _px(ttl: float) -> int:
        return max(int(ttl * 1000), 1)

    def incr(self, key: str, ttl: float) -> int:
        k = self._k(key)
        n = int(self._r.incr(k))
        # Fixed window: TTL only when the counter is created. The ttl==-1 check heals a counter
        # whose creator died between INCR and PEXPIRE, which would otherwise never expire.
        if n == 1 or self._r.pttl(k) == -1:
            self._r.pexpire(k, self._px(ttl))
        return n

    def ttl(self, key: str) -> float:
        ms = self._r.pttl(self._k(key))
        return 0.0 if ms is None or ms < 0 else ms / 1000.0

    def get(self, key: str) -> Any | None:
        raw = self._r.get(self._k(key))
        if raw is None:
            return None
        try:
            return json.loads(raw)
        except (TypeError, ValueError):
            return raw

    def set(self, key: str, value: Any, ttl: float) -> None:
        self._r.set(self._k(key), json.dumps(value), px=self._px(ttl))

    def delete(self, key: str) -> None:
        self._r.delete(self._k(key))


_global_state_store: StateStore | None = None


def build_state_store(settings: Any) -> StateStore:
    """FULL mode + REDIS_URL -> Redis. In production an unreachable Redis is a startup error
    (silently using per-process memory would make rate limits and OTP attempt counters
    per-worker, i.e. bypassable). In development it falls back with a warning."""
    if settings.redis_url and settings.app_mode == "full":
        try:
            return RedisStateStore.from_url(settings.redis_url)
        except Exception as exc:                       # ImportError, connection refused, auth...
            if settings.is_production:
                raise RuntimeError(f"Redis is required in production but unavailable: {type(exc).__name__}") from None
            import logging
            logging.getLogger("secureshare.state").warning(
                "redis_unavailable_using_memory error=%s", type(exc).__name__)
    return InMemoryStateStore()


def get_state_store() -> StateStore:
    global _global_state_store
    if _global_state_store is None:
        from app.config.settings import get_settings
        _global_state_store = build_state_store(get_settings())
    return _global_state_store
