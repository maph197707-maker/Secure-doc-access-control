"""Email delivery for one-time codes: EmailService -> EmailProvider -> SmtpEmailProvider.

The only production provider is SMTP (Gmail by default: smtp.gmail.com, 587 + STARTTLS or 465 + SSL,
authenticated with an App Password). A send either succeeds (the SMTP server accepted the message) or
raises EmailDeliveryError with a categorised `reason`; nothing ever pretends a message was sent.
Test doubles live under tests/support and are never selected from configuration. Stdlib only.
"""
from __future__ import annotations

import re
import smtplib
import socket
import ssl
from abc import ABC, abstractmethod
from email.message import EmailMessage
from email.utils import formataddr
from typing import Callable

from app.integrations import errors as E

_ADDR = re.compile(r"^[^@\s\r\n<>]+@[^@\s\r\n<>]+\.[^@\s\r\n<>]+$")


class EmailDeliveryError(E.DeliveryFailure):
    """The message could not be sent (see `.reason`)."""


class EmailConfigError(E.ProviderConfigError):
    """Email is not configured (missing SMTP settings)."""


def mask_email(addr: str) -> str:
    local, _, domain = addr.partition("@")
    return f"{local[:1]}{'*' * max(len(local) - 1, 2)}@{domain}"


def valid_address(addr: str) -> bool:
    return bool(addr) and len(addr) <= 320 and bool(_ADDR.match(addr))


class EmailProvider(ABC):
    name = "base"

    @abstractmethod
    def send(self, msg: EmailMessage) -> None:
        """Deliver one message or raise EmailDeliveryError."""


class SmtpEmailProvider(EmailProvider):
    name = "smtp"

    def __init__(self, host: str, port: int, user: str, password: str, *, security: str = "starttls",
                 timeout: int = 10, factory: Callable[..., smtplib.SMTP] | None = None) -> None:
        if not (host and user and password):
            raise EmailConfigError("SMTP_HOST, SMTP_USER and SMTP_PASSWORD are required.")
        if security not in ("starttls", "ssl"):
            raise EmailConfigError("SMTP_SECURITY must be 'starttls' or 'ssl'.")
        self.host, self.port, self.user = host, port, user
        self._password = password.replace(" ", "")      # Google shows App Passwords in 4-char groups
        self.security, self.timeout = security, timeout
        # `factory` is the injection seam for tests (a fake SMTP class); production uses smtplib.
        self._factory = factory or (smtplib.SMTP_SSL if security == "ssl" else smtplib.SMTP)

    def send(self, msg: EmailMessage) -> None:
        try:
            kwargs = {"timeout": self.timeout}
            if self.security == "ssl" and self._factory is smtplib.SMTP_SSL:
                kwargs["context"] = ssl.create_default_context()
            with self._factory(self.host, self.port, **kwargs) as s:
                if self.security == "starttls":
                    s.starttls(context=ssl.create_default_context())
                s.login(self.user, self._password)
                refused = s.send_message(msg)
                if refused:                               # some (here: the only) recipient refused
                    raise EmailDeliveryError(E.RECIPIENT, "recipient refused")
        except EmailDeliveryError:
            raise
        except smtplib.SMTPAuthenticationError:
            raise EmailDeliveryError(E.AUTH, "smtp authentication failed") from None
        except (smtplib.SMTPRecipientsRefused, smtplib.SMTPSenderRefused) as exc:
            raise EmailDeliveryError(E.RECIPIENT if isinstance(exc, smtplib.SMTPRecipientsRefused) else E.CONFIG,
                                     type(exc).__name__) from None
        except smtplib.SMTPResponseException as exc:
            code = getattr(exc, "smtp_code", 0)
            text = str(exc).lower()
            reason = (E.RATE_LIMITED if "limit" in text or "too many" in text
                      else E.UNAVAILABLE if 400 <= code < 500 else E.REJECTED)
            raise EmailDeliveryError(reason, f"smtp {code}") from None
        except (TimeoutError, socket.timeout):
            raise EmailDeliveryError(E.TIMEOUT, "smtp timeout") from None
        except (smtplib.SMTPException, ssl.SSLError, OSError) as exc:
            raise EmailDeliveryError(E.UNAVAILABLE if isinstance(exc, smtplib.SMTPException) else E.NETWORK,
                                     type(exc).__name__) from None


class EmailService:
    def __init__(self, provider: EmailProvider, from_addr: str, from_name: str = "SecureShare") -> None:
        self.provider, self.from_addr, self.from_name = provider, from_addr, from_name

    @classmethod
    def from_settings(cls, st=None) -> "EmailService":
        if st is None:
            from app.config.settings import get_settings
            st = get_settings()
        if not st.email_configured:
            raise EmailConfigError("SMTP is not configured (SMTP_HOST, SMTP_USER, SMTP_PASSWORD).")
        provider = SmtpEmailProvider(st.smtp_host, st.smtp_port, st.smtp_user,
                                     st.smtp_password.get_secret_value(), security=st.smtp_security,
                                     timeout=st.smtp_timeout_seconds)
        return cls(provider, st.email_from_address, st.email_from_name)

    def send_otp(self, to: str, code: str, minutes: int = 10) -> None:
        if not valid_address(to):
            raise EmailDeliveryError(E.RECIPIENT, "invalid recipient address")
        msg = EmailMessage()
        msg["From"] = formataddr((self.from_name, self.from_addr))
        msg["To"] = to
        msg["Subject"] = "Your SecureShare verification code"
        msg.set_content(f"Your SecureShare verification code is {code}.\n"
                        f"It expires in {minutes} minutes and can be used once.\n"
                        "If you did not request it, you can ignore this email.")
        self.provider.send(msg)

    def send_password_reset(self, to: str, link: str, minutes: int = 60) -> None:
        if not valid_address(to):
            raise EmailDeliveryError(E.RECIPIENT, "invalid recipient address")
        msg = EmailMessage()
        msg["From"] = formataddr((self.from_name, self.from_addr))
        msg["To"] = to
        msg["Subject"] = "Reset your SecureShare password"
        msg.set_content("We received a request to reset your SecureShare password.\n\n"
                        f"Open this link to choose a new one (valid for {minutes} minutes, single use):\n{link}\n\n"
                        "If you did not request this, you can ignore this email; your password is unchanged.")
        self.provider.send(msg)
