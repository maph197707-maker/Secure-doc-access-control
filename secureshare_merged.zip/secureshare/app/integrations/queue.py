"""Job queue with an honest synchronous fallback.

If `use_celery` is on AND celery imports, work is sent to the broker and the result says QUEUED.
Otherwise the task runs inline and the result says EXECUTED_SYNC. QUEUED is never reported for work
that actually ran inline, and EXECUTED_SYNC is never reported for work that was only queued.
"""
from __future__ import annotations

import importlib
from dataclasses import dataclass
from typing import Any, Callable

QUEUED, EXECUTED_SYNC, FAILED = "QUEUED", "EXECUTED_SYNC", "FAILED"

TASKS: dict[str, str] = {   # public name -> "module:function"
    "document.extract_text": "app.workers.tasks.document_tasks:extract_text",
    "notification.build": "app.workers.tasks.notification_tasks:build",
    "maintenance.cleanup_temp": "app.workers.tasks.maintenance_tasks:cleanup_temp_dir",
    "audit.verify": "app.workers.tasks.audit_tasks:verify",
    "alert.detect": "app.workers.tasks.alert_tasks:detect_threats",
}


@dataclass(frozen=True)
class JobResult:
    status: str
    mode: str                 # "celery" | "inline"
    result: Any = None
    error: str = ""


def resolve(name: str) -> Callable[..., Any]:
    if name not in TASKS:
        raise KeyError(f"unknown task {name!r}")
    mod, _, fn = TASKS[name].partition(":")
    return getattr(importlib.import_module(mod), fn)


class QueueService:
    def __init__(self, use_celery: bool = False) -> None:
        self._celery = None
        if use_celery:
            try:
                from app.workers.celery_app import celery_app
                self._celery = celery_app
            except Exception:  # noqa: BLE001 - celery/redis missing -> fall back, and say so
                self._celery = None

    @property
    def mode(self) -> str:
        return "celery" if self._celery is not None else "inline"

    def enqueue(self, name: str, *args: Any, **kwargs: Any) -> JobResult:
        fn = resolve(name)
        if self._celery is not None:
            try:
                self._celery.send_task(name, args=args, kwargs=kwargs)
                return JobResult(QUEUED, "celery")
            except Exception as exc:  # noqa: BLE001 - broker down
                return JobResult(FAILED, "celery", error=f"broker unavailable: {exc.__class__.__name__}")
        try:
            return JobResult(EXECUTED_SYNC, "inline", result=fn(*args, **kwargs))
        except Exception as exc:  # noqa: BLE001
            return JobResult(FAILED, "inline", error=exc.__class__.__name__)
