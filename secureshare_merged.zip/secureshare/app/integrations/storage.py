"""Storage abstraction: StorageProvider protocol, LocalStorageProvider, S3StorageProvider.

All document bytes (already encrypted by the caller) go through StorageService; no other
module should touch the storage directory directly. Object keys are internal random names
(see app.security.path_security.new_internal_name), never user-supplied filenames.

S3StorageProvider needs boto3 and credentials. Without them every operation raises
ProviderUnavailable - it never pretends to have stored anything.
"""
from __future__ import annotations

import contextlib
import os
import tempfile
from pathlib import Path
from typing import Protocol

from app.security.path_security import PathViolation, safe_join

PROVIDER_UNAVAILABLE = "PROVIDER_UNAVAILABLE"


class StorageError(Exception):
    """Generic storage failure (missing object, I/O error, illegal key)."""


class ProviderUnavailable(StorageError):
    """Provider is not configured or its SDK/credentials are missing."""

    code = PROVIDER_UNAVAILABLE


class StorageProvider(Protocol):
    name: str

    def save(self, key: str, data: bytes) -> int: ...
    def read(self, key: str) -> bytes: ...
    def delete(self, key: str) -> bool: ...
    def exists(self, key: str) -> bool: ...
    def size(self, key: str) -> int: ...


class LocalStorageProvider:
    """Filesystem storage outside any web-served directory.

    Writes are atomic (temp file + os.replace), files are 0600, symlinks and traversal are
    refused via safe_join.
    """

    name = "local"

    def __init__(self, root: Path) -> None:
        self._root = Path(root)
        self._root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        try:
            return safe_join(self._root, key)
        except PathViolation as exc:
            raise StorageError(str(exc)) from exc

    def save(self, key: str, data: bytes) -> int:
        target = self._path(key)
        fd, tmp = tempfile.mkstemp(dir=self._root, prefix=".tmp-")
        try:
            with os.fdopen(fd, "wb") as fh:
                fh.write(data)
                fh.flush()
                os.fsync(fh.fileno())
            os.chmod(tmp, 0o600)
            os.replace(tmp, target)
        except OSError as exc:
            with contextlib.suppress(OSError):
                os.unlink(tmp)
            raise StorageError(f"write failed: {exc.__class__.__name__}") from exc
        return len(data)

    def read(self, key: str) -> bytes:
        try:
            return self._path(key).read_bytes()
        except FileNotFoundError as exc:
            raise StorageError("object not found") from exc
        except OSError as exc:
            raise StorageError(f"read failed: {exc.__class__.__name__}") from exc

    def delete(self, key: str) -> bool:
        try:
            self._path(key).unlink()
            return True
        except FileNotFoundError:
            return False
        except OSError as exc:
            raise StorageError(f"delete failed: {exc.__class__.__name__}") from exc

    def exists(self, key: str) -> bool:
        return self._path(key).is_file()

    def size(self, key: str) -> int:
        try:
            return self._path(key).stat().st_size
        except FileNotFoundError as exc:
            raise StorageError("object not found") from exc


class S3StorageProvider:
    """S3-compatible storage. Requires boto3 + credentials; otherwise PROVIDER_UNAVAILABLE.

    UNVERIFIED against a live bucket in this repository's test environment.
    """

    name = "s3"

    def __init__(self, bucket: str, region: str | None = None, endpoint_url: str | None = None,
                 prefix: str = "", client: object | None = None) -> None:
        self._bucket, self._prefix = bucket, prefix.strip("/")
        self._client = client
        if client is None:
            if not bucket:
                raise ProviderUnavailable("S3 bucket not configured")
            try:
                import boto3  # type: ignore[import-not-found]
            except ImportError as exc:
                raise ProviderUnavailable("boto3 not installed") from exc
            session = boto3.session.Session()
            if session.get_credentials() is None:
                raise ProviderUnavailable("no AWS credentials available")
            self._client = session.client("s3", region_name=region, endpoint_url=endpoint_url)

    def _k(self, key: str) -> str:
        if not key or "/" in key or "\\" in key or key in (".", "..") or "\x00" in key:
            raise StorageError("illegal storage key")
        return f"{self._prefix}/{key}" if self._prefix else key

    def save(self, key: str, data: bytes) -> int:
        try:
            self._client.put_object(Bucket=self._bucket, Key=self._k(key), Body=data,  # type: ignore[attr-defined]
                                    ServerSideEncryption="AES256")
        except Exception as exc:  # noqa: BLE001 - boto raises many types
            raise StorageError(f"s3 write failed: {exc.__class__.__name__}") from exc
        return len(data)

    def read(self, key: str) -> bytes:
        try:
            return self._client.get_object(Bucket=self._bucket, Key=self._k(key))["Body"].read()  # type: ignore[attr-defined]
        except Exception as exc:  # noqa: BLE001
            raise StorageError(f"s3 read failed: {exc.__class__.__name__}") from exc

    def delete(self, key: str) -> bool:
        existed = self.exists(key)
        try:
            self._client.delete_object(Bucket=self._bucket, Key=self._k(key))  # type: ignore[attr-defined]
        except Exception as exc:  # noqa: BLE001
            raise StorageError(f"s3 delete failed: {exc.__class__.__name__}") from exc
        return existed

    def exists(self, key: str) -> bool:
        try:
            self._client.head_object(Bucket=self._bucket, Key=self._k(key))  # type: ignore[attr-defined]
            return True
        except Exception:  # noqa: BLE001 - 404 and transport errors both mean "not confirmed present"
            return False

    def size(self, key: str) -> int:
        try:
            return int(self._client.head_object(Bucket=self._bucket, Key=self._k(key))["ContentLength"])  # type: ignore[attr-defined]
        except Exception as exc:  # noqa: BLE001
            raise StorageError(f"s3 size failed: {exc.__class__.__name__}") from exc


class StorageService:
    """Single entry point used by document code."""

    def __init__(self, provider: StorageProvider) -> None:
        self.provider = provider

    def save(self, key: str, data: bytes) -> int:
        return self.provider.save(key, data)

    def read(self, key: str) -> bytes:
        return self.provider.read(key)

    def delete(self, key: str) -> bool:
        return self.provider.delete(key)

    def exists(self, key: str) -> bool:
        return self.provider.exists(key)

    def size(self, key: str) -> int:
        return self.provider.size(key)


_S3_CACHE: dict[tuple, "StorageService"] = {}


def build_storage_service(settings) -> StorageService:  # noqa: ANN001 - Settings imported lazily by callers
    if settings.storage_backend == "s3":
        cfg = (getattr(settings, "s3_bucket", ""), getattr(settings, "s3_region", None),
               getattr(settings, "s3_endpoint_url", None), getattr(settings, "s3_prefix", ""))
        if cfg not in _S3_CACHE:  # one boto3 client per configuration, not one per request
            _S3_CACHE[cfg] = StorageService(S3StorageProvider(
                bucket=cfg[0], region=cfg[1], endpoint_url=cfg[2], prefix=cfg[3]))
        return _S3_CACHE[cfg]
    return StorageService(LocalStorageProvider(settings.storage_root))
