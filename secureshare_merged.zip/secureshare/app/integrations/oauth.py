"""OAuth 2.0 authorization-code + PKCE (S256) for Google and Microsoft. No third-party package.

Security properties implemented here (all unit-tested with a fake transport):
- single-use `state` bound to a server-side record (CSRF / login-fixation defence), 10-minute TTL
- PKCE verifier kept server-side only; challenge = BASE64URL(SHA256(verifier))
- `nonce` is generated and checked against the ID token claim when one is returned
- the profile is accepted ONLY if the provider says the email is verified (blocks account takeover
  through an unverified-email IdP account)
- `link_decision` never auto-links an OAuth identity to an existing local account unless the user
  is already signed in as that account (or the email is verified AND the account has no password
  login disabled flag) - otherwise it demands explicit confirmation.
Live provider calls are UNVERIFIED in this sandbox (no network, no client credentials)."""
from __future__ import annotations

import base64
import hashlib
import json
import secrets
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable

PROVIDER_UNAVAILABLE = "PROVIDER_UNAVAILABLE"
PROVIDERS = ("google", "microsoft")
STATE_TTL = 600.0
MS_CONSUMER_TENANT = "9188040d-6c67-4c5b-b112-36a304b66dad"

ENDPOINTS = {
    "google": {"auth": "https://accounts.google.com/o/oauth2/v2/auth",
               "token": "https://oauth2.googleapis.com/token",
               "userinfo": "https://openidconnect.googleapis.com/v1/userinfo",
               "scope": "openid email profile"},
    "microsoft": {"auth": "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
                  "token": "https://login.microsoftonline.com/common/oauth2/v2.0/token",
                  "userinfo": "https://graph.microsoft.com/oidc/userinfo",
                  "scope": "openid email profile"},
}

Transport = Callable[[str, str, dict[str, str], bytes | None], tuple[int, str]]   # method,url,headers,body -> status,text


class OAuthError(Exception):
    """Message is safe to show; never contains tokens or secrets."""


def provider_status(name: str, client_id: str = "", client_secret: str = "") -> str:
    if name not in PROVIDERS:
        raise ValueError(f"unknown provider {name!r}")
    return "CONFIGURED" if client_id and client_secret else PROVIDER_UNAVAILABLE


def _b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def pkce_challenge(verifier: str) -> str:
    return _b64u(hashlib.sha256(verifier.encode()).digest())


def _urllib_transport(method: str, url: str, headers: dict[str, str], body: bytes | None) -> tuple[int, str]:
    req = urllib.request.Request(url, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as r:      # noqa: S310 - https endpoints only
            return r.status, r.read(1_000_000).decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read(10_000).decode("utf-8", "replace")


def default_transport() -> Transport:
    """Indirection so tests can swap the network for a fake identity provider."""
    return _urllib_transport


@dataclass(frozen=True)
class Profile:
    provider: str
    subject: str
    email: str
    email_verified: bool
    name: str = ""


class OAuthClient:
    def __init__(self, provider: str, client_id: str, client_secret: str, redirect_uri: str,
                 state_store, transport: Transport = _urllib_transport) -> None:
        if provider_status(provider, client_id, client_secret) != "CONFIGURED":
            raise OAuthError("This sign-in provider is not configured.")
        if not redirect_uri.startswith(("https://", "http://localhost", "http://127.0.0.1")):
            raise OAuthError("redirect_uri must be https (http only for localhost).")
        self.p, self.cid, self.secret, self.redirect = provider, client_id, client_secret, redirect_uri
        self.store, self.tx, self.ep = state_store, transport, ENDPOINTS[provider]

    def authorize_url(self, next_path: str = "/dashboard") -> str:
        state, verifier, nonce = secrets.token_urlsafe(32), secrets.token_urlsafe(64), secrets.token_urlsafe(16)
        if not next_path.startswith("/") or next_path.startswith("//"):
            next_path = "/dashboard"                           # open-redirect guard
        self.store.set(f"oauth:{state}", {"p": self.p, "v": verifier, "n": nonce, "next": next_path}, STATE_TTL)
        q = urllib.parse.urlencode({
            "client_id": self.cid, "redirect_uri": self.redirect, "response_type": "code",
            "scope": self.ep["scope"], "state": state, "nonce": nonce,
            "code_challenge": pkce_challenge(verifier), "code_challenge_method": "S256"})
        return f"{self.ep['auth']}?{q}"

    def complete(self, state: str, code: str) -> tuple[Profile, str]:
        """Returns (profile, next_path). State is consumed on first use even if the exchange fails."""
        rec = self.store.get(f"oauth:{state}") if state else None
        self.store.delete(f"oauth:{state}")
        if not rec or rec.get("p") != self.p:
            raise OAuthError("Sign-in session expired or invalid. Please try again.")
        body = urllib.parse.urlencode({
            "grant_type": "authorization_code", "code": code, "redirect_uri": self.redirect,
            "client_id": self.cid, "client_secret": self.secret, "code_verifier": rec["v"]}).encode()
        st, text = self.tx("POST", self.ep["token"], {"Content-Type": "application/x-www-form-urlencoded",
                                                      "Accept": "application/json"}, body)
        if st != 200:
            raise OAuthError("The provider rejected the sign-in.")
        try:
            tok = json.loads(text)
            access = tok["access_token"]
        except (ValueError, KeyError):
            raise OAuthError("Unexpected provider response.") from None
        claims: dict[str, Any] = {}
        if tok.get("id_token"):
            claims = _jwt_claims(tok["id_token"])
            if claims.get("nonce") not in (None, rec["n"]):
                raise OAuthError("Sign-in nonce mismatch.")
            if claims.get("aud") not in (None, self.cid):
                raise OAuthError("Token audience mismatch.")
        st, text = self.tx("GET", self.ep["userinfo"], {"Authorization": f"Bearer {access}", "Accept": "application/json"}, None)
        if st != 200:
            raise OAuthError("Could not read the provider profile.")
        try:
            info = json.loads(text)
        except ValueError:
            raise OAuthError("Unexpected provider response.") from None
        email = str(info.get("email") or "").strip().lower()
        verified = info.get("email_verified")
        verified = verified is True or str(verified).lower() == "true"
        if self.p == "microsoft" and "email_verified" not in info:
            # MS omits it. Personal Microsoft accounts (the consumer tenant) always have a verified address;
            # work/school tenants do not guarantee it, so those stay unverified (never assumed).
            verified = claims.get("tid") == MS_CONSUMER_TENANT or str(claims.get("xms_edov")).lower() in ("1", "true")
        if not info.get("sub") or not email:
            raise OAuthError("The provider did not return an email address.")
        return Profile(self.p, str(info["sub"]), email, verified, str(info.get("name") or "")[:200]), rec["next"]


def _jwt_claims(jwt: str) -> dict[str, Any]:
    """Decode WITHOUT trusting: the token came straight from the token endpoint over TLS in the
    code flow, and is used only for nonce/aud sanity - identity comes from the userinfo call."""
    try:
        seg = jwt.split(".")[1]
        return json.loads(base64.urlsafe_b64decode(seg + "=" * (-len(seg) % 4)))
    except Exception:                                          # noqa: BLE001
        raise OAuthError("Malformed identity token.") from None


def link_decision(profile: Profile, existing_by_identity: bool, existing_by_email: bool,
                  signed_in_as_that_account: bool) -> str:
    """LOGIN | CREATE | LINK | CONFIRM_REQUIRED | REJECT_UNVERIFIED"""
    if existing_by_identity:
        return "LOGIN"
    if not profile.email_verified:
        return "REJECT_UNVERIFIED"
    if existing_by_email:
        return "LINK" if signed_in_as_that_account else "CONFIRM_REQUIRED"
    return "CREATE"
