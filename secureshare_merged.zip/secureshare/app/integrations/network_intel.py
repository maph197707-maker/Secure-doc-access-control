"""IP reputation / geo / VPN intelligence. No external feed is bundled, so every lookup reports
PROVIDER_UNAVAILABLE. Callers must pass network_state through to the PDP unchanged; the PDP never
treats an unavailable lookup as 'clean'. Private/loopback addresses are classified locally."""
from __future__ import annotations

import ipaddress
from dataclasses import dataclass

PROVIDER_UNAVAILABLE = "PROVIDER_UNAVAILABLE"


@dataclass(frozen=True)
class NetworkInfo:
    state: str          # PRIVATE | LOOPBACK | INVALID | PROVIDER_UNAVAILABLE
    detail: str = ""


def lookup(ip: str | None) -> NetworkInfo:
    try:
        a = ipaddress.ip_address(ip or "")
    except ValueError:
        return NetworkInfo("INVALID", "not an IP address")
    if a.is_loopback:
        return NetworkInfo("LOOPBACK")
    if a.is_private:
        return NetworkInfo("PRIVATE")
    return NetworkInfo(PROVIDER_UNAVAILABLE, "no IP-intelligence provider configured")
