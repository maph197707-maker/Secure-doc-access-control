"""Application settings — pydantic-settings v2, loaded once at startup."""
from __future__ import annotations

import os
import secrets
from pathlib import Path
from typing import Literal

from pydantic import Field, SecretStr, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=ROOT / ".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
        # A blank "KEY=" line in .env (as shipped in .env.example) means "use the default",
        # not "parse an empty string" (which crashed bool/int settings at startup).
        env_ignore_empty=True,
    )

    # ── App ──────────────────────────────────────────────────────────────────
    app_name: str = "SecureShare"
    app_env: Literal["dev", "staging", "production"] = "dev"
    app_mode: Literal["lite", "full"] = "lite"
    debug: bool = False
    secret_key: str = Field(default_factory=lambda: secrets.token_hex(32))
    master_secret: str = Field(default_factory=lambda: secrets.token_hex(32))
    public_base_url: str = "http://localhost:8000"
    allowed_hosts: list[str] | str = ["localhost", "127.0.0.1", "0.0.0.0"]
    trusted_origins: list[str] | str = ["http://localhost:8000", "http://127.0.0.1:8000"]
    cookie_secure: bool = False   # True in production
    # Test-suite only: lets the literal token "demo" satisfy CSRF. Off by default (a dev server must verify
    # CSRF like production does) and refused outside APP_ENV=dev by `csrf_demo_token_dev_only`.
    csrf_allow_demo_token: bool = False
    # Guest login ("Continue as guest"): a real, temporary, database-backed account (no email/code needed).
    # On by default in every environment; set GUEST_LOGIN_ENABLED=false to switch it off.
    guest_login_enabled: bool | None = None
    # False (default): sign-up needs no email delivery. The account is active at once and the person
    # verifies email / phone later from /profile. True: sign-up sends an email code first (needs SMTP).
    signup_email_verification_required: bool = False
    cookie_domain: str | None = None

    # ── Database ─────────────────────────────────────────────────────────────
    database_url: str = f"sqlite+aiosqlite:///{ROOT / 'secureshare.db'}"
    db_echo: bool = False
    db_pool_size: int = 5
    db_max_overflow: int = 10

    # ── Redis / State ─────────────────────────────────────────────────────────
    redis_url: str | None = None          # None → InMemoryStateStore

    # ── Storage ───────────────────────────────────────────────────────────────
    storage_backend: Literal["local", "s3"] = "local"
    s3_bucket: str = ""
    s3_region: str | None = None
    s3_endpoint_url: str | None = None
    s3_prefix: str = ""
    storage_root: Path = ROOT / "storage" / "encrypted"
    quarantine_root: Path = ROOT / "storage" / "quarantine"
    temp_root: Path = ROOT / "storage" / "temporary"
    processed_root: Path = ROOT / "storage" / "processed"
    max_upload_bytes: int = 50 * 1024 * 1024  # 50 MB
    allowed_extensions: list[str] | str = [
        "pdf", "docx", "xlsx", "pptx", "txt", "csv", "png", "jpg", "jpeg",
        "zip", "md", "json", "xml", "rtf", "odt", "ods", "odp", "gif", "webp"
    ]

    # ── KMS ───────────────────────────────────────────────────────────────────
    kms_backend: Literal["local_dev", "aws", "vault", "azure", "hsm"] = "local_dev"
    kms_aws_key_id: str = ""            # KMS_BACKEND=aws: key id / ARN / alias (needs boto3 + AWS credentials)
    kms_aws_region: str = ""
    vault_addr: str = ""                # KMS_BACKEND=vault: https://vault.example.com:8200
    vault_token: SecretStr = SecretStr("")
    vault_transit_key: str = ""         # a transit key created with derived=true
    vault_transit_mount: str = "transit"
    vault_namespace: str = ""
    vault_timeout_seconds: int = Field(default=5, ge=1, le=30)
    kms_key_file: Path = ROOT / ".kms_dev_key"
    kms_master_key_env: str = ""  # hex-encoded 32 bytes; auto-generated if empty in dev

    # ── Email (SMTP, e.g. Gmail) ──────────────────────────────────────────────
    # Gmail: smtp.gmail.com, 587 + STARTTLS (or 465 + SSL), an App Password (needs 2-Step Verification).
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_security: Literal["starttls", "ssl"] = "starttls"
    smtp_user: str = ""
    smtp_password: SecretStr = SecretStr("")
    smtp_timeout_seconds: int = Field(default=10, ge=1, le=60)
    email_from: str = ""                 # defaults to SMTP_USER (Gmail rewrites other From addresses)
    email_from_name: str = "SecureShare"

    # ── SMS (Twilio Programmable Messaging) ───────────────────────────────────
    twilio_account_sid: str = ""
    twilio_auth_token: SecretStr = SecretStr("")
    twilio_from_number: str = ""         # E.164 sender number ...
    twilio_messaging_service_sid: str = ""   # ... or a Messaging Service SID (MG...)
    sms_default_country_code: str = "+91"
    sms_timeout_seconds: int = Field(default=10, ge=1, le=60)

    # ── One-time codes (email + SMS) ──────────────────────────────────────────
    otp_ttl_seconds: int = Field(default=600, ge=60, le=3600)
    otp_max_attempts: int = Field(default=5, ge=1, le=10)
    otp_resend_cooldown_seconds: int = Field(default=30, ge=5, le=600)
    otp_max_sends_per_hour: int = Field(default=5, ge=1, le=30)   # per destination address / number

    # ── Malware ───────────────────────────────────────────────────────────────
    malware_backend: Literal["dev", "clamav", "provider_unavailable"] = "dev"
    clamav_host: str = "localhost"
    clamav_port: int = 3310
    # When malware scan is unavailable: "hold" or "allow_with_warning"
    malware_unavailable_policy: Literal["hold", "allow_with_warning"] = "allow_with_warning"
    # ── DLP / document analysis ──────────────────────────────────────────────
    dlp_enabled: bool = True
    # OFF: findings only warn and raise the document's DLP level (the PDP then restricts sharing/download).
    # HIGH / CRITICAL: uploads whose worst finding reaches that level are rejected before anything is stored.
    dlp_block_threshold: Literal["OFF", "HIGH", "CRITICAL"] = "OFF"
    analysis_max_text_chars: int = 1_000_000
    analysis_stored_text_chars: int = 100_000     # redacted text kept for search

    # ── OAuth ─────────────────────────────────────────────────────────────────
    google_client_id: str = ""
    google_client_secret: str = ""
    microsoft_client_id: str = ""
    microsoft_client_secret: str = ""

    # ── Session ───────────────────────────────────────────────────────────────
    session_idle_timeout: int = 1800       # seconds (30 min)
    session_absolute_timeout: int = 86400  # seconds (24 h)
    session_cookie_name: str = "ss_session"

    # ── Rate limiting ─────────────────────────────────────────────────────────
    rate_limit_login: str = "10/minute"
    rate_limit_api: str = "200/minute"
    rate_limit_upload: str = "20/hour"
    rate_limit_share: str = "50/hour"

    # ── MFA ───────────────────────────────────────────────────────────────────
    totp_issuer: str = "SecureShare"
    backup_codes_count: int = 10

    # ── Security score weights ────────────────────────────────────────────────
    security_score_encryption_weight: int = 20
    security_score_access_control_weight: int = 20
    security_score_malware_weight: int = 20
    security_score_dlp_weight: int = 20
    security_score_audit_weight: int = 20

    # ── Logging ───────────────────────────────────────────────────────────────
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"
    log_format: Literal["json", "console"] = "console"

    # ── Task queue ────────────────────────────────────────────────────────────
    task_queue_backend: Literal["inline", "celery"] = "inline"
    use_celery: bool = False              # False -> tasks run inline and are reported as EXECUTED_SYNC
    celery_broker_url: str = "redis://localhost:6379/0"
    celery_result_backend: str = "redis://localhost:6379/0"
    inline_queue_workers: int = 4

    # ── WebAuthn / Passkeys ───────────────────────────────────────────────────
    webauthn_rp_name: str = "SecureShare"
    webauthn_rp_id: str = "localhost"
    webauthn_origin: str = "http://localhost:8000"

    # ── OCR ───────────────────────────────────────────────────────────────────
    ocr_backend: Literal["tesseract", "provider_unavailable"] = "provider_unavailable"
    tesseract_cmd: str = "tesseract"

    # ── Demo ──────────────────────────────────────────────────────────────────
    demo_mode: bool = False
    demo_admin_email: str = "admin@demo.secureshare.local"
    demo_admin_password: str = ""  # auto-generated on seed

    # ── Computed helpers ──────────────────────────────────────────────────────
    @property
    def is_production(self) -> bool:
        return self.app_env == "production"

    @property
    def is_dev(self) -> bool:
        return self.app_env == "dev"

    @property
    def guest_login_active(self) -> bool:
        return True if self.guest_login_enabled is None else bool(self.guest_login_enabled)

    @property
    def google_oauth_configured(self) -> bool:
        return bool(self.google_client_id and self.google_client_secret)

    @property
    def microsoft_oauth_configured(self) -> bool:
        return bool(self.microsoft_client_id and self.microsoft_client_secret)

    @property
    def email_from_address(self) -> str:
        return (self.email_from or self.smtp_user).strip()

    @property
    def email_configured(self) -> bool:
        return bool(self.smtp_host.strip() and self.smtp_user.strip() and self.smtp_password.get_secret_value().strip()
                    and self.email_from_address)

    @property
    def sms_configured(self) -> bool:
        return bool(self.twilio_account_sid.strip() and self.twilio_auth_token.get_secret_value().strip()
                    and (self.twilio_from_number.strip() or self.twilio_messaging_service_sid.strip()))

    @property
    def malware_configured(self) -> bool:
        return self.malware_backend != "provider_unavailable"

    @property
    def ocr_configured(self) -> bool:
        return self.ocr_backend != "provider_unavailable"

    @field_validator("allowed_hosts", "trusted_origins", "allowed_extensions", mode="before")
    @classmethod
    def parse_comma_separated(cls, v: object) -> object:
        if isinstance(v, str):
            v_str = v.strip()
            if v_str.startswith("[") and v_str.endswith("]"):
                import json
                try:
                    return json.loads(v_str)
                except Exception:
                    pass
            return [x.strip() for x in v_str.split(",") if x.strip()]
        return v

    @field_validator("database_url", mode="before")
    @classmethod
    def resolve_sqlite_path(cls, v: str) -> str:
        """Normalise DATABASE_URL so the same value works with the async engine + Alembic:
        sqlite:/// -> sqlite+aiosqlite:///, postgres(ql):// -> postgresql+psycopg://, and make
        SQLite paths absolute. Provider URLs (Supabase / Neon) can be pasted as-is."""
        if v.startswith("sqlite:///"):
            v = "sqlite+aiosqlite:///" + v[len("sqlite:///"):]
        for old in ("postgres://", "postgresql://"):
            if v.startswith(old):
                v = "postgresql+psycopg://" + v[len(old):]
        if v.startswith("sqlite") and ":///" in v:
            prefix, path = v.split("///", 1)
            if not os.path.isabs(path) and not path.startswith(":"):
                return f"{prefix}///{ROOT / path}"
        return v

    @model_validator(mode="after")
    def csrf_demo_token_dev_only(self) -> "Settings":
        if self.csrf_allow_demo_token and not self.is_dev:
            raise ValueError("CSRF_ALLOW_DEMO_TOKEN may only be enabled when APP_ENV=dev (it disables CSRF checking).")
        return self

    @model_validator(mode="after")
    def production_requires_real_email(self) -> "Settings":
        """Only when sign-up itself requires an email code must production have real SMTP."""
        if self.is_production and self.signup_email_verification_required and not self.email_configured:
            raise ValueError("Email delivery is required when APP_ENV=production: set SMTP_HOST, SMTP_USER, "
                             "SMTP_PASSWORD (and optionally EMAIL_FROM).")
        return self

    @model_validator(mode="after")
    def production_requires_stable_secrets(self) -> "Settings":
        """Without stable secrets every restart rotates the KEK (documents become undecryptable)
        and invalidates all sessions; with several workers each would hold a different key."""
        if not self.is_production:
            return self
        problems: list[str] = []
        for name in ("secret_key", "master_secret"):
            value = getattr(self, name)
            if name not in self.model_fields_set or len(value) < 32 or value.startswith("__"):
                problems.append(f"{name.upper()} must be set explicitly to a random value of 32+ characters")
        if not self.cookie_secure:
            problems.append("COOKIE_SECURE must be true (production is served over HTTPS)")
        if problems:
            raise ValueError("Unsafe production configuration: " + "; ".join(problems) + ".")
        return self

    @model_validator(mode="after")
    def dev_placeholder_secrets_become_random(self) -> "Settings":
        """Dev only: an unedited ``__GENERATE__`` placeholder (copied straight from .env.example) is
        replaced by a random per-process value instead of being used literally as a key. Production and
        staging never reach this (production_requires_stable_secrets rejects placeholders first).
        Run ``python -m scripts.doctor`` to write permanent secrets into .env."""
        if self.is_dev:
            for name in ("secret_key", "master_secret"):
                if getattr(self, name).startswith("__"):
                    setattr(self, name, secrets.token_hex(32))
        return self

    @model_validator(mode="after")
    def non_dev_links_must_be_https(self) -> "Settings":
        """Share links carry the access token in the URL, so outside local development they must be
        https:// (TLS terminated by Caddy/nginx/your load balancer). Never silently build http links."""
        if self.is_dev:
            return self
        if "public_base_url" not in self.model_fields_set or not self.public_base_url.lower().startswith("https://"):
            raise ValueError("Unsafe configuration: PUBLIC_BASE_URL must be set explicitly to your https:// origin "
                             "when APP_ENV is not dev (secure links would otherwise be sent over plain http).")
        return self

    @model_validator(mode="after")
    def ensure_storage_dirs(self) -> "Settings":
        """Create storage directories on startup."""
        for d in [self.storage_root, self.quarantine_root, self.temp_root, self.processed_root]:
            d.mkdir(parents=True, exist_ok=True)
        if self.database_url.startswith("sqlite") and ":///" in self.database_url:
            db_path = Path(self.database_url.split(":///", 1)[1])      # e.g. ./data/secureshare.db
            if str(db_path) not in ("", ":memory:"):
                db_path.parent.mkdir(parents=True, exist_ok=True)
        return self


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
