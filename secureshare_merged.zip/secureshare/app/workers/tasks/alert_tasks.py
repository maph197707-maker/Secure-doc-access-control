from __future__ import annotations

from dataclasses import asdict
from datetime import datetime

from app.security.threat_detection import SecEvent, detect


def detect_threats(events: list[dict]) -> list[dict]:
    parsed = [
        SecEvent(
            id=str(e.get("id", f"ev-{i}")),
            kind=str(e.get("kind") or e.get("action") or "LOGIN_FAILED"),
            at=datetime.fromisoformat(e["at"]) if isinstance(e["at"], str) else e["at"],
            user_id=e.get("user_id"),
            ip=e.get("ip"),
            device=e.get("device"),
            target=e.get("target"),
        )
        for i, e in enumerate(events)
    ]
    return [asdict(a) for a in detect(parsed)]
