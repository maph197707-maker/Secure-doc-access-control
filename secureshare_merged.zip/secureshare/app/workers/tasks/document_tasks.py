"""Document processing tasks (pure over bytes; callers persist results)."""
from __future__ import annotations

from app.integrations.ocr import get_ocr_provider


def extract_text(data: bytes, filename: str, mime: str | None = None) -> dict:
    r = get_ocr_provider().extract(data, filename, mime)
    return {"status": r.status, "text": r.text, "engine": r.engine, "detail": r.detail}
