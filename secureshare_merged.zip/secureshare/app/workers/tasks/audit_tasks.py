from __future__ import annotations

from app.services.audit import verify_chain


def verify(records: list[dict]) -> dict:
    r = verify_chain(records)
    return {k: getattr(r, k) for k in r.__dataclass_fields__}
