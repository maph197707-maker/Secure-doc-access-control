from __future__ import annotations

import os
import time
from pathlib import Path


def cleanup_temp_dir(path: str, max_age_seconds: int = 3600) -> dict:
    """Delete regular files older than max_age in a temp directory (no symlink following)."""
    root, removed, kept = Path(path), 0, 0
    if not root.is_dir():
        return {"removed": 0, "kept": 0, "status": "NO_SUCH_DIR"}
    cutoff = time.time() - max_age_seconds
    for p in root.iterdir():
        try:
            if p.is_symlink() or not p.is_file():
                kept += 1
            elif p.stat().st_mtime < cutoff:
                os.unlink(p)
                removed += 1
            else:
                kept += 1
        except OSError:
            kept += 1
    return {"removed": removed, "kept": kept, "status": "OK"}
