"""Builds notification payloads. Messages never contain secrets, OTPs or tokens."""
from __future__ import annotations

_SENSITIVE = ("password", "otp", "token", "secret")


def build(user_id: str, type_: str, title: str, message: str,
          resource_type: str | None = None, resource_id: str | None = None) -> dict:
    if any(w in (title + " " + message).lower() for w in ("otp:", "token=", "password:", "secret=")):
        raise ValueError("notification text must not contain credentials")
    return {"user_id": user_id, "type": type_, "title": title[:200], "message": message,
            "resource_type": resource_type, "resource_id": resource_id, "read": False}
