"""Celery application. Importing this module without celery installed raises ImportError, which
QueueService treats as "use the inline fallback"."""
from __future__ import annotations

import os

from celery import Celery  # type: ignore[import-not-found]

from app.integrations.queue import TASKS, resolve

celery_app = Celery("secureshare",
                    broker=os.environ.get("CELERY_BROKER_URL", "redis://localhost:6379/0"),
                    backend=os.environ.get("CELERY_RESULT_BACKEND", "redis://localhost:6379/0"))
celery_app.conf.update(task_serializer="json", result_serializer="json", accept_content=["json"],
                       task_acks_late=True, task_time_limit=300)

for _name in TASKS:                       # register every task under its public name
    celery_app.task(resolve(_name), name=_name)
