"""Create in-app notifications. Messages never contain secrets, OTPs or keys."""
from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.notification import Notification

DOCUMENT_SHARED = "DOCUMENT_SHARED"
SHARE_UPDATED = "SHARE_UPDATED"
ACCESS_REQUEST = "ACCESS_REQUEST"
ACCESS_APPROVED = "ACCESS_APPROVED"
ACCESS_REJECTED = "ACCESS_REJECTED"
ACCESS_REVOKED = "ACCESS_REVOKED"
MFA_ENABLED = "MFA_ENABLED"
MFA_DISABLED = "MFA_DISABLED"
ACCOUNT_LOCKED = "ACCOUNT_LOCKED"


async def notify(db: AsyncSession, user_id: str, type_: str, title: str, message: str,
                 resource_type: str | None = None, resource_id: str | None = None) -> Notification:
    n = Notification(user_id=user_id, type=type_, title=title[:200], message=message,
                     resource_type=resource_type, resource_id=resource_id, read=False)
    db.add(n)
    await db.flush()
    return n


async def notify_fan_out(db: AsyncSession, user_id: str, type_: str, title: str, message: str,
                         resource_type: str | None = None, resource_id: str | None = None,
                         email_send=None, sms_send=None):
    """Create the in-app row, then deliver by email/SMS according to the user's saved preferences.
    Returns the per-channel outcomes (never raises for delivery problems)."""
    from sqlalchemy import select
    from app.models.user import User
    from app.models.user_preference import UserPreference
    from app.services.notify_fanout import Recipient, fan_out

    user = (await db.execute(select(User).where(User.id == user_id))).scalar_one_or_none()
    if user is None:
        return []
    pref = (await db.execute(select(UserPreference).where(UserPreference.user_id == user_id))).scalar_one_or_none()
    muted = frozenset(getattr(pref, "muted_types", None) or [])
    r = Recipient(user_id=user_id, email=getattr(user, "email", None),
                  phone_e164=getattr(user, "phone", None),
                  email_verified=bool(getattr(user, "email_verified", False)),
                  phone_verified=bool(getattr(user, "phone_verified", False)),
                  email_enabled=bool(getattr(pref, "email_notifications", True)),
                  sms_enabled=False, muted_types=muted)
    # The planner decides eligibility; the async in-app row is written below. SMS stays off until a
    # per-user SMS preference column exists (sms_enabled=False above is deliberate, not a stub).
    outcomes = fan_out(r, type_, title, message, in_app=lambda *_: None, email=email_send, sms=sms_send)
    if any(o.channel == "in_app" and o.status == "SENT" for o in outcomes):
        await notify(db, user_id, type_, title, message, resource_type, resource_id)
    return outcomes


async def safe_notify(db: AsyncSession, user_id: str, type_: str, title: str, message: str,
                      resource_type: str | None = None, resource_id: str | None = None) -> None:
    """Security-event notification (in-app + email per the user's preferences). Runs inside a SAVEPOINT and
    swallows every error: a notification problem must never fail or roll back the sign-in / MFA change that
    triggered it. Messages never contain secrets or codes."""
    import logging
    try:
        async with db.begin_nested():
            await notify_fan_out(db, user_id, type_, title, message, resource_type, resource_id)
    except Exception:                                              # noqa: BLE001
        logging.getLogger(__name__).warning("notification fan-out failed for %s", type_, exc_info=True)
