"""Dynamic watermark burned into rendered page images (Pillow). Text comes from real
recipient/session/document/time/classification values supplied by the viewer service."""
from __future__ import annotations

from datetime import datetime, timezone

from PIL import Image, ImageDraw, ImageFont

MAX_PIXELS = 40_000_000  # decompression / DoS guard


class ImageTooLarge(Exception):
    pass


def watermark_lines(recipient: str, session_id: str, doc_id: str, when: datetime, classification: str) -> list[str]:
    ts = when.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    return [classification.upper(), f"{recipient}", f"sess {session_id[:8]} | doc {doc_id[:8]} | {ts}"]


def _font(size: int) -> ImageFont.ImageFont | ImageFont.FreeTypeFont:
    try:
        return ImageFont.load_default(size=size)
    except TypeError:  # very old Pillow
        return ImageFont.load_default()


def apply_watermark(img: Image.Image, lines: list[str], opacity: int = 70, angle: float = 30.0) -> Image.Image:
    if img.width * img.height > MAX_PIXELS:
        raise ImageTooLarge("image exceeds pixel cap")
    base = img.convert("RGBA")
    w, h = base.size
    size = max(14, w // 28)
    font = _font(size)
    diag = int((w * w + h * h) ** 0.5)
    layer = Image.new("RGBA", (diag, diag), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    step_y, step_x = int(size * (len(lines) + 3)), int(size * 22)
    for row, y in enumerate(range(0, diag, step_y)):
        for x in range(-step_x if row % 2 else 0, diag, step_x):
            for i, line in enumerate(lines):
                d.text((x, y + i * int(size * 1.2)), line, font=font, fill=(200, 30, 30, opacity))
    layer = layer.rotate(angle, resample=Image.Resampling.BICUBIC)
    left, top = (diag - w) // 2, (diag - h) // 2
    layer = layer.crop((left, top, left + w, top + h))
    return Image.alpha_composite(base, layer).convert("RGB")
