"""Viewer rules (pure). The viewer NEVER serves the stored ciphertext. The route must:
  1. authenticate, 2. call app.services.zero_trust.decide(); proceed only on ALLOW/RESTRICT,
  3. decrypt into memory (or a TemporaryFile that is removed on close) and stream it,
  4. write the audit event, 5. discard the plaintext.
`policy_from_decision` turns the PDP result into the flags the template and response headers use."""
from __future__ import annotations

from dataclasses import dataclass

from app.core.enums import Decision
from app.services.policy_engine import Decision_


@dataclass(frozen=True)
class ViewerPolicy:
    may_view: bool
    can_download: bool
    can_print: bool
    can_copy: bool
    watermark: bool
    stopped_reason: str
    required_actions: tuple[str, ...]


def policy_from_decision(d: Decision_) -> ViewerPolicy:
    if d.decision in (Decision.DENY, Decision.VERIFY):
        return ViewerPolicy(False, False, False, False, True, ",".join(d.reasons), tuple(d.required_actions))
    r = d.restrictions
    return ViewerPolicy(True, bool(r.get("download", True)), bool(r.get("print", True)),
                        bool(r.get("copy", True)), bool(r.get("watermark", False)), "", ())


def response_headers(filename_safe: str, inline: bool) -> dict[str, str]:
    """Headers for streamed plaintext: never cached, never sniffed, never framed."""
    disp = "inline" if inline else "attachment"
    return {"Cache-Control": "no-store, max-age=0", "Pragma": "no-cache", "X-Content-Type-Options": "nosniff",
            "Content-Disposition": f'{disp}; filename="{filename_safe}"', "X-Frame-Options": "DENY",
            "Content-Security-Policy": "default-src 'none'; sandbox"}
