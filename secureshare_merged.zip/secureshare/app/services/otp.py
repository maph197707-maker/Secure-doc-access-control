"""One-time codes for email and SMS: generation, hashed persistence, delivery, verification.

Every decision is made here, server-side, from the persisted `otp_challenges` row:

  send():    cooldown + hourly quotas -> supersede older code -> generate (secrets) -> persist
             HMAC(code) with expiry / attempt limit / cooldown -> call the provider -> record the
             outcome. A failed provider call marks the row DELIVERY_FAILED (the code is dead, the user
             is not locked out of retrying) and raises DeliveryError; nothing is "sent" otherwise.
  verify():  the attempt is counted atomically BEFORE the comparison, a correct code is consumed
             atomically (one-time use), expired / locked / used challenges never verify.

The raw code exists only in memory, between generation and the provider call. It is never stored,
logged, audited or returned. The frontend only renders a form; it decides nothing.
"""
from __future__ import annotations

import asyncio
import secrets
import string
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import StrEnum
from typing import Any, Callable

from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.logging import logger
from app.config.settings import Settings, get_settings
from app.core.exceptions import DeliveryError, ProviderUnavailableError, RateLimitExceededError
from app.crypto.hashing import constant_time_equal, hmac_sha256
from app.integrations import errors as E
from app.integrations.email import mask_email
from app.integrations.sms import mask_phone
from app.models import otp as m
from app.models.otp import OtpChallenge
from app.repositories.audit import AuditRepository

CODE_LENGTH = 6
SUBJECT_SENDS_MULTIPLIER = 2          # per-subject hourly cap = 2 x per-destination cap
HOUR = 3600

# Audit actions (never contain a code, a raw address/number or a credential).
AUDIT_SENT = "OTP_SENT"
AUDIT_SEND_BLOCKED = "OTP_SEND_BLOCKED"
AUDIT_DELIVERY_FAILED = "OTP_DELIVERY_FAILED"
AUDIT_VERIFIED = "OTP_VERIFIED"
AUDIT_VERIFY_FAILED = "OTP_VERIFY_FAILED"


class OtpPurpose(StrEnum):
    EMAIL_VERIFY = "EMAIL_VERIFY"
    PHONE_VERIFY = "PHONE_VERIFY"
    RECIPIENT_EMAIL = "RECIPIENT_EMAIL"
    RECIPIENT_PHONE = "RECIPIENT_PHONE"


class OtpResult(StrEnum):
    OK = "OK"
    WRONG = "WRONG"
    EXPIRED = "EXPIRED"
    LOCKED = "LOCKED"
    USED = "USED"
    NOT_FOUND = "NOT_FOUND"          # no active challenge for this subject + destination


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def generate_code(length: int = CODE_LENGTH) -> str:
    """Uniformly random numeric code from the OS CSPRNG (secrets), zero-padded, never time-seeded."""
    return "".join(secrets.choice(string.digits) for _ in range(length))


def derive_key(master_secret: str | bytes) -> bytes:
    master = master_secret.encode() if isinstance(master_secret, str) else master_secret
    return hmac_sha256(master, b"otp-challenge-v1")


def hash_code(key: bytes, challenge_id: str, code: str) -> str:
    """HMAC-SHA256(key, challenge_id:code). Bound to the challenge so a hash cannot be replayed on another."""
    return hmac_sha256(key, f"{challenge_id}:{code}".encode()).hex()


def hash_destination(key: bytes, destination: str) -> str:
    return hmac_sha256(key, b"dest:" + destination.strip().lower().encode()).hex()


def normalize_code(code: str | None) -> str | None:
    c = (code or "").strip().replace(" ", "").replace("-", "")
    return c if (c.isascii() and c.isdigit() and len(c) == CODE_LENGTH) else None


@dataclass(frozen=True)
class SendReceipt:
    """Returned only after the provider accepted the message."""
    challenge_id: str
    channel: str
    destination_hint: str
    expires_in: int
    resend_after: int


def _hint(channel: str, destination: str) -> str:
    return mask_phone(destination) if channel == "sms" else mask_email(destination)


class OtpService:
    def __init__(self, db: AsyncSession, settings: Settings | None = None, *, key: bytes | None = None) -> None:
        self.db = db
        self.settings = settings or get_settings()
        self._key = key or derive_key(self.settings.master_secret)
        self.audit = AuditRepository(db)

    # ── send ─────────────────────────────────────────────────────────────────
    async def send(self, *, purpose: OtpPurpose, subject: str, destination: str, channel: str,
                   deliver: Callable[[str, int], Any], user_id: str | None = None,
                   ip: str | None = None, user_agent: str | None = None,
                   rollback_on_failure: bool = False) -> SendReceipt:
        """Create, persist and deliver a code. `deliver(code, minutes)` is the ONLY place the raw code
        leaves this method (a provider call). `rollback_on_failure` is for callers whose own pending
        work (e.g. a half-created account) must not survive a failed delivery."""
        st, now = self.settings, utcnow()
        dest_hash = hash_destination(self._key, destination)
        hint = _hint(channel, destination)
        ctx = {"purpose": purpose.value, "channel": channel, "destination": hint}

        # 1. cooldown: a code that was delivered (or is in flight) blocks an immediate resend.
        latest = (await self.db.execute(
            select(OtpChallenge).where(
                OtpChallenge.purpose == purpose.value, OtpChallenge.subject == subject,
                OtpChallenge.destination_hash == dest_hash,
                OtpChallenge.status != m.DELIVERY_FAILED)
            .order_by(OtpChallenge.created_at.desc()).limit(1))).scalar_one_or_none()
        if latest is not None and latest.resend_available_at > now:
            wait = max(int((latest.resend_available_at - now).total_seconds()) + 1, 1)
            await self._blocked(rollback_on_failure, user_id, ip, user_agent, {**ctx, "reason": "cooldown"})
            raise RateLimitExceededError(f"Please wait {wait} seconds before requesting another code.",
                                         retry_after=wait)

        # 2. hourly quotas (count failed sends too: they can still cost money / be abused).
        since = now - timedelta(seconds=HOUR)
        per_dest = (await self.db.execute(select(func.count()).select_from(OtpChallenge).where(
            OtpChallenge.destination_hash == dest_hash, OtpChallenge.created_at > since))).scalar_one()
        per_subject = (await self.db.execute(select(func.count()).select_from(OtpChallenge).where(
            OtpChallenge.subject == subject, OtpChallenge.created_at > since))).scalar_one()
        if per_dest >= st.otp_max_sends_per_hour or per_subject >= st.otp_max_sends_per_hour * SUBJECT_SENDS_MULTIPLIER:
            await self._blocked(rollback_on_failure, user_id, ip, user_agent, {**ctx, "reason": "hourly_quota"})
            raise RateLimitExceededError("Too many codes requested. Please try again later.", retry_after=HOUR)

        # 3. supersede older codes (exactly one active code), then persist the new hashed one.
        await self.db.execute(update(OtpChallenge).where(
            OtpChallenge.purpose == purpose.value, OtpChallenge.subject == subject,
            OtpChallenge.destination_hash == dest_hash, OtpChallenge.status == m.PENDING)
            .values(status=m.SUPERSEDED))
        code = generate_code()
        cid = str(uuid.uuid4())
        row = OtpChallenge(
            id=cid, purpose=purpose.value, channel=channel, subject=subject, destination_hash=dest_hash,
            destination_hint=hint, otp_hash=hash_code(self._key, cid, code), status=m.PENDING,
            expires_at=now + timedelta(seconds=st.otp_ttl_seconds), attempt_count=0,
            max_attempts=st.otp_max_attempts,
            resend_available_at=now + timedelta(seconds=st.otp_resend_cooldown_seconds))
        self.db.add(row)
        await self.db.flush()

        # 4. deliver. The blocking provider call runs off the event loop.
        try:
            await asyncio.to_thread(deliver, code, st.otp_ttl_seconds // 60)
        except E.DeliveryFailure as exc:
            await self._delivery_failed(row, exc.reason, rollback_on_failure, user_id, ip, user_agent, ctx)
            raise self._to_error(exc.reason) from None
        except Exception as exc:          # a provider bug must still never leave a live code behind
            logger.error("otp_delivery_unexpected_error", error=type(exc).__name__, **ctx)
            await self._delivery_failed(row, "unexpected_error", rollback_on_failure, user_id, ip, user_agent, ctx)
            raise DeliveryError("We couldn't send the verification code. Please try again shortly.",
                                reason="unexpected_error") from None
        finally:
            code = "0" * CODE_LENGTH      # drop the plaintext reference as soon as possible

        row.sent_at = utcnow()
        await self.audit.log_event(AUDIT_SENT, user_id=user_id, resource_type="otp_challenge", resource_id=cid,
                                   ip_address=ip, user_agent=user_agent, details=ctx)
        return SendReceipt(cid, channel, hint, st.otp_ttl_seconds, st.otp_resend_cooldown_seconds)

    # ── verify ───────────────────────────────────────────────────────────────
    async def verify(self, *, purpose: OtpPurpose, subject: str, destination: str, code: str,
                     user_id: str | None = None, ip: str | None = None,
                     user_agent: str | None = None) -> OtpResult:
        """Decide whether `code` is valid. A non-OK outcome (and its attempt count) is committed here so
        it survives the caller's error path. On OK the challenge is consumed in the caller's transaction:
        the caller commits it together with the state it unlocks (e.g. email_verified)."""
        now = utcnow()
        dest_hash = hash_destination(self._key, destination)
        ctx = {"purpose": purpose.value, "destination": _hint("sms" if "PHONE" in purpose.value else "email", destination)}
        row = (await self.db.execute(
            select(OtpChallenge).where(
                OtpChallenge.purpose == purpose.value, OtpChallenge.subject == subject,
                OtpChallenge.destination_hash == dest_hash,
                OtpChallenge.status.in_([m.PENDING, m.VERIFIED, m.LOCKED, m.EXPIRED]))
            .order_by(OtpChallenge.created_at.desc()).limit(1))).scalar_one_or_none()
        if row is None:
            return await self._failed(OtpResult.NOT_FOUND, None, user_id, ip, user_agent, ctx)
        ctx["challenge"] = row.id
        if row.status == m.VERIFIED:
            return await self._failed(OtpResult.USED, row.id, user_id, ip, user_agent, ctx)
        if row.status == m.LOCKED or row.attempt_count >= row.max_attempts:
            if row.status != m.LOCKED:
                row.status = m.LOCKED
            return await self._failed(OtpResult.LOCKED, row.id, user_id, ip, user_agent, ctx)
        if row.status == m.EXPIRED or row.expires_at <= now:
            row.status = m.EXPIRED
            return await self._failed(OtpResult.EXPIRED, row.id, user_id, ip, user_agent, ctx)

        # Count the attempt first (atomic, conditional): concurrent guesses cannot exceed the limit.
        counted = (await self.db.execute(
            update(OtpChallenge).where(
                OtpChallenge.id == row.id, OtpChallenge.status == m.PENDING,
                OtpChallenge.attempt_count < OtpChallenge.max_attempts)
            .values(attempt_count=OtpChallenge.attempt_count + 1)
            .returning(OtpChallenge.attempt_count))).scalar_one_or_none()
        if counted is None:                      # lost a race: consumed / locked / superseded meanwhile
            await self.db.refresh(row)
            res = OtpResult.USED if row.status == m.VERIFIED else \
                OtpResult.LOCKED if row.attempt_count >= row.max_attempts else OtpResult.NOT_FOUND
            return await self._failed(res, row.id, user_id, ip, user_agent, ctx)

        clean = normalize_code(code)
        good = clean is not None and constant_time_equal(hash_code(self._key, row.id, clean), row.otp_hash)
        if not good:
            if counted >= row.max_attempts:
                await self.db.execute(update(OtpChallenge).where(OtpChallenge.id == row.id).values(status=m.LOCKED))
                return await self._failed(OtpResult.LOCKED, row.id, user_id, ip, user_agent,
                                          {**ctx, "attempts": counted})
            return await self._failed(OtpResult.WRONG, row.id, user_id, ip, user_agent, {**ctx, "attempts": counted})

        consumed = (await self.db.execute(
            update(OtpChallenge).where(OtpChallenge.id == row.id, OtpChallenge.status == m.PENDING)
            .values(status=m.VERIFIED, verified_at=now))).rowcount
        if consumed != 1:                        # another request consumed it first: one-time use holds
            return await self._failed(OtpResult.USED, row.id, user_id, ip, user_agent, ctx)
        await self.audit.log_event(AUDIT_VERIFIED, user_id=user_id, resource_type="otp_challenge",
                                   resource_id=row.id, ip_address=ip, user_agent=user_agent, details=ctx)
        return OtpResult.OK

    # ── housekeeping ─────────────────────────────────────────────────────────
    async def purge(self, older_than_days: int = 7) -> int:
        """Delete challenges that ended long ago (they only matter for the audit trail, which has its own rows)."""
        from sqlalchemy import delete
        cutoff = utcnow() - timedelta(days=older_than_days)
        res = await self.db.execute(delete(OtpChallenge).where(OtpChallenge.created_at < cutoff))
        return res.rowcount or 0

    # ── internals ────────────────────────────────────────────────────────────
    async def _failed(self, res: OtpResult, cid: str | None, user_id, ip, ua, ctx) -> OtpResult:
        await self.audit.log_event(AUDIT_VERIFY_FAILED, user_id=user_id, resource_type="otp_challenge",
                                   resource_id=cid, ip_address=ip, user_agent=ua,
                                   details={**ctx, "result": res.value})
        await self.db.commit()                  # keep the attempt count + audit even if the caller raises
        return res

    async def _blocked(self, rollback: bool, user_id, ip, ua, details) -> None:
        if rollback:
            await self.db.rollback()
        await self.audit.log_event(AUDIT_SEND_BLOCKED, user_id=None if rollback else user_id,
                                   resource_type="otp_challenge", ip_address=ip, user_agent=ua, details=details)
        await self.db.commit()

    async def _delivery_failed(self, row: OtpChallenge, reason: str, rollback: bool, user_id, ip, ua, ctx) -> None:
        cid = row.id
        if rollback:
            await self.db.rollback()           # discards the caller's half-created records AND this row
            await self.audit.log_event(AUDIT_DELIVERY_FAILED, user_id=None, resource_type="otp_challenge",
                                       resource_id=None, ip_address=ip, user_agent=ua,
                                       details={**ctx, "reason": reason})
        else:
            row.status = m.DELIVERY_FAILED      # dead code, excluded from cooldown and verification
            await self.audit.log_event(AUDIT_DELIVERY_FAILED, user_id=user_id, resource_type="otp_challenge",
                                       resource_id=cid, ip_address=ip, user_agent=ua,
                                       details={**ctx, "reason": reason})
        await self.db.commit()
        logger.warning("otp_delivery_failed", reason=reason, **ctx)

    @staticmethod
    def _to_error(reason: str) -> DeliveryError:
        if reason in (E.AUTH, E.CONFIG, E.RATE_LIMITED):
            # Operator problem (bad credentials / quota): do not blame the user's address.
            return ProviderUnavailableError(reason=reason)
        if reason == E.RECIPIENT:
            return DeliveryError("We couldn't deliver a code to that address or number. Check it and try again.",
                                 status_code=422, reason=reason)
        return DeliveryError("We couldn't send the verification code. Please try again shortly.", reason=reason)
