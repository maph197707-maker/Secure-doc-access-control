"""Alerts service for managing security notifications and incidents."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Sequence
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import NotFoundError, PermissionDeniedError
from app.models.security_alert import SecurityAlert


class AlertService:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def create_alert(
        self,
        alert_type: str,
        severity: str,
        message: str,
        user_id: str | None = None,
        document_id: str | None = None,
        link_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> SecurityAlert:
        alert = SecurityAlert(
            alert_type=alert_type,
            severity=severity,
            message=message,
            user_id=user_id,
            document_id=document_id,
            link_id=link_id,
            acknowledged=False,
        )
        self.session.add(alert)
        await self.session.flush()
        return alert

    async def list_alerts(
        self,
        user_id: str | None = None,
        is_admin: bool = False,
        unacknowledged_only: bool = False,
        limit: int = 50,
    ) -> Sequence[SecurityAlert]:
        stmt = select(SecurityAlert)
        if not is_admin and user_id:
            stmt = stmt.where(SecurityAlert.user_id == user_id)
        if unacknowledged_only:
            stmt = stmt.where(SecurityAlert.acknowledged == False)
        stmt = stmt.order_by(desc(SecurityAlert.created_at)).limit(limit)
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def acknowledge_alert(self, alert_id: str, acknowledging_user_id: str, is_admin: bool = False) -> SecurityAlert:
        stmt = select(SecurityAlert).where(SecurityAlert.id == alert_id)
        res = await self.session.execute(stmt)
        alert = res.scalar_one_or_none()
        if not alert:
            raise NotFoundError("Alert not found.")
        if not is_admin and alert.user_id != acknowledging_user_id:
            raise PermissionDeniedError("Cannot acknowledge alert for another user.")

        alert.acknowledged = True
        alert.acknowledged_by = acknowledging_user_id
        alert.acknowledged_at = datetime.now(timezone.utc).replace(tzinfo=None)
        await self.session.flush()
        return alert
