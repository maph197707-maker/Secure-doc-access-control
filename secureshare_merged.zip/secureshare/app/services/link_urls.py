"""Build share URLs that actually open on the *recipient's* device.

`PUBLIC_BASE_URL=http://localhost:8000` is useless on a phone: localhost there is the phone.
In dev, when the configured base is a loopback address, we build the URL from the request and, if
the request itself came in on localhost, swap in this machine's LAN address. In staging/production
the configured PUBLIC_BASE_URL is always used verbatim (it must be your HTTPS origin).
"""
from __future__ import annotations

import ipaddress
import socket
from urllib.parse import urlsplit

from fastapi import Request

from app.config.settings import get_settings

_LOOPBACK = {"localhost", "127.0.0.1", "::1", "0.0.0.0"}
# Real LAN ranges only. (ipaddress.is_private is broader: it also covers documentation/reserved
# blocks, which must not be treated as "my local network".)
_LAN_NETS = [ipaddress.ip_network(n) for n in
             ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "fc00::/7")]


def lan_ip() -> str | None:
    """Best-effort LAN address of this machine. No packets are sent (UDP connect only)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        return None if ip.startswith("127.") else ip
    except OSError:
        return None
    finally:
        s.close()


def is_private_host(hostname: str) -> bool:
    """True for loopback / RFC1918 / link-local IPs and bare .local names (LAN demo hosts)."""
    h = hostname.strip("[]").lower()
    if h in _LOOPBACK or h.endswith(".local"):
        return True
    try:
        ip = ipaddress.ip_address(h)
    except ValueError:
        return False
    return ip.is_loopback or ip.is_link_local or any(ip in n for n in _LAN_NETS)


def base_url_for(request: Request) -> str:
    st = get_settings()
    configured = st.public_base_url.rstrip("/")
    if not st.is_dev:
        return configured
    cfg_host = (urlsplit(configured).hostname or "").lower()
    if cfg_host not in _LOOPBACK or configured.lower().startswith("https://"):
        return configured                      # operator set a real / TLS address: respect it verbatim
    host_header = request.headers.get("host", "")
    hostname = host_header.rsplit(":", 1)[0].strip("[]").lower() if host_header else ""
    port = host_header.rsplit(":", 1)[1] if ":" in host_header else ""
    scheme = request.url.scheme
    if hostname in _LOOPBACK or not hostname:
        ip = lan_ip()
        if not ip:
            return configured
        hostname = ip
    return f"{scheme}://{hostname}{':' + port if port else ''}"


def share_url(request: Request, raw_token: str) -> str:
    base = base_url_for(request)
    if not get_settings().is_dev and not base.lower().startswith("https://"):
        # Settings validation already prevents this; this is the last line of defence for links.
        raise RuntimeError("Refusing to build a non-https share link outside development.")
    return f"{base}/view/{raw_token}"
