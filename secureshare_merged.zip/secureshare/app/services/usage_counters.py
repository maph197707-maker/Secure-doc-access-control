"""Atomic usage limits. A single conditional UPDATE decides the race: exactly one concurrent
caller can take the last view/download. Plain SQL, valid on SQLite and PostgreSQL (no FOR UPDATE).

Expects table secure_links(id, revoked, max_views, views_used, max_downloads, downloads_used, one_time)."""
from __future__ import annotations

from typing import Any

_VIEW = ("UPDATE secure_links SET views_used = views_used + 1 WHERE id = :id AND revoked = 0 "
         "AND (max_views IS NULL OR views_used < max_views) AND (one_time = 0 OR views_used = 0)")
_DOWNLOAD = ("UPDATE secure_links SET downloads_used = downloads_used + 1 WHERE id = :id AND revoked = 0 "
             "AND (max_downloads IS NULL OR downloads_used < max_downloads) AND (one_time = 0 OR downloads_used = 0)")


def consume(execute: Any, kind: str, link_id: str) -> bool:
    """`execute(sql, params)` must return rowcount. True = this caller got the slot."""
    sql = {"view": _VIEW, "download": _DOWNLOAD}[kind]
    return execute(sql, {"id": link_id}) == 1
