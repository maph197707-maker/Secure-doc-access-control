"""Secure link creation, validation, and redemption service."""
from __future__ import annotations

import time
from datetime import datetime, timedelta, timezone
from typing import Optional, Sequence

from sqlalchemy import case, func, null, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.config.settings import get_settings
from app.core.exceptions import NotFoundError, PermissionDeniedError, ValidationError
from app.crypto.password import hash_password, verify_password
from app.crypto.hashing import constant_time_equal, hmac_sha256
from app.crypto.tokens import new_token, token_hash
from app.models.audit import AuditLog
from app.models.document import Document
from app.models.recipient import Recipient
from app.models.secure_link import SecureLink
from app.repositories.audit import AuditRepository
from app.repositories.document import DocumentRepository
from app.services.recipient_gate import (BOUND_MODES, MODE_NONE, MODE_PHONE, RecipientError, RecipientRef,
                                         clean_recipients)


class SecureLinkService:
    def __init__(self, db: AsyncSession) -> None:
        self.db = db
        self.settings = get_settings()
        self.doc_repo = DocumentRepository(db)
        self.audit_repo = AuditRepository(db)
        self._key = self.settings.master_secret.encode()

    async def create_link(
        self,
        document_id: str,
        created_by: str,
        expires_in_hours: int = 72,
        max_views: Optional[int] = None,
        max_downloads: Optional[int] = None,
        allow_downloads: bool = True,
        allow_print: bool = False,
        allow_copy: bool = False,
        requires_password: bool = False,
        password: Optional[str] = None,
        password_hash: Optional[str] = None,
        watermark_forced: bool = True,
        one_time_view: bool = False,
        one_time_download: bool = False,
        requires_mfa: bool = False,
        recipient_emails: Optional[list[str]] = None,
        binding_mode: str = MODE_NONE,
        recipients: Optional[list[dict]] = None,
        expires_at_utc: Optional[datetime] = None,
        valid_from_utc: Optional[datetime] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> tuple[SecureLink, str]:
        """Create a secure link for a document. Returns (SecureLink, raw_token)."""

        # Verify document exists and belongs to user
        doc = await self.doc_repo.get_by_id(document_id)
        if not doc:
            raise NotFoundError("Document not found.")
        if doc.owner_id != created_by:
            raise PermissionDeniedError("You do not own this document.")

        # Recipient list (dicts with email/phone). `recipient_emails` stays for older callers.
        rcpts = [{"email": e, "phone": None} for e in (recipient_emails or [])] + list(recipients or [])
        rcpts = self._clean_recipients(rcpts, binding_mode)

        # Generate token
        raw_token = new_token(32)
        t_hash = token_hash(raw_token, self._key)
        token_prefix = raw_token[:12]

        now = datetime.now(timezone.utc).replace(tzinfo=None)
        expires_at = expires_at_utc if expires_at_utc is not None else now + timedelta(hours=expires_in_hours)

        for label, limit in (("views", max_views), ("downloads", max_downloads)):
            if limit is not None and limit < 1:
                raise ValidationError(f"Maximum {label} must be at least 1.")
        if valid_from_utc is not None and valid_from_utc >= expires_at:
            raise ValidationError("The start time must be before the expiry time.")
        if one_time_download and not allow_downloads:
            raise ValidationError("One-time download needs downloads to be allowed.")

        if requires_mfa and binding_mode not in BOUND_MODES:
            # a link visitor has no MFA factor, so the PDP would VERIFY forever: refuse, don't create a dead link
            raise ValidationError("MFA on a link needs recipient verification (email or SMS code).")

        # Hash password if required
        if requires_password and password_hash:
            pass  # already an argon2 hash (share wizard never keeps the plaintext in its draft)
        elif requires_password:
            if not password:
                # Never silently create an unprotected link when protection was requested.
                raise ValidationError("A password is required when password protection is on.")
            password_hash = hash_password(password)

        link = SecureLink(
            document_id=document_id,
            created_by=created_by,
            token_hash=t_hash,
            token_prefix=token_prefix,
            status="ACTIVE",
            reputation="NORMAL",
            password_hash=password_hash,
            requires_mfa=requires_mfa,
            allow_downloads=allow_downloads,
            allow_print=allow_print,
            allow_copy=allow_copy,
            watermark_forced=watermark_forced,
            max_views=max_views,
            views_remaining=max_views,
            max_downloads=max_downloads,
            downloads_remaining=max_downloads,
            one_time_view=one_time_view,
            one_time_download=one_time_download,
            binding_mode=binding_mode,
            valid_from=valid_from_utc,
            expires_at=expires_at,
        )
        self.db.add(link)
        await self.db.flush()

        # Add recipients if provided
        for r in rcpts:
            self.db.add(Recipient(link_id=link.id, email=r["email"], phone=r["phone"]))
        if rcpts:
            await self.db.flush()

        await self.audit_repo.log_event(
            action="SECURE_LINK_CREATE",
            user_id=created_by,
            resource_type="secure_link",
            resource_id=link.id,
            ip_address=ip_address,
            user_agent=user_agent,
            details={"document_id": document_id, "expires_at": expires_at.isoformat(),
                     "valid_from": valid_from_utc.isoformat() if valid_from_utc else None,
                     "max_views": max_views, "max_downloads": max_downloads,
                     "allow_downloads": allow_downloads, "one_time_view": one_time_view,
                     "one_time_download": one_time_download,
                     "password_protected": bool(password_hash), "requires_mfa": requires_mfa,
                     "binding_mode": binding_mode, "recipients": len(rcpts)},
        )

        return link, raw_token

    def _clean_recipients(self, rcpts: list[dict], binding_mode: str) -> list[dict]:
        try:
            return clean_recipients(rcpts, binding_mode, self.settings.sms_default_country_code)
        except RecipientError as exc:
            raise ValidationError(str(exc)) from None

    # ── recipient binding ────────────────────────────────────────────────────
    async def recipient_refs(self, link: SecureLink) -> list[RecipientRef]:
        res = await self.db.execute(select(Recipient).where(Recipient.link_id == link.id).order_by(Recipient.created_at))
        return [RecipientRef(r.id, r.email, r.phone) for r in res.scalars().all()]

    @property
    def master_key(self) -> bytes:
        return self._key

    @staticmethod
    def recipient_cookie_name(link: SecureLink) -> str:
        return f"ssr_{link.id[:8]}"

    async def mark_recipient_verified(self, link: SecureLink, recipient_id: str, mode: str) -> None:
        res = await self.db.execute(select(Recipient).where(Recipient.id == recipient_id, Recipient.link_id == link.id))
        r = res.scalar_one_or_none()
        if r is None:
            return
        r.otp_verified = True
        if mode == MODE_PHONE:
            r.phone_verified = True
        else:
            r.email_verified = True
        r.bound_at = datetime.now(timezone.utc).replace(tzinfo=None)
        await self.db.flush()

    async def find(self, raw_token: str) -> Optional[SecureLink]:
        """Look a raw token up by its keyed hash. No validity checks."""
        t_hash = token_hash(raw_token, self._key)
        stmt = (
            select(SecureLink)
            .options(selectinload(SecureLink.document))
            .where(SecureLink.token_hash == t_hash)
        )
        res = await self.db.execute(stmt)
        return res.scalar_one_or_none()

    async def get_link_by_token(self, raw_token: str) -> SecureLink:
        """Resolve a raw token to a SecureLink, raising if not found or not usable."""
        link = await self.find(raw_token)
        if not link:
            raise NotFoundError("Secure link not found.")
        self._check_link_validity(link)
        return link

    def _check_link_validity(self, link: SecureLink) -> None:
        if link.status != "ACTIVE":
            raise PermissionDeniedError("This link has been revoked or expired.")
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        if link.expires_at and link.expires_at < now:
            raise PermissionDeniedError("This link has expired.")
        if link.valid_from and link.valid_from > now:
            raise PermissionDeniedError("This link is not active yet.")
        if link.views_remaining is not None and link.views_remaining <= 0:
            raise PermissionDeniedError("This link has reached its view limit.")
        doc = link.document
        if doc is None or getattr(doc, "is_deleted", False):
            raise NotFoundError("The shared document is no longer available.")

    # ── atomic usage counters ────────────────────────────────────────────────
    # One conditional UPDATE decides the race: only one concurrent caller can take the last
    # view/download. Plain SQLAlchemy Core, so it behaves the same on SQLite and PostgreSQL.
    async def consume_view(self, link: SecureLink) -> bool:
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        stmt = (
            update(SecureLink)
            .where(
                SecureLink.id == link.id,
                SecureLink.status == "ACTIVE",
                or_(SecureLink.views_remaining.is_(None), SecureLink.views_remaining > 0),
            )
            .values(
                view_count=SecureLink.view_count + 1,
                last_accessed_at=now,
                views_remaining=case(
                    (SecureLink.views_remaining.is_(None), null()),
                    else_=SecureLink.views_remaining - 1,
                ),
                status=case((SecureLink.one_time_view == True, "USED"), else_=SecureLink.status),  # noqa: E712
            )
            .execution_options(synchronize_session=False)
        )
        res = await self.db.execute(stmt)
        await self.db.refresh(link)
        return res.rowcount == 1

    async def consume_download(self, link: SecureLink) -> bool:
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        stmt = (
            update(SecureLink)
            .where(
                SecureLink.id == link.id,
                SecureLink.status == "ACTIVE",
                SecureLink.allow_downloads == True,  # noqa: E712
                or_(SecureLink.downloads_remaining.is_(None), SecureLink.downloads_remaining > 0),
            )
            .values(
                download_count=SecureLink.download_count + 1,
                last_accessed_at=now,
                downloads_remaining=case(
                    (SecureLink.downloads_remaining.is_(None), null()),
                    else_=SecureLink.downloads_remaining - 1,
                ),
                status=case(
                    (SecureLink.one_time_download == True, "USED"),  # noqa: E712
                    else_=SecureLink.status,
                ),
            )
            .execution_options(synchronize_session=False)
        )
        res = await self.db.execute(stmt)
        await self.db.refresh(link)
        return res.rowcount == 1

    # ── password gate ────────────────────────────────────────────────────────
    MAX_PASSWORD_FAILS = 5
    FAIL_WINDOW = timedelta(minutes=15)
    UNLOCK_TTL = 900  # seconds a correct password keeps the link unlocked in that browser

    @staticmethod
    def unlock_cookie_name(link: SecureLink) -> str:
        return f"ssl_{link.id[:8]}"

    async def recent_password_failures(self, link_id: str) -> int:
        since = datetime.now(timezone.utc).replace(tzinfo=None) - self.FAIL_WINDOW
        res = await self.db.execute(
            select(func.count()).select_from(AuditLog).where(
                AuditLog.action == "SECURE_LINK_PASSWORD_FAIL",
                AuditLog.resource_id == link_id,
                AuditLog.created_at >= since,
            )
        )
        return int(res.scalar_one())

    async def check_password(
        self, link: SecureLink, password: str, ip: Optional[str], ua: Optional[str]
    ) -> bool:
        """Verify the link password with brute-force lockout. Never logs the password."""
        if not link.password_hash:
            return True
        if await self.recent_password_failures(link.id) >= self.MAX_PASSWORD_FAILS:
            await self.audit_repo.log_event(
                action="SECURE_LINK_LOCKED", resource_type="secure_link", resource_id=link.id,
                ip_address=ip, user_agent=ua, details={"reason": "too_many_password_failures"})
            raise PermissionDeniedError("Too many wrong passwords. Try again in 15 minutes.")
        if verify_password(link.password_hash, password or ""):
            return True
        await self.audit_repo.log_event(
            action="SECURE_LINK_PASSWORD_FAIL", resource_type="secure_link", resource_id=link.id,
            ip_address=ip, user_agent=ua, details={})
        return False

    def issue_unlock(self, link: SecureLink) -> str:
        exp = int(time.time()) + self.UNLOCK_TTL
        sig = hmac_sha256(self._key, f"unlock:{link.id}:{exp}".encode()).hex()
        return f"{exp}.{sig}"

    def unlock_valid(self, link: SecureLink, value: Optional[str]) -> bool:
        """True when the link needs no password, or the browser holds a fresh signed unlock."""
        if not link.password_hash:
            return True
        if not value or "." not in value:
            return False
        exp_s, sig = value.split(".", 1)
        if not exp_s.isdigit() or int(exp_s) < time.time():
            return False
        good = hmac_sha256(self._key, f"unlock:{link.id}:{exp_s}".encode()).hex()
        return constant_time_equal(sig, good)

    async def log_denied(
        self, link: Optional[SecureLink], reason: str, ip: Optional[str], ua: Optional[str]
    ) -> None:
        await self.audit_repo.log_event(
            action="SECURE_LINK_DENIED", resource_type="secure_link",
            resource_id=link.id if link else None, ip_address=ip, user_agent=ua,
            details={"reason": reason})

    async def get_owned(self, link_id: str, user_id: str) -> SecureLink:
        res = await self.db.execute(
            select(SecureLink).options(selectinload(SecureLink.document))
            .where(SecureLink.id == link_id))
        link = res.scalar_one_or_none()
        if not link or link.created_by != user_id:
            raise NotFoundError("Secure link not found.")      # same answer for "not yours"
        return link

    async def rotate_link(self, link_id: str, user_id: str,
                          ip_address: Optional[str] = None,
                          user_agent: Optional[str] = None) -> tuple[SecureLink, str]:
        """Issue a brand-new token for an existing link. The old URL stops working immediately."""
        link = await self.get_owned(link_id, user_id)
        if link.status != "ACTIVE":
            raise PermissionDeniedError("Only active links can be rotated.")
        raw = new_token(32)
        link.token_hash = token_hash(raw, self._key)
        link.token_prefix = raw[:12]
        await self.db.flush()
        await self.audit_repo.log_event(
            action="SECURE_LINK_ROTATE", user_id=user_id, resource_type="secure_link",
            resource_id=link.id, ip_address=ip_address, user_agent=user_agent)
        return link, raw

    async def revoke_link(
        self,
        link_id: str,
        user_id: str,
        reason: str = "user_revocation",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> None:
        stmt = select(SecureLink).where(SecureLink.id == link_id)
        res = await self.db.execute(stmt)
        link = res.scalar_one_or_none()
        if not link:
            raise NotFoundError("Secure link not found.")
        if link.created_by != user_id:
            raise PermissionDeniedError("Access denied.")
        link.status = "REVOKED"
        link.revoked_at = datetime.now(timezone.utc).replace(tzinfo=None)
        link.revoke_reason = reason
        await self.db.flush()
        await self.audit_repo.log_event(
            action="SECURE_LINK_REVOKE",
            user_id=user_id,
            resource_type="secure_link",
            resource_id=link_id,
            ip_address=ip_address,
            user_agent=user_agent,
        )

    async def list_for_user(
        self,
        user_id: str,
        page: int = 1,
        page_size: int = 20,
    ) -> tuple[Sequence[SecureLink], int]:
        from sqlalchemy import func
        base_stmt = select(SecureLink).where(SecureLink.created_by == user_id)
        count_res = await self.db.execute(select(func.count()).select_from(base_stmt.subquery()))
        total = count_res.scalar_one()
        stmt = (
            base_stmt.order_by(SecureLink.created_at.desc())
            .offset((page - 1) * page_size)
            .limit(page_size)
        )
        res = await self.db.execute(stmt)
        return res.scalars().all(), total
