"""Identity verification helpers (second factor checks). Kept for callers that only have a user id;
the sign-in flow itself lives in AuthService.complete_mfa_login and set-up in MfaService."""
from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.exceptions import AuthenticationError, ValidationError
from app.integrations.state import StateStore, get_state_store
from app.models.user import User
from app.services import mfa


class IdentityService:
    def __init__(self, session: AsyncSession, store: StateStore | None = None) -> None:
        self.session = session
        self.store = store or get_state_store()

    async def _user(self, user_id: str) -> User | None:
        return (await self.session.execute(select(User).where(User.id == user_id))).scalar_one_or_none()

    async def verify_totp(self, user_id: str, code: str) -> bool:
        user = await self._user(user_id)
        if not user or not user.totp_secret:
            raise ValidationError("TOTP is not configured for this user.")
        secret = mfa.open_secret(user.totp_secret, get_settings().master_secret, user.id)
        if secret is None or mfa.verify_totp(self.store, user.id, secret, code) != mfa.MfaResult.OK:
            raise AuthenticationError("Invalid authenticator code.")
        return True

    async def verify_recovery_code(self, user_id: str, code: str) -> bool:
        user = await self._user(user_id)
        if not user or not user.recovery_codes:
            raise ValidationError("No recovery codes configured.")
        valid, remaining = mfa.consume_recovery_code(list(user.recovery_codes), code)
        if not valid:
            raise AuthenticationError("Invalid recovery code.")
        user.recovery_codes = remaining
        await self.session.flush()
        return True
