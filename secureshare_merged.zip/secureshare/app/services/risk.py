"""Explainable, deterministic risk scoring. Every reason lists the stored event IDs it came from.
Risk is a SIGNAL for the PDP; it never grants or overrides access."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from typing import TYPE_CHECKING

from app.core.enums import RiskLevel

if TYPE_CHECKING:  # keep the pure scoring functions importable without SQLAlchemy
    from sqlalchemy.ext.asyncio import AsyncSession

# code -> (points per event, cap for the code)
RULES: dict[str, tuple[int, int]] = {
    "FAILED_LOGIN": (8, 32), "FAILED_OTP": (10, 40), "NEW_DEVICE": (20, 20), "UNUSUAL_HOUR": (10, 10),
    "RAPID_DOWNLOAD": (15, 30), "REPEATED_DENIAL": (8, 32), "MULTI_IP": (10, 20),
    "LINK_SUSPICIOUS": (15, 15), "LINK_ABUSED": (35, 35), "OLD_SESSION": (5, 5),
    "DLP_HIGH": (10, 10), "DLP_CRITICAL": (20, 20),
}


@dataclass(frozen=True)
class RiskEvent:
    code: str
    event_id: str


@dataclass(frozen=True)
class Reason:
    code: str
    points: int
    evidence_ids: tuple[str, ...]


@dataclass(frozen=True)
class RiskResult:
    score: int
    level: RiskLevel
    reasons: list[Reason] = field(default_factory=list)


def level_for(score: int) -> RiskLevel:
    if score >= 75:
        return RiskLevel.CRITICAL
    if score >= 50:
        return RiskLevel.HIGH
    if score >= 25:
        return RiskLevel.MEDIUM
    return RiskLevel.LOW


def evaluate_risk(events: list[RiskEvent]) -> RiskResult:
    grouped: dict[str, list[str]] = {}
    for e in events:
        if e.code not in RULES:
            raise ValueError(f"unknown risk signal {e.code!r}")
        grouped.setdefault(e.code, []).append(e.event_id)
    reasons = []
    for code, ids in sorted(grouped.items()):
        per, cap = RULES[code]
        reasons.append(Reason(code, min(per * len(ids), cap), tuple(ids)))
    score = min(sum(r.points for r in reasons), 100)
    return RiskResult(score, level_for(score), reasons)


# audit action -> threat-detection event kind (None = not a risk input).
# Keys MUST be the action strings the app actually writes (see services/*.py log_event calls);
# a key that nothing writes silently blinds the risk engine.
_AUDIT_KIND = {
    "USER_LOGIN_FAILED": "LOGIN_FAILED", "USER_LOGIN": "LOGIN_OK",
    "MFA_FAILED": "OTP_FAILED", "EMAIL_OTP_FAILED": "OTP_FAILED", "PHONE_CODE_FAIL": "OTP_FAILED",
    "SECURE_LINK_PASSWORD_FAIL": "OTP_FAILED", "SECURE_LINK_RECIPIENT_CODE_FAIL": "OTP_FAILED",
    "ACCESS_DENIED": "ACCESS_DENIED", "SECURE_LINK_DENIED": "ACCESS_DENIED", "SECURE_LINK_LOCKED": "ACCESS_DENIED",
    "DOCUMENT_DOWNLOAD": "DOWNLOAD", "SECURE_LINK_DOWNLOAD": "DOWNLOAD",
    "SECURE_LINK_CREATE": "SHARE_CREATED", "SHARE_CREATED": "SHARE_CREATED",
}


def score_events(events: list) -> dict[str, Any]:
    """Pure: SecEvents -> threat detection -> explainable score. Used for users and for links."""
    from app.security.threat_detection import detect, to_risk_events
    alerts = detect(events)
    result = evaluate_risk([RiskEvent(code, eid) for code, eid in to_risk_events(alerts)])
    return {
        "score": result.score,
        "level": result.level.value if hasattr(result.level, "value") else str(result.level),
        "reasons": [{"code": r.code, "points": r.points, "evidence_ids": list(r.evidence_ids)} for r in result.reasons],
        "alerts": [{"code": a.code, "severity": a.severity, "message": a.message,
                    "evidence_ids": list(a.evidence_ids)} for a in alerts],
        "events_considered": len(events),
    }


class RiskEngine:
    """DB-backed risk engine. Reads the user's real audit events from the last 24h, runs the
    threat-detection rules over them, and scores the resulting evidence with evaluate_risk().
    The score is a SIGNAL for the Zero-Trust PDP (app.services.zero_trust); it never grants access."""

    WINDOW_HOURS, MAX_EVENTS = 24, 500

    def __init__(self, db: "AsyncSession") -> None:
        self.db = db

    async def evaluate_user(self, user_id: str) -> dict[str, Any]:
        from datetime import datetime, timedelta, timezone

        from sqlalchemy import select

        from app.models.audit import AuditLog
        from app.security.threat_detection import SecEvent

        since = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(hours=self.WINDOW_HOURS)
        rows = (await self.db.scalars(
            select(AuditLog).where(AuditLog.user_id == user_id, AuditLog.created_at >= since,
                                   AuditLog.action.in_(list(_AUDIT_KIND)))
            .order_by(AuditLog.created_at.desc()).limit(self.MAX_EVENTS))).all()
        return score_events([SecEvent(id=r.id, kind=_AUDIT_KIND[r.action], at=r.created_at, user_id=user_id,
                                      ip=r.ip_address, device=r.user_agent, target=r.resource_id) for r in rows])

    async def evaluate_link(self, link_id: str, ip: str | None) -> dict[str, Any]:
        """Risk for an anonymous/recipient link redemption: this link's own failure/denial history
        plus any denial/OTP-failure events from the same IP in the window. Events are attributed to
        the link id so the per-subject burst rules in threat_detection apply."""
        from datetime import datetime, timedelta, timezone

        from sqlalchemy import or_, select

        from app.models.audit import AuditLog
        from app.security.threat_detection import SecEvent

        since = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(hours=self.WINDOW_HOURS)
        cond = AuditLog.resource_id == link_id
        if ip:
            cond = or_(cond, AuditLog.ip_address == ip)
        rows = (await self.db.scalars(
            select(AuditLog).where(cond, AuditLog.created_at >= since,
                                   AuditLog.action.in_(list(_AUDIT_KIND)))
            .order_by(AuditLog.created_at.desc()).limit(self.MAX_EVENTS))).all()
        return score_events([SecEvent(id=r.id, kind=_AUDIT_KIND[r.action], at=r.created_at, user_id=link_id,
                                      ip=r.ip_address, device=r.user_agent, target=r.resource_id) for r in rows])
