"""Policy simulator: runs the SAME pure PDP used in production on a hypothetical context."""
from __future__ import annotations

from dataclasses import asdict
from typing import Any

from app.services.policy_engine import AccessContext, Decision_, evaluate


def simulate(ctx: AccessContext) -> dict[str, Any]:
    d: Decision_ = evaluate(ctx)
    out = asdict(d)
    out["decision"] = d.decision.value
    out["dlp_level"] = d.dlp_level.value
    out["simulated"] = True
    return out
