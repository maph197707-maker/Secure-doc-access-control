"""Server-side authorization for document content. Every view/download goes through here.

Flow: load doc -> load grants from the DB NOW (never cached, so revocation is immediate) ->
RBAC + ABAC + expiry + revocation + risk via the zero-trust PDP -> audit -> allow/deny.
Admins are NOT implicitly allowed to read content: they need ownership or a grant (zero trust).
"""
from __future__ import annotations

from dataclasses import replace

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.enums import Decision, DlpLevel, Permission, RiskLevel
from app.core.exceptions import NotFoundError, PermissionDeniedError
from app.models.access_grant import AccessGrant
from app.models.document import Document
from app.models.user import User
from app.repositories.audit import AuditRepository
from app.services.risk import RiskEngine
from app.services.zero_trust import enforce_restrictions, risk_level_for
from app.services import grants_logic as gl


def role_permission_codes(user: User) -> set[str]:
    return {p.code for r in user.roles for p in r.permissions}


class AccessControlService:
    def __init__(self, db: AsyncSession) -> None:
        self.db = db
        self.audit = AuditRepository(db)

    async def grants_for(self, doc_id: str, user_id: str) -> list[AccessGrant]:
        res = await self.db.execute(select(AccessGrant).where(
            AccessGrant.document_id == doc_id, AccessGrant.grantee_id == user_id))
        return list(res.scalars().all())

    async def authorize(self, user: User, doc: Document, action: Permission, *,
                        ip: str | None = None, user_agent: str | None = None,
                        mfa_verified: bool = False, correlation_id: str = "") -> gl.AccessOutcome:
        now = gl.utcnow()
        is_owner = doc.owner_id == user.id
        grants = [] if is_owner else await self.grants_for(doc.id, user.id)
        try:
            dlp = DlpLevel(doc.dlp_level)
        except ValueError:
            dlp = DlpLevel.NONE
        # Live risk signal from the user's recent audit events. No default score: if the engine cannot
        # answer, risk is unknown and the PDP is told CRITICAL, so access is denied.
        try:
            risk_score = int((await RiskEngine(self.db).evaluate_user(user.id))["score"])
        except Exception:                                  # noqa: BLE001
            risk_score = 100
        outcome = gl.decide(
            action=action, now=now, is_owner=is_owner, user_status_active=user.is_active,
            email_verified=user.email_verified, role_permissions=role_permission_codes(user),
            grants=grants, dlp_level=dlp, risk_score=risk_score, risk_level=risk_level_for(risk_score),
            classification=doc.classification,
            mfa_verified=mfa_verified, correlation_id=correlation_id)
        # a RESTRICT that forbids the requested action (e.g. download at HIGH risk) is a DENY here
        outcome = replace(outcome, decision=enforce_restrictions(outcome.decision, action))
        d = outcome.decision
        await self.audit.log_event(
            action=f"DOCUMENT_{action.value}" if outcome.allowed else "ACCESS_DENIED",
            user_id=user.id, resource_type="document", resource_id=doc.id,
            ip_address=ip, user_agent=user_agent,
            details={"requested": action.value, "decision": d.decision.value,
                     "reasons": outcome.reasons, "restrictions": d.restrictions,
                     "risk_score": d.risk_score})
        return outcome

    async def require(self, user: User, doc: Document, action: Permission, **kw) -> gl.AccessOutcome:
        out = await self.authorize(user, doc, action, **kw)
        if not out.allowed:
            # persisted by the caller's commit (see api layer); reasons help the UI explain
            raise PermissionDeniedError(
                "Access denied." if out.decision.decision == Decision.DENY else "Additional verification required.",
                details={"decision": out.decision.decision.value, "reasons": out.reasons,
                         "required_actions": out.decision.required_actions})
        return out


async def get_document_or_404(db: AsyncSession, doc_id: str) -> Document:
    res = await db.execute(select(Document).where(Document.id == doc_id, Document.is_deleted == False))  # noqa: E712
    doc = res.scalar_one_or_none()
    if not doc:
        raise NotFoundError("Document not found.")
    return doc
