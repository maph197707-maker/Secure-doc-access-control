"""Tamper-evident audit chain: hash_n = SHA3-256(hash_{n-1} || canonical_json(event_n)),
optional HMAC seal with a separate HKDF-derived audit key, and a Merkle root for daily anchoring.
DB persistence (append-only repository) wraps these pure functions."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any, Sequence

from app.crypto.hashing import constant_time_equal, hmac_sha256

GENESIS = "0" * 64


def canonical_json(event: dict[str, Any]) -> bytes:
    return json.dumps(event, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode()


def chain_hash(prev_hash: str, event: dict[str, Any]) -> str:
    return hashlib.sha3_256(prev_hash.encode() + canonical_json(event)).hexdigest()


def seal(audit_key: bytes, seq: int, digest: str) -> str:
    return hmac_sha256(audit_key, f"{seq}|{digest}".encode()).hex()


def make_record(prev: dict[str, Any] | None, event: dict[str, Any], audit_key: bytes | None = None) -> dict[str, Any]:
    seq = 1 if prev is None else prev["seq"] + 1
    prev_hash = GENESIS if prev is None else prev["hash"]
    h = chain_hash(prev_hash, event)
    return {"seq": seq, "event": event, "prev_hash": prev_hash, "hash": h,
            "seal": seal(audit_key, seq, h) if audit_key else None}


@dataclass(frozen=True)
class VerifyResult:
    ok: bool
    checked: int
    broken_at: int | None = None
    reason: str = ""


def verify_chain(records: Sequence[dict[str, Any]], audit_key: bytes | None = None) -> VerifyResult:
    prev_hash, expected_seq = GENESIS, 1
    for r in records:
        if r["seq"] != expected_seq:
            return VerifyResult(False, expected_seq - 1, r["seq"], "sequence gap or reorder (deletion suspected)")
        if r["prev_hash"] != prev_hash:
            return VerifyResult(False, expected_seq - 1, r["seq"], "previous-hash link broken")
        if not constant_time_equal(chain_hash(prev_hash, r["event"]), r["hash"]):
            return VerifyResult(False, expected_seq - 1, r["seq"], "event content modified")
        if audit_key and not constant_time_equal(seal(audit_key, r["seq"], r["hash"]), r.get("seal") or ""):
            return VerifyResult(False, expected_seq - 1, r["seq"], "HMAC seal invalid")
        prev_hash, expected_seq = r["hash"], expected_seq + 1
    return VerifyResult(True, len(records))


def merkle_root(hashes: Sequence[str]) -> str:
    if not hashes:
        return GENESIS
    level = [bytes.fromhex(h) for h in hashes]
    while len(level) > 1:
        if len(level) % 2:
            level.append(level[-1])
        level = [hashlib.sha3_256(level[i] + level[i + 1]).digest() for i in range(0, len(level), 2)]
    return level[0].hex()


def event_payload(seq: int, action: str, user_id, resource_type, resource_id, details) -> dict[str, Any]:
    """The exact dict that is hashed for a persisted audit row (single source of truth for the
    writer and the verifier)."""
    return {"seq": seq, "action": action, "user_id": user_id, "resource_type": resource_type,
            "resource_id": resource_id, "details": details or {}}


def rows_to_records(rows: Sequence[Any]) -> list[dict[str, Any]]:
    """Convert AuditLog-like rows (ordered by sequence_number) to verify_chain() records."""
    return [{"seq": r.sequence_number,
             "event": event_payload(r.sequence_number, r.action, r.user_id, r.resource_type,
                                    r.resource_id, r.details),
             "prev_hash": r.prev_hash, "hash": r.entry_hash, "seal": getattr(r, "seal", None)}
            for r in rows]
