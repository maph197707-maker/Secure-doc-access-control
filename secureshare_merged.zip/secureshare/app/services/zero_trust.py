"""Zero-Trust facade: RBAC + ABAC attribute enrichment around the pure PDP in policy_engine.

`decide()` is the single authorization entry point for documents, viewer and shares. The PDP's
answer (ALLOW / DENY / RESTRICT / VERIFY) is final: nothing here, and no AI component, can
upgrade a DENY. Server-side only; hiding UI buttons is never the control.
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime

from app.core.enums import Classification, Decision, DlpLevel, Permission, RiskLevel
from app.services.policy_engine import AccessContext, Decision_, evaluate

_DOC = ["DOCUMENT_VIEW", "DOCUMENT_DOWNLOAD", "DOCUMENT_UPLOAD", "DOCUMENT_EDIT", "DOCUMENT_DELETE",
        "DOCUMENT_SHARE", "DOCUMENT_RESHARE", "DOCUMENT_REVOKE", "DOCUMENT_SIGN", "DOCUMENT_VERIFY"]

ROLE_PERMISSIONS: dict[str, frozenset[str]] = {
    "USER": frozenset(_DOC),
    "MANAGER": frozenset(_DOC + ["AUDIT_VIEW", "SECURITY_VIEW", "ANALYTICS_VIEW"]),
    "ADMIN": frozenset(_DOC + ["AUDIT_VIEW", "SECURITY_VIEW", "ANALYTICS_VIEW",
                               "USER_MANAGE", "POLICY_MANAGE", "SYSTEM_MANAGE"]),
}
# Admin-surface permissions, e.g. MANAGE_USERS -> USER_MANAGE
ADMIN_ACTIONS = {"MANAGE_USERS": "USER_MANAGE", "MANAGE_SECURITY": "POLICY_MANAGE",
                 "MANAGE_SETTINGS": "SYSTEM_MANAGE"}


def role_permissions(role: str) -> frozenset[str]:
    return ROLE_PERMISSIONS.get((role or "").upper(), frozenset())   # unknown role -> nothing


def has_permission(role: str, permission: str) -> bool:
    return ADMIN_ACTIONS.get(permission, permission) in role_permissions(role)


def risk_level_for(score: int) -> RiskLevel:
    return (RiskLevel.CRITICAL if score >= 75 else RiskLevel.HIGH if score >= 50
            else RiskLevel.MEDIUM if score >= 25 else RiskLevel.LOW)


def apply_abac(ctx: AccessContext, *, classification: Classification | str | None = None,
               auth_strength: str = "PASSWORD") -> AccessContext:
    """Attribute rules: classification and authentication strength raise the bar.
    RESTRICTED needs MFA; TOP_SECRET needs MFA and a trusted device. Never lowers anything."""
    c = Classification(classification) if classification else None
    changes: dict[str, object] = {}
    if c in (Classification.RESTRICTED, Classification.TOP_SECRET):
        changes["mfa_required"] = True
    if c == Classification.TOP_SECRET:
        changes["device_required"] = True
    if auth_strength.upper() in ("MFA", "STRONG"):
        changes["mfa_verified"] = True
    return replace(ctx, **changes) if changes else ctx


def decide(ctx: AccessContext, *, role: str | None = None, risk_score: int | None = None,
           classification: Classification | str | None = None, dlp_level: DlpLevel | None = None,
           auth_strength: str = "PASSWORD") -> Decision_:
    """Enrich the context (role perms, risk, ABAC) and ask the PDP. Server-side only."""
    changes: dict[str, object] = {}
    if role is not None:
        changes["role_permissions"] = role_permissions(role)
    if risk_score is not None:
        changes.update(risk_score=risk_score, risk_level=risk_level_for(risk_score))
    if dlp_level is not None:
        changes["dlp_level"] = dlp_level
    ctx = apply_abac(replace(ctx, **changes) if changes else ctx,
                     classification=classification, auth_strength=auth_strength)
    return evaluate(ctx)


_RESTRICTION_KEY = {Permission.DOWNLOAD: "download", Permission.PRINT: "print",
                    Permission.COPY: "copy", Permission.RESHARE: "reshare"}


def enforce_restrictions(decision: Decision_, action: Permission) -> Decision_:
    """A RESTRICT that forbids the REQUESTED action becomes DENY. Never upgrades anything."""
    if decision.decision != Decision.RESTRICT:
        return decision
    key = _RESTRICTION_KEY.get(action)
    if key is not None and decision.restrictions.get(key) is False:
        return replace(decision, decision=Decision.DENY, reasons=[f"RESTRICTED_{key.upper()}"],
                       required_actions=[], restrictions={})
    return decision
