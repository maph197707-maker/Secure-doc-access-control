"""Authentication and account lifecycle service."""
from __future__ import annotations

import secrets
from urllib.parse import quote
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.config.constants import (
    AUDIT_EMAIL_VERIFIED,
    AUDIT_MFA_FAILED,
    AUDIT_MFA_RECOVERY_USED,
    AUDIT_PASSWORD_RESET_REQUEST,
    AUDIT_PASSWORD_RESET_SUCCESS,
    AUDIT_USER_LOGIN,
    AUDIT_USER_LOGIN_FAILED,
    AUDIT_USER_REGISTER,
)
from app.config.settings import get_settings
from app.core.enums import RoleName, UserStatus
from app.core.exceptions import (
    AuthenticationError,
    ConflictError,
    LockoutError,
    NotFoundError,
    PermissionDeniedError,
    ProviderUnavailableError,
    RateLimitExceededError,
    ValidationError,
    MfaRequiredError,
)
from app.crypto.password import hash_password, password_problems, verify_password
from app.crypto.tokens import new_token, token_hash
from app.integrations import factory
from app.integrations.email import EmailDeliveryError, EmailService
from app.integrations.state import StateStore, get_state_store
from app.integrations.oauth import Profile, link_decision
from app.models.auth import LoginHistory, PasswordReset
from app.models.oauth_account import OAuthAccount
from app.models.role import Role
from app.models.session import UserSession
from app.models.user import User
from app.models.user_preference import UserPreference
from app.repositories.audit import AuditRepository
from app.repositories.user import UserRepository
from app.services import mfa
from app.services.otp import OtpPurpose, OtpResult, OtpService, SendReceipt
from app.services.rate_limiter import LoginThrottle
from app.services.sessions import SessionService

# Resend quotas (fixed one-hour window, shared StateStore). Counted for every request, whether or
# not the address belongs to an account, so the limit itself is not an account-existence oracle.
RESENDS_PER_HOUR_EMAIL = 10
RESENDS_PER_HOUR_IP = 30
RESEND_WINDOW = 3600
GUEST_EMAIL_DOMAIN = "guest.example.com"   # guest accounts can never receive mail
GUESTS_PER_HOUR_IP = 20


def is_guest_user(user: User) -> bool:
    """Guest accounts are the ones created by guest_login(); their address can never receive mail."""
    return (user.email or "").lower().endswith("@" + GUEST_EMAIL_DOMAIN)


@dataclass(frozen=True)
class OtpDelivery:
    """A verification code the email provider accepted. Built only after the send succeeded; it never
    carries the code itself."""

    channel: str
    destination: str                # masked address, safe to show

    @property
    def message(self) -> str:
        return "A verification code has been sent to your email."


class AuthService:
    def __init__(self, db: AsyncSession, store: StateStore | None = None,
                 email_service: EmailService | None = None) -> None:
        self.db = db
        self._email = email_service
        self.settings = get_settings()
        self.store = store or get_state_store()
        self.user_repo = UserRepository(db)
        self.audit_repo = AuditRepository(db)
        self.session_service = SessionService(db, self.store)
        self.throttle = LoginThrottle(self.store)
        self._otp = OtpService(db, self.settings)
        self._otp_key = self.settings.master_secret.encode()   # password-reset token hashing (unchanged)

    async def register(
        self,
        email: str,
        password: str,
        full_name: str,
        phone: str | None = None,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ) -> tuple[User, OtpDelivery | None]:
        email = email.strip().lower()
        if email.endswith("@" + GUEST_EMAIL_DOMAIN):
            raise ValidationError("This email domain is reserved. Please use your own email address.")

        # Check existing user
        existing = await self.user_repo.get_by_email(email)
        if existing:
            raise ConflictError("A user with this email address already exists.")

        # Password rules
        problems = password_problems(password)
        if problems:
            raise ValidationError(problems[0])

        # Password hash
        h_pw = hash_password(password)

        # Get or assign default role
        stmt_role = select(Role).where(Role.name == RoleName.USER.value)
        res_role = await self.db.execute(stmt_role)
        role = res_role.scalar_one_or_none()

        user = User(
            email=email,
            full_name=full_name.strip(),
            phone=phone.strip() if phone else None,
            hashed_password=h_pw,
            status=(UserStatus.PENDING_VERIFICATION.value if self.settings.signup_email_verification_required
                    else UserStatus.ACTIVE.value),
            email_verified=False,
        )
        if role:
            user.roles.append(role)

        pref = UserPreference(user=user, theme="system", onboarding_seen=False)
        self.db.add(user)
        self.db.add(pref)
        await self.db.flush()
        await self.db.refresh(user, attribute_names=["roles"])

        if not self.settings.signup_email_verification_required:
            # No email is sent at sign-up. The account is active but its email (and phone) stay
            # UNVERIFIED until the person proves them later from /profile; nothing is marked verified.
            await self.audit_repo.log_event(
                action=AUDIT_USER_REGISTER, user_id=user.id, resource_type="user", resource_id=user.id,
                ip_address=ip_address, user_agent=user_agent,
                details={"email": email, "otp_delivery": None, "verification": "deferred"},
            )
            return user, None

        # Create the OTP, persist only its hash, then send it. Nothing is committed here: if delivery
        # fails OtpService rolls the half-created account back (audited) and raises, so the user can
        # simply retry; the code is only ever "sent" if the SMTP provider accepted it.
        delivery = await self._send_email_otp(user.id, email, ip_address, user_agent, rollback_on_failure=True)

        # Audit
        await self.audit_repo.log_event(
            action=AUDIT_USER_REGISTER,
            user_id=user.id,
            resource_type="user",
            resource_id=user.id,
            ip_address=ip_address,
            user_agent=user_agent,
            details={"email": email, "otp_delivery": delivery.channel},
        )

        return user, delivery

    def _email_service(self) -> EmailService:
        if self._email is None:
            self._email = factory.get_email_service()
        if self._email is None:
            # Never fall back to a fake sender: without real SMTP no verification code can be delivered.
            raise ProviderUnavailableError("Email delivery is not configured on this server.", reason="misconfigured")
        return self._email

    async def _send_email_otp(self, user_id: str, email: str, ip: str | None, ua: str | None, *,
                              rollback_on_failure: bool = False) -> OtpDelivery:
        try:
            svc = self._email_service()
        except ProviderUnavailableError:
            if rollback_on_failure:
                await self.db.rollback()
            raise
        receipt: SendReceipt = await self._otp.send(
            purpose=OtpPurpose.EMAIL_VERIFY, subject=user_id, destination=email, channel="email",
            deliver=lambda code, minutes: svc.send_otp(email, code, minutes),
            user_id=user_id, ip=ip, user_agent=ua, rollback_on_failure=rollback_on_failure)
        return OtpDelivery(channel="email", destination=receipt.destination_hint)

    async def verify_email(
        self,
        email: str,
        code: str,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ) -> bool:
        """Backend-only verification: the decision comes from the persisted, hashed challenge."""
        email = email.strip().lower()
        user = await self.user_repo.get_by_email(email)
        if not user:
            # Same status + message as a wrong code, so this endpoint cannot be used to learn which
            # addresses are registered (resend-verification already behaves this way).
            raise ValidationError("Invalid verification code. Please check and try again.")

        result = await self._otp.verify(purpose=OtpPurpose.EMAIL_VERIFY, subject=user.id, destination=email,
                                        code=code, user_id=user.id, ip=ip_address, user_agent=user_agent)
        if result == OtpResult.LOCKED:
            raise LockoutError("Too many failed attempts. Please request a new code.", retry_after=60)
        if result in (OtpResult.EXPIRED, OtpResult.NOT_FOUND):
            raise ValidationError("Verification code expired. Please request a new one.")
        if result == OtpResult.USED:
            raise ValidationError("This verification code was already used. Please request a new one.")
        if result == OtpResult.WRONG:
            raise ValidationError("Invalid verification code. Please check and try again.")

        user.email_verified = True
        if user.status == UserStatus.PENDING_VERIFICATION.value:    # never re-activate a suspended account
            user.status = UserStatus.ACTIVE.value
        await self.db.flush()
        await self.audit_repo.log_event(
            action=AUDIT_EMAIL_VERIFIED,
            user_id=user.id,
            resource_type="user",
            resource_id=user.id,
            ip_address=ip_address,
            user_agent=user_agent,
        )
        return True

    async def resend_email_verification(self, email: str, ip_address: str | None = None,
                                        user_agent: str | None = None) -> OtpDelivery | None:
        """Issue a NEW code and deliver it. The previous code is superseded, the cooldown and hourly
        quotas are enforced from persisted state, and a failed delivery leaves no live code behind.
        Returns None (without revealing why) for unknown or already-verified addresses."""
        email = email.strip().lower()
        if self.store.incr(f"otpresend:e:{email}", RESEND_WINDOW) > RESENDS_PER_HOUR_EMAIL or (
                ip_address and self.store.incr(f"otpresend:ip:{ip_address}", RESEND_WINDOW) > RESENDS_PER_HOUR_IP):
            raise RateLimitExceededError("Too many codes requested. Please try again later.",
                                         retry_after=RESEND_WINDOW)

        user = await self.user_repo.get_by_email(email)
        if not user or user.email_verified:
            return None
        return await self._send_email_otp(user.id, email, ip_address, user_agent)

    async def send_profile_email_code(self, user: User, ip_address: str | None = None,
                                      user_agent: str | None = None) -> OtpDelivery:
        """Signed-in user asks for a code for THEIR address (profile page). Raises DeliveryError /
        ProviderUnavailableError when SMTP is missing or fails; a code is only ever 'sent' if the
        provider accepted it."""
        if is_guest_user(user):
            raise ValidationError("Guest accounts have no real email address. Create an account to verify one.")
        if user.email_verified:
            raise ValidationError("Your email is already verified.")
        if self.store.incr(f"otpresend:e:{user.email}", RESEND_WINDOW) > RESENDS_PER_HOUR_EMAIL or (
                ip_address and self.store.incr(f"otpresend:ip:{ip_address}", RESEND_WINDOW) > RESENDS_PER_HOUR_IP):
            raise RateLimitExceededError("Too many codes requested. Please try again later.",
                                         retry_after=RESEND_WINDOW)
        return await self._send_email_otp(user.id, user.email, ip_address, user_agent)

    async def guest_login(
        self,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ) -> tuple[User, UserSession, str]:
        """Create a throw-away, pre-verified ordinary USER account and sign it in (no registration).

        Disabled unless GUEST_LOGIN_ENABLED (default: dev only). The account has a random password
        nobody knows, is never an admin, and is rate limited per IP."""
        if not self.settings.guest_login_active:
            raise PermissionDeniedError("Guest access is not enabled on this server.")
        if ip_address and self.store.incr(f"guest:ip:{ip_address}", 3600) > GUESTS_PER_HOUR_IP:
            raise RateLimitExceededError("Too many guest sessions from this address. Try again later.",
                                         retry_after=3600)
        role = (await self.db.execute(select(Role).where(Role.name == RoleName.USER.value))).scalar_one_or_none()
        user = User(
            email=f"guest-{secrets.token_hex(6)}@{GUEST_EMAIL_DOMAIN}",
            full_name="Guest",
            hashed_password=hash_password(new_token(32)),
            status=UserStatus.ACTIVE.value,
            email_verified=True,
        )
        if role:
            user.roles.append(role)
        self.db.add(user)
        self.db.add(UserPreference(user=user, theme="system", onboarding_seen=False))
        await self.db.flush()
        await self.db.refresh(user, attribute_names=["roles"])
        session, raw_token = await self.session_service.create_session(
            user=user, ip_address=ip_address, user_agent=user_agent)
        await self.audit_repo.log_event(
            action="GUEST_LOGIN", user_id=user.id, resource_type="user", resource_id=user.id,
            ip_address=ip_address, user_agent=user_agent, details={"guest": True},
        )
        return user, session, raw_token

    async def login(
        self,
        email: str,
        password: str,
        ip_address: str | None = None,
        user_agent: str | None = None,
        device_fingerprint: str | None = None,
        remember_me: bool = False,
    ) -> tuple[User, UserSession, str]:
        email = email.strip().lower()

        # 1. Lockout check
        locked_sec = self.throttle.locked_for(email)
        if locked_sec > 0:
            await self.audit_repo.log_event(
                action=AUDIT_USER_LOGIN_FAILED,
                user_id=None,
                resource_type="user",
                ip_address=ip_address,
                user_agent=user_agent,
                details={"email": email, "reason": "account_locked", "retry_after": locked_sec},
            )
            raise LockoutError(
                f"Account is temporarily locked. Try again in {locked_sec} seconds.",
                retry_after=locked_sec,
            )

        # 2. Find user
        user = await self.user_repo.get_by_email(email)
        if not user:
            self.throttle.record_failure(email)
            raise AuthenticationError("Invalid email or password.")

        if user.status == UserStatus.SUSPENDED.value or user.is_deleted:
            raise PermissionDeniedError("Your account has been suspended.")

        # 3. Verify password
        if not verify_password(user.hashed_password, password):
            user.failed_login_count += 1
            lock_secs = self.throttle.record_failure(email)

            lh = LoginHistory(
                user_id=user.id,
                ip_address=ip_address,
                user_agent=user_agent,
                success=False,
                failure_reason="invalid_password",
            )
            self.db.add(lh)

            now = datetime.now(timezone.utc).replace(tzinfo=None)
            if lock_secs > 0:
                user.locked_until = now + timedelta(seconds=lock_secs)

            await self.db.flush()
            if lock_secs > 0:
                from app.services.notifications import ACCOUNT_LOCKED, safe_notify
                await safe_notify(self.db, user.id, ACCOUNT_LOCKED, "Account temporarily locked",
                                  "Too many failed sign-in attempts. Sign-in is paused for a short time.",
                                  "user", user.id)

            await self.audit_repo.log_event(
                action=AUDIT_USER_LOGIN_FAILED,
                user_id=user.id,
                resource_type="user",
                resource_id=user.id,
                ip_address=ip_address,
                user_agent=user_agent,
                details={"reason": "invalid_password", "attempts": user.failed_login_count},
            )

            if lock_secs > 0:
                raise LockoutError(
                    f"Too many failed login attempts. Locked for {lock_secs} seconds.",
                    retry_after=lock_secs,
                )
            raise AuthenticationError("Invalid email or password.")

        # 3a. Email must be proven first when sign-up verification is required (status stays PENDING until then)
        if user.status == UserStatus.PENDING_VERIFICATION.value and not user.email_verified:
            raise PermissionDeniedError("Please verify your email address first. Enter the code we sent you, "
                                        "or request a new one on the verification page.")

        # 3b. Second factor (only for accounts that turned MFA on; it is optional per account).
        if user.mfa_enabled and user.totp_secret:
            cid = mfa.open_challenge(self.store, user.id)
            self.store.set(f"mfa:ctx:{cid}", {"remember_me": bool(remember_me)}, mfa.CHALLENGE_TTL)
            raise MfaRequiredError(cid)

        return await self._finish_login(user, ip_address, user_agent, remember_me)

    async def oauth_login(
        self,
        profile: Profile,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ) -> tuple[User, UserSession, str]:
        """Google / Microsoft sign-in, second half (after the provider proved the identity).

        1. known (provider, subject)           -> sign that user in
        2. verified email matches a local user -> link the identity to it (see below), sign in
        3. otherwise                           -> create an ACTIVE, email-verified account, sign in
        If the local account has MFA on, the authenticator step is still required (MfaRequiredError).

        Account-takeover guard: a provider-verified email is proof the visitor owns the address. If the
        EXISTING local account never proved that address, somebody else may have pre-registered it and
        know its password, so linking also invalidates that password and ends its sessions."""
        email = profile.email.strip().lower()
        if email.endswith("@" + GUEST_EMAIL_DOMAIN):
            raise ValidationError("This email domain is reserved.")

        linked = (await self.db.execute(
            select(OAuthAccount).where(OAuthAccount.provider == profile.provider,
                                       OAuthAccount.provider_account_id == profile.subject))).scalar_one_or_none()
        by_email = None if linked else await self.user_repo.get_by_email(email)
        decision = link_decision(profile, linked is not None, by_email is not None, False)

        if decision == "REJECT_UNVERIFIED" and by_email is None and profile.provider == "microsoft":
            # Microsoft work/school tenants do not guarantee the email claim. Creating a NEW account is
            # safe (nothing to take over) but its email stays unverified; linking is never allowed.
            decision = "CREATE"
        if decision == "REJECT_UNVERIFIED":
            raise AuthenticationError("The provider could not confirm that you own this email address.")

        newly_created = False
        if decision == "LOGIN":
            user = await self.user_repo.get_by_id(linked.user_id)
            if user is None:
                raise AuthenticationError("This sign-in is no longer valid.")
        elif decision in ("LINK", "CONFIRM_REQUIRED"):
            user = by_email
            if not user.email_verified:
                user.hashed_password = hash_password(new_token(32))
                user.email_verified = True
                await self.session_service.revoke_other_sessions(user.id, "")
            self.db.add(OAuthAccount(user_id=user.id, provider=profile.provider,
                                     provider_account_id=profile.subject, email=email))
        else:   # CREATE
            role = (await self.db.execute(select(Role).where(Role.name == RoleName.USER.value))).scalar_one_or_none()
            user = User(
                email=email,
                full_name=(profile.name or email.split("@")[0]).strip()[:255],
                hashed_password=hash_password(new_token(32)),    # random: password login is off until they reset it
                status=UserStatus.ACTIVE.value,
                email_verified=bool(profile.email_verified),
            )
            if role:
                user.roles.append(role)
            self.db.add(user)
            self.db.add(UserPreference(user=user, theme="system", onboarding_seen=False))
            await self.db.flush()
            await self.db.refresh(user, attribute_names=["roles"])
            self.db.add(OAuthAccount(user_id=user.id, provider=profile.provider,
                                     provider_account_id=profile.subject, email=email))
            newly_created = True
            await self.audit_repo.log_event(
                action=AUDIT_USER_REGISTER, user_id=user.id, resource_type="user", resource_id=user.id,
                ip_address=ip_address, user_agent=user_agent,
                details={"email": email, "oauth_provider": profile.provider})

        if user.status == UserStatus.SUSPENDED.value or user.is_deleted:
            raise PermissionDeniedError("Your account has been suspended.")
        if user.status == UserStatus.PENDING_VERIFICATION.value and profile.email_verified:
            user.status = UserStatus.ACTIVE.value
        await self.db.flush()
        await self.audit_repo.log_event(
            action="OAUTH_LOGIN", user_id=user.id, resource_type="user", resource_id=user.id,
            ip_address=ip_address, user_agent=user_agent,
            details={"provider": profile.provider, "decision": decision, "new_account": newly_created})

        if user.mfa_enabled and user.totp_secret:
            cid = mfa.open_challenge(self.store, user.id)
            self.store.set(f"mfa:ctx:{cid}", {"remember_me": False}, mfa.CHALLENGE_TTL)
            raise MfaRequiredError(cid)
        return await self._finish_login(user, ip_address, user_agent, False)

    async def _finish_login(self, user: User, ip_address: str | None, user_agent: str | None,
                            remember_me: bool) -> tuple[User, UserSession, str]:
        """Everything that happens once ALL required factors passed: reset throttles, history,
        session, audit. Shared by the password-only path and the MFA completion path."""
        email = user.email
        # 4. Success — reset throttle & failure count
        self.throttle.record_success(email)
        user.failed_login_count = 0
        user.locked_until = None
        user.last_login_at = datetime.now(timezone.utc).replace(tzinfo=None)

        lh = LoginHistory(
            user_id=user.id,
            ip_address=ip_address,
            user_agent=user_agent,
            success=True,
        )
        self.db.add(lh)
        await self.db.flush()

        # 5. Create Session
        session, raw_token = await self.session_service.create_session(
            user=user,
            ip_address=ip_address,
            user_agent=user_agent,
            remember_me=remember_me,
        )

        # 6. Audit
        await self.audit_repo.log_event(
            action=AUDIT_USER_LOGIN,
            user_id=user.id,
            resource_type="session",
            resource_id=session.id,
            ip_address=ip_address,
            user_agent=user_agent,
        )

        return user, session, raw_token

    async def complete_mfa_login(
        self, challenge_id: str, code: str, ip_address: str | None = None, user_agent: str | None = None,
    ) -> tuple[User, UserSession, str]:
        """Second step of login: authenticator code (6 digits) or a single-use recovery code."""
        user_id = mfa.resolve_challenge(self.store, challenge_id) if challenge_id else None
        if not user_id:
            raise AuthenticationError("This sign-in attempt expired. Please sign in again.")
        user = await self.user_repo.get_by_id(user_id)
        if (not user or user.is_deleted or user.status == UserStatus.SUSPENDED.value
                or not user.totp_secret):
            raise AuthenticationError("This sign-in attempt is no longer valid. Please sign in again.")

        ok = False
        used_recovery = False
        if mfa.looks_like_totp(code):
            secret = mfa.open_secret(user.totp_secret, self.settings.master_secret, user.id)
            if secret is None:
                raise AuthenticationError("Two-factor data could not be read. Contact an administrator.")
            res = mfa.verify_totp(self.store, user.id, secret, code.replace(" ", ""))
            if res == mfa.MfaResult.LOCKED:
                raise LockoutError("Too many wrong codes. Try again in 15 minutes.", retry_after=mfa.LOCK_SECONDS)
            ok = res == mfa.MfaResult.OK
        else:
            if self.store.get(f"mfa:lock:{user.id}"):
                raise LockoutError("Too many wrong codes. Try again in 15 minutes.", retry_after=mfa.LOCK_SECONDS)
            ok, remaining = mfa.consume_recovery_code(list(user.recovery_codes or []), code or "")
            if ok:
                user.recovery_codes = remaining          # single use: the matching hash is gone
                used_recovery = True
            elif self.store.incr(f"mfa:att:{user.id}", mfa.LOCK_SECONDS) >= mfa.MAX_ATTEMPTS:
                self.store.set(f"mfa:lock:{user.id}", True, mfa.LOCK_SECONDS)
                raise LockoutError("Too many wrong codes. Try again in 15 minutes.", retry_after=mfa.LOCK_SECONDS)

        if not ok:
            await self.audit_repo.log_event(
                action=AUDIT_MFA_FAILED, user_id=user.id, resource_type="user", resource_id=user.id,
                ip_address=ip_address, user_agent=user_agent, details={"reason": "wrong_or_replayed_code"})
            raise AuthenticationError("That code is not valid. Check your authenticator app and try again.")

        ctx = self.store.get(f"mfa:ctx:{challenge_id}") or {}
        mfa.close_challenge(self.store, challenge_id)
        self.store.delete(f"mfa:ctx:{challenge_id}")
        if used_recovery:
            await self.audit_repo.log_event(
                action=AUDIT_MFA_RECOVERY_USED, user_id=user.id, resource_type="user", resource_id=user.id,
                ip_address=ip_address, user_agent=user_agent,
                details={"codes_left": len(user.recovery_codes or [])})
        return await self._finish_login(user, ip_address, user_agent, bool(ctx.get("remember_me")))


    async def logout(
        self,
        session_id: str,
        user_id: str,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ) -> None:
        await self.session_service.revoke_session(session_id, reason="user_logout")
        await self.audit_repo.log_event(
            action="USER_LOGOUT",
            user_id=user_id,
            resource_type="session",
            resource_id=session_id,
            ip_address=ip_address,
            user_agent=user_agent,
        )

    async def request_password_reset(
        self, email: str, ip_address: str | None = None, user_agent: str | None = None,
        base_url: str | None = None,
    ) -> str | None:
        """Create a single-use reset token and e-mail the link. Returns the raw token (or None for an
        unknown address). Delivery being unavailable is a server condition, identical for every address,
        so it is reported (ProviderUnavailableError); a failed send to one real address is audited and
        not revealed, so the response cannot be used to learn which addresses have accounts."""
        email = email.strip().lower()
        mailer = self._email_service()                      # same answer for every address
        user = await self.user_repo.get_by_email(email)
        if not user or is_guest_user(user):
            return None

        raw_token = new_token(32)
        h_token = token_hash(raw_token, self._otp_key)
        now = datetime.now(timezone.utc).replace(tzinfo=None)

        pr = PasswordReset(
            user_id=user.id,
            token_hash=h_token,
            expires_at=now + timedelta(hours=1),
        )
        self.db.add(pr)
        await self.db.flush()

        await self.audit_repo.log_event(
            action=AUDIT_PASSWORD_RESET_REQUEST,
            user_id=user.id,
            resource_type="user",
            resource_id=user.id,
            ip_address=ip_address,
            user_agent=user_agent,
        )
        base = (base_url or self.settings.public_base_url).rstrip("/")
        link = f"{base}/reset-password?token={quote(raw_token, safe='')}&email={quote(email, safe='')}"
        try:
            mailer.send_password_reset(email, link, 60)
        except EmailDeliveryError as exc:
            await self.audit_repo.log_event(
                action="PASSWORD_RESET_DELIVERY_FAILED", user_id=user.id, resource_type="user", resource_id=user.id,
                ip_address=ip_address, user_agent=user_agent, details={"reason": str(exc.reason)})
        return raw_token

    async def confirm_password_reset(
        self,
        email: str,
        raw_token: str,
        new_password: str,
        ip_address: str | None = None,
        user_agent: str | None = None,
    ) -> bool:
        email = email.strip().lower()
        user = await self.user_repo.get_by_email(email)
        if not user:
            raise NotFoundError("User not found.")

        problems = password_problems(new_password)
        if problems:
            raise ValidationError(problems[0])

        h_token = token_hash(raw_token, self._otp_key)
        now = datetime.now(timezone.utc).replace(tzinfo=None)

        stmt = (
            select(PasswordReset)
            .where(
                PasswordReset.user_id == user.id,
                PasswordReset.token_hash == h_token,
                PasswordReset.used_at == None,
                PasswordReset.expires_at > now,
            )
            .order_by(PasswordReset.created_at.desc())
            .limit(1)
        )
        res = await self.db.execute(stmt)
        pr = res.scalar_one_or_none()

        if not pr:
            raise ValidationError("Password reset token is invalid or expired.")

        pr.used_at = now
        user.hashed_password = hash_password(new_password)
        if not user.email_verified:                      # the reset link went to this mailbox: it proves ownership
            user.email_verified = True
            if user.status == UserStatus.PENDING_VERIFICATION.value:
                user.status = UserStatus.ACTIVE.value
        await self.db.flush()

        # Revoke all existing sessions for security
        await self.session_service.revoke_other_sessions(user.id, "")

        await self.audit_repo.log_event(
            action=AUDIT_PASSWORD_RESET_SUCCESS,
            user_id=user.id,
            resource_type="user",
            resource_id=user.id,
            ip_address=ip_address,
            user_agent=user_agent,
        )

        return True
