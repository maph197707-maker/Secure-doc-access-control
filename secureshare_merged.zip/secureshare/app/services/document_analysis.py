"""Document analysis pipeline run on every upload (and on demand for a rescan).

    bytes -> text extraction (OOXML / plain text / PDF text layer / OCR) -> DLP scan -> classification
          -> persisted: Document.dlp_level, DLPFinding rows, DocumentMetadata (redacted searchable text)
          -> audit events (+ security alert for HIGH/CRITICAL)

Honesty rules: a file type nobody can read is recorded as ``status=UNSUPPORTED`` (or PROVIDER_UNAVAILABLE
when OCR tooling is missing); it is never reported as scanned-and-clean. The stored searchable text has
every validated sensitive value replaced by ``[REDACTED:rule]``, so the database never holds raw PII
extracted from an encrypted document.
"""
from __future__ import annotations

import asyncio
import html
import io
import re
import zipfile
from dataclasses import dataclass, field

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import Settings
from app.core.enums import Classification, DlpAction, DlpLevel
from app.integrations.ocr import COMPLETED, FAILED, PROVIDER_UNAVAILABLE, get_ocr_provider
from app.models.dlp_finding import DLPFinding
from app.models.document import Document
from app.models.document_metadata import DocumentMetadata
from app.repositories.audit import AuditRepository
from app.services import dlp
from app.services.alerts import AlertService

UNSUPPORTED = "UNSUPPORTED"
_ZIP_READ_CAP = 20 * 1024 * 1024        # per XML member; protects against decompression bombs
_CLASS_RANK = {Classification.PUBLIC.value: 0, Classification.INTERNAL.value: 1,
               Classification.CONFIDENTIAL.value: 2, Classification.RESTRICTED.value: 3}
_LEVEL_TO_CLASS = {DlpLevel.HIGH: Classification.CONFIDENTIAL.value, DlpLevel.CRITICAL: Classification.RESTRICTED.value}
_TAG = re.compile(r"<[^>]+>")


@dataclass
class Extraction:
    status: str                 # COMPLETED | FAILED | PROVIDER_UNAVAILABLE | UNSUPPORTED
    text: str = ""
    engine: str = ""
    detail: str = ""
    meta: dict = field(default_factory=dict)


@dataclass
class Analysis:
    extraction: Extraction
    report: dlp.ScanReport
    action: DlpAction
    suggested_classification: str | None


def _member(zf: zipfile.ZipFile, name: str) -> str:
    with zf.open(name) as fh:
        return fh.read(_ZIP_READ_CAP).decode("utf-8", "replace")


def _xml_text(xml: str, para_tags: tuple[str, ...]) -> str:
    for t in para_tags:
        xml = xml.replace(f"</{t}>", "\n")
    return html.unescape(_TAG.sub("", xml))


def _core_props(zf: zipfile.ZipFile) -> dict:
    if "docProps/core.xml" not in zf.namelist():
        return {}
    xml = _member(zf, "docProps/core.xml")
    out = {}
    for key, tag in (("title", "dc:title"), ("author", "dc:creator"), ("subject", "dc:subject")):
        m = re.search(rf"<{tag}[^>]*>(.*?)</{tag}>", xml, re.S)
        if m:
            out[key] = html.unescape(m.group(1)).strip()[:500]
    return out


def _extract_ooxml(data: bytes, ext: str) -> Extraction:
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
        names = zf.namelist()
        meta = _core_props(zf)
        if ext == "docx":
            text = _xml_text(_member(zf, "word/document.xml"), ("w:p", "w:tr"))
        elif ext == "pptx":
            slides = sorted((n for n in names if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)),
                            key=lambda n: int(re.findall(r"\d+", n)[0]))
            text = "\n".join(_xml_text(_member(zf, n), ("a:p",)) for n in slides)
            meta["page_count"] = len(slides)
        else:  # xlsx
            parts = []
            if "xl/sharedStrings.xml" in names:
                parts.append(_xml_text(_member(zf, "xl/sharedStrings.xml"), ("si",)))
            for n in names:
                if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", n):
                    xml = _member(zf, n)
                    parts.append("\n".join(html.unescape(v) for v in re.findall(r"<v>([^<]*)</v>", xml)))
            text = "\n".join(parts)
            meta["page_count"] = len([n for n in names if n.startswith("xl/worksheets/sheet")])
        return Extraction(COMPLETED, text.strip(), f"ooxml-{ext}", meta=meta)
    except (zipfile.BadZipFile, KeyError, OSError) as exc:
        return Extraction(FAILED, engine=f"ooxml-{ext}", detail=exc.__class__.__name__)


def extract(data: bytes, filename: str, mime: str | None = None) -> Extraction:
    """Blocking (OCR may spawn tesseract/pdftotext); callers run it in a worker thread."""
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext in ("docx", "pptx", "xlsx"):
        return _extract_ooxml(data, ext)
    r = get_ocr_provider().extract(data, filename, mime)
    if r.status == PROVIDER_UNAVAILABLE and "no extractor" in r.detail:
        return Extraction(UNSUPPORTED, engine=r.engine, detail=f"no text extractor for .{ext or 'unknown'} files")
    return Extraction(r.status, r.text, r.engine, r.detail)


def analyze_bytes(data: bytes, filename: str, settings: Settings, mime: str | None = None) -> Analysis:
    ex = extract(data, filename, mime)
    text = ex.text[: settings.analysis_max_text_chars]
    report = dlp.scan_text(text) if settings.dlp_enabled and ex.status == COMPLETED else dlp.ScanReport()
    block_on = None if settings.dlp_block_threshold == "OFF" else DlpLevel(settings.dlp_block_threshold)
    return Analysis(ex, report, dlp.action_for(report.level, block_on), _LEVEL_TO_CLASS.get(report.level))


async def analyze_async(data: bytes, filename: str, settings: Settings) -> Analysis:
    return await asyncio.to_thread(analyze_bytes, data, filename, settings)


async def persist(db: AsyncSession, doc: Document, analysis: Analysis, settings: Settings, *,
                  actor_id: str | None, ip: str | None = None, user_agent: str | None = None,
                  version_id: str | None = None) -> None:
    """Store results for ``doc`` (replacing any previous scan) and emit audit events / alerts."""
    ex, report = analysis.extraction, analysis.report
    audit = AuditRepository(db)

    await db.execute(delete(DLPFinding).where(DLPFinding.document_id == doc.id))
    for f in report.findings:
        db.add(DLPFinding(document_id=doc.id, version_id=version_id, rule_name=f.rule_name, category=f.category,
                          severity=f.severity.value, match_count=f.match_count, sample_masked=f.sample_masked,
                          action_taken=analysis.action.value))
    doc.dlp_level = report.level.value

    # Raise (never lower) the classification when sensitive content is found.
    raised_to = None
    sug = analysis.suggested_classification
    if sug and _CLASS_RANK.get(sug, 0) > _CLASS_RANK.get(doc.classification, 0):
        doc.classification, raised_to = sug, sug

    res = await db.execute(select(DocumentMetadata).where(DocumentMetadata.document_id == doc.id))
    md = res.scalar_one_or_none() or DocumentMetadata(document_id=doc.id)
    stored = dlp.redact(ex.text)[: settings.analysis_stored_text_chars] if ex.status == COMPLETED else None
    md.extracted_text = stored
    md.word_count = len(ex.text.split()) if ex.status == COMPLETED else None
    md.page_count = ex.meta.get("page_count", md.page_count)
    md.title, md.author, md.subject = (ex.meta.get("title"), ex.meta.get("author"), ex.meta.get("subject"))
    md.extra = {"analysis": {"status": ex.status, "engine": ex.engine, "detail": ex.detail[:200],
                             "dlp_level": report.level.value, "dlp_matches": report.total_matches,
                             "truncated": report.truncated, "classification_raised_to": raised_to}}
    db.add(md)
    await db.flush()

    if report.findings:
        await audit.log_event(
            action="DLP_FINDING", user_id=actor_id, resource_type="document", resource_id=doc.id,
            ip_address=ip, user_agent=user_agent,
            details={"level": report.level.value, "rules": {f.rule_name: f.match_count for f in report.findings},
                     "classification_raised_to": raised_to})
    if report.level in (DlpLevel.HIGH, DlpLevel.CRITICAL):
        await AlertService(db).create_alert(
            alert_type="DLP_SENSITIVE_CONTENT", severity=report.level.value, user_id=doc.owner_id, document_id=doc.id,
            message=f"Sensitive data detected in '{doc.display_name}' ({report.level.value}): "
                    + ", ".join(sorted({f.rule_name for f in report.findings})))


async def block_event(db: AsyncSession, analysis: Analysis, filename: str, actor_id: str | None,
                      ip: str | None, user_agent: str | None) -> None:
    await AuditRepository(db).log_event(
        action="DLP_BLOCKED", user_id=actor_id, resource_type="document", ip_address=ip, user_agent=user_agent,
        details={"filename": filename[:200], "level": analysis.report.level.value,
                 "rules": {f.rule_name: f.match_count for f in analysis.report.findings}})
