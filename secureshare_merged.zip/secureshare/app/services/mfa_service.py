"""Turn authenticator-app MFA on / off for a signed-in account (optional per account).

MFA is never forced: sign-up and login work without it. Once a person enables it, login asks for the
6-digit code (or a single-use recovery code) after the password. The TOTP secret is stored sealed
(AES-256-GCM, bound to the user id); recovery codes are stored only as salted hashes and the plain
codes are shown exactly once.
"""
from __future__ import annotations

from sqlalchemy.ext.asyncio import AsyncSession

from app.config.constants import AUDIT_MFA_DISABLED, AUDIT_MFA_ENABLED
from app.config.settings import get_settings
from app.core.exceptions import AuthenticationError, LockoutError, ValidationError
from app.crypto.password import verify_password
from app.integrations.state import StateStore, get_state_store
from app.models.user import User
from app.repositories.audit import AuditRepository
from app.services import mfa
from app.services.auth import is_guest_user
from app.services.notifications import MFA_DISABLED, MFA_ENABLED, safe_notify

PENDING_TTL = 600


class MfaService:
    def __init__(self, db: AsyncSession, store: StateStore | None = None) -> None:
        self.db = db
        self.store = store or get_state_store()
        self.settings = get_settings()
        self.audit = AuditRepository(db)

    def begin_setup(self, user: User) -> tuple[str, str]:
        """(base32 secret, otpauth:// URI). Held server-side until the first code proves the app works."""
        if is_guest_user(user):
            raise ValidationError("Guest accounts are temporary. Create an account to use two-factor sign-in.")
        if user.mfa_enabled:
            raise ValidationError("Two-factor sign-in is already on.")
        secret = mfa.new_secret()
        self.store.set(f"mfa:pending:{user.id}", secret, PENDING_TTL)
        return secret, mfa.provisioning_uri(secret, user.email, self.settings.totp_issuer)

    def pending_setup(self, user: User) -> tuple[str, str] | None:
        secret = self.store.get(f"mfa:pending:{user.id}")
        return (secret, mfa.provisioning_uri(secret, user.email, self.settings.totp_issuer)) if secret else None

    async def confirm_setup(self, user: User, code: str, ip: str | None = None, ua: str | None = None) -> list[str]:
        secret = self.store.get(f"mfa:pending:{user.id}")
        if not secret:
            raise ValidationError("Setup expired. Start again to get a new QR code.")
        res = mfa.verify_totp(self.store, user.id, secret, (code or "").replace(" ", ""))
        if res == mfa.MfaResult.LOCKED:
            raise LockoutError("Too many wrong codes. Try again in 15 minutes.", retry_after=mfa.LOCK_SECONDS)
        if res != mfa.MfaResult.OK:
            raise ValidationError("That code is not valid. Check the code in your authenticator app.")
        plain, hashed = mfa.generate_recovery_codes()
        user.totp_secret = mfa.seal_secret(secret, self.settings.master_secret, user.id)
        user.recovery_codes = hashed
        user.mfa_enabled = True
        self.store.delete(f"mfa:pending:{user.id}")
        await self.db.flush()
        await self.audit.log_event(action=AUDIT_MFA_ENABLED, user_id=user.id, resource_type="user",
                                   resource_id=user.id, ip_address=ip, user_agent=ua, details={})
        await safe_notify(self.db, user.id, MFA_ENABLED, "Two-factor sign-in turned on",
                          "Two-factor sign-in is now on for your account.", "user", user.id)
        return plain

    async def disable(self, user: User, password: str, ip: str | None = None, ua: str | None = None) -> None:
        if not verify_password(user.hashed_password, password or ""):
            raise AuthenticationError("Password is incorrect.")
        user.mfa_enabled = False
        user.totp_secret = None
        user.recovery_codes = None
        await self.db.flush()
        await self.audit.log_event(action=AUDIT_MFA_DISABLED, user_id=user.id, resource_type="user",
                                   resource_id=user.id, ip_address=ip, user_agent=ua, details={})
        await safe_notify(self.db, user.id, MFA_DISABLED, "Two-factor sign-in turned off",
                          "Two-factor sign-in was turned off. If this was not you, change your password now.",
                          "user", user.id)

    async def regenerate_recovery_codes(self, user: User, password: str) -> list[str]:
        if not user.mfa_enabled:
            raise ValidationError("Turn on two-factor sign-in first.")
        if not verify_password(user.hashed_password, password or ""):
            raise AuthenticationError("Password is incorrect.")
        plain, hashed = mfa.generate_recovery_codes()
        user.recovery_codes = hashed
        await self.db.flush()
        return plain

    @staticmethod
    def recovery_codes_left(user: User) -> int:
        return len(user.recovery_codes or [])
