"""Zero-Trust decision for secure-link view/download. Pure: builds an AccessContext from the link row
(+ recipient-session state + a RiskEngine result) and asks the PDP. The PDP's answer is final;
token / password / OTP / expiry checks in share_flow are additional gates, never a substitute.
Anything unrecognised fails closed (revoked / abused / DENY)."""
from __future__ import annotations

from datetime import datetime
from typing import Any

from app.core.enums import Decision, DlpLevel, Permission, RiskLevel
from app.services.policy_engine import (AccessContext, Binding, Decision_, LinkStatus, Principal,
                                        Reputation, evaluate)
from app.services.risk import level_for

BOUND_MODES = ("EMAIL_OTP", "PHONE_OTP")        # == recipient_gate.BOUND_MODES (no import: keep this pure)
_STATUS = {"ACTIVE": LinkStatus.ACTIVE, "REVOKED": LinkStatus.REVOKED, "EXPIRED": LinkStatus.EXPIRED,
           "USED": LinkStatus.EXPIRED}
_REP = {"NORMAL": Reputation.NORMAL, "SUSPICIOUS": Reputation.SUSPICIOUS, "ABUSED": Reputation.ABUSED}


def _dlp(v: Any) -> DlpLevel:
    try:
        return DlpLevel(v)
    except ValueError:
        return DlpLevel.CRITICAL          # unknown classification of sensitivity -> strictest


def build_context(link: Any, doc: Any, action: Permission, now: datetime, *, recipient_verified: bool,
                  risk_score: int, correlation_id: str = "") -> AccessContext:
    granted = {Permission.VIEW}
    if link.allow_downloads:
        granted.add(Permission.DOWNLOAD)
    if getattr(link, "allow_print", False):
        granted.add(Permission.PRINT)
    if getattr(link, "allow_copy", False):
        granted.add(Permission.COPY)
    status = _STATUS.get(str(link.status), LinkStatus.REVOKED)          # unknown status -> not usable
    if status == LinkStatus.ACTIVE and link.valid_from and link.valid_from > now:
        status = LinkStatus.NOT_STARTED
    bound = link.binding_mode in BOUND_MODES
    one_time = bool(link.one_time_download if action == Permission.DOWNLOAD else link.one_time_view)
    return AccessContext(
        action=action, now=now, principal=Principal.RECIPIENT,
        granted=frozenset(granted),
        binding_required=bound,
        binding=(Binding.VERIFIED if recipient_verified else Binding.PENDING) if bound else Binding.NOT_REQUIRED,
        mfa_required=bool(link.requires_mfa), mfa_verified=False,       # link redemption has no MFA factor
        device_required=bool(link.device_binding_required), device_trusted=False,
        link_status=status, reputation=_REP.get(str(link.reputation), Reputation.SUSPICIOUS),
        policy_active=(status == LinkStatus.ACTIVE),
        valid_from=link.valid_from, expires_at=link.expires_at,
        views_used=int(link.view_count or 0), max_views=link.max_views,
        downloads_used=int(link.download_count or 0), max_downloads=link.max_downloads,
        one_time=one_time,
        risk_score=risk_score, risk_level=level_for(risk_score),
        dlp_level=_dlp(getattr(doc, "dlp_level", "NONE")),
        correlation_id=correlation_id)


def decide_link_access(link: Any, doc: Any, action: Permission, now: datetime, *, recipient_verified: bool,
                       risk_score: int, correlation_id: str = "") -> Decision_:
    return evaluate(build_context(link, doc, action, now, recipient_verified=recipient_verified,
                                  risk_score=risk_score, correlation_id=correlation_id))


def enforce(decision: Decision_, action: Permission) -> tuple[bool, str]:
    """(allowed, reason). ALLOW passes; RESTRICT passes unless it removes the requested action;
    DENY and VERIFY do not pass."""
    if decision.decision == Decision.ALLOW:
        return True, ""
    if decision.decision == Decision.RESTRICT:
        if action == Permission.DOWNLOAD and decision.restrictions.get("download") is False:
            return False, "DOWNLOAD_RESTRICTED"
        return True, ""
    return False, ",".join(decision.reasons)
