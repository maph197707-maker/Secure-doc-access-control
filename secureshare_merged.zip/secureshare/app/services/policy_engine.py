"""Zero-Trust Policy Decision Point.

evaluate(ctx) is PURE and DETERMINISTIC (time comes from ctx.now; no I/O). Production access,
the policy simulator and the attack simulator all call this same function.
Precedence: DENY > VERIFY > RESTRICT > ALLOW. Default is DENY: ALLOW is reachable only when
every step of the pipeline passes.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum

from app.core.enums import Decision, DlpLevel, Permission, RiskLevel
from app.crypto.hashing import sha256_hex


class Principal(StrEnum):
    ANONYMOUS = "ANONYMOUS"   # holds a link, nothing verified
    USER = "USER"             # authenticated account
    RECIPIENT = "RECIPIENT"   # link recipient (identity comes from binding)


class Binding(StrEnum):
    NOT_REQUIRED = "NOT_REQUIRED"
    PENDING = "PENDING"
    VERIFIED = "VERIFIED"
    FAILED = "FAILED"


class LinkStatus(StrEnum):
    NONE = "NONE"
    ACTIVE = "ACTIVE"
    REVOKED = "REVOKED"
    EXPIRED = "EXPIRED"
    NOT_STARTED = "NOT_STARTED"


class Reputation(StrEnum):
    NORMAL = "NORMAL"
    SUSPICIOUS = "SUSPICIOUS"
    ABUSED = "ABUSED"


@dataclass(frozen=True)
class AccessContext:
    action: Permission
    now: datetime
    principal: Principal = Principal.ANONYMOUS
    session_active: bool = False
    email_verified: bool = False
    is_owner: bool = False
    role_permissions: frozenset[str] = frozenset()     # RBAC, e.g. {"DOCUMENT_VIEW"}
    granted: frozenset[Permission] = frozenset()       # per-document grants
    binding_required: bool = False
    binding: Binding = Binding.NOT_REQUIRED
    otp_required: bool = False
    otp_verified: bool = False
    mfa_required: bool = False
    mfa_verified: bool = False
    device_required: bool = False
    device_trusted: bool = False
    link_status: LinkStatus = LinkStatus.NONE
    reputation: Reputation = Reputation.NORMAL
    policy_active: bool = True
    policy_id: str = ""
    policy_version: int = 0
    valid_from: datetime | None = None
    expires_at: datetime | None = None
    allowed_hours: tuple[int, int] | None = None       # (start_hour, end_hour) inclusive-exclusive, UTC
    views_used: int = 0
    max_views: int | None = None
    downloads_used: int = 0
    max_downloads: int | None = None
    one_time: bool = False
    risk_score: int = 0
    risk_level: RiskLevel = RiskLevel.LOW
    dlp_level: DlpLevel = DlpLevel.NONE
    dlp_allow_download: bool = False                   # explicit owner override for HIGH/CRITICAL docs
    network_state: str = "UNKNOWN"                     # or PROVIDER_UNAVAILABLE; never fabricated
    correlation_id: str = ""


@dataclass(frozen=True)
class Decision_:
    decision: Decision
    policy_id: str
    policy_version: int
    reasons: list[str]
    required_actions: list[str]
    risk_score: int
    dlp_level: DlpLevel
    restrictions: dict[str, object]
    correlation_id: str

    @property
    def allowed(self) -> bool:
        return self.decision in (Decision.ALLOW, Decision.RESTRICT)


_RBAC = {Permission.VIEW: "DOCUMENT_VIEW", Permission.DOWNLOAD: "DOCUMENT_DOWNLOAD",
         Permission.EDIT: "DOCUMENT_EDIT", Permission.DELETE: "DOCUMENT_DELETE",
         Permission.RESHARE: "DOCUMENT_RESHARE", Permission.PRINT: "DOCUMENT_VIEW",
         Permission.COPY: "DOCUMENT_VIEW", Permission.COMMENT: "DOCUMENT_VIEW", Permission.SIGN: "DOCUMENT_VIEW"}
_HIGH_DLP = (DlpLevel.HIGH, DlpLevel.CRITICAL)


def evaluate(ctx: AccessContext) -> Decision_:
    deny: list[str] = []
    verify: list[str] = []
    actions: list[str] = []
    restrict: dict[str, object] = {}

    def need(reason: str, action: str) -> None:
        verify.append(reason)
        if action not in actions:
            actions.append(action)

    a = ctx.action
    # 1 authenticate / identify
    if ctx.principal == Principal.ANONYMOUS:
        if ctx.link_status == LinkStatus.ACTIVE:
            need("IDENTITY_NOT_ESTABLISHED", "VERIFY_IDENTITY")
        else:
            deny.append("AUTHENTICATION_REQUIRED")
    elif ctx.principal == Principal.USER and not ctx.session_active:
        deny.append("SESSION_INVALID")
    elif ctx.principal == Principal.USER and not ctx.email_verified:
        need("EMAIL_NOT_VERIFIED", "VERIFY_EMAIL")

    is_owner_user = ctx.principal == Principal.USER and ctx.is_owner
    # 2 ownership / RBAC
    if ctx.principal == Principal.USER and not is_owner_user and _RBAC[a] not in ctx.role_permissions:
        deny.append("RBAC_PERMISSION_MISSING")
    # 3 ABAC: time window
    if ctx.allowed_hours is not None:
        start, end = ctx.allowed_hours
        h = ctx.now.hour
        inside = start <= h < end if start <= end else (h >= start or h < end)
        if not inside:
            deny.append("OUTSIDE_ALLOWED_TIME_WINDOW")
    # 4 document policy / share policy grants
    if not is_owner_user:
        if a not in ctx.granted:
            deny.append("PERMISSION_NOT_GRANTED")
        if not ctx.policy_active:
            deny.append("POLICY_REVOKED")
        # 5 expiry + 6 revocation (link)
        if ctx.principal != Principal.USER or ctx.link_status != LinkStatus.NONE:
            if ctx.link_status == LinkStatus.REVOKED:
                deny.append("LINK_REVOKED")
            elif ctx.link_status == LinkStatus.EXPIRED:
                deny.append("LINK_EXPIRED")
            elif ctx.link_status == LinkStatus.NOT_STARTED:
                deny.append("LINK_NOT_YET_VALID")
        if ctx.expires_at is not None and ctx.now >= ctx.expires_at and "LINK_EXPIRED" not in deny:
            deny.append("LINK_EXPIRED")
        if ctx.valid_from is not None and ctx.now < ctx.valid_from and "LINK_NOT_YET_VALID" not in deny:
            deny.append("LINK_NOT_YET_VALID")
        if ctx.reputation == Reputation.ABUSED:
            deny.append("LINK_ABUSED")
        elif ctx.reputation == Reputation.SUSPICIOUS:
            need("LINK_SUSPICIOUS", "STEP_UP_VERIFICATION")
        # 7 recipient binding / OTP
        if ctx.binding_required:
            if ctx.binding == Binding.FAILED:
                deny.append("RECIPIENT_BINDING_FAILED")
            elif ctx.binding != Binding.VERIFIED:
                need("RECIPIENT_NOT_VERIFIED", "VERIFY_RECIPIENT")
        if ctx.otp_required and not ctx.otp_verified:
            need("OTP_REQUIRED", "ENTER_OTP")
        # 8 device
        if ctx.device_required and not ctx.device_trusted:
            need("DEVICE_NOT_TRUSTED", "VERIFY_DEVICE")
        # 10 usage limits (enforced again atomically at redemption)
        if a == Permission.VIEW:
            if ctx.one_time and ctx.views_used >= 1:
                deny.append("ONE_TIME_LINK_USED")
            elif ctx.max_views is not None and ctx.views_used >= ctx.max_views:
                deny.append("VIEW_LIMIT_REACHED")
        if a == Permission.DOWNLOAD:
            if ctx.one_time and ctx.downloads_used >= 1:
                deny.append("ONE_TIME_LINK_USED")
            elif ctx.max_downloads is not None and ctx.downloads_used >= ctx.max_downloads:
                deny.append("DOWNLOAD_LIMIT_REACHED")
    # 9 MFA
    mfa_needed = ctx.mfa_required or ctx.dlp_level in _HIGH_DLP
    if mfa_needed and not ctx.mfa_verified:
        need("MFA_REQUIRED", "COMPLETE_MFA")
    # 11 risk (signal only, evaluated by the PDP like any other attribute)
    if ctx.risk_level == RiskLevel.CRITICAL:
        deny.append("RISK_CRITICAL")
    elif ctx.risk_level == RiskLevel.HIGH:
        if not ctx.mfa_verified:
            need("RISK_HIGH", "COMPLETE_MFA")
        else:
            restrict.update(download=False, reason_risk="HIGH")
    # 12 DLP
    if ctx.dlp_level in _HIGH_DLP:
        restrict.update(watermark=True, print=False, copy=False, reshare=False,
                        download=bool(ctx.dlp_allow_download and restrict.get("download", True)),
                        audit_severity="HIGH", raise_alert=True)
        if ctx.principal == Principal.RECIPIENT and ctx.binding != Binding.VERIFIED:
            need("DLP_REQUIRES_RECIPIENT_VERIFICATION", "VERIFY_RECIPIENT")
        if a in (Permission.PRINT, Permission.COPY, Permission.RESHARE):
            deny.append("DLP_ACTION_BLOCKED")
        if a == Permission.DOWNLOAD and not ctx.dlp_allow_download:
            deny.append("DLP_DOWNLOAD_BLOCKED")

    # 13 decide (precedence DENY > VERIFY > RESTRICT > ALLOW)
    if deny:
        decision, reasons, req, res = Decision.DENY, sorted(set(deny)), [], {}
    elif verify:
        decision, reasons, req, res = Decision.VERIFY, sorted(set(verify)), actions, {}
    elif restrict:
        decision, reasons, req, res = Decision.RESTRICT, ["RESTRICTIONS_APPLY"], [], restrict
    else:
        decision, reasons, req, res = Decision.ALLOW, ["ALL_CHECKS_PASSED"], [], {}
    return Decision_(decision, ctx.policy_id, ctx.policy_version, reasons, req, ctx.risk_score,
                     ctx.dlp_level, res, ctx.correlation_id)


def policy_snapshot_hash(policy: dict[str, object]) -> str:
    """Versioning: hash of the canonical policy JSON. Store next to policy_version; optionally sign it."""
    return sha256_hex(json.dumps(policy, sort_keys=True, separators=(",", ":"), default=str).encode())
