"""Data-loss-prevention engine: deterministic, checksum-validated detection of sensitive data in text.

Pure functions (no DB, no network). Persistence and enforcement live in
``app.services.document_analysis``; the Zero-Trust PDP consumes the resulting ``DlpLevel``.

Design rules
* Structured identifiers are only reported when their checksum/format validates (Luhn for cards,
  Verhoeff for Aadhaar, mod-97 for IBAN, holder-type letter for PAN, area rules for US SSN), so random
  digit strings are not reported as PII.
* The raw matched value is NEVER returned or stored; only a masked sample (last 4 characters at most).
* Scanning is bounded (MAX_SCAN_CHARS) so a hostile document cannot make a scan unbounded.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable

from app.core.enums import DlpAction, DlpLevel

MAX_SCAN_CHARS = 2_000_000
_ORDER = {DlpLevel.NONE: 0, DlpLevel.LOW: 1, DlpLevel.MEDIUM: 2, DlpLevel.HIGH: 3, DlpLevel.CRITICAL: 4}


# ── checksums ────────────────────────────────────────────────────────────────
def luhn_ok(digits: str) -> bool:
    if not digits.isdigit() or not 13 <= len(digits) <= 19:
        return False
    total, alt = 0, False
    for ch in reversed(digits):
        d = int(ch)
        if alt:
            d *= 2
            if d > 9:
                d -= 9
        total += d
        alt = not alt
    return total % 10 == 0


_V_D = ((0, 1, 2, 3, 4, 5, 6, 7, 8, 9), (1, 2, 3, 4, 0, 6, 7, 8, 9, 5), (2, 3, 4, 0, 1, 7, 8, 9, 5, 6),
        (3, 4, 0, 1, 2, 8, 9, 5, 6, 7), (4, 0, 1, 2, 3, 9, 5, 6, 7, 8), (5, 9, 8, 7, 6, 0, 4, 3, 2, 1),
        (6, 5, 9, 8, 7, 1, 0, 4, 3, 2), (7, 6, 5, 9, 8, 2, 1, 0, 4, 3), (8, 7, 6, 5, 9, 3, 2, 1, 0, 4),
        (9, 8, 7, 6, 5, 4, 3, 2, 1, 0))
_V_P = ((0, 1, 2, 3, 4, 5, 6, 7, 8, 9), (1, 5, 7, 6, 2, 8, 3, 0, 9, 4), (5, 8, 0, 3, 7, 9, 6, 1, 4, 2),
        (8, 9, 1, 6, 0, 4, 3, 5, 2, 7), (9, 4, 5, 3, 1, 2, 6, 8, 7, 0), (4, 2, 8, 6, 5, 7, 3, 9, 0, 1),
        (2, 7, 9, 3, 8, 0, 6, 4, 1, 5), (7, 0, 4, 6, 9, 1, 3, 2, 5, 8))


def verhoeff_ok(number: str) -> bool:
    if not number.isdigit():
        return False
    c = 0
    for i, ch in enumerate(reversed(number)):
        c = _V_D[c][_V_P[i % 8][int(ch)]]
    return c == 0


def iban_ok(value: str) -> bool:
    v = re.sub(r"\s+", "", value).upper()
    if not re.fullmatch(r"[A-Z]{2}\d{2}[A-Z0-9]{11,30}", v):
        return False
    rearranged = v[4:] + v[:4]
    num = "".join(str(int(c, 36)) for c in rearranged)
    return int(num) % 97 == 1


# ── masking ──────────────────────────────────────────────────────────────────
def mask(value: str, keep: int = 4) -> str:
    v = value.strip()
    if len(v) <= keep:
        return "*" * len(v)
    return "*" * (len(v) - keep) + v[-keep:]


def _mask_email(value: str) -> str:
    local, _, domain = value.partition("@")
    return (local[:1] + "***@" + domain) if domain else mask(value)


# ── rules ────────────────────────────────────────────────────────────────────
@dataclass(frozen=True)
class Rule:
    name: str
    category: str          # PII | FINANCIAL | CREDENTIAL | KEYWORD
    severity: DlpLevel
    pattern: re.Pattern
    validate: Callable[[str], bool] | None = None
    masker: Callable[[str], str] = mask
    group: int = 0


def _digits(s: str) -> str:
    return re.sub(r"\D", "", s)


_PAN_HOLDER = set("ABCFGHLJPT")

RULES: tuple[Rule, ...] = (
    Rule("credit_card", "FINANCIAL", DlpLevel.CRITICAL, re.compile(r"(?<![\d-])(?:\d[ -]?){12,18}\d(?![\d-])"),
         lambda s: luhn_ok(_digits(s)) and len(set(_digits(s))) > 1, lambda s: mask(_digits(s))),
    Rule("aadhaar", "PII", DlpLevel.CRITICAL, re.compile(r"(?<![\d-])[2-9]\d{3}[ -]?\d{4}[ -]?\d{4}(?![\d-])"),
         lambda s: len(_digits(s)) == 12 and verhoeff_ok(_digits(s)), lambda s: mask(_digits(s))),
    Rule("us_ssn", "PII", DlpLevel.CRITICAL,
         re.compile(r"(?<![\d-])(?!000|666|9\d\d)\d{3}-(?!00)\d{2}-(?!0000)\d{4}(?![\d-])"), None),
    Rule("pan_card", "PII", DlpLevel.HIGH, re.compile(r"\b[A-Z]{3}[ABCFGHLJPT][A-Z]\d{4}[A-Z]\b"),
         lambda s: s[3] in _PAN_HOLDER),
    Rule("iban", "FINANCIAL", DlpLevel.HIGH, re.compile(r"\b[A-Z]{2}\d{2}(?: ?[A-Z0-9]{4}){2,7}(?: ?[A-Z0-9]{1,4})?\b"),
         iban_ok, lambda s: mask(re.sub(r"\s+", "", s))),
    Rule("bank_account", "FINANCIAL", DlpLevel.HIGH,
         re.compile(r"(?i)\b(?:a/c|acct?|account)(?:\s*(?:no|number|num|#))?\.?\s*[:\-]?\s*(\d{9,18})\b"),
         None, mask, group=1),
    Rule("ifsc_code", "FINANCIAL", DlpLevel.MEDIUM, re.compile(r"\b[A-Z]{4}0[A-Z0-9]{6}\b"), None),
    Rule("private_key", "CREDENTIAL", DlpLevel.CRITICAL,
         re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY(?: BLOCK)?-----"), None, lambda s: "[private key block]"),
    Rule("aws_access_key", "CREDENTIAL", DlpLevel.CRITICAL, re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"), None),
    Rule("api_token", "CREDENTIAL", DlpLevel.HIGH,
         re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{30,}|xox[abprs]-[A-Za-z0-9-]{10,}|AIza[0-9A-Za-z_\-]{35}|sk_live_[0-9A-Za-z]{16,})\b"), None),
    Rule("jwt", "CREDENTIAL", DlpLevel.HIGH,
         re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b"), None),
    Rule("password_assignment", "CREDENTIAL", DlpLevel.HIGH,
         re.compile(r"(?i)\b(?:password|passwd|pwd|secret|api[_-]?key)\s*[:=]\s*[\"']?([^\s\"']{6,})"),
         lambda s: not s.startswith(("<", "{", "$", "*", "%")), lambda s: "[redacted]", group=1),
    Rule("email_address", "PII", DlpLevel.LOW,
         re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}\b"), None, _mask_email),
    Rule("phone_number", "PII", DlpLevel.LOW,
         re.compile(r"(?<!\d)(?<!\d\.)(?:\+91[\s-]?|0)?[6-9]\d{4}[\s-]?\d{5}(?!\d)(?!\.\d)"
                    r"|(?<!\d)(?<!\d\.)\+\d{1,3}[\s-]?\d{2,4}[\s-]?\d{3,4}[\s-]?\d{3,4}(?!\d)(?!\.\d)"),
         lambda s: 10 <= len(_digits(s)) <= 13),
    Rule("confidential_marking", "KEYWORD", DlpLevel.LOW,
         re.compile(r"(?i)\b(?:top secret|strictly confidential|confidential|internal use only|do not distribute|restricted)\b"),
         None, lambda s: s.lower()),
)


@dataclass
class Finding:
    rule_name: str
    category: str
    severity: DlpLevel
    match_count: int
    sample_masked: str


@dataclass
class ScanReport:
    level: DlpLevel = DlpLevel.NONE
    findings: list[Finding] = field(default_factory=list)
    chars_scanned: int = 0
    truncated: bool = False

    @property
    def total_matches(self) -> int:
        return sum(f.match_count for f in self.findings)

    def to_dict(self) -> dict:
        return {"level": self.level.value, "total_matches": self.total_matches, "truncated": self.truncated,
                "chars_scanned": self.chars_scanned,
                "findings": [{"rule": f.rule_name, "category": f.category, "severity": f.severity.value,
                              "count": f.match_count, "sample": f.sample_masked} for f in self.findings]}


def _escalate(rule: Rule, count: int) -> DlpLevel:
    """Volume raises severity: many e-mails/phones together are a bulk personal-data leak."""
    sev = rule.severity
    if rule.name in ("email_address", "phone_number"):
        if count >= 25:
            return DlpLevel.HIGH
        if count >= 5:
            return DlpLevel.MEDIUM
    if rule.name == "confidential_marking":
        return DlpLevel.MEDIUM if count >= 3 else DlpLevel.LOW
    if rule.name in ("ifsc_code", "pan_card") and count >= 10:
        return DlpLevel.CRITICAL
    return sev


def scan_text(text: str) -> ScanReport:
    report = ScanReport()
    if not text:
        return report
    if len(text) > MAX_SCAN_CHARS:
        text, report.truncated = text[:MAX_SCAN_CHARS], True
    report.chars_scanned = len(text)
    top = DlpLevel.NONE
    for rule in RULES:
        count, sample = 0, ""
        for m in rule.pattern.finditer(text):
            val = m.group(rule.group) if rule.group else m.group(0)
            if rule.validate and not rule.validate(val):
                continue
            count += 1
            if not sample:
                sample = rule.masker(val)
        if count:
            sev = _escalate(rule, count)
            report.findings.append(Finding(rule.name, rule.category, sev, count, sample[:200]))
            if _ORDER[sev] > _ORDER[top]:
                top = sev
    report.findings.sort(key=lambda f: (-_ORDER[f.severity], f.rule_name))
    report.level = top
    return report


def action_for(level: DlpLevel, block_on: DlpLevel | None) -> DlpAction:
    """BLOCK once the configured threshold is reached, WARN for anything else that was found."""
    if level == DlpLevel.NONE:
        return DlpAction.ALLOW
    if block_on is not None and _ORDER[level] >= _ORDER[block_on]:
        return DlpAction.BLOCK
    return DlpAction.WARN


def redact(text: str) -> str:
    """Return ``text`` with every validated sensitive value replaced by a ``[REDACTED:rule]`` tag."""
    spans: list[tuple[int, int, str]] = []
    for rule in RULES:
        if rule.category == "KEYWORD":
            continue
        for m in rule.pattern.finditer(text):
            val = m.group(rule.group) if rule.group else m.group(0)
            if rule.validate and not rule.validate(val):
                continue
            s, e = (m.start(rule.group), m.end(rule.group)) if rule.group else m.span()
            spans.append((s, e, rule.name))
    out, pos = [], 0
    for s, e, name in sorted(spans):
        if s < pos:
            continue
        out.append(text[pos:s])
        out.append(f"[REDACTED:{name}]")
        pos = e
    out.append(text[pos:])
    return "".join(out)
