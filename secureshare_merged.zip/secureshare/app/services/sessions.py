"""User session management service backed by DB and StateStore."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Sequence
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.config.constants import (
    DEFAULT_SESSION_ABSOLUTE_TIMEOUT_SECONDS,
    DEFAULT_SESSION_IDLE_TIMEOUT_SECONDS,
)
from app.config.settings import get_settings
from app.core.enums import SessionStatus
from app.crypto.tokens import new_token, token_hash
from app.integrations.state import StateStore, get_state_store
from app.models.session import UserSession
from app.models.user import User


class SessionService:
    def __init__(self, db: AsyncSession, store: StateStore | None = None) -> None:
        self.db = db
        self.settings = get_settings()
        self.store = store or get_state_store()
        self._key = self.settings.secret_key.encode()

    def _hash(self, token: str) -> str:
        return token_hash(token, self._key)

    async def create_session(
        self,
        user: User,
        ip_address: str | None = None,
        user_agent: str | None = None,
        device_id: str | None = None,
        remember_me: bool = False,
    ) -> tuple[UserSession, str]:
        raw_token = new_token(32)
        s_hash = self._hash(raw_token)

        now = datetime.now(timezone.utc).replace(tzinfo=None)
        idle_seconds = self.settings.session_idle_timeout
        abs_seconds = (
            self.settings.session_absolute_timeout * 7
            if remember_me
            else self.settings.session_absolute_timeout
        )

        expires_at = now + timedelta(seconds=idle_seconds)
        abs_expires_at = now + timedelta(seconds=abs_seconds)

        session = UserSession(
            user_id=user.id,
            session_hash=s_hash,
            device_id=device_id,
            ip_address=ip_address,
            user_agent=user_agent,
            status=SessionStatus.ACTIVE.value,
            last_active_at=now,
            expires_at=expires_at,
            absolute_expires_at=abs_expires_at,
            mfa_verified=not user.mfa_enabled,  # MFA required if user has MFA on
        )
        self.db.add(session)
        await self.db.flush()

        # Cache in state store for fast lookup
        self.store.set(f"sess:{s_hash}", {"id": session.id, "user_id": user.id}, idle_seconds)

        return session, raw_token

    async def get_session(self, raw_token: str) -> tuple[UserSession | None, User | None]:
        if not raw_token:
            return None, None

        s_hash = self._hash(raw_token)
        stmt = (
            select(UserSession)
            .options(
                selectinload(UserSession.user).selectinload(User.roles),
                selectinload(UserSession.user).selectinload(User.preference),
            )
            .where(UserSession.session_hash == s_hash)
        )
        res = await self.db.execute(stmt)
        session = res.scalar_one_or_none()

        if not session:
            return None, None

        now = datetime.now(timezone.utc).replace(tzinfo=None)

        # Check expiration or revocation
        if session.status != SessionStatus.ACTIVE.value:
            return None, None
        if session.expires_at < now or session.absolute_expires_at < now:
            session.status = SessionStatus.EXPIRED.value
            await self.db.flush()
            self.store.delete(f"sess:{s_hash}")
            return None, None

        # Slide idle expiration
        session.last_active_at = now
        session.expires_at = now + timedelta(seconds=self.settings.session_idle_timeout)
        await self.db.flush()

        # Update cache TTL
        self.store.set(f"sess:{s_hash}", {"id": session.id, "user_id": session.user_id}, self.settings.session_idle_timeout)

        return session, session.user

    async def revoke_session(self, session_id: str, reason: str = "user_logout") -> bool:
        stmt = select(UserSession).where(UserSession.id == session_id)
        res = await self.db.execute(stmt)
        session = res.scalar_one_or_none()
        if not session:
            return False

        now = datetime.now(timezone.utc).replace(tzinfo=None)
        session.status = SessionStatus.REVOKED.value
        session.revoked_at = now
        session.revoke_reason = reason
        await self.db.flush()

        self.store.delete(f"sess:{session.session_hash}")
        return True

    async def revoke_other_sessions(self, user_id: str, current_session_id: str) -> int:
        stmt = (
            select(UserSession)
            .where(
                UserSession.user_id == user_id,
                UserSession.id != current_session_id,
                UserSession.status == SessionStatus.ACTIVE.value,
            )
        )
        res = await self.db.execute(stmt)
        sessions = res.scalars().all()

        now = datetime.now(timezone.utc).replace(tzinfo=None)
        count = 0
        for s in sessions:
            s.status = SessionStatus.REVOKED.value
            s.revoked_at = now
            s.revoke_reason = "revoked_by_user"
            self.store.delete(f"sess:{s.session_hash}")
            count += 1

        if count > 0:
            await self.db.flush()

        return count

    async def list_user_sessions(self, user_id: str) -> Sequence[UserSession]:
        stmt = (
            select(UserSession)
            .where(UserSession.user_id == user_id, UserSession.status == SessionStatus.ACTIVE.value)
            .order_by(UserSession.last_active_at.desc())
        )
        res = await self.db.execute(stmt)
        return res.scalars().all()
