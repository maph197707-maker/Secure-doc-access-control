"""Device service for device fingerprinting, tracking, and trust management."""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from typing import Sequence
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import NotFoundError, PermissionDeniedError
from app.models.device import Device


def compute_fingerprint(user_agent: str | None, ip_address: str | None) -> str:
    raw = f"{user_agent or 'unknown'}|{ip_address or '0.0.0.0'}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]


class DeviceService:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def list_devices(self, user_id: str) -> Sequence[Device]:
        stmt = select(Device).where(Device.user_id == user_id).order_by(desc(Device.registered_at))
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def get_device(self, device_id: str) -> Device | None:
        stmt = select(Device).where(Device.id == device_id)
        res = await self.session.execute(stmt)
        return res.scalar_one_or_none()

    async def register_or_update(
        self,
        user_id: str,
        user_agent: str | None = None,
        ip_address: str | None = None,
        name: str | None = None,
        trust: str = "TRUSTED",
    ) -> Device:
        fp = compute_fingerprint(user_agent, ip_address)
        stmt = select(Device).where(Device.user_id == user_id, Device.device_fingerprint == fp)
        res = await self.session.execute(stmt)
        device = res.scalar_one_or_none()

        now = datetime.now(timezone.utc).replace(tzinfo=None)
        if device:
            device.last_seen_at = now
            if ip_address:
                device.ip_address = ip_address
            if user_agent:
                device.user_agent = user_agent
        else:
            device = Device(
                user_id=user_id,
                device_fingerprint=fp,
                name=name or (user_agent[:40] if user_agent else "Standard Browser"),
                user_agent=user_agent,
                ip_address=ip_address,
                trust=trust,
                registered_at=now,
                last_seen_at=now,
            )
            self.session.add(device)

        await self.session.flush()
        return device

    async def revoke_device(self, device_id: str, user_id: str | None = None, is_admin: bool = False) -> bool:
        device = await self.get_device(device_id)
        if not device:
            raise NotFoundError("Device not found.")
        if not is_admin and user_id and device.user_id != user_id:
            raise PermissionDeniedError("Cannot revoke device belonging to another user.")

        await self.session.delete(device)
        await self.session.flush()
        return True
