"""Pure (no DB, no I/O) share-grant rules, so they can be unit tested without the full stack.

The PDP (policy_engine.evaluate) stays the single decision point; this module only turns stored
grants into the AccessContext it consumes. Risk is passed in as a signal and never grants access.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable

from app.core.enums import Decision, Permission, RiskLevel
from app.services.policy_engine import AccessContext, Decision_, Principal, evaluate

SHAREABLE = (Permission.VIEW, Permission.DOWNLOAD, Permission.EDIT, Permission.RESHARE)
ACTIVE, EXPIRED, REVOKED = "ACTIVE", "EXPIRED", "REVOKED"


class GrantInputError(ValueError):
    pass


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def to_naive_utc(dt: datetime | None) -> datetime | None:
    if dt is None:
        return None
    return dt.astimezone(timezone.utc).replace(tzinfo=None) if dt.tzinfo else dt


def normalize_permissions(perms: Iterable[str]) -> list[str]:
    out: list[str] = []
    for p in perms:
        try:
            perm = Permission(str(p).strip().upper())
        except ValueError as exc:
            raise GrantInputError(f"Unknown permission: {p!r}") from exc
        if perm not in SHAREABLE:
            raise GrantInputError(f"Permission {perm.value} cannot be shared")
        if perm.value not in out:
            out.append(perm.value)
    if not out:
        raise GrantInputError("At least one permission is required")
    if Permission.VIEW.value not in out:
        out.insert(0, Permission.VIEW.value)   # DOWNLOAD/EDIT/RESHARE without VIEW makes no sense
    return out


def validate_expiry(expires_at: datetime | None, now: datetime) -> datetime | None:
    exp = to_naive_utc(expires_at)
    if exp is not None and exp <= now:
        raise GrantInputError("Expiration must be in the future")
    return exp


def grant_state(grant: Any, now: datetime) -> str:
    if grant.revoked_at is not None:
        return REVOKED
    if grant.expires_at is not None and grant.expires_at <= now:
        return EXPIRED
    return ACTIVE


def effective_permissions(grants: Iterable[Any], now: datetime) -> frozenset[Permission]:
    perms: set[Permission] = set()
    for g in grants:
        if grant_state(g, now) == ACTIVE:
            for p in g.permissions or []:
                try:
                    perms.add(Permission(p))
                except ValueError:
                    continue
    return frozenset(perms)


@dataclass(frozen=True)
class AccessOutcome:
    decision: Decision_
    extra_reasons: tuple[str, ...] = ()

    @property
    def allowed(self) -> bool:
        return self.decision.allowed

    @property
    def reasons(self) -> list[str]:
        return list(self.decision.reasons) + list(self.extra_reasons)


def decide(*, action: Permission, now: datetime, is_owner: bool, user_status_active: bool,
           email_verified: bool, role_permissions: Iterable[str], grants: Iterable[Any],
           dlp_level: Any, risk_score: int = 0, risk_level: RiskLevel = RiskLevel.LOW,
           mfa_verified: bool = False, device_trusted: bool = True,
           correlation_id: str = "", classification: Any = None) -> AccessOutcome:
    grants = list(grants)
    live = effective_permissions(grants, now)
    ctx = AccessContext(
        action=action, now=now, principal=Principal.USER, session_active=user_status_active,
        email_verified=email_verified, is_owner=is_owner,
        role_permissions=frozenset(role_permissions), granted=live,
        mfa_verified=mfa_verified, device_trusted=device_trusted,
        risk_score=risk_score, risk_level=risk_level, dlp_level=dlp_level,
        correlation_id=correlation_id,
    )
    # Zero-trust ABAC: RESTRICTED needs MFA, TOP_SECRET needs MFA + trusted device. Only ever raises the bar.
    from app.services.zero_trust import apply_abac
    ctx = apply_abac(ctx, classification=classification, auth_strength="MFA" if mfa_verified else "PASSWORD")
    result = evaluate(ctx)
    extra: list[str] = []
    if not is_owner and result.decision == Decision.DENY:
        states = {grant_state(g, now) for g in grants}
        if live == frozenset() and states:
            extra.append("SHARE_REVOKED" if REVOKED in states and ACTIVE not in states and EXPIRED not in states
                         else "SHARE_EXPIRED" if EXPIRED in states and REVOKED not in states
                         else "SHARE_NO_LONGER_ACTIVE")
    return AccessOutcome(result, tuple(extra))
