"""Link reputation from recorded access stats: NORMAL / SUSPICIOUS / ABUSED (signal for the PDP)."""
from __future__ import annotations

from dataclasses import dataclass

from app.services.policy_engine import Reputation


@dataclass(frozen=True)
class LinkStats:
    failed_verifications: int = 0
    denied_requests: int = 0
    unique_ips: int = 0
    unique_devices: int = 0
    accesses_last_hour: int = 0
    off_hours_accesses: int = 0


def compute_reputation(s: LinkStats) -> tuple[Reputation, list[str]]:
    pts, why = 0, []
    for cond, p, label in (
        (s.failed_verifications >= 3, 2, "REPEATED_FAILED_VERIFICATIONS"),
        (s.failed_verifications >= 10, 3, "MANY_FAILED_VERIFICATIONS"),
        (s.denied_requests >= 5, 2, "REPEATED_DENIALS"),
        (s.unique_ips >= 4, 2, "MANY_DISTINCT_IPS"),
        (s.unique_devices >= 4, 2, "MANY_DISTINCT_DEVICES"),
        (s.accesses_last_hour >= 30, 2, "HIGH_ACCESS_FREQUENCY"),
        (s.off_hours_accesses >= 3, 1, "OFF_HOURS_PATTERN"),
    ):
        if cond:
            pts += p
            why.append(label)
    if pts >= 5:
        return Reputation.ABUSED, why
    if pts >= 2:
        return Reputation.SUSPICIOUS, why
    return Reputation.NORMAL, why
