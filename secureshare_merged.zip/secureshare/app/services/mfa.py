"""MFA: RFC 6238 TOTP, hashed recovery codes, challenges with expiry/attempt limits and replay
prevention. Pure + StateStore; the caller persists the TOTP secret and recovery-code hashes in the
user's mfa record and writes the audit events (MFA_ENABLED, MFA_DISABLED, LOGIN_FAILURE).

Email/SMS OTP delivery is never claimed: `deliver_otp` returns PROVIDER_UNAVAILABLE unless a
real sender callable is supplied and succeeds.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import struct
import time
from enum import StrEnum
from typing import Callable
from urllib.parse import quote

from app.crypto.hashing import constant_time_equal
from app.integrations.state import StateStore

PERIOD, DIGITS, WINDOW = 30, 6, 1
MAX_ATTEMPTS, LOCK_SECONDS, CHALLENGE_TTL = 5, 900, 300


class MfaResult(StrEnum):
    OK = "OK"
    WRONG = "WRONG"
    REPLAYED = "REPLAYED"
    LOCKED = "LOCKED"
    EXPIRED = "EXPIRED"
    PROVIDER_UNAVAILABLE = "PROVIDER_UNAVAILABLE"
    DELIVERED = "DELIVERED"


def new_secret() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")


def _hotp(secret_b32: str, counter: int) -> str:
    key = base64.b32decode(secret_b32 + "=" * (-len(secret_b32) % 8), casefold=True)
    h = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    o = h[-1] & 0x0F
    code = (struct.unpack(">I", h[o:o + 4])[0] & 0x7FFFFFFF) % (10 ** DIGITS)
    return str(code).zfill(DIGITS)


def totp_at(secret_b32: str, at: float | None = None) -> str:
    return _hotp(secret_b32, int((time.time() if at is None else at) // PERIOD))


def provisioning_uri(secret_b32: str, account: str, issuer: str = "SecureShare") -> str:
    return (f"otpauth://totp/{quote(issuer)}:{quote(account)}?secret={secret_b32}"
            f"&issuer={quote(issuer)}&algorithm=SHA1&digits={DIGITS}&period={PERIOD}")


def verify_totp(store: StateStore, user_id: str, secret_b32: str, code: str,
                now: float | None = None) -> MfaResult:
    """Attempt-limited, replay-safe TOTP check (+/- WINDOW steps). A code that already
    succeeded for this user can never succeed again."""
    if store.get(f"mfa:lock:{user_id}"):
        return MfaResult.LOCKED
    t = time.time() if now is None else now
    code = (code or "").strip()
    step = int(t // PERIOD)
    matched = None
    if len(code) == DIGITS and code.isdigit():
        for s in range(step - WINDOW, step + WINDOW + 1):
            if constant_time_equal(_hotp(secret_b32, s), code):   # no early exit on mismatch
                matched = s
    if matched is None:
        if store.incr(f"mfa:att:{user_id}", LOCK_SECONDS) >= MAX_ATTEMPTS:
            store.set(f"mfa:lock:{user_id}", True, LOCK_SECONDS)
            return MfaResult.LOCKED
        return MfaResult.WRONG
    if store.get(f"mfa:used:{user_id}:{matched}"):
        return MfaResult.REPLAYED
    store.set(f"mfa:used:{user_id}:{matched}", True, PERIOD * (2 * WINDOW + 2))
    store.delete(f"mfa:att:{user_id}")
    return MfaResult.OK


# ---- recovery codes: shown once, stored only as hashes, single use ------------------------
def generate_recovery_codes(n: int = 10) -> tuple[list[str], list[str]]:
    """Returns (plaintext codes to show once, salted hashes to store)."""
    plain = [f"{secrets.token_hex(2)}-{secrets.token_hex(2)}-{secrets.token_hex(2)}" for _ in range(n)]
    return plain, [_hash_code(c) for c in plain]


def _hash_code(code: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(8)
    return salt.hex() + "$" + hashlib.sha256(salt + code.strip().lower().encode()).hexdigest()


def consume_recovery_code(stored_hashes: list[str], code: str) -> tuple[bool, list[str]]:
    """Returns (ok, remaining hashes). The matching hash is removed so a code works once."""
    for h in stored_hashes:
        salt_hex, _, digest = h.partition("$")
        cand = hashlib.sha256(bytes.fromhex(salt_hex) + code.strip().lower().encode()).hexdigest()
        if constant_time_equal(cand, digest):
            return True, [x for x in stored_hashes if x != h]
    return False, stored_hashes


# ---- challenge (login step-up) -------------------------------------------------------------
def open_challenge(store: StateStore, user_id: str) -> str:
    cid = secrets.token_urlsafe(24)
    store.set(f"mfa:ch:{cid}", user_id, CHALLENGE_TTL)
    return cid


def resolve_challenge(store: StateStore, cid: str) -> str | None:
    return store.get(f"mfa:ch:{cid}")


def close_challenge(store: StateStore, cid: str) -> None:
    store.delete(f"mfa:ch:{cid}")


def deliver_otp(channel: str, destination: str, code: str,
                sender: Callable[[str, str, str], bool] | None = None) -> MfaResult:
    """DELIVERED only if a real sender reports success; otherwise PROVIDER_UNAVAILABLE."""
    if sender is None:
        return MfaResult.PROVIDER_UNAVAILABLE
    try:
        return MfaResult.DELIVERED if sender(channel, destination, code) else MfaResult.PROVIDER_UNAVAILABLE
    except Exception:  # noqa: BLE001 - any provider failure means "not delivered"
        return MfaResult.PROVIDER_UNAVAILABLE


# ---- at-rest protection of the TOTP secret --------------------------------------------------
# The authenticator secret is as sensitive as a password: a database leak must not let anyone mint
# valid codes. It is sealed with AES-256-GCM under a key derived (HKDF-SHA256) from the app master
# secret, and bound to the user id so a sealed value cannot be pasted onto another account.
def _seal_key(master_secret: str) -> bytes:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b"secureshare/totp-secret/v1"
                ).derive(master_secret.encode())


def seal_secret(secret_b32: str, master_secret: str, user_id: str) -> str:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    nonce = secrets.token_bytes(12)
    ct = AESGCM(_seal_key(master_secret)).encrypt(nonce, secret_b32.encode(), user_id.encode())
    return "v1." + base64.urlsafe_b64encode(nonce + ct).decode()


def open_secret(sealed: str, master_secret: str, user_id: str) -> str | None:
    """Plain base32 secret, or None if the value is malformed / tampered / for another user."""
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    try:
        if not sealed.startswith("v1."):
            return None
        raw = base64.urlsafe_b64decode(sealed[3:].encode())
        return AESGCM(_seal_key(master_secret)).decrypt(raw[:12], raw[12:], user_id.encode()).decode()
    except (InvalidTag, ValueError):
        return None


def looks_like_totp(code: str) -> bool:
    c = (code or "").strip().replace(" ", "")
    return len(c) == DIGITS and c.isdigit()
