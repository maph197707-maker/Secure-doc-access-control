"""Maps a scanner result + policy to what the upload pipeline must do. Pure logic (no DB)."""
from __future__ import annotations

from dataclasses import dataclass

from app.integrations.malware import MalwareScanner, ScanResult, ScanStatus


@dataclass(frozen=True)
class ScanDecision:
    reject: bool           # INFECTED: do not store at all
    db_result: str         # value for Document.malware_scan_result (honest, never a guessed CLEAN)
    doc_status: str        # value for Document.status
    detail: str = ""


def decide(result: ScanResult, unavailable_policy: str = "allow_with_warning") -> ScanDecision:
    s = result.status
    if s == ScanStatus.INFECTED:
        return ScanDecision(True, "INFECTED", "QUARANTINED", result.detail)
    if s == ScanStatus.CLEAN:
        return ScanDecision(False, "CLEAN", "UPLOADED", "")
    if s == ScanStatus.NO_DETECTION_DEV:
        return ScanDecision(False, "DEV_ONLY", "UPLOADED", result.detail)
    # PROVIDER_UNAVAILABLE (or anything unknown): never reported as clean
    if unavailable_policy == "hold":
        return ScanDecision(False, "PROVIDER_UNAVAILABLE", "QUARANTINED", result.detail)
    return ScanDecision(False, "PROVIDER_UNAVAILABLE", "UPLOADED", result.detail)


def scan_bytes(scanner: MalwareScanner, data: bytes, unavailable_policy: str) -> tuple[ScanResult, ScanDecision]:
    result = scanner.scan(data)
    return result, decide(result, unavailable_policy)
