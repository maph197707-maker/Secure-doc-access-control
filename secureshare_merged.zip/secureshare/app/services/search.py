"""Lexical document search (no semantic search is claimed). Pure ranking/filter/paginate over
records the caller has ALREADY restricted to documents the user may see; authorization is not
done here. Matches name, tags, owner, classification, metadata and OCR text."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from app.ml.features import tokens

SORTS = {"relevance", "name", "created", "size"}
MAX_PAGE_SIZE = 100


@dataclass(frozen=True)
class SearchPage:
    items: list[dict[str, Any]]
    total: int
    page: int
    page_size: int
    mode: str = "lexical"

    @property
    def pages(self) -> int:
        return max((self.total + self.page_size - 1) // self.page_size, 1)


def _score(doc: dict[str, Any], terms: list[str]) -> int:
    name = " ".join(tokens(str(doc.get("name", ""))))
    tags = " ".join(t.lower() for t in doc.get("tags", []))
    meta = " ".join(str(v).lower() for v in (doc.get("metadata") or {}).values())
    text = str(doc.get("ocr_text") or "").lower()
    owner = str(doc.get("owner", "")).lower()
    s = 0
    for t in terms:
        s += 5 * (t in name) + 4 * (t in tags) + 2 * (t in meta or t in owner) + (t in text)
    return s


def search(docs: list[dict[str, Any]], q: str = "", *, classification: str | None = None,
           owner: str | None = None, tag: str | None = None, shared: bool | None = None,
           created_from: datetime | None = None, created_to: datetime | None = None,
           sort: str = "relevance", page: int = 1, page_size: int = 20) -> SearchPage:
    if sort not in SORTS:
        raise ValueError(f"unknown sort {sort!r}")
    page, page_size = max(page, 1), min(max(page_size, 1), MAX_PAGE_SIZE)
    terms = [t.lower() for t in q.split() if t.strip()]
    hits: list[tuple[int, dict[str, Any]]] = []
    for d in docs:
        if classification and d.get("classification") != classification:
            continue
        if owner and str(d.get("owner", "")).lower() != owner.lower():
            continue
        if tag and tag.lower() not in [t.lower() for t in d.get("tags", [])]:
            continue
        if shared is not None and bool(d.get("shared")) != shared:
            continue
        c = d.get("created")
        if created_from and (c is None or c < created_from):
            continue
        if created_to and (c is None or c > created_to):
            continue
        sc = _score(d, terms) if terms else 0
        if terms and sc == 0:
            continue
        hits.append((sc, d))
    key = {"relevance": lambda h: (-h[0], str(h[1].get("name", "")).lower()),
           "name": lambda h: str(h[1].get("name", "")).lower(),
           "created": lambda h: -(h[1].get("created") or datetime.min).timestamp(),
           "size": lambda h: -int(h[1].get("size", 0))}[sort]
    hits.sort(key=key)
    start = (page - 1) * page_size
    return SearchPage([d for _, d in hits[start:start + page_size]], len(hits), page, page_size)
