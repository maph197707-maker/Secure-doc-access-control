"""Per-document DEK wrapping with AES-256-GCM (replaces the old XOR 'dev KMS').

Wrapped keys are bound to (document, version) via AAD, so a wrapped DEK copied onto another
document fails to unwrap. Legacy rows (key_reference == "master_v1") were XOR-wrapped; they can
still be READ so existing uploads keep working, and `needs_rewrap` flags them for migration.
"""
from __future__ import annotations

import base64
import hashlib

from app.crypto.envelope import KeyError_, LocalDevelopmentKeyProvider, WrappedKey, new_dek, open_dek

KEY_REF_GCM = "kek_v1_gcm"
KEY_REF_LEGACY_XOR = "master_v1"


def _provider(master_secret: str) -> LocalDevelopmentKeyProvider:
    return LocalDevelopmentKeyProvider(hashlib.sha256(master_secret.encode()).digest())


def generate_wrapped_dek(master_secret: str, doc_id: str, version: int) -> tuple[bytes, str, str, str]:
    """Returns (dek, wrapped_b64, key_reference, key_version)."""
    dek, wk = new_dek(_provider(master_secret), doc_id, version)
    return dek, base64.b64encode(wk.wrapped).decode(), KEY_REF_GCM, str(wk.key_version)


def unwrap_dek(master_secret: str, wrapped_b64: str, key_reference: str, key_version: str,
               doc_id: str, version: int) -> bytes:
    raw = base64.b64decode(wrapped_b64.encode())
    if key_reference == KEY_REF_LEGACY_XOR:
        master = hashlib.sha256(master_secret.encode()).digest()
        return bytes(a ^ b for a, b in zip(raw, master[: len(raw)]))
    if key_reference != KEY_REF_GCM:
        raise KeyError_(f"unknown key reference {key_reference!r}")
    return open_dek(_provider(master_secret), WrappedKey(raw, int(key_version)), doc_id, version)


def needs_rewrap(key_reference: str) -> bool:
    return key_reference == KEY_REF_LEGACY_XOR


# ---- KMS-backed wrapping (aws / vault / any KeyProvider) ----------------------------------
# New rows wrapped by an external KMS get key_reference "kms_<backend>". Rows wrapped by the local
# dev KEK ("kek_v1_gcm") or the legacy XOR scheme stay readable via the master secret, so switching
# KMS_BACKEND does not orphan existing documents.
KEY_REF_KMS_PREFIX = "kms_"


def reference_for_backend(backend: str) -> str:
    return KEY_REF_GCM if backend == "local_dev" else f"{KEY_REF_KMS_PREFIX}{backend}"


def wrap_new_dek(kms, backend: str, doc_id: str, version: int) -> tuple[bytes, str, str, str]:
    """Like generate_wrapped_dek but through an arbitrary KeyProvider (e.g. build_kms(settings))."""
    dek, wk = new_dek(kms, doc_id, version)
    return dek, base64.b64encode(wk.wrapped).decode(), reference_for_backend(backend), str(wk.key_version)


def unwrap_any(master_secret: str, kms, backend: str, wrapped_b64: str, key_reference: str,
               key_version: str, doc_id: str, version: int) -> bytes:
    if key_reference.startswith(KEY_REF_KMS_PREFIX):
        if key_reference != reference_for_backend(backend):
            raise KeyError_(f"document was wrapped by {key_reference!r} but KMS_BACKEND={backend!r}")
        wk = WrappedKey(base64.b64decode(wrapped_b64.encode()), int(key_version))
        return open_dek(kms, wk, doc_id, version)
    return unwrap_dek(master_secret, wrapped_b64, key_reference, key_version, doc_id, version)
