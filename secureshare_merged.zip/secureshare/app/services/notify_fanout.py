"""Notification fan-out planning + delivery. Pure logic: senders are injected callables, so it runs
without a DB or network. A failing channel never blocks the others and never raises to the caller;
every attempt is reported honestly (SENT / SKIPPED / FAILED / PROVIDER_UNAVAILABLE)."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Mapping

SENT, SKIPPED, FAILED, UNAVAILABLE = "SENT", "SKIPPED", "FAILED", "PROVIDER_UNAVAILABLE"

# Types that justify leaving the app. Others stay in-app only.
EXTERNAL_TYPES = {"DOCUMENT_SHARED", "ACCESS_REQUEST", "ACCESS_APPROVED", "ACCESS_REJECTED",
                  "ACCESS_REVOKED", "SECURITY_ALERT"}
SMS_TYPES = {"SECURITY_ALERT", "ACCESS_REQUEST"}      # SMS costs money: only time-critical types


@dataclass(frozen=True)
class Recipient:
    user_id: str
    email: str | None = None
    phone_e164: str | None = None
    email_verified: bool = False
    phone_verified: bool = False
    email_enabled: bool = True
    sms_enabled: bool = False
    muted_types: frozenset[str] = frozenset()


@dataclass(frozen=True)
class Outcome:
    channel: str
    status: str
    detail: str = ""


class SenderUnavailable(Exception):
    """Raised by a sender callable when its provider is not configured."""


def plan(r: Recipient, type_: str) -> dict[str, str | None]:
    """channel -> None if it should be attempted, else the reason it is skipped."""
    out: dict[str, str | None] = {"in_app": None if type_ not in r.muted_types else "type muted"}
    ext = type_ in EXTERNAL_TYPES and type_ not in r.muted_types
    out["email"] = (None if ext and r.email_enabled and r.email and r.email_verified
                    else "not an external type" if type_ not in EXTERNAL_TYPES
                    else "muted" if type_ in r.muted_types
                    else "email notifications off" if not r.email_enabled
                    else "no verified email")
    out["sms"] = (None if type_ in SMS_TYPES and r.sms_enabled and r.phone_e164 and r.phone_verified
                  and type_ not in r.muted_types
                  else "not an SMS type" if type_ not in SMS_TYPES
                  else "SMS off" if not r.sms_enabled
                  else "no verified phone" if not (r.phone_e164 and r.phone_verified) else "muted")
    return out


def fan_out(r: Recipient, type_: str, title: str, message: str, *,
            in_app: Callable[[str, str, str, str], None],
            email: Callable[[str, str, str], None] | None = None,
            sms: Callable[[str, str], None] | None = None) -> list[Outcome]:
    """Messages must already be free of secrets/OTPs/keys (see notifications.py)."""
    p, res = plan(r, type_), []

    def attempt(ch: str, call: Callable[[], None] | None):
        if p[ch] is not None:
            res.append(Outcome(ch, SKIPPED, p[ch] or "")); return
        if call is None:
            res.append(Outcome(ch, UNAVAILABLE, "no sender configured")); return
        try:
            call(); res.append(Outcome(ch, SENT))
        except SenderUnavailable as exc:
            res.append(Outcome(ch, UNAVAILABLE, str(exc)[:120]))
        except Exception as exc:                        # noqa: BLE001 - isolate channel failures
            res.append(Outcome(ch, FAILED, type(exc).__name__))

    attempt("in_app", lambda: in_app(r.user_id, type_, title, message))
    attempt("email", (lambda: email(r.email, title, message)) if email else None)
    attempt("sms", (lambda: sms(r.phone_e164, f"{title}: {message}"[:300])) if sms else None)
    return res
