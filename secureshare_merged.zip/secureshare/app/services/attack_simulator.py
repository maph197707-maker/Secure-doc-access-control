"""Attack scenario battery: each scenario is a hostile context that the PDP must NOT allow.
A scenario passes only if the real PDP returns DENY (or VERIFY where stated)."""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timedelta, timezone

from app.core.enums import Decision, Permission, RiskLevel
from app.services.policy_engine import AccessContext, Binding, LinkStatus, Principal, evaluate


def scenarios(now: datetime | None = None) -> list[tuple[str, AccessContext, Decision]]:
    now = now or datetime.now(timezone.utc)
    link = AccessContext(action=Permission.VIEW, now=now, principal=Principal.RECIPIENT,
                         granted=frozenset({Permission.VIEW, Permission.DOWNLOAD}),
                         link_status=LinkStatus.ACTIVE, binding_required=True, binding=Binding.VERIFIED)
    return [
        ("expired link replay", replace(link, expires_at=now - timedelta(seconds=1)), Decision.DENY),
        ("revoked link replay", replace(link, link_status=LinkStatus.REVOKED), Decision.DENY),
        ("link before start time", replace(link, valid_from=now + timedelta(hours=1)), Decision.DENY),
        ("wrong recipient (binding failed)", replace(link, binding=Binding.FAILED), Decision.DENY),
        ("unverified recipient", replace(link, binding=Binding.PENDING), Decision.VERIFY),
        ("view limit exhausted", replace(link, max_views=3, views_used=3), Decision.DENY),
        ("one-time link reuse", replace(link, one_time=True, views_used=1), Decision.DENY),
        ("critical-risk session", replace(link, risk_level=RiskLevel.CRITICAL, risk_score=90), Decision.DENY),
        ("ungranted permission (download)", replace(link, action=Permission.DOWNLOAD,
                                                      granted=frozenset({Permission.VIEW})), Decision.DENY),
        ("anonymous without link", AccessContext(action=Permission.VIEW, now=now), Decision.DENY),
    ]


def run(now: datetime | None = None) -> dict:
    results = []
    for name, ctx, expected in scenarios(now):
        got = evaluate(ctx).decision
        results.append({"scenario": name, "expected": expected.value, "actual": got.value, "passed": got == expected})
    return {"passed": sum(r["passed"] for r in results), "total": len(results), "results": results}
