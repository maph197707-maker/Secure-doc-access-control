"""Safe database status for the admin screen. NEVER returns the password, the user name or the
full connection string: only type, masked host, version, reachability and migration state."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from sqlalchemy import text
from sqlalchemy.engine import make_url
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import ROOT, get_settings


def mask_host(host: str | None) -> str:
    """db.abcd1234.supabase.co -> d***.supabase.co ; 10.0.0.5 -> 10.*.*.* ; None -> '-'"""
    if not host:
        return "-"
    parts = host.split(".")
    if len(parts) == 4 and all(p.isdigit() for p in parts):
        return f"{parts[0]}.*.*.*"
    if len(parts) <= 2:
        return host[0] + "***"
    return f"{parts[0][0]}***." + ".".join(parts[-2:])


def migration_head() -> str | None:
    """Newest revision shipped in alembic/versions (None if Alembic is unavailable)."""
    try:
        from alembic.config import Config
        from alembic.script import ScriptDirectory
        cfg = Config(str(ROOT / "alembic.ini"))
        cfg.set_main_option("script_location", str(ROOT / "alembic"))
        return ScriptDirectory.from_config(cfg).get_current_head()
    except Exception:
        return None


async def database_status(db: AsyncSession | None = None) -> dict[str, Any]:
    """Probe on a DEDICATED connection. Probing through the request session (and rolling it back on the
    expected 'no alembic_version table yet' failure) expired every ORM object in that session, so the
    page that rendered the result crashed with MissingGreenlet. `db` is accepted for compatibility."""
    from app.db.session import engine

    url = make_url(get_settings().database_url)
    sqlite = url.get_backend_name() == "sqlite"
    out: dict[str, Any] = {
        "type": "SQLite" if sqlite else "PostgreSQL",
        "host": ("local file: " + Path(url.database or "").name) if sqlite else mask_host(url.host),
        "status": "Disconnected", "version": None, "migration": "Unknown",
        "current_revision": None, "head_revision": migration_head(),
    }
    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
            out["status"] = "Connected"
            out["version"] = (await conn.execute(text(
                "SELECT sqlite_version()" if sqlite else "SELECT version()"))).scalar_one()
            if not sqlite:
                out["version"] = str(out["version"]).split(",")[0]       # drop compiler details
    except Exception:
        return out                                                        # no driver text: may leak host
    try:
        async with engine.connect() as conn:
            out["current_revision"] = (await conn.execute(text("SELECT version_num FROM alembic_version"))).scalar_one_or_none()
    except Exception:
        out["migration"] = "Pending (alembic upgrade head has not been run)"
        return out
    head = out["head_revision"]
    out["migration"] = "Current" if head and out["current_revision"] == head else "Pending"
    return out
