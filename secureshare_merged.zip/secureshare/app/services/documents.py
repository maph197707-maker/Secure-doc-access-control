"""Document upload, retrieval, and management service."""
from __future__ import annotations

import hashlib
import io
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Sequence

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.exceptions import NotFoundError, PermissionDeniedError, ProviderUnavailableError, ValidationError
from app.crypto.aead import decrypt_stream, encrypt_bytes
from app.integrations.storage import StorageError, StorageService, build_storage_service
from app.integrations.kms import KmsUnavailable, build_kms
from app.integrations.malware import build_scanner
from app.services.key_wrap import unwrap_any, wrap_new_dek
from app.services.upload_scan import scan_bytes
from app.services import document_analysis as analysis_svc
from app.core.enums import DlpAction
from app.models.document import Document
from app.models.document_version import DocumentVersion
from app.repositories.audit import AuditRepository
from app.repositories.document import DocumentRepository
from app.security.validators import UploadRejected, validate_upload


def _gen_dek() -> bytes:
    """Generate a random 32-byte document encryption key."""
    return os.urandom(32)


class DocumentService:
    def __init__(self, db: AsyncSession) -> None:
        self.db = db
        self.settings = get_settings()
        self.storage: StorageService = build_storage_service(self.settings)
        self.scanner = build_scanner(self.settings)
        self._kms = None
        self.doc_repo = DocumentRepository(db)
        self.audit_repo = AuditRepository(db)

    def _kms_provider(self):
        if self._kms is None:
            try:
                self._kms = build_kms(self.settings)
            except KmsUnavailable as exc:      # PROVIDER_UNAVAILABLE: refuse, never silently use a dev key
                raise ProviderUnavailableError("Encryption key service is unavailable. Please try again later.") from exc
        return self._kms

    async def upload(
        self,
        owner_id: str,
        filename: str,
        content: bytes,
        display_name: Optional[str] = None,
        folder_id: Optional[str] = None,
        classification: str = "INTERNAL",
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> Document:
        """Validate, encrypt, and store an uploaded file. Returns the Document record."""
        settings = self.settings

        # 1. Validate file
        max_bytes = settings.max_upload_bytes
        allowed = tuple(settings.allowed_extensions)
        try:
            validated = validate_upload(
                filename, content[:8192], len(content),
                max_bytes=max_bytes, allowed=allowed
            )
        except UploadRejected as exc:
            raise ValidationError(exc.message)

        # 1b. Malware scan BEFORE anything is stored. INFECTED is rejected; an unavailable scanner is
        #     recorded as PROVIDER_UNAVAILABLE (or held) - never as CLEAN.
        scan, verdict = scan_bytes(self.scanner, content, settings.malware_unavailable_policy)
        if verdict.reject:
            await self.audit_repo.log_event(
                action="UPLOAD_BLOCKED_MALWARE", user_id=owner_id, resource_type="document",
                ip_address=ip_address, user_agent=user_agent,
                details={"filename": validated.safe_name, "engine": scan.engine, "signature": verdict.detail[:100]})
            await self.db.commit()          # keep the audit row: the raised error would otherwise roll it back
            raise ValidationError("The file was blocked because malware was detected.")

        # 1c. Text extraction + DLP scan BEFORE storage so a configured BLOCK threshold rejects the upload
        #     without ever writing ciphertext. Unreadable types are recorded as UNSUPPORTED, never "clean".
        analysis = await analysis_svc.analyze_async(content, validated.safe_name, settings)
        if analysis.action == DlpAction.BLOCK:
            await analysis_svc.block_event(self.db, analysis, validated.safe_name, owner_id, ip_address, user_agent)
            await self.db.commit()
            raise ValidationError(
                "This file was blocked by the data-loss-prevention policy: it contains "
                + ", ".join(sorted({f.rule_name.replace('_', ' ') for f in analysis.report.findings})) + ".")

        # 2. Compute hashes
        sha256 = hashlib.sha256(content).hexdigest()
        sha3 = hashlib.sha3_256(content).hexdigest()

        # 3. Generate internal storage name (the object key; never a user-supplied filename)
        internal_name = str(uuid.uuid4())
        storage_key = f"{internal_name}.enc"

        # 4. Per-document DEK, wrapped with AES-256-GCM (bound to document id + version)
        try:
            dek, wrapped_dek, key_ref, key_ver = wrap_new_dek(
                self._kms_provider(), settings.kms_backend, internal_name, 1)
        except KmsUnavailable as exc:      # cloud KMS outage: refuse the upload (503), never use a local key instead
            raise ProviderUnavailableError("Encryption key service is unavailable. Please try again later.") from exc
        encrypted = encrypt_bytes(dek, content, doc_id=internal_name, version=1, key_version=1)

        # 5. Store ciphertext through the configured backend (local atomic write or S3)
        try:
            self.storage.save(storage_key, encrypted)
        except StorageError as exc:
            raise ValidationError("The document could not be stored. Please try again.") from exc

        # 6. Create Document record
        doc = Document(
            owner_id=owner_id,
            folder_id=folder_id,
            original_filename=validated.safe_name,
            internal_name=internal_name,
            display_name=display_name or validated.safe_name,
            doc_type=validated.ext.upper(),
            status=verdict.doc_status,
            classification=classification,
            size_bytes=len(content),
            sha256=sha256,
            sha3_256=sha3,
            malware_scan_result=verdict.db_result,
            dlp_level="NONE",
        )
        self.db.add(doc)
        await self.db.flush()

        # 7. Create DocumentVersion record
        version = DocumentVersion(
            document_id=doc.id,
            version_number=1,
            created_by=owner_id,
            size_bytes=len(content),
            sha256=sha256,
            sha3_256=sha3,
            storage_path=storage_key,
            wrapped_dek=wrapped_dek,
            key_reference=key_ref,
            key_version=key_ver,
            nonce_prefix="",  # nonce is embedded in SSG1 format
        )
        self.db.add(version)
        await self.db.flush()

        doc.current_version_id = version.id
        await self.db.flush()

        # 7b. Persist DLP findings / level / classification / searchable (redacted) text
        await analysis_svc.persist(self.db, doc, analysis, settings, actor_id=owner_id, ip=ip_address,
                                   user_agent=user_agent, version_id=version.id)

        # 8. Audit
        await self.audit_repo.log_event(
            action="DOCUMENT_UPLOAD",
            user_id=owner_id,
            resource_type="document",
            resource_id=doc.id,
            ip_address=ip_address,
            user_agent=user_agent,
            details={"filename": validated.safe_name, "size_bytes": len(content),
                     "scan": verdict.db_result, "scan_engine": scan.engine},
        )

        return doc

    async def get_for_user(
        self, doc_id: str, user_id: str, is_superuser: bool = False
    ) -> Document:
        doc = await self.doc_repo.get_by_id(doc_id)
        if not doc:
            raise NotFoundError("Document not found.")
        if not is_superuser and doc.owner_id != user_id:
            raise PermissionDeniedError("Access denied.")
        return doc

    async def list_for_user(
        self,
        owner_id: str,
        page: int = 1,
        page_size: int = 20,
        folder_id: Optional[str] = None,
    ) -> tuple[Sequence[Document], int]:
        skip = (page - 1) * page_size
        return await self.doc_repo.list_for_user(
            owner_id, skip=skip, limit=page_size, folder_id=folder_id
        )

    async def update(
        self,
        doc_id: str,
        user_id: str,
        is_superuser: bool = False,
        display_name: Optional[str] = None,
        classification: Optional[str] = None,
        category: Optional[str] = None,
        sensitivity_level: Optional[int] = None,
        folder_id: Optional[str] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> Document:
        doc = await self.get_for_user(doc_id, user_id, is_superuser)
        if display_name is not None:
            doc.display_name = display_name
        if classification is not None:
            doc.classification = classification
        if category is not None:
            doc.category = category
        if sensitivity_level is not None:
            doc.sensitivity_level = sensitivity_level
        if folder_id is not None:
            doc.folder_id = folder_id
        await self.db.flush()
        await self.audit_repo.log_event(
            action="DOCUMENT_UPDATE",
            user_id=user_id,
            resource_type="document",
            resource_id=doc.id,
            ip_address=ip_address,
            user_agent=user_agent,
        )
        return doc

    async def delete(
        self,
        doc_id: str,
        user_id: str,
        is_superuser: bool = False,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> None:
        doc = await self.get_for_user(doc_id, user_id, is_superuser)
        doc.soft_delete()
        await self.db.flush()
        await self.audit_repo.log_event(
            action="DOCUMENT_DELETE",
            user_id=user_id,
            resource_type="document",
            resource_id=doc_id,
            ip_address=ip_address,
            user_agent=user_agent,
        )

    async def open_stream(self, doc: Document):
        """Authorization MUST already have happened (AccessControlService). Returns a generator of
        decrypted chunks; the file is never fully loaded into memory."""
        if doc.status == "QUARANTINED":      # held by the malware policy: never decrypt or serve
            raise PermissionDeniedError("This document is quarantined and cannot be opened.")
        if not doc.current_version_id:
            raise NotFoundError("No version found for document.")
        res = await self.db.execute(select(DocumentVersion).where(
            DocumentVersion.id == doc.current_version_id))
        version = res.scalar_one_or_none()
        if not version:
            raise NotFoundError("Document version not found.")
        # Rows written before the StorageService change hold an absolute local path; the object
        # key is always its final component. Path(...).name also strips any traversal prefix.
        key = Path(version.storage_path).name
        try:
            if not self.storage.exists(key):
                raise NotFoundError("File not found in storage.")
            blob = self.storage.read(key)
        except StorageError as exc:
            raise NotFoundError("File not found in storage.") from exc
        try:
            dek = unwrap_any(self.settings.master_secret,
                             self._kms_provider() if version.key_reference.startswith("kms_") else None,
                             self.settings.kms_backend, version.wrapped_dek, version.key_reference,
                             version.key_version, doc.internal_name, version.version_number)
        except KmsUnavailable as exc:
            raise ProviderUnavailableError("Encryption key service is unavailable. Please try again later.") from exc

        def gen():
            yield from decrypt_stream(dek, io.BytesIO(blob), doc_id=doc.internal_name,
                                      version=version.version_number, key_version=1)
        return gen()
