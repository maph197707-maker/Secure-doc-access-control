"""Admin service for system-wide user, security, and metrics operations."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Sequence
from sqlalchemy import desc, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.enums import RoleName, UserStatus
from app.core.exceptions import NotFoundError
from app.models.document import Document
from app.models.role import Role
from app.models.secure_link import SecureLink
from app.models.security_alert import SecurityAlert
from app.models.user import User


class AdminService:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def list_users(
        self,
        skip: int = 0,
        limit: int = 20,
        search: str | None = None,
    ) -> tuple[Sequence[User], int]:
        stmt = select(User).where(User.is_deleted == False)
        if search:
            search_pattern = f"%{search.strip()}%"
            stmt = stmt.where(
                or_(
                    User.email.ilike(search_pattern),
                    User.full_name.ilike(search_pattern),
                )
            )

        count_stmt = select(func.count()).select_from(stmt.subquery())
        total = (await self.session.execute(count_stmt)).scalar() or 0

        users_stmt = stmt.order_by(desc(User.created_at)).offset(skip).limit(limit)
        users = (await self.session.execute(users_stmt)).scalars().all()
        return users, total

    async def get_user_detail(self, user_id: str) -> User:
        stmt = select(User).where(User.id == user_id, User.is_deleted == False)
        user = (await self.session.execute(stmt)).scalar_one_or_none()
        if not user:
            raise NotFoundError("User not found.")
        return user

    async def suspend_user(self, user_id: str) -> User:
        user = await self.get_user_detail(user_id)
        user.status = UserStatus.SUSPENDED.value
        await self.session.flush()
        return user

    async def activate_user(self, user_id: str) -> User:
        user = await self.get_user_detail(user_id)
        user.status = UserStatus.ACTIVE.value
        await self.session.flush()
        return user

    async def toggle_suspend_user(self, user_id: str) -> User:
        user = await self.get_user_detail(user_id)
        if user.status == UserStatus.ACTIVE.value:
            user.status = UserStatus.SUSPENDED.value
        else:
            user.status = UserStatus.ACTIVE.value
        await self.session.flush()
        return user

    async def set_user_role(self, user_id: str, role: RoleName | str) -> User:
        """Replace the user's roles with the single named role. `User.role` is a read-only property
        derived from `roles`, so the relationship is what has to change."""
        user = await self.get_user_detail(user_id)
        name = role.value if hasattr(role, "value") else str(role)
        row = (await self.session.execute(select(Role).where(Role.name == name))).scalar_one_or_none()
        if row is None:
            raise NotFoundError(f"Role {name} does not exist. Run scripts/seed_roles.py.")
        user.roles = [row]
        await self.session.flush()
        return user

    async def get_admin_metrics(self) -> list[dict[str, Any]]:
        total_users = (
            await self.session.execute(
                select(func.count(User.id)).where(User.is_deleted == False)
            )
        ).scalar() or 0

        total_docs = (
            await self.session.execute(
                select(func.count(Document.id)).where(Document.is_deleted == False)
            )
        ).scalar() or 0

        active_links = (
            await self.session.execute(
                select(func.count(SecureLink.id)).where(SecureLink.status == "ACTIVE")
            )
        ).scalar() or 0

        pending_alerts = (
            await self.session.execute(
                select(func.count(SecurityAlert.id)).where(SecurityAlert.acknowledged == False)
            )
        ).scalar() or 0

        return [
            {"label": "Total Users", "value": total_users, "delta": None, "icon": "users"},
            {"label": "Total Documents", "value": total_docs, "delta": None, "icon": "file-text"},
            {"label": "Active Links", "value": active_links, "delta": None, "icon": "link"},
            {"label": "Pending Alerts", "value": pending_alerts, "delta": None, "icon": "alert"},
        ]

    async def get_recent_users(self, limit: int = 10) -> list[dict[str, Any]]:
        stmt = (
            select(User)
            .where(User.is_deleted == False)
            .order_by(desc(User.created_at))
            .limit(limit)
        )
        users = (await self.session.execute(stmt)).scalars().all()
        result = []
        for u in users:
            name = u.full_name or u.email.split("@")[0]
            parts = name.split()
            initials = ("".join(p[0] for p in parts[:2])).upper() or "U"
            result.append({
                "id": u.id,
                "name": name,
                "initials": initials,
                "email": u.email,
                "role": u.role,
                "status": u.status.lower() if u.status else "active",
                "mfa": bool(u.totp_secret),
                "created": u.created_at,
                "last_login": u.last_login_at,
            })
        return result
