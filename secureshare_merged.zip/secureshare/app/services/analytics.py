"""Analytics aggregation over real rows. Empty input yields zeros / empty series: no fabricated
values, no fake percentages (delta is None when the previous period is zero)."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timedelta
from typing import Iterable


def daily_series(times: Iterable[datetime], days: int, now: datetime) -> dict[str, list]:
    start = (now - timedelta(days=days - 1)).replace(hour=0, minute=0, second=0, microsecond=0)
    labels = [(start + timedelta(days=i)) for i in range(days)]
    counts = Counter(t.date() for t in times if t >= start and t <= now)
    return {"labels": [d.strftime("%a %d") for d in labels], "values": [counts.get(d.date(), 0) for d in labels]}


def pct_delta(current: float, previous: float) -> float | None:
    return None if not previous else round(100 * (current - previous) / previous, 1)


def breakdown(items: Iterable[str]) -> dict[str, list]:
    c = Counter(items)
    ordered = sorted(c.items(), key=lambda kv: (-kv[1], kv[0]))
    return {"labels": [k for k, _ in ordered], "values": [v for _, v in ordered]}


def storage_by_classification(rows: Iterable[tuple[str, int]]) -> dict[str, int]:
    out: Counter[str] = Counter()
    for cls, size in rows:
        out[cls or "UNCLASSIFIED"] += max(int(size or 0), 0)
    return dict(out)
