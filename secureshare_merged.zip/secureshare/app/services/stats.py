"""Real statistics for dashboards and analytics. Every number comes from a SQL query over stored rows.

Rules: no constants, no padding, no defaults that look like data. A period with nothing in it yields
zeros; a delta with no prior-period basis yields None (the templates then say "No prior-period data").
All datetimes are naive UTC (that is how the models store them).
"""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.audit import AuditLog
from app.models.document import Document
from app.models.notification import Notification
from app.models.secure_link import SecureLink
from app.models.user import User
from app.services.audit import GENESIS, chain_hash

# audit action -> (icon, tone, title). Unknown actions fall back to a readable title.
ACTION_VIEW: dict[str, tuple[str, str, str]] = {
    "DOCUMENT_UPLOAD": ("upload", "info", "Document uploaded"),
    "DOCUMENT_UPDATE": ("edit", "info", "Document updated"),
    "DOCUMENT_DELETE": ("trash", "warning", "Document deleted"),
    "SECURE_LINK_CREATE": ("link", "success", "Secure link created"),
    "SHARE_CREATED": ("link", "success", "Share created"),
    "SECURE_LINK_ROTATE": ("link", "info", "Link rotated"),
    "SECURE_LINK_REVOKE": ("link", "warning", "Link revoked"),
    "SECURE_LINK_DENIED": ("shield", "warning", "Link access denied"),
    "SECURE_LINK_PASSWORD_FAIL": ("shield", "warning", "Wrong link password"),
    "SECURE_LINK_LOCKED": ("shield", "danger", "Link locked after failures"),
    "SECURE_LINK_RECIPIENT_VERIFIED": ("check", "success", "Recipient verified"),
    "USER_LOGOUT": ("user", "info", "Signed out"),
    "USER_PASSWORD_CHANGE": ("shield", "info", "Password changed"),
    "ACCESS_DENIED": ("shield", "danger", "Access denied"),
}
DENIAL_ACTIONS = ("ACCESS_DENIED", "SECURE_LINK_DENIED", "SECURE_LINK_PASSWORD_FAIL",
                  "SECURE_LINK_LOCKED", "SECURE_LINK_RECIPIENT_CODE_FAIL", "PHONE_CODE_FAIL")


def utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def action_view(action: str) -> tuple[str, str, str]:
    return ACTION_VIEW.get(action, ("activity", "info", action.replace("_", " ").capitalize()))


def pct_delta(current: int | float, previous: int | float) -> float | None:
    """Percent change, or None when there is no prior-period basis (never an invented number)."""
    if not previous:
        return None
    return round((current - previous) * 100.0 / previous, 1)


def day_buckets(days: int, now: datetime | None = None) -> list[datetime]:
    """Midnight-aligned UTC day starts, oldest first, ending with today."""
    today = (now or utcnow()).replace(hour=0, minute=0, second=0, microsecond=0)
    return [today - timedelta(days=i) for i in range(days - 1, -1, -1)]


def bucket_counts(times: list[datetime], days: int, now: datetime | None = None) -> dict[str, list]:
    """Count timestamps per day. Portable across SQLite/PostgreSQL (bucketed in Python)."""
    starts = day_buckets(days, now)
    counts: Counter[datetime] = Counter()
    for t in times:
        counts[t.replace(hour=0, minute=0, second=0, microsecond=0)] += 1
    return {"labels": [d.strftime("%a" if days <= 7 else "%d %b") for d in starts],
            "values": [counts.get(d, 0) for d in starts]}


async def audit_times(db: AsyncSession, *, user_id: str | None, since: datetime,
                      actions: tuple[str, ...] | None = None, until: datetime | None = None) -> list[datetime]:
    stmt = select(AuditLog.created_at).where(AuditLog.created_at >= since)
    if until:
        stmt = stmt.where(AuditLog.created_at < until)
    if user_id:
        stmt = stmt.where(AuditLog.user_id == user_id)
    if actions:
        stmt = stmt.where(AuditLog.action.in_(actions))
    return [t for t in (await db.scalars(stmt.limit(50_000))).all() if t]


async def recent_activity(db: AsyncSession, user_id: str | None, limit: int = 10) -> list[dict[str, Any]]:
    stmt = select(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit)
    if user_id:
        stmt = stmt.where(AuditLog.user_id == user_id)
    out = []
    for row in (await db.scalars(stmt)).all():
        icon, kind, title = action_view(row.action)
        detail = (row.details or {}).get("filename") or (row.details or {}).get("reason") or row.resource_type or ""
        out.append({"icon": icon, "kind": kind, "title": title, "detail": str(detail), "when": row.created_at})
    return out


async def user_overview(db: AsyncSession, user: User) -> dict[str, Any]:
    now = utcnow()
    docs = await db.scalar(select(func.count(Document.id)).where(
        Document.owner_id == user.id, Document.is_deleted.is_(False))) or 0
    active_links = await db.scalar(select(func.count(SecureLink.id)).where(
        SecureLink.created_by == user.id, SecureLink.status == "ACTIVE", SecureLink.revoked_at.is_(None),
        (SecureLink.expires_at.is_(None)) | (SecureLink.expires_at > now))) or 0
    downloads = await db.scalar(select(func.coalesce(func.sum(SecureLink.download_count), 0)).where(
        SecureLink.created_by == user.id)) or 0
    week = bucket_counts(await audit_times(db, user_id=user.id, since=now - timedelta(days=7)), 7, now)
    return {"documents": int(docs), "active_links": int(active_links), "downloads": int(downloads),
            "activity": week, "recent": await recent_activity(db, user.id, 6)}


async def analytics(db: AsyncSession, user: User, days: int) -> dict[str, Any]:
    """Current period vs the equally long period before it, for the signed-in owner only."""
    now = utcnow()
    cur_start, prev_start = now - timedelta(days=days), now - timedelta(days=2 * days)

    async def docs_between(a, b) -> int:
        return int(await db.scalar(select(func.count(Document.id)).where(
            Document.owner_id == user.id, Document.is_deleted.is_(False),
            Document.created_at >= a, Document.created_at < b)) or 0)

    async def links_between(col, a, b) -> int:
        return int(await db.scalar(select(func.coalesce(func.sum(col), 0)).where(
            SecureLink.created_by == user.id, SecureLink.created_at >= a, SecureLink.created_at < b)) or 0)

    d_cur, d_prev = await docs_between(cur_start, now), await docs_between(prev_start, cur_start)
    v_cur, v_prev = (await links_between(SecureLink.view_count, cur_start, now),
                     await links_between(SecureLink.view_count, prev_start, cur_start))
    dl_cur, dl_prev = (await links_between(SecureLink.download_count, cur_start, now),
                       await links_between(SecureLink.download_count, prev_start, cur_start))
    dn_cur = len(await audit_times(db, user_id=user.id, since=cur_start, actions=DENIAL_ACTIONS))
    dn_prev = len(await audit_times(db, user_id=user.id, since=prev_start, until=cur_start, actions=DENIAL_ACTIONS))
    total_docs = int(await db.scalar(select(func.count(Document.id)).where(
        Document.owner_id == user.id, Document.is_deleted.is_(False))) or 0)

    kinds: Counter[str] = Counter()
    for name in (await db.scalars(select(Document.original_filename).where(
            Document.owner_id == user.id, Document.is_deleted.is_(False)))).all():
        ext = name.rsplit(".", 1)[-1].lower() if "." in name else "other"
        kinds["PDF" if ext == "pdf" else "DOCX" if ext in ("doc", "docx") else
              "Image" if ext in ("png", "jpg", "jpeg", "gif", "webp") else "Other"] += 1
    order = [k for k in ("PDF", "DOCX", "Image", "Other") if kinds.get(k)]
    return {
        "range": days,
        "trend": bucket_counts(await audit_times(db, user_id=user.id, since=cur_start), days, now),
        "types": {"labels": order, "values": [kinds[k] for k in order]},
        "metrics": [
            {"label": "Total Documents", "value": total_docs, "delta": pct_delta(d_cur, d_prev), "icon": "file"},
            {"label": "Link Views", "value": v_cur, "delta": pct_delta(v_cur, v_prev), "icon": "eye"},
            {"label": "Downloads", "value": dl_cur, "delta": pct_delta(dl_cur, dl_prev), "icon": "download"},
            {"label": "Denied Attempts", "value": dn_cur, "delta": pct_delta(dn_cur, dn_prev), "icon": "alert"},
        ],
    }


async def unread_count(db: AsyncSession, user_id: str) -> int:
    return int(await db.scalar(select(func.count(Notification.id)).where(
        Notification.user_id == user_id, Notification.read.is_(False))) or 0)


async def verify_audit_chain(db: AsyncSession) -> dict[str, Any]:
    """Re-derive every entry hash from its predecessor. broken_at is the first bad sequence number."""
    rows = (await db.scalars(select(AuditLog).where(AuditLog.sequence_number.is_not(None))
                             .order_by(AuditLog.sequence_number))).all()
    prev, broken, expected_seq = GENESIS, None, 1
    for r in rows:
        payload = {"seq": r.sequence_number, "action": r.action, "user_id": r.user_id,
                   "resource_type": r.resource_type, "resource_id": r.resource_id, "details": r.details or {}}
        if (r.sequence_number != expected_seq or r.prev_hash != prev
                or r.entry_hash != chain_hash(prev, payload)):
            broken = r.sequence_number
            break
        prev, expected_seq = r.entry_hash, expected_seq + 1
    return {"ok": broken is None, "count": len(rows), "head": prev[:16] if rows else "-", "broken_at": broken}
