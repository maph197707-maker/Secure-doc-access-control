"""Fixed-window rate limiter + escalating login lockout, on top of a StateStore."""
from __future__ import annotations

from dataclasses import dataclass

from app.integrations.state import StateStore


@dataclass(frozen=True)
class LimitResult:
    allowed: bool
    remaining: int
    retry_after: int  # seconds


def hit(store: StateStore, key: str, limit: int, window: int) -> LimitResult:
    n = store.incr(f"rl:{key}", window)
    if n > limit:
        return LimitResult(False, 0, max(int(store.ttl(f"rl:{key}")) + 1, 1))
    return LimitResult(True, limit - n, 0)


FREE_ATTEMPTS = 5


def lockout_seconds(failures: int) -> int:
    """0 for the first 5 failures, then 30s doubling each time, capped at 1 hour."""
    if failures < FREE_ATTEMPTS:
        return 0
    return min(30 * 2 ** (failures - FREE_ATTEMPTS), 3600)


class LoginThrottle:
    def __init__(self, store: StateStore, failure_memory: int = 24 * 3600) -> None:
        self.store, self.memory = store, failure_memory

    def locked_for(self, subject: str) -> int:
        return int(self.store.ttl(f"lock:{subject}")) + (1 if self.store.get(f"lock:{subject}") else 0)

    def record_failure(self, subject: str) -> int:
        """Returns lockout seconds now in force (0 = none)."""
        n = self.store.incr(f"fail:{subject}", self.memory)
        secs = lockout_seconds(n)
        if secs:
            self.store.set(f"lock:{subject}", True, secs)
        return secs

    def record_success(self, subject: str) -> None:
        self.store.delete(f"fail:{subject}")
        self.store.delete(f"lock:{subject}")
