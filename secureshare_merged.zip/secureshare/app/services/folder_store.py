"""Database layer for the nested folder tree. The pure rules (names, depth, cycles, duplicates) live in
app.services.folders; this module loads the owner's folders, applies those rules, then writes.

Every method is scoped to `owner_id`: a folder or document that belongs to someone else is reported as
"not found" (no existence oracle). Deleting a folder NEVER deletes documents: its sub-folders and
documents move up to the parent. Nothing here is executed in the authoring sandbox (no FastAPI/SQLAlchemy
installed there); tests/unit/test_folder_store.py covers it once dependencies are present.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.document import Document
from app.models.folder import Folder
from app.services.folders import FolderError, FolderNode, check_create, check_move, clean_name


def _now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


@dataclass(frozen=True)
class Crumb:
    id: str | None
    name: str


class FolderStore:
    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    # ── loading ──────────────────────────────────────────────────────────────
    async def _rows(self, owner_id: str) -> dict[str, Folder]:
        rows = (await self.db.scalars(select(Folder).where(
            Folder.owner_id == owner_id, Folder.is_deleted.is_(False)))).all()
        return {f.id: f for f in rows}

    @staticmethod
    def _nodes(rows: dict[str, Folder]) -> dict[str, FolderNode]:
        return {i: FolderNode(i, f.parent_id, f.name, f.owner_id) for i, f in rows.items()}

    async def nodes(self, owner_id: str) -> dict[str, FolderNode]:
        return self._nodes(await self._rows(owner_id))

    async def get(self, owner_id: str, folder_id: str) -> Folder:
        f = (await self._rows(owner_id)).get(folder_id)
        if f is None:
            raise FolderError("folder not found")
        return f

    # ── folder operations ────────────────────────────────────────────────────
    async def create(self, owner_id: str, parent_id: str | None, name: str) -> Folder:
        nodes = await self.nodes(owner_id)
        name = check_create(nodes, owner_id, parent_id or None, name)
        f = Folder(owner_id=owner_id, parent_id=parent_id or None, name=name)
        self.db.add(f)
        await self.db.flush()
        return f

    async def rename(self, owner_id: str, folder_id: str, name: str) -> Folder:
        rows = await self._rows(owner_id)
        f = rows.get(folder_id)
        if f is None:
            raise FolderError("folder not found")
        others = {k: v for k, v in self._nodes(rows).items() if k != folder_id}
        f.name = check_create(others, owner_id, f.parent_id, name)
        await self.db.flush()
        return f

    async def move(self, owner_id: str, folder_id: str, new_parent_id: str | None) -> Folder:
        rows = await self._rows(owner_id)
        nodes = self._nodes(rows)
        new_parent_id = new_parent_id or None
        check_move(nodes, owner_id, folder_id, new_parent_id)
        # depth of the moved subtree must still fit under the new parent
        from app.services.folders import MAX_DEPTH, depth
        sub = self._subtree_height(nodes, folder_id)
        if depth(nodes, new_parent_id) + sub > MAX_DEPTH:
            raise FolderError("maximum folder depth reached")
        f = rows[folder_id]
        f.parent_id = new_parent_id
        await self.db.flush()
        return f

    @staticmethod
    def _subtree_height(nodes: dict[str, FolderNode], root: str) -> int:
        kids: dict[str | None, list[str]] = {}
        for n in nodes.values():
            kids.setdefault(n.parent_id, []).append(n.id)

        def h(i: str) -> int:
            return 1 + max((h(c) for c in kids.get(i, [])), default=0)
        return h(root)

    async def delete(self, owner_id: str, folder_id: str) -> dict[str, int]:
        """Soft-delete one folder. Its children and documents move to its parent; nothing is lost."""
        rows = await self._rows(owner_id)
        f = rows.get(folder_id)
        if f is None:
            raise FolderError("folder not found")
        parent = f.parent_id
        siblings = {r.name.lower() for r in rows.values() if r.parent_id == parent and r.id != folder_id}
        moved_folders = 0
        for child in [r for r in rows.values() if r.parent_id == folder_id]:
            child.parent_id = parent
            base, n = child.name, 2
            while child.name.lower() in siblings:            # never collide with an existing sibling
                child.name = f"{base} ({n})"[:120]
                n += 1
            siblings.add(child.name.lower())
            moved_folders += 1
        docs = (await self.db.scalars(select(Document).where(
            Document.owner_id == owner_id, Document.folder_id == folder_id,
            Document.is_deleted.is_(False)))).all()
        for d in docs:
            d.folder_id = parent
        f.soft_delete()
        await self.db.flush()
        return {"folders": moved_folders, "documents": len(docs)}

    # ── documents ────────────────────────────────────────────────────────────
    async def move_document(self, owner_id: str, doc_id: str, folder_id: str | None) -> Document:
        doc = (await self.db.scalars(select(Document).where(
            Document.id == doc_id, Document.owner_id == owner_id, Document.is_deleted.is_(False)))).first()
        if doc is None:
            raise FolderError("document not found")
        if folder_id:
            await self.get(owner_id, folder_id)               # must be the owner's own folder
        doc.folder_id = folder_id or None
        await self.db.flush()
        return doc

    # ── browsing ─────────────────────────────────────────────────────────────
    def breadcrumbs(self, nodes: dict[str, FolderNode], folder_id: str | None) -> list[Crumb]:
        trail: list[Crumb] = []
        seen: set[str] = set()
        while folder_id and folder_id in nodes and folder_id not in seen:
            seen.add(folder_id)
            trail.append(Crumb(folder_id, nodes[folder_id].name))
            folder_id = nodes[folder_id].parent_id
        trail.append(Crumb(None, "My Documents"))
        return list(reversed(trail))

    async def listing(self, owner_id: str, folder_id: str | None) -> dict[str, Any]:
        """Sub-folders (with item counts) and documents directly inside `folder_id` (None = root)."""
        rows = await self._rows(owner_id)
        nodes = self._nodes(rows)
        if folder_id is not None and folder_id not in rows:
            raise FolderError("folder not found")
        doc_counts = dict((await self.db.execute(
            select(Document.folder_id, func.count()).where(
                Document.owner_id == owner_id, Document.is_deleted.is_(False),
                Document.folder_id.is_not(None)).group_by(Document.folder_id))).all())
        child_counts: dict[str, int] = {}
        for n in nodes.values():
            if n.parent_id:
                child_counts[n.parent_id] = child_counts.get(n.parent_id, 0) + 1
        subs = sorted((n for n in nodes.values() if n.parent_id == folder_id), key=lambda n: n.name.lower())
        docs_q = select(Document).where(Document.owner_id == owner_id, Document.is_deleted.is_(False))
        docs_q = docs_q.where(Document.folder_id == folder_id if folder_id else Document.folder_id.is_(None))
        docs = (await self.db.scalars(docs_q.order_by(Document.updated_at.desc()).limit(500))).all()
        return {
            "crumbs": self.breadcrumbs(nodes, folder_id),
            "folders": [{"id": n.id, "name": n.name,
                         "items": int(doc_counts.get(n.id, 0)) + child_counts.get(n.id, 0)} for n in subs],
            "documents": [{"id": d.id, "name": d.display_name or d.original_filename,
                           "size": d.size_bytes or 0, "updated": d.updated_at,
                           "classification": d.classification} for d in docs],
            # every folder as a flat, indented list for the "move to" pickers
            "choices": self.flat_choices(nodes),
        }

    @staticmethod
    def flat_choices(nodes: dict[str, FolderNode], exclude_subtree_of: str | None = None) -> list[dict[str, Any]]:
        kids: dict[str | None, list[FolderNode]] = {}
        for n in nodes.values():
            kids.setdefault(n.parent_id, []).append(n)
        out: list[dict[str, Any]] = []

        def walk(pid: str | None, level: int) -> None:
            for n in sorted(kids.get(pid, []), key=lambda x: x.name.lower()):
                if n.id == exclude_subtree_of:
                    continue
                out.append({"id": n.id, "label": ("\u2003" * level) + n.name})
                walk(n.id, level + 1)
        walk(None, 0)
        return out


__all__ = ["FolderStore", "FolderError", "Crumb", "clean_name"]
