"""Recipient-bound links: prove you are the named recipient before the document opens.

No web framework: the routes pass in plain RecipientRef values, a StateStore and an OtpService.

Flow  (binding_mode EMAIL_OTP or PHONE_OTP)
  1. CLAIM  - the visitor types the recipient email. If it matches a recipient of THIS link, a one-time
              code goes to the contact ON FILE (the email itself, or the stored phone). The answer is
              identical whether or not it matched, so the page cannot be used to guess who the
              recipients are, and the visitor never chooses where the code is sent.
  2. CODE   - the visitor submits the code. On success the browser gets a signed, expiring cookie
              naming the recipient; every /view/... request re-checks it.
Throttles: per (link, IP) and per link claim attempts (StateStore); code persistence, expiry, attempts,
cooldown, per-destination quotas and one-time use come from services.otp (database-backed).
"""
from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from enum import StrEnum

from app.core.exceptions import DeliveryError, RateLimitExceededError
from app.crypto.hashing import constant_time_equal, hmac_sha256
from app.integrations.email import EmailService
from app.integrations.sms import SMSService, normalize_phone
from app.integrations.state import StateStore
from app.services import otp
from app.services.otp import OtpPurpose, OtpService

MODE_NONE, MODE_EMAIL, MODE_PHONE = "NONE", "EMAIL_OTP", "PHONE_OTP"
BOUND_MODES = (MODE_EMAIL, MODE_PHONE)
CLAIMS_PER_IP, CLAIMS_PER_LINK, CLAIM_WINDOW = 10, 30, 900
PENDING_TTL, SESSION_TTL = 600, 3600

GENERIC_SENT = "If that email belongs to a recipient of this link, a verification code has been sent."


@dataclass(frozen=True)
class RecipientRef:
    id: str
    email: str
    phone: str | None = None          # E.164, required for PHONE_OTP


class ClaimStatus(StrEnum):
    SENT = "SENT"                      # shown for matches AND non-matches (no oracle)
    THROTTLED = "THROTTLED"


@dataclass(frozen=True)
class ClaimOutcome:
    status: ClaimStatus
    message: str
    pending: str | None = None         # signed token for the code form; None when nothing was sent
    delivered: bool = False            # internal (audit); never shown to the visitor


def normalize_email(s: str) -> str:
    return (s or "").strip().lower()


class RecipientError(ValueError):
    """Bad recipient input (message is safe to show the link owner)."""


def clean_recipients(rcpts: list[dict], binding_mode: str, default_cc: str = "+91") -> list[dict]:
    """Validate/normalise recipients for the chosen binding mode. Bound links need a named recipient
    (and, for SMS, a phone number); an unbound link keeps whatever was given."""
    if binding_mode != MODE_NONE and binding_mode not in BOUND_MODES:
        raise RecipientError("Unknown recipient verification mode.")
    out, seen = [], set()
    for r in rcpts:
        email = normalize_email(r.get("email") or "")
        if not email:
            continue
        if "@" not in email or len(email) > 320 or any(c.isspace() for c in email):
            raise RecipientError("Enter a valid recipient email.")
        phone = (r.get("phone") or "").strip() or None
        if phone:
            try:
                phone = normalize_phone(phone, default_cc)
            except ValueError as exc:
                raise RecipientError(str(exc)) from None
        if email in seen:
            continue
        seen.add(email)
        out.append({"email": email, "phone": phone})
    if binding_mode in BOUND_MODES and not out:
        raise RecipientError("Recipient verification needs the recipient's email.")
    if binding_mode == MODE_PHONE and any(not r["phone"] for r in out):
        raise RecipientError("SMS verification needs the recipient's phone number.")
    return out


def _subkey(master: bytes, label: bytes) -> bytes:
    return hmac_sha256(master, b"recipient-gate:" + label)


def _sign(master: bytes, label: bytes, payload: str) -> str:
    return hmac_sha256(_subkey(master, label), payload.encode()).hex()


def client_binding(user_agent: str | None) -> str:
    """Short browser fingerprint folded into the signed recipient session so a copied cookie does not
    work from a different browser/device. Not a strong secret (UA is guessable) - it stops casual
    cookie sharing / another user's browser, not a determined attacker who also copies the UA."""
    return hashlib.sha256((user_agent or "").encode()).hexdigest()[:16]


def _issue(master: bytes, label: bytes, link_id: str, rid: str, ttl: int, now: float | None = None,
           binding: str = "") -> str:
    exp = int((now if now is not None else time.time()) + ttl)
    payload = f"{link_id}:{rid}:{exp}" + (f":{binding}" if binding else "")
    return f"{rid}.{exp}.{_sign(master, label, payload)}"


def _read(master: bytes, label: bytes, link_id: str, value: str | None, now: float | None = None,
          binding: str = "") -> str | None:
    if not value or value.count(".") != 2:
        return None
    rid, exp_s, sig = value.split(".")
    if not exp_s.isdigit() or int(exp_s) < (now if now is not None else time.time()):
        return None
    good = _sign(master, label, f"{link_id}:{rid}:{exp_s}" + (f":{binding}" if binding else ""))
    return rid if constant_time_equal(sig, good) else None


def issue_pending(master: bytes, link_id: str, rid: str, now: float | None = None) -> str:
    return _issue(master, b"pending", link_id, rid, PENDING_TTL, now)


def read_pending(master: bytes, link_id: str, value: str | None, now: float | None = None) -> str | None:
    return _read(master, b"pending", link_id, value, now)


def issue_session(master: bytes, link_id: str, rid: str, now: float | None = None, binding: str = "") -> str:
    return _issue(master, b"session", link_id, rid, SESSION_TTL, now, binding)


def session_recipient(master: bytes, link_id: str, value: str | None, now: float | None = None,
                      binding: str = "") -> str | None:
    """Recipient id the browser verified as, or None. Label differs from 'pending', so a pending
    token (issued before the code was proven) can never be replayed as a verified session."""
    return _read(master, b"session", link_id, value, now, binding)


def find_recipient(recipients: list[RecipientRef], typed_email: str) -> RecipientRef | None:
    typed = normalize_email(typed_email)
    hit = None
    for r in recipients:                       # no early exit: same work whether or not it matches
        if constant_time_equal(r.email, typed) and hit is None:
            hit = r
    return hit


def _otp_key_for(link_id: str, rid: str) -> str:
    return f"{link_id}:{rid}"


async def claim(otp_svc: OtpService, store: StateStore, *, link_id: str, mode: str, ip: str, typed_email: str,
                recipients: list[RecipientRef], master: bytes, email: EmailService | None,
                sms: SMSService | None, user_agent: str | None = None) -> ClaimOutcome:
    if store.incr(f"rclaim:ip:{link_id}:{ip}", CLAIM_WINDOW) > CLAIMS_PER_IP or \
            store.incr(f"rclaim:link:{link_id}", CLAIM_WINDOW) > CLAIMS_PER_LINK:
        return ClaimOutcome(ClaimStatus.THROTTLED, "Too many attempts. Try again in a few minutes.")
    rec = find_recipient(recipients, typed_email)
    if rec is None or mode not in BOUND_MODES:
        return ClaimOutcome(ClaimStatus.SENT, GENERIC_SENT)
    delivered = await _deliver(otp_svc, link_id, mode, rec, email, sms, ip, user_agent)
    return ClaimOutcome(ClaimStatus.SENT, GENERIC_SENT,
                        pending=issue_pending(master, link_id, rec.id), delivered=delivered)


async def _deliver(otp_svc: OtpService, link_id, mode, rec, email, sms, ip, ua) -> bool:
    """True only if the provider accepted the code. Failures are already audited by OtpService; the
    visitor still gets the generic answer (so the page is not a recipient-guessing oracle)."""
    if mode == MODE_PHONE:
        if sms is None or not rec.phone:
            return False
        purpose, channel, dest = OtpPurpose.RECIPIENT_PHONE, "sms", rec.phone
        send = lambda code, minutes: sms.send_otp(rec.phone, code, minutes)     # noqa: E731
    else:
        if email is None:
            return False
        purpose, channel, dest = OtpPurpose.RECIPIENT_EMAIL, "email", rec.email
        send = lambda code, minutes: email.send_otp(rec.email, code, minutes)   # noqa: E731
    try:
        await otp_svc.send(purpose=purpose, subject=_otp_key_for(link_id, rec.id), destination=dest,
                           channel=channel, deliver=send, ip=ip, user_agent=ua)
    except (DeliveryError, RateLimitExceededError):
        return False
    return True


async def check_code(otp_svc: OtpService, *, link_id: str, mode: str, rec: RecipientRef, code: str,
                     ip: str | None = None, user_agent: str | None = None) -> otp.OtpResult:
    if mode == MODE_PHONE:
        if not rec.phone:
            return otp.OtpResult.NOT_FOUND
        purpose, dest = OtpPurpose.RECIPIENT_PHONE, rec.phone
    else:
        purpose, dest = OtpPurpose.RECIPIENT_EMAIL, rec.email
    return await otp_svc.verify(purpose=purpose, subject=_otp_key_for(link_id, rec.id), destination=dest,
                                code=code, ip=ip, user_agent=user_agent)
