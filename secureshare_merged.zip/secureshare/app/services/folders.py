"""Folder hierarchy rules (pure). The DB layer loads (id, parent_id, name, owner_id) tuples, calls
these checks, then writes. Ownership is verified by the caller before any move/rename."""
from __future__ import annotations

import re
from dataclasses import dataclass

MAX_DEPTH, MAX_NAME = 16, 120
_BAD = re.compile(r"[\x00-\x1f/\\]")


class FolderError(ValueError):
    pass


@dataclass(frozen=True)
class FolderNode:
    id: str
    parent_id: str | None
    name: str
    owner_id: str


def clean_name(name: str) -> str:
    n = (name or "").strip()
    if not n or n in (".", "..") or len(n) > MAX_NAME or _BAD.search(n):
        raise FolderError("invalid folder name")
    return n


def depth(nodes: dict[str, FolderNode], folder_id: str | None) -> int:
    d, seen = 0, set()
    while folder_id:
        if folder_id in seen:
            raise FolderError("cycle in folder tree")
        seen.add(folder_id)
        folder_id = nodes[folder_id].parent_id
        d += 1
    return d


def check_create(nodes: dict[str, FolderNode], owner_id: str, parent_id: str | None, name: str) -> str:
    name = clean_name(name)
    if parent_id is not None:
        parent = nodes.get(parent_id)
        if parent is None or parent.owner_id != owner_id:       # same error: no existence oracle
            raise FolderError("parent folder not found")
        if depth(nodes, parent_id) >= MAX_DEPTH:
            raise FolderError("maximum folder depth reached")
    if any(n.owner_id == owner_id and n.parent_id == parent_id and n.name.lower() == name.lower()
           for n in nodes.values()):
        raise FolderError("a folder with that name already exists here")
    return name


def check_move(nodes: dict[str, FolderNode], owner_id: str, folder_id: str, new_parent_id: str | None) -> None:
    f = nodes.get(folder_id)
    if f is None or f.owner_id != owner_id:
        raise FolderError("folder not found")
    cur = new_parent_id
    while cur:                                   # moving a folder into itself/its descendants
        if cur == folder_id:
            raise FolderError("cannot move a folder into itself or its descendant")
        cur = nodes[cur].parent_id
    check_create({k: v for k, v in nodes.items() if k != folder_id}, owner_id, new_parent_id, f.name)


def tree(nodes: dict[str, FolderNode], owner_id: str) -> list[dict]:
    kids: dict[str | None, list[FolderNode]] = {}
    for n in nodes.values():
        if n.owner_id == owner_id:
            kids.setdefault(n.parent_id, []).append(n)

    def build(pid: str | None) -> list[dict]:
        return [{"id": n.id, "name": n.name, "children": build(n.id)}
                for n in sorted(kids.get(pid, []), key=lambda x: x.name.lower())]
    return build(None)
