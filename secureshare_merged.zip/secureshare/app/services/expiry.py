"""Link expiry with an explicit timezone.

The wizard's <input type="datetime-local"> carries no timezone, so the browser's IANA zone name
(Intl.DateTimeFormat().resolvedOptions().timeZone) travels with it. Everything stored is naive UTC.

DST edge cases:
* gap (clocks jump forward, e.g. 02:30 does not exist)  -> mapped to the real instant the wall
  clock would have shown, i.e. shifted forward by the gap;
* fold (clocks fall back, 01:30 happens twice)          -> the EARLIER instant, so a link never
  outlives what the owner typed.
"""
from __future__ import annotations

import math
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

MAX_HOURS = 24 * 365
DEFAULT_TZ = "UTC"


class ExpiryError(ValueError):
    """User-facing validation problem (message is safe to show)."""


def load_zone(name: str | None) -> ZoneInfo:
    name = (name or DEFAULT_TZ).strip() or DEFAULT_TZ
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError, OSError):
        raise ExpiryError("Unknown timezone. Pick a timezone from the list.") from None


def local_to_utc(local_iso: str, tz_name: str | None) -> datetime:
    """'2026-10-05T10:00' in tz -> naive UTC datetime."""
    try:
        naive = datetime.fromisoformat(local_iso)
    except (ValueError, TypeError):
        raise ExpiryError("Enter a valid expiry date and time.") from None
    if naive.tzinfo is not None:                       # already absolute: trust it
        return naive.astimezone(timezone.utc).replace(tzinfo=None)
    zone = load_zone(tz_name)
    aware = naive.replace(tzinfo=zone, fold=0)         # fold=0 = earlier instant for ambiguous times
    return aware.astimezone(timezone.utc).replace(tzinfo=None)


def utc_to_local_str(utc_naive: datetime, tz_name: str | None) -> str:
    zone = load_zone(tz_name)
    return utc_naive.replace(tzinfo=timezone.utc).astimezone(zone).strftime("%Y-%m-%d %H:%M %Z")


def hours_until(local_iso: str, tz_name: str | None, now_utc: datetime | None = None) -> int:
    """Whole hours (>=1, capped at one year) from now until the chosen local time."""
    now = now_utc or datetime.now(timezone.utc).replace(tzinfo=None)
    secs = (local_to_utc(local_iso, tz_name) - now).total_seconds()
    if secs <= 0:
        raise ExpiryError("The expiry time must be in the future.")
    return max(1, min(math.ceil(secs / 3600), MAX_HOURS))


def expires_at(local_iso: str, tz_name: str | None, now_utc: datetime | None = None) -> datetime:
    """Exact naive-UTC expiry (no hour rounding); same validation as hours_until."""
    now = now_utc or datetime.now(timezone.utc).replace(tzinfo=None)
    when = local_to_utc(local_iso, tz_name)
    if when <= now:
        raise ExpiryError("The expiry time must be in the future.")
    return min(when, now + timedelta(hours=MAX_HOURS))
