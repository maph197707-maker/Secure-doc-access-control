"""Storage quota arithmetic. Enforced server-side by the upload path BEFORE bytes are stored;
`used` and `count` must come from the database (sum of non-deleted document sizes), never the client."""
from __future__ import annotations

from dataclasses import dataclass


class QuotaExceeded(Exception):
    def __init__(self, reason: str) -> None:
        super().__init__(reason)
        self.reason = reason


@dataclass(frozen=True)
class QuotaStatus:
    used_bytes: int
    limit_bytes: int
    file_count: int
    file_limit: int

    @property
    def remaining_bytes(self) -> int:
        return max(self.limit_bytes - self.used_bytes, 0)

    @property
    def percent_used(self) -> float:
        return round(100 * self.used_bytes / self.limit_bytes, 1) if self.limit_bytes else 100.0


def status(used_bytes: int, file_count: int, limit_bytes: int, file_limit: int) -> QuotaStatus:
    return QuotaStatus(max(used_bytes, 0), limit_bytes, max(file_count, 0), file_limit)


def check_upload(q: QuotaStatus, incoming_bytes: int) -> None:
    """Raises QuotaExceeded (map to HTTP 409/413) if the upload would break a limit."""
    if incoming_bytes < 0:
        raise QuotaExceeded("invalid size")
    if q.file_count + 1 > q.file_limit:
        raise QuotaExceeded("file count limit reached")
    if q.used_bytes + incoming_bytes > q.limit_bytes:
        raise QuotaExceeded("storage quota exceeded")


async def usage_for_user(db, user_id: str):  # noqa: ANN001
    """(used_bytes, file_count) from the database for one owner."""
    from sqlalchemy import func, select

    from app.models.document import Document
    row = (await db.execute(select(func.coalesce(func.sum(Document.size_bytes), 0), func.count(Document.id))
                            .where(Document.owner_id == user_id, Document.is_deleted.is_(False)))).one()
    return int(row[0]), int(row[1])
