"""Access management API — access requests, grants, and attempt audit."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_client_ip, get_current_active_user, get_db, get_user_agent
from app.repositories.audit import AuditRepository
from app.services import grants_logic as gl
from app.services import notifications as nt
from app.models.access_grant import AccessGrant
from app.models.access_request import AccessRequest
from app.models.document import Document
from app.models.user import User

router = APIRouter(prefix="/access", tags=["access"])


class CreateAccessRequest(BaseModel):
    document_id: str
    requested_permissions: list[str] = ["VIEW"]
    reason: Optional[str] = None


class AccessRequestResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    document_id: str
    requester_id: str
    requested_permissions: list[str]
    reason: Optional[str] = None
    status: str
    reviewed_by: Optional[str] = None
    reviewed_at: Optional[datetime] = None
    created_at: datetime


class ReviewAccessRequest(BaseModel):
    status: str  # APPROVED or REJECTED
    expires_at: Optional[datetime] = None


@router.post("/requests", response_model=AccessRequestResponse, status_code=201)
async def create_access_request(
    body: CreateAccessRequest,
    request: Request,
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> AccessRequestResponse:
    """Submit an access request. Owner is notified; nothing is granted until they approve."""
    doc = (await db.execute(select(Document).where(
        Document.id == body.document_id, Document.is_deleted == False))).scalar_one_or_none()  # noqa: E712
    if not doc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    if doc.owner_id == user.id:
        raise HTTPException(status_code=400, detail="You already own this document")
    try:
        perms = gl.normalize_permissions(body.requested_permissions)
    except gl.GrantInputError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    dup = (await db.execute(select(AccessRequest).where(
        AccessRequest.document_id == doc.id, AccessRequest.requester_id == user.id,
        AccessRequest.status == "PENDING"))).scalars().first()
    if dup:
        raise HTTPException(status_code=409, detail="You already have a pending request for this document")
    req = AccessRequest(document_id=doc.id, requester_id=user.id, requested_permissions=perms,
                        reason=(body.reason or "")[:1000] or None, status="PENDING")
    db.add(req)
    await db.flush()
    await AuditRepository(db).log_event(
        action="ACCESS_REQUEST", user_id=user.id, resource_type="document", resource_id=doc.id,
        ip_address=get_client_ip(request), user_agent=get_user_agent(request),
        details={"request_id": req.id, "permissions": perms})
    await nt.notify(db, doc.owner_id, nt.ACCESS_REQUEST, "Access requested",
                    f"{user.full_name} requested {', '.join(perms)} on '{doc.display_name}'.",
                    "access_request", req.id)
    await db.commit()
    await db.refresh(req)
    return AccessRequestResponse.model_validate(req)


@router.get("/requests", response_model=list[AccessRequestResponse])
async def list_access_requests(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    pending_only: bool = Query(default=True),
) -> list[AccessRequestResponse]:
    """List access requests for documents owned by current user."""
    # Find documents owned by user
    doc_subq = select(Document.id).where(Document.owner_id == user.id, Document.is_deleted == False)
    stmt = select(AccessRequest).where(AccessRequest.document_id.in_(doc_subq))
    if pending_only:
        stmt = stmt.where(AccessRequest.status == "PENDING")
    stmt = stmt.order_by(AccessRequest.created_at.desc())

    res = await db.execute(stmt)
    return [AccessRequestResponse.model_validate(r) for r in res.scalars().all()]


@router.post("/requests/{request_id}/review", response_model=AccessRequestResponse)
async def review_access_request(
    request_id: str,
    body: ReviewAccessRequest,
    request: Request,
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> AccessRequestResponse:
    """Owner approves/rejects. Approval creates (or updates) the grant on the server."""
    decision = body.status.strip().upper()
    if decision not in ("APPROVED", "REJECTED"):
        raise HTTPException(status_code=422, detail="status must be APPROVED or REJECTED")
    req = (await db.execute(select(AccessRequest).where(AccessRequest.id == request_id))).scalar_one_or_none()
    if not req:
        raise HTTPException(status_code=404, detail="Request not found")
    doc = (await db.execute(select(Document).where(Document.id == req.document_id))).scalar_one_or_none()
    # Only the owner decides. Admin role alone does not grant access to someone else's content.
    if not doc or doc.owner_id != user.id:
        raise HTTPException(status_code=404, detail="Request not found")
    if req.status != "PENDING":
        raise HTTPException(status_code=409, detail="Request already reviewed")
    requester = (await db.execute(select(User).where(User.id == req.requester_id))).scalar_one()

    req.status = decision
    req.reviewed_by = user.id
    req.reviewed_at = gl.utcnow()
    if decision == "APPROVED":
        from app.api.v1.shares import upsert_grant
        await upsert_grant(db, doc=doc, grantee=requester, granted_by=user,
                           permissions=gl.normalize_permissions(req.requested_permissions),
                           expires_at=gl.to_naive_utc(body.expires_at))
    await AuditRepository(db).log_event(
        action="ACCESS_APPROVED" if decision == "APPROVED" else "ACCESS_REJECTED", user_id=user.id,
        resource_type="document", resource_id=doc.id, ip_address=get_client_ip(request),
        user_agent=get_user_agent(request), details={"request_id": req.id, "requester_id": requester.id})
    await nt.notify(db, requester.id, nt.ACCESS_APPROVED if decision == "APPROVED" else nt.ACCESS_REJECTED,
                    "Access request " + decision.lower(),
                    f"Your request for '{doc.display_name}' was {decision.lower()}.", "document", doc.id)
    await db.commit()
    await db.refresh(req)
    return AccessRequestResponse.model_validate(req)
