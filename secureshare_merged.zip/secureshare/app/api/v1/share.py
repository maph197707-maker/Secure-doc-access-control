"""Share wizard and draft API."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Annotated, Any, Optional
from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.dependencies import get_current_active_user, get_db, get_client_ip, get_user_agent
from app.models.document import Document
from app.models.share_draft import ShareDraft
from app.models.user import User
from app.schemas.document import SecureLinkResponse
from app.services.link_urls import share_url
from app.services.secure_links import SecureLinkService

router = APIRouter(prefix="/share", tags=["share"])
settings = get_settings()


class DraftSaveRequest(BaseModel):
    step: int
    data: dict[str, Any]
    document_id: Optional[str] = None
    idempotency_key: Optional[str] = None


class DraftCompleteRequest(BaseModel):
    document_id: str
    password_protect: bool = False
    link_password: Optional[str] = None
    expires_in_hours: Optional[int] = 72
    max_views: Optional[int] = None
    max_downloads: Optional[int] = None
    allow_download: bool = False
    one_time: bool = False
    recipient_email: Optional[str] = None
    binding_mode: str = "NONE"


@router.post("/draft")
async def save_share_draft(
    body: DraftSaveRequest,
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict[str, Any]:
    """Save an in-progress share wizard draft."""
    stmt = select(ShareDraft).where(ShareDraft.owner_id == user.id)
    if body.idempotency_key:
        stmt = stmt.where(ShareDraft.idempotency_key == body.idempotency_key)
    # Without an idempotency key an owner may hold several drafts: take the newest instead of letting
    # scalar_one_or_none() raise MultipleResultsFound (HTTP 500).
    res = await db.execute(stmt.order_by(ShareDraft.created_at.desc()).limit(1))
    draft = res.scalars().first()

    if not draft:
        draft = ShareDraft(
            owner_id=user.id,
            step=body.step,
            data=body.data,
            document_id=body.document_id,
            idempotency_key=body.idempotency_key,
            expires_at=datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(days=1),
        )
        db.add(draft)
    else:
        draft.step = body.step
        draft.data = body.data
        if body.document_id:
            draft.document_id = body.document_id
        draft.expires_at = datetime.now(timezone.utc).replace(tzinfo=None) + timedelta(days=1)

    await db.commit()
    await db.refresh(draft)
    return {"status": "saved", "draft_id": draft.id, "step": draft.step}


@router.post("/finalize", response_model=SecureLinkResponse)
async def finalize_share(
    body: DraftCompleteRequest,
    user: Annotated[User, Depends(get_current_active_user)],
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> SecureLinkResponse:
    """Finalize the share wizard and generate the secure link."""
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    svc = SecureLinkService(db)

    recipient_emails = [body.recipient_email] if body.recipient_email else None

    link, raw_token = await svc.create_link(
        document_id=body.document_id,
        created_by=user.id,
        expires_in_hours=body.expires_in_hours or 72,
        max_views=body.max_views,
        max_downloads=body.max_downloads,
        allow_downloads=body.allow_download,
        requires_password=body.password_protect,
        password=body.link_password,
        one_time_view=body.one_time,
        recipient_emails=recipient_emails,
        binding_mode=body.binding_mode,
        ip_address=ip,
        user_agent=ua,
    )
    await db.commit()
    result = SecureLinkResponse.model_validate(link)
    result.share_url = share_url(request, raw_token)
    return result
