"""Sessions API endpoints."""
from __future__ import annotations

from typing import Annotated
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_user_and_session, get_db
from app.core.exceptions import NotFoundError, PermissionDeniedError
from app.models.session import UserSession
from app.models.user import User
from app.schemas.auth import SessionResponse
from app.services.sessions import SessionService

router = APIRouter(prefix="/sessions", tags=["sessions"])


@router.get("", response_model=list[SessionResponse])
async def list_sessions(
    auth: Annotated[tuple[UserSession, User], Depends(get_current_user_and_session)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> list[SessionResponse]:
    current_session, user = auth
    svc = SessionService(db)
    sessions = await svc.list_user_sessions(user.id)

    res = []
    for s in sessions:
        item = SessionResponse.model_validate(s)
        item.is_current = (s.id == current_session.id)
        res.append(item)
    return res


@router.delete("/{session_id}")
async def revoke_session(
    session_id: str,
    auth: Annotated[tuple[UserSession, User], Depends(get_current_user_and_session)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    current_session, user = auth
    svc = SessionService(db)

    # Ensure session belongs to user
    sessions = await svc.list_user_sessions(user.id)
    if not any(s.id == session_id for s in sessions):
        raise NotFoundError("Session not found.")

    await svc.revoke_session(session_id, reason="user_revocation")
    await db.commit()
    return {"status": "ok", "message": "Session revoked successfully."}


@router.post("/revoke-others")
async def revoke_other_sessions(
    auth: Annotated[tuple[UserSession, User], Depends(get_current_user_and_session)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    current_session, user = auth
    svc = SessionService(db)
    count = await svc.revoke_other_sessions(user.id, current_session.id)
    await db.commit()
    return {"status": "ok", "message": f"Revoked {count} other session(s)."}
