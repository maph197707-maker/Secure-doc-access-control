"""Audit log API — list events for authenticated user or admin."""
from __future__ import annotations

from typing import Annotated
from fastapi import APIRouter, Depends, Query
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_active_user, get_db
from app.models.audit import AuditLog
from app.models.user import User
from app.schemas.audit import AuditListResponse, AuditLogEntry

router = APIRouter(prefix="/audit", tags=["audit"])


@router.get("", response_model=AuditListResponse)
async def list_audit_events(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    action: str | None = Query(default=None),
) -> AuditListResponse:
    base_stmt = select(AuditLog)
    # Non-superusers only see their own events
    if not user.is_superuser:
        base_stmt = base_stmt.where(AuditLog.user_id == user.id)
    if action:
        base_stmt = base_stmt.where(AuditLog.action == action)

    count_res = await db.execute(select(func.count()).select_from(base_stmt.subquery()))
    total = count_res.scalar_one()

    stmt = (
        base_stmt.order_by(AuditLog.created_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    )
    res = await db.execute(stmt)
    items = [AuditLogEntry.model_validate(row) for row in res.scalars().all()]
    return AuditListResponse(items=items, total=total, page=page, page_size=page_size)
