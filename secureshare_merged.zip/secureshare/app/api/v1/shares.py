"""User-to-user sharing: create / list (My Shares, Shared With Me) / modify / revoke.

Every mutation is authorized server-side, persisted, audited and notified. Download/view of the
shared bytes is enforced separately (documents.py -> AccessControlService) on every request, so a
revocation here takes effect on the grantee's very next call.
"""
from __future__ import annotations

from datetime import datetime
from typing import Annotated, Optional

from fastapi import APIRouter, Depends, Query, Request
from pydantic import BaseModel
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_client_ip, get_current_active_user, get_db, get_user_agent
from app.core.enums import Permission
from app.core.exceptions import NotFoundError, PermissionDeniedError, ValidationError
from app.models.access_grant import AccessGrant
from app.models.document import Document
from app.models.user import User
from app.repositories.audit import AuditRepository
from app.services import grants_logic as gl
from app.services import notifications as nt
from app.services.access_control import AccessControlService, get_document_or_404

router = APIRouter(prefix="/shares", tags=["shares"])


class CreateShare(BaseModel):
    document_id: str
    grantee_email: str
    permissions: list[str] = ["VIEW"]
    expires_at: Optional[datetime] = None


class UpdateShare(BaseModel):
    permissions: Optional[list[str]] = None
    expires_at: Optional[datetime] = None
    clear_expiry: bool = False


class RevokeShare(BaseModel):
    reason: Optional[str] = None


def _row(g: AccessGrant, doc: Document, other: User, now: datetime, side: str) -> dict:
    d = {"id": g.id, "document_id": doc.id, "document_name": doc.display_name,
         "permissions": list(g.permissions or []), "created_at": g.created_at,
         "expires_at": g.expires_at, "revoked_at": g.revoked_at,
         "status": gl.grant_state(g, now), "classification": doc.classification,
         "restricted": doc.dlp_level in ("HIGH", "CRITICAL")}
    if side == "mine":
        d.update(recipient_email=other.email, recipient_name=other.full_name)
    else:
        d.update(owner_email=other.email, owner_name=other.full_name,
                 can_view="VIEW" in d["permissions"] and d["status"] == gl.ACTIVE,
                 can_download="DOWNLOAD" in d["permissions"] and d["status"] == gl.ACTIVE)
    return d


async def _live_grant(db: AsyncSession, doc_id: str, grantee_id: str) -> AccessGrant | None:
    res = await db.execute(select(AccessGrant).where(
        AccessGrant.document_id == doc_id, AccessGrant.grantee_id == grantee_id,
        AccessGrant.revoked_at.is_(None)).order_by(AccessGrant.created_at.desc()))
    now = gl.utcnow()
    for g in res.scalars().all():
        if gl.grant_state(g, now) == gl.ACTIVE:
            return g
    return None


async def upsert_grant(db: AsyncSession, *, doc: Document, grantee: User, granted_by: User,
                       permissions: list[str], expires_at: datetime | None) -> tuple[AccessGrant, bool]:
    """Create or update the single live grant for (document, grantee). Returns (grant, created)."""
    existing = await _live_grant(db, doc.id, grantee.id)
    if existing:
        existing.permissions = permissions
        existing.expires_at = expires_at
        await db.flush()
        return existing, False
    g = AccessGrant(document_id=doc.id, grantee_id=grantee.id, granted_by=granted_by.id,
                    permissions=permissions, expires_at=expires_at)
    db.add(g)
    await db.flush()
    return g, True


@router.post("", status_code=201)
async def create_share(body: CreateShare, request: Request,
                       user: Annotated[User, Depends(get_current_active_user)],
                       db: Annotated[AsyncSession, Depends(get_db)]) -> dict:
    now = gl.utcnow()
    doc = await get_document_or_404(db, body.document_id)
    # Owner may share; others only if they hold a live RESHARE grant AND the PDP allows it.
    if doc.owner_id != user.id:
        await AccessControlService(db).require(
            user, doc, Permission.RESHARE, ip=get_client_ip(request), user_agent=get_user_agent(request))
    try:
        perms = gl.normalize_permissions(body.permissions)
        exp = gl.validate_expiry(body.expires_at, now)
    except gl.GrantInputError as exc:
        raise ValidationError(str(exc)) from exc
    res = await db.execute(select(User).where(
        func.lower(User.email) == body.grantee_email.strip().lower(), User.is_deleted == False))  # noqa: E712
    grantee = res.scalar_one_or_none()
    if not grantee or not grantee.is_active:
        raise NotFoundError("Recipient not found or not active.")   # same message for both: no probing
    if grantee.id == doc.owner_id or grantee.id == user.id:
        raise ValidationError("You cannot share a document with its owner or yourself.")
    if doc.owner_id != user.id:                      # resharer cannot hand out more than they hold
        mine = gl.effective_permissions(await AccessControlService(db).grants_for(doc.id, user.id), now)
        if not {Permission(p) for p in perms} <= mine:
            raise PermissionDeniedError("You cannot grant permissions you do not hold.")
    g, created = await upsert_grant(db, doc=doc, grantee=grantee, granted_by=user,
                                    permissions=perms, expires_at=exp)
    await AuditRepository(db).log_event(
        action="SHARE_CREATED" if created else "PERMISSION_CHANGE", user_id=user.id,
        resource_type="document", resource_id=doc.id, ip_address=get_client_ip(request),
        user_agent=get_user_agent(request),
        details={"grant_id": g.id, "grantee_id": grantee.id, "permissions": perms,
                 "expires_at": exp.isoformat() if exp else None})
    await nt.notify(db, grantee.id, nt.DOCUMENT_SHARED, "A document was shared with you",
                    f"{user.full_name} shared '{doc.display_name}' ({', '.join(perms)}).",
                    "document", doc.id)
    await db.commit()
    return _row(g, doc, grantee, now, "mine")


@router.get("/mine")
async def my_shares(user: Annotated[User, Depends(get_current_active_user)],
                    db: Annotated[AsyncSession, Depends(get_db)],
                    page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)) -> dict:
    now = gl.utcnow()
    base = (select(AccessGrant, Document, User)
            .join(Document, Document.id == AccessGrant.document_id)
            .join(User, User.id == AccessGrant.grantee_id)
            .where(AccessGrant.granted_by == user.id, Document.is_deleted == False))  # noqa: E712
    total = (await db.execute(select(func.count()).select_from(base.subquery()))).scalar_one()
    rows = (await db.execute(base.order_by(AccessGrant.created_at.desc())
                             .offset((page - 1) * page_size).limit(page_size))).all()
    return {"items": [_row(g, d, u, now, "mine") for g, d, u in rows], "total": total, "page": page}


@router.get("/with-me")
async def shared_with_me(user: Annotated[User, Depends(get_current_active_user)],
                         db: Annotated[AsyncSession, Depends(get_db)],
                         page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)) -> dict:
    now = gl.utcnow()
    base = (select(AccessGrant, Document, User)
            .join(Document, Document.id == AccessGrant.document_id)
            .join(User, User.id == Document.owner_id)
            .where(AccessGrant.grantee_id == user.id, Document.is_deleted == False))  # noqa: E712
    total = (await db.execute(select(func.count()).select_from(base.subquery()))).scalar_one()
    rows = (await db.execute(base.order_by(AccessGrant.created_at.desc())
                             .offset((page - 1) * page_size).limit(page_size))).all()
    return {"items": [_row(g, d, u, now, "with_me") for g, d, u in rows], "total": total, "page": page}


async def _owned_grant(db: AsyncSession, grant_id: str, user: User) -> tuple[AccessGrant, Document]:
    res = await db.execute(select(AccessGrant).where(AccessGrant.id == grant_id))
    g = res.scalar_one_or_none()
    if not g or g.grantee_id is None:
        raise NotFoundError("Share not found.")
    doc = await get_document_or_404(db, g.document_id)
    # only the document owner or whoever created the grant may change it
    if doc.owner_id != user.id and g.granted_by != user.id:
        raise NotFoundError("Share not found.")           # 404 not 403: do not reveal existence
    return g, doc


@router.patch("/{grant_id}")
async def update_share(grant_id: str, body: UpdateShare, request: Request,
                       user: Annotated[User, Depends(get_current_active_user)],
                       db: Annotated[AsyncSession, Depends(get_db)]) -> dict:
    now = gl.utcnow()
    g, doc = await _owned_grant(db, grant_id, user)
    if gl.grant_state(g, now) == gl.REVOKED:
        raise ValidationError("A revoked share cannot be modified. Create a new share.")
    try:
        if body.permissions is not None:
            g.permissions = gl.normalize_permissions(body.permissions)
        if body.clear_expiry:
            g.expires_at = None
        elif body.expires_at is not None:
            g.expires_at = gl.validate_expiry(body.expires_at, now)
    except gl.GrantInputError as exc:
        raise ValidationError(str(exc)) from exc
    await AuditRepository(db).log_event(
        action="PERMISSION_CHANGE", user_id=user.id, resource_type="document", resource_id=doc.id,
        ip_address=get_client_ip(request), user_agent=get_user_agent(request),
        details={"grant_id": g.id, "permissions": list(g.permissions),
                 "expires_at": g.expires_at.isoformat() if g.expires_at else None})
    await nt.notify(db, g.grantee_id, nt.SHARE_UPDATED, "Share permissions changed",
                    f"Your access to '{doc.display_name}' was updated.", "document", doc.id)
    grantee = (await db.execute(select(User).where(User.id == g.grantee_id))).scalar_one()
    await db.commit()
    return _row(g, doc, grantee, now, "mine")


@router.delete("/{grant_id}")
async def revoke_share(grant_id: str, request: Request,
                       user: Annotated[User, Depends(get_current_active_user)],
                       db: Annotated[AsyncSession, Depends(get_db)],
                       body: RevokeShare | None = None) -> dict:
    now = gl.utcnow()
    g, doc = await _owned_grant(db, grant_id, user)
    if g.revoked_at is None:
        g.revoked_at = now
        g.revoke_reason = ((body.reason if body else None) or "")[:500] or None
        await AuditRepository(db).log_event(
            action="REVOCATION", user_id=user.id, resource_type="document", resource_id=doc.id,
            ip_address=get_client_ip(request), user_agent=get_user_agent(request),
            details={"grant_id": g.id, "grantee_id": g.grantee_id})
        await nt.notify(db, g.grantee_id, nt.ACCESS_REVOKED, "Access revoked",
                        f"Your access to '{doc.display_name}' was revoked.", "document", doc.id)
    await db.commit()
    return {"id": g.id, "status": gl.REVOKED, "revoked_at": g.revoked_at}
