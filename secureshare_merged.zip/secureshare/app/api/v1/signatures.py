"""Signatures API — cryptographic signing and verification of documents."""
from __future__ import annotations

import base64
from datetime import datetime, timezone
from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_active_user, get_db
from app.crypto.signatures import SigAlg, generate_keypair, sign, verify
from app.models.document import Document
from app.models.signature import Signature
from app.models.user import User

router = APIRouter(prefix="/signatures", tags=["signatures"])


class SignatureResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    document_id: str
    version_id: Optional[str] = None
    algorithm: str
    signature_b64: str
    public_key_reference: str
    signer_id: str
    payload_sha256: str
    verified_at: Optional[datetime] = None
    verify_result: Optional[bool] = None
    created_at: datetime


@router.post("/documents/{document_id}/sign", response_model=SignatureResponse, status_code=201)
async def sign_document(
    document_id: str,
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    algorithm: str = "ED25519",
) -> SignatureResponse:
    """Digitally sign a document using asymmetric cryptography (Ed25519 by default)."""
    doc_stmt = select(Document).where(Document.id == document_id, Document.is_deleted == False)
    doc_res = await db.execute(doc_stmt)
    doc = doc_res.scalar_one_or_none()
    if not doc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    if doc.owner_id != user.id and user.role != "ADMIN":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    alg = SigAlg(algorithm) if algorithm in SigAlg.__members__ else SigAlg.ED25519
    priv_pem, pub_pem = generate_keypair(alg)
    digest_bytes = bytes.fromhex(doc.sha256)
    sig_bytes = sign(alg, priv_pem, digest_bytes)

    sig_record = Signature(
        document_id=doc.id,
        algorithm=alg.value,
        signature_b64=base64.b64encode(sig_bytes).decode("ascii"),
        public_key_reference=base64.b64encode(pub_pem).decode("ascii"),
        signer_id=user.id,
        payload_sha256=doc.sha256,
        verified_at=datetime.now(timezone.utc),
        verify_result=True,
    )
    db.add(sig_record)
    await db.commit()
    await db.refresh(sig_record)
    return SignatureResponse.model_validate(sig_record)


@router.get("/documents/{document_id}", response_model=list[SignatureResponse])
async def list_document_signatures(
    document_id: str,
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> list[SignatureResponse]:
    """List all cryptographic signatures for a document."""
    doc_stmt = select(Document).where(Document.id == document_id, Document.is_deleted == False)
    doc_res = await db.execute(doc_stmt)
    doc = doc_res.scalar_one_or_none()
    if not doc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")

    stmt = select(Signature).where(Signature.document_id == document_id).order_by(Signature.created_at.desc())
    res = await db.execute(stmt)
    return [SignatureResponse.model_validate(s) for s in res.scalars().all()]


@router.post("/{signature_id}/verify", response_model=SignatureResponse)
async def verify_signature(
    signature_id: str,
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> SignatureResponse:
    """Verify cryptographic signature integrity."""
    stmt = select(Signature).where(Signature.id == signature_id)
    res = await db.execute(stmt)
    sig = res.scalar_one_or_none()
    if not sig:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Signature not found")

    pub_pem = base64.b64decode(sig.public_key_reference)
    sig_bytes = base64.b64decode(sig.signature_b64)
    digest_bytes = bytes.fromhex(sig.payload_sha256)
    alg = SigAlg(sig.algorithm)

    is_valid = verify(alg, pub_pem, digest_bytes, sig_bytes)
    sig.verify_result = is_valid
    sig.verified_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(sig)
    return SignatureResponse.model_validate(sig)
