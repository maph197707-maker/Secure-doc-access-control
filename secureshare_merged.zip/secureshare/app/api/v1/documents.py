"""Documents API endpoints — upload, list, get, update, delete, download."""
from __future__ import annotations

from typing import Annotated
from fastapi import APIRouter, Depends, Request, Response, UploadFile, File, Form, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import (get_client_ip, get_current_active_user, get_db, get_mfa_verified,
                                   get_user_agent)
from app.core.enums import Permission
from app.core.exceptions import PermissionDeniedError
from app.models.user import User
from app.services.access_control import AccessControlService, get_document_or_404
from app.schemas.document import DocumentListResponse, DocumentResponse, DocumentUpdateRequest
from app.services.documents import DocumentService

router = APIRouter(prefix="/documents", tags=["documents"])


@router.post("", status_code=201, response_model=DocumentResponse)
@router.post("/upload", status_code=201, response_model=DocumentResponse)
async def upload_document(
    user: Annotated[User, Depends(get_current_active_user)],
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
    file: UploadFile = File(...),
    display_name: str | None = Form(default=None),
    classification: str = Form(default="INTERNAL"),
    folder_id: str | None = Form(default=None),
) -> DocumentResponse:
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    content = await file.read()
    svc = DocumentService(db)
    doc = await svc.upload(
        owner_id=user.id,
        filename=file.filename or "upload",
        content=content,
        display_name=display_name,
        folder_id=folder_id,
        classification=classification,
        ip_address=ip,
        user_agent=ua,
    )
    await db.commit()
    return DocumentResponse.model_validate(doc)


@router.get("", response_model=DocumentListResponse)
async def list_documents(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
    folder_id: str | None = Query(default=None),
) -> DocumentListResponse:
    svc = DocumentService(db)
    docs, total = await svc.list_for_user(
        owner_id=user.id, page=page, page_size=page_size, folder_id=folder_id
    )
    return DocumentListResponse(
        items=[DocumentResponse.model_validate(d) for d in docs],
        total=total,
        page=page,
        page_size=page_size,
    )


@router.get("/{doc_id}", response_model=DocumentResponse)
async def get_document(
    doc_id: str,
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> DocumentResponse:
    svc = DocumentService(db)
    doc = await svc.get_for_user(doc_id, user.id, is_superuser=user.is_superuser)
    return DocumentResponse.model_validate(doc)


@router.patch("/{doc_id}", response_model=DocumentResponse)
async def update_document(
    doc_id: str,
    body: DocumentUpdateRequest,
    user: Annotated[User, Depends(get_current_active_user)],
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> DocumentResponse:
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    svc = DocumentService(db)
    doc = await svc.update(
        doc_id=doc_id,
        user_id=user.id,
        is_superuser=user.is_superuser,
        display_name=body.display_name,
        classification=body.classification,
        category=body.category,
        sensitivity_level=body.sensitivity_level,
        folder_id=body.folder_id,
        ip_address=ip,
        user_agent=ua,
    )
    await db.commit()
    return DocumentResponse.model_validate(doc)


@router.delete("/{doc_id}", status_code=204)
async def delete_document(
    doc_id: str,
    user: Annotated[User, Depends(get_current_active_user)],
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> None:
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    svc = DocumentService(db)
    await svc.delete(doc_id, user.id, is_superuser=user.is_superuser, ip_address=ip, user_agent=ua)
    await db.commit()


async def _serve(doc_id: str, action: Permission, disposition: str, request: Request,
                 user: User, db: AsyncSession, mfa_verified: bool = False) -> StreamingResponse:
    doc = await get_document_or_404(db, doc_id)
    ac = AccessControlService(db)
    out = await ac.authorize(user, doc, action, ip=get_client_ip(request),
                             user_agent=get_user_agent(request), mfa_verified=mfa_verified)
    if not out.allowed:
        await db.commit()          # keep the ACCESS_DENIED audit row; then refuse
        raise PermissionDeniedError(
            "Access denied.", details={"decision": out.decision.decision.value, "reasons": out.reasons})
    stream = await DocumentService(db).open_stream(doc)
    await db.commit()
    safe = doc.original_filename.replace('"', "").replace("\r", "").replace("\n", "")
    return StreamingResponse(
        stream, media_type="application/octet-stream",
        headers={"Content-Disposition": f'{disposition}; filename="{safe}"',
                 "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"})


@router.get("/{doc_id}/download")
async def download_document(doc_id: str, request: Request,
                            user: Annotated[User, Depends(get_current_active_user)],
                            db: Annotated[AsyncSession, Depends(get_db)],
                            mfa: Annotated[bool, Depends(get_mfa_verified)]) -> StreamingResponse:
    """DOWNLOAD permission required (owner, or a live share that includes DOWNLOAD)."""
    return await _serve(doc_id, Permission.DOWNLOAD, "attachment", request, user, db, mfa)


@router.get("/{doc_id}/content")
async def view_document(doc_id: str, request: Request,
                        user: Annotated[User, Depends(get_current_active_user)],
                        db: Annotated[AsyncSession, Depends(get_db)],
                        mfa: Annotated[bool, Depends(get_mfa_verified)]) -> StreamingResponse:
    """VIEW permission required. Same engine; a view-only share cannot call /download."""
    return await _serve(doc_id, Permission.VIEW, "inline", request, user, db, mfa)
