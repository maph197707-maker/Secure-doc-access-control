"""Simulator API — Zero-Trust Policy Decision Point and Attack Simulation."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Annotated, Any, Optional
from fastapi import APIRouter, Depends
from pydantic import BaseModel

from app.core.dependencies import get_current_active_user
from app.core.enums import Decision, DlpLevel, Permission, RiskLevel
from app.models.user import User
from app.services.policy_engine import (
    AccessContext,
    Binding,
    LinkStatus,
    Principal,
    Reputation,
    evaluate,
)

router = APIRouter(prefix="/simulator", tags=["simulator"])


class PolicySimRequest(BaseModel):
    action: str = "VIEW"
    principal: str = "USER"
    session_active: bool = True
    email_verified: bool = True
    is_owner: bool = False
    binding_required: bool = False
    binding: str = "NOT_REQUIRED"
    otp_required: bool = False
    otp_verified: bool = False
    mfa_required: bool = False
    mfa_verified: bool = False
    device_required: bool = False
    device_trusted: bool = False
    link_status: str = "ACTIVE"
    reputation: str = "NORMAL"
    views_used: int = 0
    max_views: Optional[int] = None
    downloads_used: int = 0
    max_downloads: Optional[int] = None
    risk_score: int = 10
    dlp_level: str = "NONE"


class PolicySimResponse(BaseModel):
    decision: str
    allowed: bool
    reasons: list[str]
    required_actions: list[str]
    risk_score: int
    dlp_level: str
    restrictions: dict[str, Any]


@router.post("/policy", response_model=PolicySimResponse)
async def simulate_policy(
    body: PolicySimRequest,
    user: Annotated[User, Depends(get_current_active_user)],
) -> PolicySimResponse:
    """Simulate a Zero-Trust access evaluation against policy rules."""
    perm = Permission(body.action) if body.action in Permission.__members__ else Permission.VIEW
    principal = Principal(body.principal) if body.principal in Principal.__members__ else Principal.USER
    binding = Binding(body.binding) if body.binding in Binding.__members__ else Binding.NOT_REQUIRED
    link_status = LinkStatus(body.link_status) if body.link_status in LinkStatus.__members__ else LinkStatus.ACTIVE
    reputation = Reputation(body.reputation) if body.reputation in Reputation.__members__ else Reputation.NORMAL
    dlp_level = DlpLevel(body.dlp_level) if body.dlp_level in DlpLevel.__members__ else DlpLevel.NONE

    granted = frozenset([perm])

    ctx = AccessContext(
        action=perm,
        now=datetime.now(timezone.utc),
        principal=principal,
        session_active=body.session_active,
        email_verified=body.email_verified,
        is_owner=body.is_owner,
        role_permissions=frozenset(["DOCUMENT_VIEW", "DOCUMENT_DOWNLOAD"] if body.session_active else []),
        granted=granted,
        binding_required=body.binding_required,
        binding=binding,
        otp_required=body.otp_required,
        otp_verified=body.otp_verified,
        mfa_required=body.mfa_required,
        mfa_verified=body.mfa_verified,
        device_required=body.device_required,
        device_trusted=body.device_trusted,
        link_status=link_status,
        reputation=reputation,
        views_used=body.views_used,
        max_views=body.max_views,
        downloads_used=body.downloads_used,
        max_downloads=body.max_downloads,
        risk_score=body.risk_score,
        dlp_level=dlp_level,
    )

    dec = evaluate(ctx)
    return PolicySimResponse(
        decision=dec.decision.value,
        allowed=dec.allowed,
        reasons=dec.reasons,
        required_actions=dec.required_actions,
        risk_score=dec.risk_score,
        dlp_level=dec.dlp_level.value,
        restrictions=dec.restrictions,
    )


@router.post("/attack")
async def simulate_attack_scenarios(
    user: Annotated[User, Depends(get_current_active_user)],
) -> dict[str, Any]:
    """Run an automated battery of simulated attack vectors against the Zero-Trust engine."""
    now = datetime.now(timezone.utc)
    scenarios = [
        {
            "name": "Expired Link Access",
            "desc": "Attacker attempts to access revoked/expired secure link token",
            "ctx": AccessContext(
                action=Permission.VIEW,
                now=now,
                principal=Principal.ANONYMOUS,
                link_status=LinkStatus.EXPIRED,
            ),
        },
        {
            "name": "Abused Reputation IP / Botnet",
            "desc": "Traffic originated from known abusive IP reputation",
            "ctx": AccessContext(
                action=Permission.VIEW,
                now=now,
                principal=Principal.ANONYMOUS,
                link_status=LinkStatus.ACTIVE,
                reputation=Reputation.ABUSED,
            ),
        },
        {
            "name": "Unverified Recipient Impersonation",
            "desc": "Attacker attempts access to email-bound document without OTP validation",
            "ctx": AccessContext(
                action=Permission.VIEW,
                now=now,
                principal=Principal.RECIPIENT,
                binding_required=True,
                binding=Binding.FAILED,
                link_status=LinkStatus.ACTIVE,
            ),
        },
        {
            "name": "Exceeded Max Views (View Quota Breach)",
            "desc": "Link has a 1-view limit but attacker replays request",
            "ctx": AccessContext(
                action=Permission.VIEW,
                now=now,
                principal=Principal.ANONYMOUS,
                link_status=LinkStatus.ACTIVE,
                views_used=5,
                max_views=1,
            ),
        },
        {
            "name": "High-Risk Threat Anomaly (Critical Risk Score)",
            "desc": "High anomaly score (95/100) triggering automated step-up or denial",
            "ctx": AccessContext(
                action=Permission.DOWNLOAD,
                now=now,
                principal=Principal.USER,
                session_active=True,
                email_verified=True,
                risk_score=95,
                risk_level=RiskLevel.CRITICAL,
            ),
        },
    ]

    results = []
    for sc in scenarios:
        dec = evaluate(sc["ctx"])
        results.append({
            "scenario": sc["name"],
            "description": sc["desc"],
            "decision": dec.decision.value,
            "blocked": not dec.allowed or dec.decision == Decision.DENY,
            "reasons": dec.reasons,
            "required_actions": dec.required_actions,
        })

    all_blocked = all(r["blocked"] for r in results)
    return {
        "summary": "All attack vectors successfully mitigated by Zero-Trust PDP" if all_blocked else "Some attacks permitted",
        "total_scenarios": len(results),
        "mitigated_count": sum(1 for r in results if r["blocked"]),
        "results": results,
    }
