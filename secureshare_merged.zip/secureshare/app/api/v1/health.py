"""Health check API — system status, database connection, and subsystem health."""
from __future__ import annotations

from typing import Annotated, Any
from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.dependencies import get_db

router = APIRouter(prefix="/health", tags=["health"])
settings = get_settings()


@router.get("")
async def health_check(
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict[str, Any]:
    """Comprehensive health check for API v1."""
    db_ok = False
    try:
        await db.execute(text("SELECT 1"))
        db_ok = True
    except Exception:
        db_ok = False

    return {
        "status": "healthy" if db_ok else "degraded",
        "version": "1.0.0",
        "app_mode": settings.app_mode,
        "database": "connected" if db_ok else "unreachable",
        "crypto": "active",
        "zero_trust_pdp": "active",
    }
