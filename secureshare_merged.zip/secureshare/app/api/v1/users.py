"""Users API — profile, update, password change."""
from __future__ import annotations

from typing import Annotated
from fastapi import APIRouter, Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_active_user, get_db, get_client_ip, get_user_agent
from app.core.exceptions import ValidationError
from app.crypto.password import hash_password, password_problems, verify_password
from app.models.user import User
from app.repositories.audit import AuditRepository
from app.schemas.user import PasswordChangeRequest, UserProfileResponse, UserUpdateRequest

router = APIRouter(prefix="/users", tags=["users"])


@router.get("/me", response_model=UserProfileResponse)
async def get_my_profile(
    user: Annotated[User, Depends(get_current_active_user)],
) -> UserProfileResponse:
    return UserProfileResponse.model_validate(user)


@router.patch("/me", response_model=UserProfileResponse)
async def update_my_profile(
    body: UserUpdateRequest,
    user: Annotated[User, Depends(get_current_active_user)],
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> UserProfileResponse:
    if body.full_name is not None:
        user.full_name = body.full_name.strip()
    if body.phone is not None:
        user.phone = body.phone.strip() or None
    if body.department is not None:
        user.department = body.department.strip() or None
    await db.flush()

    audit = AuditRepository(db)
    await audit.log_event(
        action="USER_PROFILE_UPDATE",
        user_id=user.id,
        resource_type="user",
        resource_id=user.id,
        ip_address=get_client_ip(request),
        user_agent=get_user_agent(request),
    )
    await db.commit()
    return UserProfileResponse.model_validate(user)


@router.post("/me/change-password")
async def change_password(
    body: PasswordChangeRequest,
    user: Annotated[User, Depends(get_current_active_user)],
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    if not verify_password(user.hashed_password, body.old_password):
        raise ValidationError("Current password is incorrect.")
    problems = password_problems(body.new_password)
    if problems:
        raise ValidationError(problems[0])
    user.hashed_password = hash_password(body.new_password)
    await db.flush()

    audit = AuditRepository(db)
    await audit.log_event(
        action="USER_PASSWORD_CHANGE",
        user_id=user.id,
        resource_type="user",
        resource_id=user.id,
        ip_address=get_client_ip(request),
        user_agent=get_user_agent(request),
    )
    await db.commit()
    return {"status": "ok", "message": "Password changed successfully."}
