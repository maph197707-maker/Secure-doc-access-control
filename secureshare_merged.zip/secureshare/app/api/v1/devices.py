"""Devices API — list and revoke trusted devices."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Annotated
from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_active_user, get_db
from app.models.device import Device
from app.models.user import User
from pydantic import BaseModel, ConfigDict


class DeviceResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str | None = None
    user_agent: str | None = None
    ip_address: str | None = None
    trust: str
    registered_at: datetime
    last_seen_at: datetime | None = None


router = APIRouter(prefix="/devices", tags=["devices"])


@router.get("", response_model=list[DeviceResponse])
async def list_devices(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> list[DeviceResponse]:
    stmt = select(Device).where(Device.user_id == user.id).order_by(Device.registered_at.desc())
    res = await db.execute(stmt)
    return [DeviceResponse.model_validate(d) for d in res.scalars().all()]


@router.delete("/{device_id}", status_code=204)
async def revoke_device(
    device_id: str,
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> None:
    from app.core.exceptions import NotFoundError, PermissionDeniedError
    stmt = select(Device).where(Device.id == device_id)
    res = await db.execute(stmt)
    device = res.scalar_one_or_none()
    if not device:
        raise NotFoundError("Device not found.")
    if device.user_id != user.id:
        raise PermissionDeniedError("Access denied.")
    await db.delete(device)
    await db.commit()
