"""Security alerts API — list and acknowledge alerts."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Annotated, Optional
from fastapi import APIRouter, Depends, Query, HTTPException, status
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_active_user, get_db
from app.models.security_alert import SecurityAlert
from app.models.user import User

router = APIRouter(prefix="/alerts", tags=["alerts"])


class AlertResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    alert_type: str
    severity: str
    user_id: Optional[str] = None
    document_id: Optional[str] = None
    link_id: Optional[str] = None
    message: str
    acknowledged: bool
    acknowledged_at: Optional[datetime] = None
    created_at: datetime


@router.get("", response_model=list[AlertResponse])
async def list_alerts(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    unacknowledged_only: bool = Query(default=False),
    limit: int = Query(default=50, ge=1, le=200),
) -> list[AlertResponse]:
    """List security alerts relevant to user or all if admin."""
    stmt = select(SecurityAlert)
    if user.role != "ADMIN":
        stmt = stmt.where(SecurityAlert.user_id == user.id)
    if unacknowledged_only:
        stmt = stmt.where(SecurityAlert.acknowledged == False)
    stmt = stmt.order_by(SecurityAlert.created_at.desc()).limit(limit)

    res = await db.execute(stmt)
    return [AlertResponse.model_validate(a) for a in res.scalars().all()]


@router.post("/{alert_id}/ack", response_model=AlertResponse)
async def acknowledge_alert(
    alert_id: str,
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> AlertResponse:
    """Acknowledge a security alert."""
    stmt = select(SecurityAlert).where(SecurityAlert.id == alert_id)
    if user.role != "ADMIN":
        stmt = stmt.where(SecurityAlert.user_id == user.id)
    res = await db.execute(stmt)
    alert = res.scalar_one_or_none()
    if not alert:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Alert not found")

    alert.acknowledged = True
    alert.acknowledged_by = user.id
    alert.acknowledged_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(alert)
    return AlertResponse.model_validate(alert)
