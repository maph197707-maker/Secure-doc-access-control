"""Notifications API — list and mark as read."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Annotated
from fastapi import APIRouter, Depends, Query
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_active_user, get_db
from app.models.notification import Notification
from app.models.user import User
from pydantic import BaseModel, ConfigDict


class NotificationResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    type: str
    title: str
    message: str
    read: bool
    resource_type: str | None = None
    resource_id: str | None = None
    created_at: datetime


router = APIRouter(prefix="/notifications", tags=["notifications"])


@router.get("", response_model=list[NotificationResponse])
async def list_notifications(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    unread_only: bool = Query(default=False),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
) -> list[NotificationResponse]:
    stmt = select(Notification).where(Notification.user_id == user.id)
    if unread_only:
        stmt = stmt.where(Notification.read == False)
    stmt = (
        stmt.order_by(Notification.created_at.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    )
    res = await db.execute(stmt)
    return [NotificationResponse.model_validate(n) for n in res.scalars().all()]


@router.get("/unread-count")
async def unread_count(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    stmt = select(func.count()).where(
        Notification.user_id == user.id, Notification.read == False
    )
    res = await db.execute(stmt)
    return {"unread_count": res.scalar_one()}


@router.post("/{notification_id}/read")
async def mark_read(
    notification_id: str,
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    stmt = select(Notification).where(
        Notification.id == notification_id, Notification.user_id == user.id
    )
    res = await db.execute(stmt)
    notif = res.scalar_one_or_none()
    if notif and not notif.read:
        notif.read = True
        notif.read_at = datetime.now(timezone.utc).replace(tzinfo=None)
        await db.flush()
        await db.commit()
    return {"status": "ok"}


@router.post("/read-all")
async def mark_all_read(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    stmt = select(Notification).where(
        Notification.user_id == user.id, Notification.read == False
    )
    res = await db.execute(stmt)
    count = 0
    for n in res.scalars().all():
        n.read = True
        n.read_at = now
        count += 1
    if count:
        await db.flush()
        await db.commit()
    return {"status": "ok", "marked_read": count}
