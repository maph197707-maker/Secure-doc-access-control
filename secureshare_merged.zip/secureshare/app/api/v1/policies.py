"""Policies API — create, list, update, and manage access policies."""
from __future__ import annotations

from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_active_user, get_db
from app.models.access_policy import AccessPolicy
from app.models.user import User

router = APIRouter(prefix="/policies", tags=["policies"])


class PolicyCreate(BaseModel):
    name: str
    description: Optional[str] = None
    document_id: Optional[str] = None
    rules: list[dict] = []
    priority: int = 0
    is_active: bool = True


class PolicyResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    description: Optional[str] = None
    document_id: Optional[str] = None
    owner_id: str
    rules: list[dict]
    priority: int
    is_active: bool


@router.post("", response_model=PolicyResponse, status_code=201)
async def create_policy(
    body: PolicyCreate,
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> PolicyResponse:
    """Create a new access policy."""
    policy = AccessPolicy(
        name=body.name,
        description=body.description,
        document_id=body.document_id,
        owner_id=user.id,
        rules=body.rules,
        priority=body.priority,
        is_active=body.is_active,
    )
    db.add(policy)
    await db.commit()
    await db.refresh(policy)
    return PolicyResponse.model_validate(policy)


@router.get("", response_model=list[PolicyResponse])
async def list_policies(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    document_id: Optional[str] = Query(default=None),
) -> list[PolicyResponse]:
    """List access policies owned by current user."""
    stmt = select(AccessPolicy).where(AccessPolicy.owner_id == user.id)
    if document_id:
        stmt = stmt.where(AccessPolicy.document_id == document_id)
    stmt = stmt.order_by(AccessPolicy.priority.desc())

    res = await db.execute(stmt)
    return [PolicyResponse.model_validate(p) for p in res.scalars().all()]


@router.delete("/{policy_id}", status_code=204)
async def delete_policy(
    policy_id: str,
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> None:
    """Delete an access policy."""
    stmt = select(AccessPolicy).where(AccessPolicy.id == policy_id, AccessPolicy.owner_id == user.id)
    res = await db.execute(stmt)
    policy = res.scalar_one_or_none()
    if not policy:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Policy not found")

    await db.delete(policy)
    await db.commit()
