"""DLP API: stateless text scan, per-document findings, owner rescan, admin summary.

Findings only ever contain MASKED samples. Only the document owner (or an admin) can read a document's
findings or trigger a rescan; recipients of a share link never see them.
"""
from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.dependencies import get_client_ip, get_current_active_user, get_db, get_user_agent
from app.core.exceptions import PermissionDeniedError
from app.models.dlp_finding import DLPFinding
from app.models.document import Document
from app.models.document_metadata import DocumentMetadata
from app.models.user import User
from app.services import dlp, document_analysis
from app.services.documents import DocumentService

router = APIRouter(prefix="/dlp", tags=["dlp"])
MAX_SCAN_BODY = 200_000


class ScanRequest(BaseModel):
    text: str = Field(min_length=1, max_length=MAX_SCAN_BODY)


@router.post("/scan")
async def scan(body: ScanRequest, user: Annotated[User, Depends(get_current_active_user)]) -> dict:
    return dlp.scan_text(body.text).to_dict()


def _doc_view(doc: Document, rows: list[DLPFinding], analysis: dict | None) -> dict:
    return {"document_id": doc.id, "dlp_level": doc.dlp_level, "classification": doc.classification,
            "analysis": analysis or {},
            "findings": [{"rule": r.rule_name, "category": r.category, "severity": r.severity,
                          "count": r.match_count, "sample": r.sample_masked, "action": r.action_taken} for r in rows]}


async def _findings(db: AsyncSession, doc: Document) -> tuple[list[DLPFinding], dict | None]:
    res = await db.execute(select(DLPFinding).where(DLPFinding.document_id == doc.id).order_by(DLPFinding.severity))
    md = (await db.execute(select(DocumentMetadata).where(DocumentMetadata.document_id == doc.id))).scalar_one_or_none()
    return list(res.scalars().all()), ((md.extra or {}).get("analysis") if md else None)


@router.get("/documents/{doc_id}/findings")
async def document_findings(doc_id: str, user: Annotated[User, Depends(get_current_active_user)],
                            db: Annotated[AsyncSession, Depends(get_db)]) -> dict:
    doc = await DocumentService(db).get_for_user(doc_id, user.id, is_superuser=user.is_superuser or user.is_admin)
    rows, analysis = await _findings(db, doc)
    return _doc_view(doc, rows, analysis)


@router.post("/documents/{doc_id}/rescan")
async def rescan(doc_id: str, request: Request, user: Annotated[User, Depends(get_current_active_user)],
                 db: Annotated[AsyncSession, Depends(get_db)]) -> dict:
    svc = DocumentService(db)
    doc = await svc.get_for_user(doc_id, user.id, is_superuser=user.is_superuser or user.is_admin)
    data = b"".join(await _read_all(svc, doc))
    settings = get_settings()
    result = await document_analysis.analyze_async(data, doc.original_filename, settings)
    await document_analysis.persist(db, doc, result, settings, actor_id=user.id, ip=get_client_ip(request),
                                    user_agent=get_user_agent(request), version_id=doc.current_version_id)
    await db.commit()
    await db.refresh(doc)
    rows, analysis = await _findings(db, doc)
    return _doc_view(doc, rows, analysis)


async def _read_all(svc: DocumentService, doc: Document) -> list[bytes]:
    return list(await svc.open_stream(doc))


@router.get("/summary")
async def summary(user: Annotated[User, Depends(get_current_active_user)],
                  db: Annotated[AsyncSession, Depends(get_db)]) -> dict:
    if not (user.is_superuser or user.is_admin):
        raise PermissionDeniedError("Administrator access required.")
    by_level = dict((await db.execute(
        select(Document.dlp_level, func.count()).where(Document.is_deleted.is_(False)).group_by(Document.dlp_level))).all())
    by_rule = dict((await db.execute(
        select(DLPFinding.rule_name, func.sum(DLPFinding.match_count)).group_by(DLPFinding.rule_name))).all())
    return {"documents_by_level": by_level, "matches_by_rule": {k: int(v or 0) for k, v in by_rule.items()}}
