"""Admin API — user management (superuser only)."""
from __future__ import annotations

from typing import Annotated
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_db, require_role
from app.core.enums import RoleName
from app.core.exceptions import NotFoundError
from app.models.user import User
from app.repositories.user import UserRepository
from app.schemas.user import UserProfileResponse
from app.services.db_status import database_status

router = APIRouter(prefix="/admin", tags=["admin"])

_require_admin = Depends(require_role(RoleName.ADMIN))


@router.get("/users", response_model=list[UserProfileResponse])
async def list_users(
    _admin: Annotated[User, _require_admin],
    db: Annotated[AsyncSession, Depends(get_db)],
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=200),
) -> list[UserProfileResponse]:
    repo = UserRepository(db)
    users = await repo.list_users(skip=(page - 1) * page_size, limit=page_size)
    return [UserProfileResponse.model_validate(u) for u in users]


@router.get("/users/{user_id}", response_model=UserProfileResponse)
async def get_user(
    user_id: str,
    _admin: Annotated[User, _require_admin],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> UserProfileResponse:
    repo = UserRepository(db)
    user = await repo.get_by_id(user_id)
    if not user:
        raise NotFoundError("User not found.")
    return UserProfileResponse.model_validate(user)


@router.post("/users/{user_id}/suspend")
async def suspend_user(
    user_id: str,
    _admin: Annotated[User, _require_admin],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    repo = UserRepository(db)
    user = await repo.get_by_id(user_id)
    if not user:
        raise NotFoundError("User not found.")
    user.status = "SUSPENDED"
    await db.flush()
    await db.commit()
    return {"status": "ok", "message": f"User {user_id} suspended."}


@router.post("/users/{user_id}/activate")
async def activate_user(
    user_id: str,
    _admin: Annotated[User, _require_admin],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    repo = UserRepository(db)
    user = await repo.get_by_id(user_id)
    if not user:
        raise NotFoundError("User not found.")
    user.status = "ACTIVE"
    user.failed_login_count = 0
    user.locked_until = None
    await db.flush()
    await db.commit()
    return {"status": "ok", "message": f"User {user_id} activated."}


@router.delete("/users/{user_id}")
async def delete_user(
    user_id: str,
    _admin: Annotated[User, _require_admin],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    repo = UserRepository(db)
    user = await repo.get_by_id(user_id)
    if not user:
        raise NotFoundError("User not found.")
    user.soft_delete()
    await db.flush()
    await db.commit()
    return {"status": "ok", "message": f"User {user_id} deleted."}


@router.get("/system/database")
async def get_database_status(
    _admin: Annotated[User, _require_admin],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    """Database type / status / masked host / version / migration state. No secrets."""
    return await database_status(db)
