"""Risk API — per-user risk signal summary."""
from __future__ import annotations

from typing import Annotated
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_active_user, get_db
from app.models.user import User
from app.services.risk import RiskEngine

router = APIRouter(prefix="/risk", tags=["risk"])


@router.get("/me")
async def get_my_risk(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    engine = RiskEngine(db)
    return await engine.evaluate_user(user.id)
