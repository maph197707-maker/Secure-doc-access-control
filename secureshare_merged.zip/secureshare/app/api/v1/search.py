"""Search API — full-text search across user's documents."""
from __future__ import annotations

from typing import Annotated
from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_active_user, get_db
from app.models.document import Document
from app.models.user import User
from app.schemas.document import DocumentResponse

router = APIRouter(prefix="/search", tags=["search"])


@router.get("/documents", response_model=list[DocumentResponse])
async def search_documents(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    q: str = Query(..., min_length=1, max_length=200),
    limit: int = Query(default=20, ge=1, le=100),
) -> list[DocumentResponse]:
    """Search documents by display name or original filename (case-insensitive)."""
    q_lower = f"%{q.lower()}%"
    stmt = (
        select(Document)
        .where(
            Document.owner_id == user.id,
            Document.is_deleted == False,
        )
        .filter(
            Document.display_name.ilike(q_lower) | Document.original_filename.ilike(q_lower)
        )
        .order_by(Document.updated_at.desc())
        .limit(limit)
    )
    res = await db.execute(stmt)
    return [DocumentResponse.model_validate(d) for d in res.scalars().all()]


@router.get("")
async def search_global(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    q: str = Query(..., min_length=1, max_length=200),
    limit: int = Query(default=8, ge=1, le=25),
) -> dict:
    """Top-bar search box (static/js/search.js calls GET /api/v1/search?q=): {documents: [{id, name}], users: []}.
    Only the caller's own documents are searched; user search is admin-only and not offered here."""
    like = f"%{q.lower()}%"
    stmt = (
        select(Document)
        .where(Document.owner_id == user.id, Document.is_deleted == False)  # noqa: E712
        .filter(Document.display_name.ilike(like) | Document.original_filename.ilike(like))
        .order_by(Document.updated_at.desc())
        .limit(limit)
    )
    rows = (await db.execute(stmt)).scalars().all()
    return {"documents": [{"id": d.id, "name": d.display_name or d.original_filename} for d in rows], "users": []}
