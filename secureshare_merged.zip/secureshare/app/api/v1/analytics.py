"""Analytics API — usage statistics for authenticated user."""
from __future__ import annotations

from typing import Annotated
from fastapi import APIRouter, Depends, Query
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_active_user, get_db
from app.models.audit import AuditLog
from app.models.document import Document
from app.models.secure_link import SecureLink
from app.models.user import User

router = APIRouter(prefix="/analytics", tags=["analytics"])


@router.get("/summary")
async def get_analytics_summary(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    # Total documents
    doc_count = await db.scalar(
        select(func.count()).where(Document.owner_id == user.id, Document.is_deleted == False)
    ) or 0

    # Total links created
    link_count = await db.scalar(
        select(func.count()).where(SecureLink.created_by == user.id)
    ) or 0

    # Active links
    active_links = await db.scalar(
        select(func.count()).where(SecureLink.created_by == user.id, SecureLink.status == "ACTIVE")
    ) or 0

    # Total link views
    total_views = await db.scalar(
        select(func.coalesce(func.sum(SecureLink.view_count), 0)).where(SecureLink.created_by == user.id)
    ) or 0

    # Total downloads
    total_downloads = await db.scalar(
        select(func.coalesce(func.sum(SecureLink.download_count), 0)).where(SecureLink.created_by == user.id)
    ) or 0

    # Recent audit events count
    recent_events = await db.scalar(
        select(func.count()).where(AuditLog.user_id == user.id)
    ) or 0

    return {
        "documents": {
            "total": doc_count,
        },
        "links": {
            "total": link_count,
            "active": active_links,
        },
        "engagement": {
            "total_views": total_views,
            "total_downloads": total_downloads,
        },
        "audit": {
            "total_events": recent_events,
        },
        "trust_score": user.trust_score,
    }


@router.get("/documents/top")
async def get_top_documents(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    limit: int = Query(default=5, ge=1, le=20),
) -> dict:
    # Top documents by view count via their secure links
    stmt = (
        select(
            SecureLink.document_id,
            func.sum(SecureLink.view_count).label("views"),
            func.sum(SecureLink.download_count).label("downloads"),
        )
        .where(SecureLink.created_by == user.id)
        .group_by(SecureLink.document_id)
        .order_by(func.sum(SecureLink.view_count).desc())
        .limit(limit)
    )
    res = await db.execute(stmt)
    rows = res.all()
    return {
        "top_documents": [
            {"document_id": r.document_id, "views": r.views or 0, "downloads": r.downloads or 0}
            for r in rows
        ]
    }
