"""Recipients API — manage authorized recipients for secure links."""
from __future__ import annotations

from typing import Annotated, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict, EmailStr
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_active_user, get_db
from app.models.recipient import Recipient
from app.models.secure_link import SecureLink
from app.models.user import User

router = APIRouter(prefix="/recipients", tags=["recipients"])


class RecipientCreate(BaseModel):
    link_id: str
    email: EmailStr
    phone: Optional[str] = None


class RecipientResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    link_id: str
    email: str
    phone: Optional[str] = None
    email_verified: bool
    otp_verified: bool
    identity_confidence: float


@router.get("/links/{link_id}", response_model=list[RecipientResponse])
async def list_link_recipients(
    link_id: str,
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> list[RecipientResponse]:
    """List authorized recipients for a specific secure link."""
    link_stmt = select(SecureLink).where(SecureLink.id == link_id)
    link_res = await db.execute(link_stmt)
    link = link_res.scalar_one_or_none()
    if not link:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Link not found")
    if link.created_by != user.id and user.role != "ADMIN":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    stmt = select(Recipient).where(Recipient.link_id == link_id)
    res = await db.execute(stmt)
    return [RecipientResponse.model_validate(r) for r in res.scalars().all()]


@router.post("", response_model=RecipientResponse, status_code=201)
async def add_recipient(
    body: RecipientCreate,
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> RecipientResponse:
    """Add a recipient to a secure link."""
    link_stmt = select(SecureLink).where(SecureLink.id == body.link_id)
    link_res = await db.execute(link_stmt)
    link = link_res.scalar_one_or_none()
    if not link:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Link not found")
    if link.created_by != user.id and user.role != "ADMIN":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    rec = Recipient(
        link_id=body.link_id,
        email=body.email.lower(),
        phone=body.phone,
    )
    db.add(rec)
    await db.commit()
    await db.refresh(rec)
    return RecipientResponse.model_validate(rec)


@router.delete("/{recipient_id}", status_code=204)
async def remove_recipient(
    recipient_id: str,
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> None:
    """Remove a recipient from a secure link."""
    stmt = select(Recipient).where(Recipient.id == recipient_id)
    res = await db.execute(stmt)
    rec = res.scalar_one_or_none()
    if not rec:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Recipient not found")

    link_stmt = select(SecureLink).where(SecureLink.id == rec.link_id)
    link_res = await db.execute(link_stmt)
    link = link_res.scalar_one_or_none()
    if not link or (link.created_by != user.id and user.role != "ADMIN"):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    await db.delete(rec)
    await db.commit()
