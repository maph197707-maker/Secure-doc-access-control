"""Secure links API — create, list, get, revoke."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Annotated
from fastapi import APIRouter, Depends, Request, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.dependencies import get_current_active_user, get_db, get_client_ip, get_user_agent
from app.models.user import User
from app.schemas.document import SecureLinkCreateRequest, SecureLinkResponse
from app.services.link_urls import share_url
from app.services.secure_links import SecureLinkService

router = APIRouter(prefix="/links", tags=["links"])
settings = get_settings()


def _naive_utc(value: datetime | None) -> datetime | None:
    """Storage is naive UTC: convert an aware datetime, trust a naive one as UTC."""
    if value is None:
        return None
    return value.astimezone(timezone.utc).replace(tzinfo=None) if value.tzinfo else value


@router.post("", status_code=201, response_model=SecureLinkResponse)
async def create_link(
    body: SecureLinkCreateRequest,
    user: Annotated[User, Depends(get_current_active_user)],
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> SecureLinkResponse:
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    svc = SecureLinkService(db)
    link, raw_token = await svc.create_link(
        document_id=body.document_id,
        created_by=user.id,
        expires_in_hours=body.expires_in_hours or 72,
        max_views=body.max_views,
        max_downloads=body.max_downloads,
        allow_downloads=body.allow_downloads,
        allow_print=body.allow_print,
        allow_copy=body.allow_copy,
        requires_password=body.requires_password,
        password=body.password,
        watermark_forced=body.watermark_forced,
        one_time_view=body.one_time_view,
        one_time_download=body.one_time_download,
        valid_from_utc=_naive_utc(body.valid_from),
        requires_mfa=body.requires_mfa,
        recipient_emails=body.recipient_emails,
        binding_mode=body.binding_mode,
        ip_address=ip,
        user_agent=ua,
    )
    await db.commit()
    result = SecureLinkResponse.model_validate(link)
    result.share_url = share_url(request, raw_token)
    return result


@router.get("", response_model=list[SecureLinkResponse])
async def list_links(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1, le=100),
) -> list[SecureLinkResponse]:
    svc = SecureLinkService(db)
    links, _ = await svc.list_for_user(user.id, page=page, page_size=page_size)
    return [SecureLinkResponse.model_validate(lnk) for lnk in links]


@router.delete("/{link_id}", status_code=204)
async def revoke_link(
    link_id: str,
    user: Annotated[User, Depends(get_current_active_user)],
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> None:
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    svc = SecureLinkService(db)
    await svc.revoke_link(link_id, user.id, ip_address=ip, user_agent=ua)
    await db.commit()
