"""Security score API — computed security posture for current user."""
from __future__ import annotations

from typing import Annotated
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_active_user, get_db
from app.models.user import User
from app.services.security_score import SecurityScoreService

router = APIRouter(prefix="/security-score", tags=["security"])


@router.get("")
async def get_security_score(
    user: Annotated[User, Depends(get_current_active_user)],
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    svc = SecurityScoreService(db)
    score_data = await svc.compute_for_user(user.id)
    return score_data
