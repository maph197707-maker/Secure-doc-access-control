"""Authentication API endpoints."""
from __future__ import annotations

from typing import Annotated
from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.constants import COOKIE_SESSION
from app.config.settings import get_settings
from app.core.dependencies import (
    get_client_ip,
    get_current_active_user,
    get_current_user_and_session,
    get_db,
    get_user_agent,
)
from app.core.responses import success_response
from app.models.session import UserSession
from app.models.user import User
from app.schemas.auth import (
    ForgotPasswordRequest,
    ResendVerificationRequest,
    ResetPasswordRequest,
    TokenResponse,
    UserLoginRequest,
    UserRegisterRequest,
    UserResponse,
    VerifyEmailRequest,
)
from app.schemas.user import UserProfileResponse
from app.services.auth import AuthService

router = APIRouter(prefix="/auth", tags=["auth"])
settings = get_settings()


@router.post("/register", status_code=201)
async def register(
    body: UserRegisterRequest,
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    auth_svc = AuthService(db)

    user, delivery = await auth_svc.register(
        email=body.email,
        password=body.password,
        full_name=body.full_name,
        phone=body.phone,
        ip_address=ip,
        user_agent=ua,
    )
    await db.commit()

    return {
        "user": UserResponse.model_validate(user).model_dump(),
        # Only reached when the email provider accepted the message; a delivery failure raises
        # DeliveryError (502/503) instead. The code itself is never part of any response.
        "message": (f"Registration successful. {delivery.message}" if delivery else
                    "Registration successful. Sign in, then verify your email and phone from your profile."),
        "otp_delivery": delivery.channel if delivery else None,
        "verification_required": delivery is not None,
    }


@router.post("/verify-email")
async def verify_email(
    body: VerifyEmailRequest,
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    auth_svc = AuthService(db)

    await auth_svc.verify_email(email=body.email, code=body.code, ip_address=ip, user_agent=ua)
    await db.commit()

    return {"status": "ok", "message": "Email verified successfully."}


@router.post("/resend-verification")
async def resend_verification(
    body: ResendVerificationRequest,
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    auth_svc = AuthService(db)
    await auth_svc.resend_email_verification(email=body.email, ip_address=get_client_ip(request),
                                             user_agent=get_user_agent(request))
    await db.commit()
    return {
        "status": "ok",
        "message": "If an unverified account exists, a new verification code was sent.",
    }


@router.post("/login", response_model=TokenResponse)
async def login(
    body: UserLoginRequest,
    request: Request,
    response: Response,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> TokenResponse:
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    auth_svc = AuthService(db)

    user, session, raw_token = await auth_svc.login(
        email=body.email,
        password=body.password,
        ip_address=ip,
        user_agent=ua,
        device_fingerprint=body.device_fingerprint,
        remember_me=body.remember_me,
    )
    await db.commit()

    # Set HTTP-only session cookie
    response.set_cookie(
        key=COOKIE_SESSION,
        value=raw_token,
        httponly=True,
        secure=settings.cookie_secure,
        samesite="lax",
        max_age=settings.session_absolute_timeout * (7 if body.remember_me else 1),
        path="/",
    )

    return TokenResponse(
        access_token=raw_token,
        expires_in=settings.session_idle_timeout,
        user=UserResponse.model_validate(user),
    )


class MfaVerifyRequest(BaseModel):
    challenge_id: str = Field(min_length=10, max_length=200)
    code: str = Field(min_length=6, max_length=32)      # 6-digit authenticator code or a recovery code


@router.post("/mfa/verify", response_model=TokenResponse)
async def mfa_verify(
    body: MfaVerifyRequest,
    request: Request,
    response: Response,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> TokenResponse:
    """Second step of API login. POST /auth/login answers 401 MFA_REQUIRED (details.challenge_id) for an
    account with two-factor on; send that id with the code here to receive the session."""
    auth_svc = AuthService(db)
    try:
        user, _session, raw_token = await auth_svc.complete_mfa_login(
            body.challenge_id, body.code.strip(), ip_address=get_client_ip(request), user_agent=get_user_agent(request))
    except Exception:
        await db.commit()          # keep the MFA_FAILED audit row, then let the error handler answer
        raise
    await db.commit()
    response.set_cookie(
        key=COOKIE_SESSION, value=raw_token, httponly=True, secure=settings.cookie_secure,
        samesite="lax", max_age=settings.session_absolute_timeout, path="/",
    )
    return TokenResponse(access_token=raw_token, expires_in=settings.session_idle_timeout,
                         user=UserResponse.model_validate(user))


@router.post("/guest", response_model=TokenResponse)
async def guest_login(
    request: Request,
    response: Response,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> TokenResponse:
    """Temporary guest account: real session, no email or code (on unless GUEST_LOGIN_ENABLED=false)."""
    auth_svc = AuthService(db)
    user, _session, raw_token = await auth_svc.guest_login(
        ip_address=get_client_ip(request), user_agent=get_user_agent(request))
    await db.commit()
    response.set_cookie(
        key=COOKIE_SESSION, value=raw_token, httponly=True, secure=settings.cookie_secure,
        samesite="lax", max_age=settings.session_absolute_timeout, path="/",
    )
    return TokenResponse(access_token=raw_token, expires_in=settings.session_idle_timeout,
                         user=UserResponse.model_validate(user))


@router.post("/logout")
async def logout(
    auth: Annotated[tuple[UserSession, User], Depends(get_current_user_and_session)],
    request: Request,
    response: Response,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    session, user = auth
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    auth_svc = AuthService(db)

    await auth_svc.logout(session_id=session.id, user_id=user.id, ip_address=ip, user_agent=ua)
    await db.commit()

    response.delete_cookie(key=COOKIE_SESSION, path="/")
    return {"status": "ok", "message": "Logged out successfully."}


@router.get("/me", response_model=UserProfileResponse)
async def get_me(
    user: Annotated[User, Depends(get_current_active_user)],
) -> UserProfileResponse:
    return UserProfileResponse.model_validate(user)


@router.post("/forgot-password")
async def forgot_password(
    body: ForgotPasswordRequest,
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    auth_svc = AuthService(db)

    token = await auth_svc.request_password_reset(email=body.email, ip_address=ip, user_agent=ua,
                                                  base_url=str(request.base_url).rstrip('/'))
    await db.commit()

    return {
        "status": "ok",
        "message": "If that email exists in our system, password reset instructions have been sent.",
        **({"dev_token": token} if settings.is_dev and token else {}),
    }


@router.post("/reset-password")
async def reset_password(
    body: ResetPasswordRequest,
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> dict:
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    auth_svc = AuthService(db)

    await auth_svc.confirm_password_reset(
        email=body.email,
        raw_token=body.token,
        new_password=body.new_password,
        ip_address=ip,
        user_agent=ua,
    )
    await db.commit()

    return {"status": "ok", "message": "Password reset successfully. Please log in with your new password."}
