"""Main API v1 router bundling all sub-routers."""
from __future__ import annotations

from fastapi import APIRouter

from app.api.v1.access import router as access_router
from app.api.v1.admin import router as admin_router
from app.api.v1.alerts import router as alerts_router
from app.api.v1.analytics import router as analytics_router
from app.api.v1.audit import router as audit_router
from app.api.v1.auth import router as auth_router
from app.api.v1.dashboard import router as dashboard_router
from app.api.v1.devices import router as devices_router
from app.api.v1.dlp import router as dlp_router
from app.api.v1.documents import router as documents_router
from app.api.v1.health import router as health_router
from app.api.v1.links import router as links_router
from app.api.v1.notifications import router as notifications_router
from app.api.v1.policies import router as policies_router
from app.api.v1.recipients import router as recipients_router
from app.api.v1.risk import router as risk_router
from app.api.v1.search import router as search_router
from app.api.v1.security_score import router as security_score_router
from app.api.v1.sessions import router as sessions_router
from app.api.v1.share import router as share_router
from app.api.v1.shares import router as shares_router
from app.api.v1.signatures import router as signatures_router
from app.api.v1.simulator import router as simulator_router
from app.api.v1.users import router as users_router

api_v1_router = APIRouter(prefix="/api/v1")

api_v1_router.include_router(access_router)
api_v1_router.include_router(admin_router)
api_v1_router.include_router(alerts_router)
api_v1_router.include_router(analytics_router)
api_v1_router.include_router(audit_router)
api_v1_router.include_router(auth_router)
api_v1_router.include_router(dashboard_router)
api_v1_router.include_router(devices_router)
api_v1_router.include_router(dlp_router)
api_v1_router.include_router(documents_router)
api_v1_router.include_router(health_router)
api_v1_router.include_router(links_router)
api_v1_router.include_router(notifications_router)
api_v1_router.include_router(policies_router)
api_v1_router.include_router(recipients_router)
api_v1_router.include_router(risk_router)
api_v1_router.include_router(search_router)
api_v1_router.include_router(security_score_router)
api_v1_router.include_router(sessions_router)
api_v1_router.include_router(share_router)
api_v1_router.include_router(shares_router)
api_v1_router.include_router(signatures_router)
api_v1_router.include_router(simulator_router)
api_v1_router.include_router(users_router)
