/* Shell-only cache: static assets. Documents, API responses and authenticated HTML are NEVER cached. */
const CACHE = 'secureshare-shell-v1';
const SHELL = ['/static/css/tokens.css', '/static/css/base.css', '/static/css/layout.css', '/static/css/components.css',
  '/static/css/pages.css', '/static/css/dark.css', '/static/js/main.js'];
self.addEventListener('install', (e) => e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL))));
self.addEventListener('activate', (e) => e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k))))));
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== self.location.origin || !url.pathname.startsWith('/static/')) return; // network only
  e.respondWith(caches.match(e.request).then((hit) => hit || fetch(e.request)));
});
