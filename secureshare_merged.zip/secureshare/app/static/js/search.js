export function debounce(fn, ms) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}
export function groupResults(data) {
  const groups = [];
  if (data.documents && data.documents.length) groups.push(['Documents', data.documents.map((d) => ({ label: d.name, href: `/documents/${encodeURIComponent(d.id)}` }))]);
  if (data.users && data.users.length) groups.push(['Users', data.users.map((u) => ({ label: u.name, href: `/admin/users/${encodeURIComponent(u.id)}` }))]);
  return groups;
}
export function initSearch() {
  const input = document.querySelector('[data-search]');
  const box = document.querySelector('[data-search-results]');
  if (!input || !box) return;
  const run = debounce(async () => {
    const q = input.value.trim();
    if (q.length < 2) { box.hidden = true; return; }
    try {
      const res = await fetch(`${input.dataset.url}?q=${encodeURIComponent(q)}`, { credentials: 'same-origin', headers: { Accept: 'application/json' } });
      if (!res.ok) { box.hidden = true; return; }
      const groups = groupResults(await res.json());
      box.replaceChildren();
      if (!groups.length) { const p = document.createElement('p'); p.className = 'muted small'; p.textContent = 'No results'; box.append(p); }
      groups.forEach(([title, items]) => {
        const h = document.createElement('p'); h.className = 'muted small'; h.textContent = title; box.append(h);
        items.forEach((it) => { const a = document.createElement('a'); a.href = it.href; a.textContent = it.label; a.className = 'nav-link'; box.append(a); });
      });
      box.hidden = false;
    } catch (_) { box.hidden = true; }
  }, 250);
  input.addEventListener('input', run);
  input.addEventListener('keydown', (e) => { if (e.key === 'Escape') box.hidden = true; });
  document.addEventListener('keydown', (e) => {
    const tag = (document.activeElement && document.activeElement.tagName) || '';
    if (e.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(tag)) { e.preventDefault(); input.focus(); }
  });
}
