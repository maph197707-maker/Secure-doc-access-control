export function csrfToken() {
  const m = document.querySelector('meta[name="csrf-token"]');
  return m ? m.content : '';
}
export function csrfHeaders(extra = {}) {
  return { 'X-CSRF-Token': csrfToken(), ...extra };
}
