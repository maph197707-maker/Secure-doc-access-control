export function initPolling() {
  const start = (el) => {
    const url = el.dataset.pollUrl;
    const every = (parseInt(el.dataset.pollSeconds, 10) || 3) * 1000;
    setTimeout(async () => {
      try {
        const r = await fetch(url, { credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch' } });
        if (!r.ok) return;
        const doc = new DOMParser().parseFromString(await r.text(), 'text/html'); // our own server-rendered fragment
        const fresh = doc.getElementById(el.id);
        if (!fresh) return;
        el.replaceWith(fresh);
        if (fresh.dataset.pollUrl) start(fresh);
      } catch (_) { start(el); }
    }, every);
  };
  document.querySelectorAll('[data-poll-url]').forEach(start);
}
