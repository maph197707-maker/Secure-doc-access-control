export function showToast(message, ms = 3000) {
  const area = document.querySelector('[data-toast-area]');
  if (!area) return;
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = message; // textContent: never interpret as HTML
  area.appendChild(t);
  setTimeout(() => t.remove(), ms);
}
