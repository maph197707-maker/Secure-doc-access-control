export const STRENGTH_LABELS = ['Too weak', 'Weak', 'Fair', 'Good', 'Strong'];
export function strengthScore(pw) {
  let s = 0;
  if (pw.length >= 12) s += 1;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) s += 1;
  if (/\d/.test(pw)) s += 1;
  if (/[^A-Za-z0-9]/.test(pw) || pw.length >= 16) s += 1;
  if (pw.length < 12) s = Math.min(s, 1);
  return s;
}
export function initAuth(root = document) {
  root.querySelectorAll('[data-reveal]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const input = root.getElementById ? root.getElementById(btn.dataset.reveal) : document.getElementById(btn.dataset.reveal);
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    });
  });
  const meter = root.querySelector('[data-strength-meter]');
  const pw = root.querySelector('#f-password');
  const text = root.querySelector('[data-strength-text]');
  if (meter && pw) {
    pw.addEventListener('input', () => {
      const s = strengthScore(pw.value);
      meter.value = s;
      if (text) text.textContent = `Strength: ${STRENGTH_LABELS[s]} (the server enforces the final policy)`;
    });
  }
}
