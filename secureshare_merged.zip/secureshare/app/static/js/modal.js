export function initModal() {
  document.querySelectorAll('[data-modal-open]').forEach((b) => b.addEventListener('click', () => {
    const d = document.getElementById(b.dataset.modalOpen);
    if (d && typeof d.showModal === 'function') d.showModal(); else if (d) d.setAttribute('open', '');
  }));
  document.querySelectorAll('[data-modal-close]').forEach((b) => b.addEventListener('click', () => {
    const d = document.getElementById(b.dataset.modalClose);
    if (d && typeof d.close === 'function') d.close(); else if (d) d.removeAttribute('open');
  }));
}
