import { showToast } from './toast.js';
export async function copyText(input) {
  try {
    await navigator.clipboard.writeText(input.value);
  } catch (_) {
    input.select();
    document.execCommand('copy'); // fallback for non-secure contexts
  }
}
export function initClipboard() {
  document.querySelectorAll('[data-copy]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const input = document.getElementById(btn.dataset.copy);
      if (!input) return;
      await copyText(input);
      showToast('Link copied');
    });
  });
}
