import { csrfHeaders } from './csrf.js';
import { showToast } from './toast.js';
export function safeRedirect(path) {
  return typeof path === 'string' && path.startsWith('/') && !path.startsWith('//') ? path : null;
}
export function initUpload() {
  document.querySelectorAll('[data-dropzone]').forEach((zone) => {
    const input = zone.querySelector('input[type=file]');
    const info = zone.querySelector('[data-file-info]');
    const bar = zone.querySelector('progress');
    if (!zone.dataset.url) {
      // Form-embedded zone (the share wizard): the file travels with the form submit, never via XHR.
      // Posting to '' used to fire a stray upload at the current page the moment a file was chosen.
      const show = () => {
        if (!input.files || !input.files[0] || !info) return;
        info.hidden = false;
        zone.querySelector('[data-file-name]').textContent = input.files[0].name;
      };
      ['dragenter', 'dragover'].forEach((ev) => zone.addEventListener(ev, (e) => { e.preventDefault(); zone.classList.add('is-over'); }));
      ['dragleave', 'drop'].forEach((ev) => zone.addEventListener(ev, (e) => { e.preventDefault(); zone.classList.remove('is-over'); }));
      zone.addEventListener('drop', (e) => {
        if (e.dataTransfer.files && e.dataTransfer.files[0]) { input.files = e.dataTransfer.files; show(); }
      });
      input.addEventListener('change', show);
      return;
    }
    const send = (file) => {
      info.hidden = false;
      zone.querySelector('[data-file-name]').textContent = file.name;
      const xhr = new XMLHttpRequest();
      xhr.open('POST', zone.dataset.url);
      Object.entries(csrfHeaders()).forEach(([k, v]) => xhr.setRequestHeader(k, v));
      xhr.upload.onprogress = (e) => { if (e.lengthComputable) bar.value = Math.round((e.loaded / e.total) * 100); };
      xhr.onload = () => {
        let body = {};
        try { body = JSON.parse(xhr.responseText); } catch (_) { /* ignore */ }
        if (xhr.status >= 200 && xhr.status < 300) {
          // The API answers with the new document (no `redirect` field): continue on its details page.
          const to = safeRedirect(body.redirect) || (body && typeof body.id === 'string'
            ? `/documents/upload?doc=${encodeURIComponent(body.id)}` : null);
          if (to) window.location.assign(to);
          else showToast('Uploaded, but the server sent no document id. Open Documents to find it.');
        } else {
          showToast((body.error && body.error.message) || 'Upload failed');
        }
      };
      xhr.onerror = () => showToast('Network error during upload');
      const fd = new FormData();
      fd.append('file', file);
      xhr.send(fd);
    };
    ['dragenter', 'dragover'].forEach((ev) => zone.addEventListener(ev, (e) => { e.preventDefault(); zone.classList.add('is-over'); }));
    ['dragleave', 'drop'].forEach((ev) => zone.addEventListener(ev, (e) => { e.preventDefault(); zone.classList.remove('is-over'); }));
    zone.addEventListener('drop', (e) => { if (e.dataTransfer.files[0]) send(e.dataTransfer.files[0]); });
    input.addEventListener('change', () => { if (input.files[0]) send(input.files[0]); });
  });
}
