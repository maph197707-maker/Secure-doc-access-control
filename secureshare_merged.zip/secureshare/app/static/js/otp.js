export function splitCode(text, length = 6) {
  return String(text || '').replace(/\D/g, '').slice(0, length).split('').filter(Boolean);
}
export function initOtp(root = document) {
  root.querySelectorAll('[data-otp]').forEach((group) => {
    const boxes = [...group.querySelectorAll('[data-otp-box]')];
    const hidden = group.querySelector('[data-otp-value]');
    const sync = () => { hidden.value = boxes.map((b) => b.value).join(''); };
    boxes.forEach((box, i) => {
      box.addEventListener('input', () => {
        box.value = box.value.replace(/\D/g, '').slice(-1);
        sync();
        if (box.value && boxes[i + 1]) boxes[i + 1].focus();
      });
      box.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && !box.value && boxes[i - 1]) { boxes[i - 1].value = ''; boxes[i - 1].focus(); sync(); }
        if (e.key === 'ArrowLeft' && boxes[i - 1]) boxes[i - 1].focus();
        if (e.key === 'ArrowRight' && boxes[i + 1]) boxes[i + 1].focus();
      });
      box.addEventListener('paste', (e) => {
        e.preventDefault();
        const digits = splitCode(e.clipboardData.getData('text'), boxes.length);
        boxes.forEach((b, k) => { b.value = digits[k] || ''; });
        sync();
        boxes[Math.min(digits.length, boxes.length - 1)].focus();
      });
    });
  });
  // resend cooldown countdown (the server enforces the real limit)
  root.querySelectorAll('[data-cooldown]').forEach((btn) => {
    let left = parseInt(btn.dataset.cooldown, 10);
    if (!(left > 0)) return;
    const label = btn.textContent;
    const tick = () => {
      if (left <= 0) { btn.disabled = false; btn.removeAttribute('aria-disabled'); btn.textContent = label; return; }
      btn.textContent = `${label} (${left}s)`; left -= 1; setTimeout(tick, 1000);
    };
    tick();
  });
}
