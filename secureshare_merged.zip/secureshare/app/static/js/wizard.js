import { showToast } from './toast.js';
export function initWizard() {
  document.querySelectorAll('[data-reveals]').forEach((input) => {
    const target = document.getElementById(input.dataset.reveals);
    if (!target) return;
    const apply = () => { target.hidden = !input.checked; };
    input.addEventListener('change', apply); apply();
  });
  // Expiry is typed in the browser's local time; send its IANA zone so the server can convert it.
  const tz = document.querySelector('[data-tz]');
  if (tz) {
    try { tz.value = Intl.DateTimeFormat().resolvedOptions().timeZone || tz.value; } catch (_) { /* keep UTC */ }
    const hint = document.getElementById('f-expires_at-hint');
    if (hint) hint.textContent = `Read in your timezone: ${tz.value}.`;
  }
  // The phone number is only needed (and only shown) for SMS verification.
  const mode = document.querySelector('[data-binding-mode]');
  const phone = document.getElementById('phone-box');
  if (mode && phone) {
    const sync = () => { phone.hidden = mode.value !== 'PHONE_OTP'; };
    mode.addEventListener('change', sync); sync();
  }
  const form = document.querySelector('[data-wizard]');
  if (form) form.addEventListener('submit', (e) => {
    // Step 1 only: block the submit when nothing is chosen yet. A chosen file OR a picked existing
    // document is enough (the server re-validates either way and rejects a document that is not yours).
    if (!form.querySelector('[data-needs-file]')) return;
    const file = form.querySelector('input[type=file]');
    const picked = form.querySelector('select[name=document_id]');
    const hasFile = !!(file && file.files && file.files.length);
    const hasDoc = !!(picked && picked.value);
    if (!hasFile && !hasDoc) { e.preventDefault(); showToast('Choose a file or an existing document to continue'); }
  });
}
