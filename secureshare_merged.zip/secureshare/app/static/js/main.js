import { initOtp } from './otp.js';
import { initAuth } from './auth.js';
import { initClipboard } from './clipboard.js';
import { initModal } from './modal.js';
import { initUpload } from './upload.js';
import { initSearch } from './search.js';
import { initNotifications } from './notifications.js';
import { initViewer } from './viewer.js';
import { initWizard } from './wizard.js';
import { initPolling } from './polling.js';

[initOtp, initAuth, initClipboard, initModal, initUpload, initSearch, initNotifications, initViewer, initWizard, initPolling]
  .forEach((fn) => { try { fn(); } catch (e) { console.error(fn.name, e); } });

if ('serviceWorker' in navigator && window.isSecureContext) {
  navigator.serviceWorker.register('/service-worker.js').catch(() => {});
}
