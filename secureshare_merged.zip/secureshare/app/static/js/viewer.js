export function isStillAllowed(status, body) {
  return status >= 200 && status < 300 && !!body && body.allowed === true;
}
export function initViewer() {
  const root = document.querySelector('[data-viewer]');
  if (!root) return;
  const stage = root.querySelector('.stage');
  if (stage) stage.addEventListener('contextmenu', (e) => e.preventDefault()); // deterrent only
  window.addEventListener('beforeprint', () => { if (stage) stage.hidden = true; });
  window.addEventListener('afterprint', () => { if (stage) stage.hidden = false; });
  const fs = root.querySelector('[data-fullscreen]');
  if (fs) fs.addEventListener('click', () => { if (document.fullscreenElement) document.exitFullscreen(); else root.requestFullscreen && root.requestFullscreen(); });
  const url = root.dataset.recheckUrl;
  const every = Math.max(parseInt(root.dataset.recheckSeconds, 10) || 30, 5) * 1000;
  if (!url) return;
  const timer = setInterval(async () => {
    let allowed = false;
    try {
      const r = await fetch(url, { credentials: 'same-origin', method: 'POST', headers: { 'X-CSRF-Token': (document.querySelector('meta[name="csrf-token"]') || {}).content || '' } });
      allowed = isStillAllowed(r.status, await r.json().catch(() => null));
    } catch (_) { allowed = false; } // fail closed
    if (!allowed) {
      clearInterval(timer);
      const body = root.querySelector('.viewer-body');
      if (body) { const p = document.createElement('p'); p.className = 'viewer-stopped'; p.setAttribute('role', 'alert'); p.textContent = 'Access to this document has ended. Ask the owner for a new link.'; body.replaceChildren(p); }
    }
  }, every);
}
