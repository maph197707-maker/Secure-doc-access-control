export function initNotifications() {
  const bell = document.querySelector('[data-unread-url]');
  if (!bell) return;
  const refresh = async () => {
    try {
      const r = await fetch(bell.dataset.unreadUrl, { credentials: 'same-origin' });
      if (!r.ok) return;
      const { unread } = await r.json();
      let badge = bell.querySelector('[data-badge]');
      if (unread > 0) {
        if (!badge) { badge = document.createElement('span'); badge.className = 'bell-badge'; badge.dataset.badge = ''; bell.append(badge); }
        badge.textContent = String(unread);
      } else if (badge) badge.remove();
    } catch (_) { /* offline: keep the last value */ }
  };
  setInterval(refresh, 60000);
}
