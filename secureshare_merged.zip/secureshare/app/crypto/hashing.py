"""Hashing helpers: SHA-256, SHA3-256, HMAC-SHA256, HKDF, constant-time compare."""
from __future__ import annotations

import hashlib
import hmac
from typing import BinaryIO, Iterable

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha3_256_hex(data: bytes) -> str:
    return hashlib.sha3_256(data).hexdigest()


def hmac_sha256(key: bytes, message: bytes) -> bytes:
    return hmac.new(key, message, hashlib.sha256).digest()


def digests_of_chunks(chunks: Iterable[bytes]) -> tuple[str, str, int]:
    """Return (sha256_hex, sha3_256_hex, size) computed in one streaming pass."""
    a, b, size = hashlib.sha256(), hashlib.sha3_256(), 0
    for c in chunks:
        a.update(c)
        b.update(c)
        size += len(c)
    return a.hexdigest(), b.hexdigest(), size


def digests_of_file(fh: BinaryIO, chunk_size: int = 1 << 20) -> tuple[str, str, int]:
    return digests_of_chunks(iter(lambda: fh.read(chunk_size), b""))


def constant_time_equal(a: str | bytes, b: str | bytes) -> bool:
    if isinstance(a, str):
        a = a.encode()
    if isinstance(b, str):
        b = b.encode()
    return hmac.compare_digest(a, b)


def hkdf(master: bytes, info: bytes, length: int = 32, salt: bytes | None = None) -> bytes:
    """Derive an independent sub-key (audit key, token key, CSRF key...) from a master secret."""
    if len(master) < 16:
        raise ValueError("master secret too short")
    return HKDF(algorithm=hashes.SHA256(), length=length, salt=salt, info=info).derive(master)
