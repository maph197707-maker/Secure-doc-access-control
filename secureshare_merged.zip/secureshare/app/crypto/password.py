"""Argon2id password hashing (argon2-cffi). Import is lazy so LITE tooling still loads
when the package is missing; doctor.py reports it."""
from __future__ import annotations

_COMMON = {"password1234", "123456789012", "qwertyuiop12", "letmein12345", "admin1234567",
           "welcome12345", "iloveyou1234", "password12345"}


def password_problems(pw: str) -> list[str]:
    problems = []
    if len(pw) < 12:
        problems.append("Use at least 12 characters.")
    if pw.lower() in _COMMON or len(set(pw)) < 5:
        problems.append("This password is too common or repetitive.")
    if not (any(c.islower() for c in pw) and any(c.isupper() for c in pw) and any(c.isdigit() for c in pw)):
        problems.append("Mix upper case, lower case and digits.")
    return problems


def hash_password(pw: str) -> str:
    from argon2 import PasswordHasher
    return PasswordHasher().hash(pw)


def verify_password(stored: str, pw: str) -> bool:
    from argon2 import PasswordHasher
    from argon2.exceptions import InvalidHashError, VerificationError
    try:
        return PasswordHasher().verify(stored, pw)
    except (VerificationError, InvalidHashError):
        return False
