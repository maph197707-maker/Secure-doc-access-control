"""Opaque random tokens. Only a keyed hash is ever stored; the raw token is shown once."""
from __future__ import annotations

import secrets
import string

from app.crypto.hashing import constant_time_equal, hmac_sha256


def new_token(nbytes: int = 32) -> str:
    return secrets.token_urlsafe(nbytes)


def token_hash(token: str, token_key: bytes) -> str:
    return hmac_sha256(token_key, token.encode()).hex()


def verify_token(token: str, stored_hash: str, token_key: bytes) -> bool:
    return constant_time_equal(token_hash(token, token_key), stored_hash)


def numeric_otp(digits: int = 6) -> str:
    return "".join(secrets.choice(string.digits) for _ in range(digits))
