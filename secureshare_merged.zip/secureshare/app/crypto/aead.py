"""Chunked, streaming AES-256-GCM.

File format:  b"SSG1" | 8-byte random nonce prefix | { 4-byte big-endian length | ciphertext+tag }*
Nonce      :  8-byte prefix + 4-byte chunk counter (96 bit)
AAD        :  document_id | version | key_version | chunk_index | final_flag

The final flag and chunk index in the AAD mean that truncation, reordering, duplication
and cross-document swaps all fail authentication. Decryption yields plaintext chunk by
chunk; callers MUST treat an IntegrityError at any point (including the last chunk) as
total failure and discard everything already produced.
"""
from __future__ import annotations

import io
import os
import struct
from typing import BinaryIO, Iterator

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

MAGIC = b"SSG1"
CHUNK = 1 << 20
TAG = 16
HEADER_LEN = len(MAGIC) + 8


class IntegrityError(Exception):
    """Ciphertext is malformed, truncated, reordered, tampered, or the key/AAD is wrong."""


def _aad(doc_id: str, version: int, key_version: int, idx: int, final: bool) -> bytes:
    return f"{doc_id}|{version}|{key_version}|{idx}|{int(final)}".encode()


def _read_full(src: BinaryIO, n: int) -> bytes:
    buf = bytearray()
    while len(buf) < n:
        part = src.read(n - len(buf))
        if not part:
            break
        buf += part
    return bytes(buf)


def encrypt_stream(key: bytes, src: BinaryIO, dst: BinaryIO, *, doc_id: str, version: int,
                   key_version: int, chunk_size: int = CHUNK) -> int:
    """Encrypt src into dst, holding at most two chunks in memory. Returns plaintext bytes."""
    if len(key) != 32:
        raise ValueError("AES-256-GCM needs a 32-byte key")
    prefix, aes = os.urandom(8), AESGCM(key)
    dst.write(MAGIC + prefix)
    cur, idx, total = _read_full(src, chunk_size), 0, 0
    while True:
        nxt = _read_full(src, chunk_size) if len(cur) == chunk_size else b""
        final = len(nxt) == 0
        if idx >= 2**32:
            raise ValueError("too many chunks")
        blob = aes.encrypt(prefix + struct.pack(">I", idx), cur,
                           _aad(doc_id, version, key_version, idx, final))
        dst.write(struct.pack(">I", len(blob)) + blob)
        total += len(cur)
        if final:
            return total
        cur, idx = nxt, idx + 1


def decrypt_stream(key: bytes, src: BinaryIO, *, doc_id: str, version: int, key_version: int,
                   chunk_size: int = CHUNK) -> Iterator[bytes]:
    if len(key) != 32:
        raise ValueError("AES-256-GCM needs a 32-byte key")
    header = _read_full(src, HEADER_LEN)
    if len(header) != HEADER_LEN or header[:4] != MAGIC:
        raise IntegrityError("bad header")
    prefix, aes = header[4:], AESGCM(key)

    def record() -> bytes | None:
        raw = _read_full(src, 4)
        if not raw:
            return None
        if len(raw) != 4:
            raise IntegrityError("truncated record header")
        (n,) = struct.unpack(">I", raw)
        if n < TAG or n > chunk_size + TAG:
            raise IntegrityError("bad record length")
        blob = _read_full(src, n)
        if len(blob) != n:
            raise IntegrityError("truncated record")
        return blob

    cur, idx = record(), 0
    if cur is None:
        raise IntegrityError("no data")
    while True:
        nxt = record()
        final = nxt is None
        try:
            yield aes.decrypt(prefix + struct.pack(">I", idx), cur,
                              _aad(doc_id, version, key_version, idx, final))
        except InvalidTag as exc:
            raise IntegrityError("authentication failed") from exc
        if final:
            return
        cur, idx = nxt, idx + 1  # type: ignore[assignment]


def encrypt_bytes(key: bytes, data: bytes, **kw: object) -> bytes:
    out = io.BytesIO()
    encrypt_stream(key, io.BytesIO(data), out, **kw)  # type: ignore[arg-type]
    return out.getvalue()


def decrypt_bytes(key: bytes, blob: bytes, **kw: object) -> bytes:
    return b"".join(decrypt_stream(key, io.BytesIO(blob), **kw))  # type: ignore[arg-type]
