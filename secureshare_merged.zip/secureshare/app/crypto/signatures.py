"""Document signatures over the SHA-256 digest of the plaintext.
Ed25519 (default), RSA-PSS, ECDSA P-256. Integrity evidence only - no legal-validity claim."""
from __future__ import annotations

from enum import StrEnum

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, padding, rsa


class SigAlg(StrEnum):
    ED25519 = "ED25519"
    RSA_PSS = "RSA_PSS"
    ECDSA_P256 = "ECDSA_P256"


_PSS = padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.DIGEST_LENGTH)


def generate_keypair(alg: SigAlg = SigAlg.ED25519) -> tuple[bytes, bytes]:
    if alg == SigAlg.ED25519:
        priv = ed25519.Ed25519PrivateKey.generate()
    elif alg == SigAlg.RSA_PSS:
        priv = rsa.generate_private_key(public_exponent=65537, key_size=3072)
    elif alg == SigAlg.ECDSA_P256:
        priv = ec.generate_private_key(ec.SECP256R1())
    else:
        raise ValueError(alg)
    return (priv.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                               serialization.NoEncryption()),
            priv.public_key().public_bytes(serialization.Encoding.PEM,
                                           serialization.PublicFormat.SubjectPublicKeyInfo))


def sign(alg: SigAlg, private_pem: bytes, digest: bytes) -> bytes:
    key = serialization.load_pem_private_key(private_pem, password=None)
    if alg == SigAlg.ED25519:
        return key.sign(digest)  # type: ignore[union-attr,call-arg]
    if alg == SigAlg.RSA_PSS:
        return key.sign(digest, _PSS, hashes.SHA256())  # type: ignore[union-attr,call-arg]
    return key.sign(digest, ec.ECDSA(hashes.SHA256()))  # type: ignore[union-attr,call-arg]


def verify(alg: SigAlg, public_pem: bytes, digest: bytes, signature: bytes) -> bool:
    key = serialization.load_pem_public_key(public_pem)
    try:
        if alg == SigAlg.ED25519:
            key.verify(signature, digest)  # type: ignore[union-attr,call-arg]
        elif alg == SigAlg.RSA_PSS:
            key.verify(signature, digest, _PSS, hashes.SHA256())  # type: ignore[union-attr,call-arg]
        else:
            key.verify(signature, digest, ec.ECDSA(hashes.SHA256()))  # type: ignore[union-attr,call-arg]
        return True
    except InvalidSignature:
        return False
