"""Envelope encryption: per-document-version DEK wrapped by a KEK from a KeyProvider.

LocalDevelopmentKeyProvider is DEV ONLY (KEK derived from an env master secret). Cloud KMS /
Vault / HSM adapters plug in behind the same Protocol and report PROVIDER_UNAVAILABLE
until configured.
"""
from __future__ import annotations

import base64
import json
import os
from dataclasses import dataclass
from typing import Protocol

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.argon2 import Argon2id

from app.core.enums import KeyState
from app.crypto.hashing import hkdf

ALGORITHM = "AES-256-GCM"


class KeyError_(Exception):
    """Wrong key, wrong context, revoked/destroyed key version, or corrupt wrapped key."""


@dataclass(frozen=True)
class WrappedKey:
    wrapped: bytes
    key_version: int
    algorithm: str = ALGORITHM


class KeyProvider(Protocol):
    label: str
    def current_version(self) -> int: ...
    def wrap(self, dek: bytes, aad: bytes) -> WrappedKey: ...
    def unwrap(self, wk: WrappedKey, aad: bytes) -> bytes: ...


_ALLOWED = {
    KeyState.GENERATED: {KeyState.ACTIVE, KeyState.DESTROYED},
    KeyState.ACTIVE: {KeyState.ROTATING, KeyState.EXPIRED, KeyState.REVOKED},
    KeyState.ROTATING: {KeyState.EXPIRED, KeyState.ACTIVE},
    KeyState.EXPIRED: {KeyState.REVOKED, KeyState.DESTROYED},
    KeyState.REVOKED: {KeyState.DESTROYED},
    KeyState.DESTROYED: set(),
}


class LocalDevelopmentKeyProvider:
    label = "DEV: local key provider (not for production)"

    def __init__(self, master_secret: bytes) -> None:
        self._master = master_secret
        self._states: dict[int, KeyState] = {1: KeyState.ACTIVE}
        self._keks: dict[int, bytes] = {1: self._derive(1)}
        self.events: list[tuple[str, int]] = []  # (event, version) -> audited by caller

    def _derive(self, v: int) -> bytes:
        return hkdf(self._master, f"kek|v{v}".encode())

    def state(self, v: int) -> KeyState:
        return self._states[v]

    def current_version(self) -> int:
        return max(v for v, s in self._states.items() if s == KeyState.ACTIVE)

    def _move(self, v: int, new: KeyState) -> None:
        if new not in _ALLOWED[self._states[v]]:
            raise KeyError_(f"illegal key transition {self._states[v]} -> {new}")
        self._states[v] = new
        self.events.append((f"KEY_{new}", v))
        if new == KeyState.DESTROYED:
            self._keks.pop(v, None)

    def rotate(self) -> int:
        old = self.current_version()
        new = old + 1
        self._states[new] = KeyState.GENERATED
        self._keks[new] = self._derive(new)
        self._move(old, KeyState.ROTATING)
        self._move(new, KeyState.ACTIVE)
        self.events.append(("KEY_ROTATED", new))
        return new

    def retire(self, v: int) -> None:
        self._move(v, KeyState.EXPIRED)

    def revoke(self, v: int) -> None:
        self._move(v, KeyState.REVOKED)

    def destroy(self, v: int) -> None:
        self._move(v, KeyState.DESTROYED)

    def wrap(self, dek: bytes, aad: bytes) -> WrappedKey:
        v = self.current_version()
        nonce = os.urandom(12)
        return WrappedKey(nonce + AESGCM(self._keks[v]).encrypt(nonce, dek, aad), v)

    def unwrap(self, wk: WrappedKey, aad: bytes) -> bytes:
        if wk.key_version not in self._keks or self._states[wk.key_version] in (
                KeyState.REVOKED, KeyState.DESTROYED):
            raise KeyError_("key version unavailable")
        try:
            return AESGCM(self._keks[wk.key_version]).decrypt(wk.wrapped[:12], wk.wrapped[12:], aad)
        except InvalidTag as exc:
            raise KeyError_("unwrap failed") from exc


def wrap_aad(doc_id: str, version: int) -> bytes:
    return f"dek|{doc_id}|{version}".encode()


def new_dek(provider: KeyProvider, doc_id: str, version: int) -> tuple[bytes, WrappedKey]:
    dek = AESGCM.generate_key(bit_length=256)
    return dek, provider.wrap(dek, wrap_aad(doc_id, version))


def open_dek(provider: KeyProvider, wk: WrappedKey, doc_id: str, version: int) -> bytes:
    return provider.unwrap(wk, wrap_aad(doc_id, version))


def rewrap(provider: KeyProvider, wk: WrappedKey, doc_id: str, version: int) -> WrappedKey:
    """Rotation: re-wrap the DEK under the current KEK. The document is NOT re-encrypted."""
    return provider.wrap(open_dek(provider, wk, doc_id, version), wrap_aad(doc_id, version))


# ---- passphrase-protected KEK backup (Argon2id + AES-256-GCM) -----------------------------
_A2 = dict(iterations=3, lanes=4, memory_cost=64 * 1024)


def export_backup(keks: dict[int, bytes], passphrase: str) -> bytes:
    if len(passphrase) < 12:
        raise ValueError("backup passphrase must be at least 12 characters")
    salt, nonce = os.urandom(16), os.urandom(12)
    key = Argon2id(salt=salt, length=32, **_A2).derive(passphrase.encode())
    payload = json.dumps({str(v): base64.b64encode(k).decode() for v, k in keks.items()}).encode()
    ct = AESGCM(key).encrypt(nonce, payload, b"secureshare-kek-backup-v1")
    return b"SSKB1" + salt + nonce + ct


def import_backup(blob: bytes, passphrase: str) -> dict[int, bytes]:
    if not blob.startswith(b"SSKB1") or len(blob) < 5 + 16 + 12 + 16:
        raise KeyError_("not a key backup")
    salt, nonce, ct = blob[5:21], blob[21:33], blob[33:]
    key = Argon2id(salt=salt, length=32, **_A2).derive(passphrase.encode())
    try:
        data = json.loads(AESGCM(key).decrypt(nonce, ct, b"secureshare-kek-backup-v1"))
    except InvalidTag as exc:
        raise KeyError_("wrong passphrase or corrupted backup") from exc
    return {int(v): base64.b64decode(k) for v, k in data.items()}


def provider_keks(p: LocalDevelopmentKeyProvider) -> dict[int, bytes]:
    return dict(p._keks)  # noqa: SLF001 - explicit backup hook for DEV provider
