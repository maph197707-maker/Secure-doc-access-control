"""Storage path safety: internal random names only, never user input."""
from __future__ import annotations

import secrets
from pathlib import Path


class PathViolation(Exception):
    pass


def new_internal_name() -> str:
    return secrets.token_hex(16)


def safe_join(root: Path, name: str) -> Path:
    """Resolve `name` under `root`; reject separators, traversal, absolute paths and symlinks."""
    if not name or any(s in name for s in ("/", "\\", "\x00")) or name in (".", "..") or Path(name).is_absolute():
        raise PathViolation("illegal storage name")
    root_r = root.resolve()
    target = (root_r / name)
    if target.is_symlink():
        raise PathViolation("symlink refused")
    resolved = target.resolve()
    if resolved.parent != root_r:
        raise PathViolation("path escapes storage root")
    return resolved
