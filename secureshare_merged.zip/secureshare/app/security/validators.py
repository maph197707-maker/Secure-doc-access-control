"""Upload validation: extension allow-list, magic bytes, size, filename normalisation.
Client filename and Content-Type are NEVER trusted. Pure Python (no libmagic)."""
from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

DEFAULT_ALLOWED = ("pdf", "docx", "xlsx", "pptx", "txt", "csv", "png", "jpg", "jpeg",
                   "zip", "md", "json", "xml", "rtf", "odt", "ods", "odp", "gif", "webp")
_FAMILY = {"pdf": "pdf", "png": "png", "jpg": "jpeg", "jpeg": "jpeg", "docx": "zip", "xlsx": "zip",
           "pptx": "zip", "txt": "text", "csv": "text",
           # zip also carries FOLDERS: zip the folder, upload the .zip
           "zip": "zip", "odt": "zip", "ods": "zip", "odp": "zip", "md": "text", "json": "text",
           "xml": "text", "rtf": "text", "gif": "gif", "webp": "webp"}
_WIN_RESERVED = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))}


class UploadRejected(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code, self.message = code, message


@dataclass(frozen=True)
class ValidatedUpload:
    ext: str
    family: str
    safe_name: str
    size: int


def normalize_filename(name: str) -> str:
    name = unicodedata.normalize("NFKC", name or "")
    name = re.split(r"[\\/]", name)[-1]                       # drop any client path
    name = "".join(c for c in name if c.isprintable())
    name = re.sub(r"[^A-Za-z0-9._ -]", "_", name).strip(" .")
    name = re.sub(r"\.{2,}", ".", name)[:120]
    stem = name.rsplit(".", 1)[0].lower()
    if not name or stem in _WIN_RESERVED or "." not in name:
        raise UploadRejected("BAD_FILENAME", "File name is not acceptable.")
    return name


def sniff_family(head: bytes) -> str | None:
    if head.startswith(b"%PDF-"):
        return "pdf"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if head.startswith(b"\xff\xd8\xff"):
        return "jpeg"
    if head.startswith(b"PK\x03\x04"):
        return "zip"
    if head.startswith((b"GIF87a", b"GIF89a")):
        return "gif"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    if b"\x00" not in head:
        try:
            head.decode("utf-8")
            return "text"
        except UnicodeDecodeError:
            try:  # head may cut a multibyte char in half
                head[:-3].decode("utf-8")
                return "text"
            except UnicodeDecodeError:
                return None
    return None


def validate_upload(filename: str, head: bytes, size: int, *, max_bytes: int,
                    allowed: tuple[str, ...] = DEFAULT_ALLOWED) -> ValidatedUpload:
    if size <= 0:
        raise UploadRejected("EMPTY_FILE", "The file is empty.")
    if size > max_bytes:
        raise UploadRejected("TOO_LARGE", f"File exceeds the {max_bytes // (1024 * 1024)} MB limit.")
    safe = normalize_filename(filename)
    ext = safe.rsplit(".", 1)[-1].lower()
    if ext not in allowed or ext not in _FAMILY:
        raise UploadRejected("TYPE_NOT_ALLOWED", "This file type is not allowed.")
    if sniff_family(head[:8192]) != _FAMILY[ext]:
        raise UploadRejected("CONTENT_MISMATCH", "File content does not match its extension.")
    return ValidatedUpload(ext, _FAMILY[ext], safe, size)
