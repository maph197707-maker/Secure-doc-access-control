"""OOXML (zip) safety: decompression-bomb, traversal and encryption guards.
Sizes are checked from declared metadata AND by counting real decompressed bytes."""
from __future__ import annotations

import zipfile
from typing import BinaryIO


class UnsafeArchive(Exception):
    pass


_MARKER = {"docx": "word/", "xlsx": "xl/", "pptx": "ppt/"}


def check_ooxml(fh: BinaryIO, kind: str, *, max_uncompressed: int = 200 * 1024 * 1024,
                max_ratio: int = 100, max_entries: int = 5000) -> None:
    try:
        zf = zipfile.ZipFile(fh)
    except zipfile.BadZipFile as exc:
        raise UnsafeArchive("not a valid zip container") from exc
    infos = zf.infolist()
    if len(infos) > max_entries:
        raise UnsafeArchive("too many entries")
    total = 0
    names = set()
    for i in infos:
        n = i.filename
        if n.startswith(("/", "\\")) or ".." in n.replace("\\", "/").split("/") or ":" in n:
            raise UnsafeArchive("illegal entry path")
        if i.flag_bits & 0x1:
            raise UnsafeArchive("encrypted entry")
        total += i.file_size
        if total > max_uncompressed:
            raise UnsafeArchive("uncompressed size limit exceeded")
        if i.compress_size and i.file_size / i.compress_size > max_ratio and i.file_size > 1 << 20:
            raise UnsafeArchive("suspicious compression ratio")
        names.add(n)
    if "[Content_Types].xml" not in names or not any(n.startswith(_MARKER[kind]) for n in names):
        raise UnsafeArchive("container does not look like " + kind)
    real = 0  # declared sizes can lie: count what actually decompresses
    for i in infos:
        with zf.open(i) as f:
            while chunk := f.read(1 << 20):
                real += len(chunk)
                if real > max_uncompressed:
                    raise UnsafeArchive("uncompressed size limit exceeded")
