"""Rule-based threat detection over REAL security events. Pure: no I/O.

Callers load events from audit_logs / security_events and persist the returned alerts.
Every alert lists the event ids it came from, and `to_risk_events` converts the same evidence
into RiskEvent inputs for app.services.risk, so scoring stays explainable.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta

# event kinds understood by the detector
LOGIN_FAILED, OTP_FAILED, ACCESS_DENIED = "LOGIN_FAILED", "OTP_FAILED", "ACCESS_DENIED"
DOWNLOAD, SHARE_CREATED, LOGIN_OK = "DOWNLOAD", "SHARE_CREATED", "LOGIN_OK"

THRESHOLDS = {"brute_force": (5, 600), "otp_failures": (5, 600), "denied": (10, 600),
              "rapid_download": (10, 300), "share_burst": (15, 3600)}


@dataclass(frozen=True)
class SecEvent:
    id: str
    kind: str
    at: datetime
    user_id: str | None = None
    ip: str | None = None
    device: str | None = None
    target: str | None = None  # e.g. document id


@dataclass(frozen=True)
class Alert:
    code: str
    severity: str  # LOW | MEDIUM | HIGH | CRITICAL
    subject: str   # user id or ip the alert is about
    message: str
    evidence_ids: tuple[str, ...]


def _window_hits(events: list[SecEvent], count: int, seconds: int) -> list[SecEvent]:
    """Return the first run of `count` events that fall inside `seconds`, else []."""
    ev = sorted(events, key=lambda e: e.at)
    for i in range(len(ev) - count + 1):
        if ev[i + count - 1].at - ev[i].at <= timedelta(seconds=seconds):
            return ev[i:i + count]
    return []


def detect(events: list[SecEvent]) -> list[Alert]:
    alerts: list[Alert] = []

    def burst(kind: str, key: str, subject_of, code: str, sev: str, msg: str) -> None:
        n, secs = THRESHOLDS[key]
        groups: dict[str, list[SecEvent]] = defaultdict(list)
        for e in events:
            if e.kind == kind and subject_of(e):
                groups[subject_of(e)].append(e)
        for subject, evs in sorted(groups.items()):
            hit = _window_hits(evs, n, secs)
            if hit:
                alerts.append(Alert(code, sev, subject, msg.format(n=n, secs=secs),
                                    tuple(e.id for e in hit)))

    burst(LOGIN_FAILED, "brute_force", lambda e: e.ip or e.user_id, "BRUTE_FORCE", "HIGH",
          "{n}+ failed logins within {secs}s")
    burst(OTP_FAILED, "otp_failures", lambda e: e.user_id, "REPEATED_OTP_FAILURE", "HIGH",
          "{n}+ failed OTP/MFA attempts within {secs}s")
    burst(ACCESS_DENIED, "denied", lambda e: e.user_id or e.ip, "EXCESSIVE_DENIED_ACCESS", "MEDIUM",
          "{n}+ denied access attempts within {secs}s")
    burst(DOWNLOAD, "rapid_download", lambda e: e.user_id, "RAPID_DOWNLOAD", "HIGH",
          "{n}+ downloads within {secs}s")
    burst(SHARE_CREATED, "share_burst", lambda e: e.user_id, "SUSPICIOUS_SHARING", "MEDIUM",
          "{n}+ shares created within {secs}s")

    # new IP / new device for a user vs their earlier successful logins (needs >=1 prior login)
    by_user: dict[str, list[SecEvent]] = defaultdict(list)
    for e in events:
        if e.kind == LOGIN_OK and e.user_id:
            by_user[e.user_id].append(e)
    for uid, logins in sorted(by_user.items()):
        logins.sort(key=lambda e: e.at)
        seen_ip, seen_dev = set(), set()
        for i, e in enumerate(logins):
            if i > 0 and e.ip and e.ip not in seen_ip:
                alerts.append(Alert("UNUSUAL_IP", "LOW", uid, "login from a previously unseen IP", (e.id,)))
            if i > 0 and e.device and e.device not in seen_dev:
                alerts.append(Alert("UNUSUAL_DEVICE", "LOW", uid, "login from a previously unseen device", (e.id,)))
            seen_ip.add(e.ip)
            seen_dev.add(e.device)
    return alerts


_TO_RISK = {"BRUTE_FORCE": "FAILED_LOGIN", "REPEATED_OTP_FAILURE": "FAILED_OTP",
            "EXCESSIVE_DENIED_ACCESS": "REPEATED_DENIAL", "RAPID_DOWNLOAD": "RAPID_DOWNLOAD",
            "UNUSUAL_IP": "MULTI_IP", "UNUSUAL_DEVICE": "NEW_DEVICE"}


def to_risk_events(alerts: list[Alert]) -> list[tuple[str, str]]:
    """(risk code, evidence id) pairs for app.services.risk.RiskEvent; unmapped alerts are skipped."""
    out: list[tuple[str, str]] = []
    for a in alerts:
        code = _TO_RISK.get(a.code)
        if code:
            out += [(code, eid) for eid in a.evidence_ids]
    return out
