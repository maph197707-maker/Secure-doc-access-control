"""Core enumerations used across all SecureShare modules."""
from __future__ import annotations

from enum import Enum


# ── Decision ──────────────────────────────────────────────────────────────────
class Decision(str, Enum):
    ALLOW = "ALLOW"
    RESTRICT = "RESTRICT"    # allowed but with extra controls (watermark, no download)
    VERIFY = "VERIFY"        # step-up required before access
    DENY = "DENY"


# ── Risk ─────────────────────────────────────────────────────────────────────
class RiskLevel(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


# ── DLP ──────────────────────────────────────────────────────────────────────
class DlpLevel(str, Enum):
    NONE = "NONE"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class DlpAction(str, Enum):
    ALLOW = "ALLOW"
    WARN = "WARN"
    BLOCK = "BLOCK"
    QUARANTINE = "QUARANTINE"
    REDACT = "REDACT"


# ── Classification ────────────────────────────────────────────────────────────
class Classification(str, Enum):
    PUBLIC = "PUBLIC"
    INTERNAL = "INTERNAL"
    CONFIDENTIAL = "CONFIDENTIAL"
    RESTRICTED = "RESTRICTED"
    TOP_SECRET = "TOP_SECRET"


# ── Document lifecycle ────────────────────────────────────────────────────────
class DocumentStatus(str, Enum):
    UPLOADED = "UPLOADED"
    VALIDATED = "VALIDATED"
    QUARANTINED = "QUARANTINED"
    SCANNING = "SCANNING"
    ANALYZED = "ANALYZED"
    CLASSIFIED = "CLASSIFIED"
    DLP_DONE = "DLP_DONE"
    SIGNED = "SIGNED"
    ENCRYPTED = "ENCRYPTED"
    STORED = "STORED"
    SHARED = "SHARED"
    ARCHIVED = "ARCHIVED"
    EXPIRED = "EXPIRED"
    REVOKED = "REVOKED"
    DELETED = "DELETED"


# ── Key states ────────────────────────────────────────────────────────────────
class KeyState(str, Enum):
    GENERATED = "GENERATED"
    ACTIVE = "ACTIVE"
    ROTATING = "ROTATING"
    EXPIRED = "EXPIRED"
    REVOKED = "REVOKED"
    DESTROYED = "DESTROYED"


class KeyAlgorithm(str, Enum):
    AES_256_GCM = "AES_256_GCM"
    RSA_4096 = "RSA_4096"
    ED25519 = "ED25519"


# ── Signature algorithm ───────────────────────────────────────────────────────
class SignatureAlgorithm(str, Enum):
    ED25519 = "ED25519"
    RSA_PSS_SHA256 = "RSA_PSS_SHA256"
    ECDSA_P256 = "ECDSA_P256"


# ── MFA type ─────────────────────────────────────────────────────────────────
class MFAType(str, Enum):
    TOTP = "TOTP"
    BACKUP_CODE = "BACKUP_CODE"
    WEBAUTHN = "WEBAUTHN"
    EMAIL_OTP = "EMAIL_OTP"
    SMS_OTP = "SMS_OTP"


# ── Scan result ───────────────────────────────────────────────────────────────
class MalwareScanResult(str, Enum):
    CLEAN = "CLEAN"
    INFECTED = "INFECTED"
    SUSPICIOUS = "SUSPICIOUS"
    PROVIDER_UNAVAILABLE = "PROVIDER_UNAVAILABLE"
    DEV_ONLY = "DEV_ONLY"
    PENDING = "PENDING"


# ── Processing job status ─────────────────────────────────────────────────────
class JobStatus(str, Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    DONE = "DONE"
    FAILED = "FAILED"
    RETRYING = "RETRYING"


class JobType(str, Enum):
    MALWARE_SCAN = "MALWARE_SCAN"
    TEXT_EXTRACT = "TEXT_EXTRACT"
    OCR = "OCR"
    DLP = "DLP"
    CLASSIFY = "CLASSIFY"
    NOTIFY = "NOTIFY"
    AUDIT_VERIFY = "AUDIT_VERIFY"
    MAINTENANCE = "MAINTENANCE"


# ── User / Auth ───────────────────────────────────────────────────────────────
class UserStatus(str, Enum):
    ACTIVE = "ACTIVE"
    SUSPENDED = "SUSPENDED"
    PENDING_VERIFICATION = "PENDING_VERIFICATION"
    LOCKED = "LOCKED"
    DELETED = "DELETED"


class RoleName(str, Enum):
    ADMIN = "ADMIN"
    MANAGER = "MANAGER"
    USER = "USER"


class PermissionCode(str, Enum):
    DOCUMENT_VIEW = "DOCUMENT_VIEW"
    DOCUMENT_DOWNLOAD = "DOCUMENT_DOWNLOAD"
    DOCUMENT_UPLOAD = "DOCUMENT_UPLOAD"
    DOCUMENT_EDIT = "DOCUMENT_EDIT"
    DOCUMENT_DELETE = "DOCUMENT_DELETE"
    DOCUMENT_SHARE = "DOCUMENT_SHARE"
    DOCUMENT_RESHARE = "DOCUMENT_RESHARE"
    DOCUMENT_REVOKE = "DOCUMENT_REVOKE"
    DOCUMENT_SIGN = "DOCUMENT_SIGN"
    DOCUMENT_VERIFY = "DOCUMENT_VERIFY"
    USER_MANAGE = "USER_MANAGE"
    AUDIT_VIEW = "AUDIT_VIEW"
    SECURITY_VIEW = "SECURITY_VIEW"
    ANALYTICS_VIEW = "ANALYTICS_VIEW"
    POLICY_MANAGE = "POLICY_MANAGE"
    SYSTEM_MANAGE = "SYSTEM_MANAGE"


class GrantPermission(str, Enum):
    VIEW = "VIEW"
    DOWNLOAD = "DOWNLOAD"
    PRINT = "PRINT"
    COPY = "COPY"
    EDIT = "EDIT"
    RESHARE = "RESHARE"
    COMMENT = "COMMENT"
    SIGN = "SIGN"
    DELETE = "DELETE"


Permission = GrantPermission


# ── Session / Device ─────────────────────────────────────────────────────────
class DeviceTrust(str, Enum):
    TRUSTED = "TRUSTED"
    UNTRUSTED = "UNTRUSTED"
    UNKNOWN = "UNKNOWN"
    BLOCKED = "BLOCKED"


class SessionStatus(str, Enum):
    ACTIVE = "ACTIVE"
    EXPIRED = "EXPIRED"
    REVOKED = "REVOKED"


# ── Link / Share ─────────────────────────────────────────────────────────────
class LinkStatus(str, Enum):
    ACTIVE = "ACTIVE"
    EXPIRED = "EXPIRED"
    REVOKED = "REVOKED"
    EXHAUSTED = "EXHAUSTED"   # max views/downloads reached


class LinkReputation(str, Enum):
    NORMAL = "NORMAL"
    SUSPICIOUS = "SUSPICIOUS"
    ABUSED = "ABUSED"


class BindingMode(str, Enum):
    NONE = "NONE"
    EMAIL = "EMAIL"
    EMAIL_OTP = "EMAIL_OTP"
    EMAIL_PHONE_OTP = "EMAIL_PHONE_OTP"    # PROVIDER_UNAVAILABLE if no SMS
    EMAIL_DEVICE = "EMAIL_DEVICE"
    EMAIL_PASSKEY = "EMAIL_PASSKEY"
    EMAIL_OTP_DEVICE = "EMAIL_OTP_DEVICE"
    EMAIL_PHONE_PASSKEY = "EMAIL_PHONE_PASSKEY"


# ── Audit ─────────────────────────────────────────────────────────────────────
class AuditAction(str, Enum):
    # Auth
    USER_REGISTERED = "USER_REGISTERED"
    USER_LOGIN = "USER_LOGIN"
    USER_LOGIN_FAILED = "USER_LOGIN_FAILED"
    USER_LOGOUT = "USER_LOGOUT"
    USER_LOCKED = "USER_LOCKED"
    USER_UNLOCKED = "USER_UNLOCKED"
    PASSWORD_CHANGED = "PASSWORD_CHANGED"
    PASSWORD_RESET_REQUESTED = "PASSWORD_RESET_REQUESTED"
    EMAIL_VERIFIED = "EMAIL_VERIFIED"
    MFA_ENABLED = "MFA_ENABLED"
    MFA_DISABLED = "MFA_DISABLED"
    MFA_PASSED = "MFA_PASSED"
    MFA_FAILED = "MFA_FAILED"
    DEVICE_REGISTERED = "DEVICE_REGISTERED"
    DEVICE_TRUSTED = "DEVICE_TRUSTED"
    DEVICE_BLOCKED = "DEVICE_BLOCKED"
    SESSION_CREATED = "SESSION_CREATED"
    SESSION_REVOKED = "SESSION_REVOKED"
    STEP_UP_REQUIRED = "STEP_UP_REQUIRED"
    STEP_UP_PASSED = "STEP_UP_PASSED"
    # Documents
    DOCUMENT_UPLOADED = "DOCUMENT_UPLOADED"
    DOCUMENT_VALIDATED = "DOCUMENT_VALIDATED"
    DOCUMENT_QUARANTINED = "DOCUMENT_QUARANTINED"
    DOCUMENT_SCANNED = "DOCUMENT_SCANNED"
    DOCUMENT_CLASSIFIED = "DOCUMENT_CLASSIFIED"
    DOCUMENT_ENCRYPTED = "DOCUMENT_ENCRYPTED"
    DOCUMENT_VIEWED = "DOCUMENT_VIEWED"
    DOCUMENT_DOWNLOADED = "DOCUMENT_DOWNLOADED"
    DOCUMENT_EDITED = "DOCUMENT_EDITED"
    DOCUMENT_DELETED = "DOCUMENT_DELETED"
    DOCUMENT_RESTORED = "DOCUMENT_RESTORED"
    DOCUMENT_ARCHIVED = "DOCUMENT_ARCHIVED"
    DOCUMENT_SHARED = "DOCUMENT_SHARED"
    DOCUMENT_SIGNED = "DOCUMENT_SIGNED"
    DOCUMENT_VERIFIED = "DOCUMENT_VERIFIED"
    VERSION_CREATED = "VERSION_CREATED"
    VERSION_RESTORED = "VERSION_RESTORED"
    # Links
    LINK_CREATED = "LINK_CREATED"
    LINK_ACCESSED = "LINK_ACCESSED"
    LINK_DENIED = "LINK_DENIED"
    LINK_REVOKED = "LINK_REVOKED"
    LINK_ROTATED = "LINK_ROTATED"
    LINK_EXPIRED = "LINK_EXPIRED"
    # Keys
    KEY_GENERATED = "KEY_GENERATED"
    KEY_ROTATED = "KEY_ROTATED"
    KEY_REVOKED = "KEY_REVOKED"
    KEY_DESTROYED = "KEY_DESTROYED"
    # DLP
    DLP_FINDING = "DLP_FINDING"
    DLP_BLOCKED = "DLP_BLOCKED"
    # Risk / Security
    RISK_ASSESSED = "RISK_ASSESSED"
    ALERT_RAISED = "ALERT_RAISED"
    POLICY_CHANGED = "POLICY_CHANGED"
    # Admin
    USER_SUSPENDED = "USER_SUSPENDED"
    USER_ROLE_CHANGED = "USER_ROLE_CHANGED"
    PERMISSION_GRANTED = "PERMISSION_GRANTED"
    PERMISSION_REVOKED = "PERMISSION_REVOKED"


# ── Notification type ─────────────────────────────────────────────────────────
class NotificationType(str, Enum):
    SHARED_WITH_YOU = "SHARED_WITH_YOU"
    LINK_ACCESSED = "LINK_ACCESSED"
    NEW_DEVICE_LOGIN = "NEW_DEVICE_LOGIN"
    THREAT_DETECTED = "THREAT_DETECTED"
    DOCUMENT_COMPLETED = "DOCUMENT_COMPLETED"
    DLP_ALERT = "DLP_ALERT"
    ACCOUNT_LOCKED = "ACCOUNT_LOCKED"
    EMAIL_VERIFIED = "EMAIL_VERIFIED"
    PASSWORD_CHANGED = "PASSWORD_CHANGED"
    LINK_EXPIRED = "LINK_EXPIRED"
    ACCESS_DENIED = "ACCESS_DENIED"


# ── Feature status (for feature-matrix) ──────────────────────────────────────
class FeatureStatus(str, Enum):
    ACTIVE = "ACTIVE"
    PROTOTYPE = "PROTOTYPE"
    PROVIDER_UNAVAILABLE = "PROVIDER_UNAVAILABLE"
    PLANNED = "PLANNED"


# ── Per-document grants (used by the policy engine) ───────────────────────────
class Permission(str, Enum):
    VIEW = "VIEW"
    DOWNLOAD = "DOWNLOAD"
    PRINT = "PRINT"
    COPY = "COPY"
    EDIT = "EDIT"
    RESHARE = "RESHARE"
    COMMENT = "COMMENT"
    SIGN = "SIGN"
    DELETE = "DELETE"
