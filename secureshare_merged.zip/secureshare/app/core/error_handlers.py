"""Global error and exception handlers for FastAPI."""
from __future__ import annotations

from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import HTMLResponse, JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.config.constants import ERR_BAD_REQUEST, ERR_INTERNAL, ERR_NOT_FOUND, ERR_VALIDATION
from app.config.logging import logger
from app.core.exceptions import SecureShareException
from app.core.responses import error_response
from app.web.templating import build_env

_env = build_env()


def _is_api_request(request: Request) -> bool:
    """Return True if request is for the API or expects JSON."""
    if request.url.path.startswith("/api/"):
        return True
    accept = request.headers.get("accept", "")
    return "application/json" in accept and "text/html" not in accept


def _get_request_id(request: Request) -> str:
    return getattr(request.state, "request_id", "") or request.headers.get("x-request-id", "")


async def secureshare_exception_handler(request: Request, exc: SecureShareException) -> JSONResponse | HTMLResponse:
    req_id = _get_request_id(request)
    logger.warning("secureshare_exception", code=exc.code, message=exc.message, request_id=req_id, path=request.url.path)
    if _is_api_request(request):
        return error_response(
            code=exc.code,
            message=exc.message,
            request_id=req_id,
            details=exc.details,
            status_code=exc.status_code,
        )
    # Render HTML error page
    tmpl = _env.get_template("errors/error.html")
    html = tmpl.render(
        code=exc.status_code,
        title=exc.code.replace("_", " ").title(),
        message=exc.message,
        request_id=req_id,
    )
    return HTMLResponse(content=html, status_code=exc.status_code)


async def http_exception_handler(request: Request, exc: StarletteHTTPException) -> JSONResponse | HTMLResponse:
    req_id = _get_request_id(request)
    code = ERR_NOT_FOUND if exc.status_code == 404 else f"HTTP_{exc.status_code}"
    if _is_api_request(request):
        return error_response(
            code=code,
            message=str(exc.detail),
            request_id=req_id,
            status_code=exc.status_code,
        )
    tmpl = _env.get_template("errors/error.html")
    html = tmpl.render(
        code=exc.status_code,
        title="Page Not Found" if exc.status_code == 404 else f"Error {exc.status_code}",
        message=str(exc.detail),
        request_id=req_id,
    )
    return HTMLResponse(content=html, status_code=exc.status_code)


async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse | HTMLResponse:
    req_id = _get_request_id(request)
    errors = exc.errors()
    # Format simplified validation error messages without leaking secrets
    details = [{"loc": e.get("loc"), "msg": e.get("msg"), "type": e.get("type")} for e in errors]
    if _is_api_request(request):
        return error_response(
            code=ERR_VALIDATION,
            message="Request validation failed.",
            request_id=req_id,
            details=details,
            status_code=422,
        )
    tmpl = _env.get_template("errors/error.html")
    html = tmpl.render(
        code=422,
        title="Validation Error",
        message="The submitted data was invalid. Please check your input.",
        request_id=req_id,
    )
    return HTMLResponse(content=html, status_code=422)


async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse | HTMLResponse:
    req_id = _get_request_id(request)
    logger.exception("unhandled_server_error", exc_info=exc, request_id=req_id, path=request.url.path)
    msg = "An unexpected error occurred. Please contact support with the request ID."
    if _is_api_request(request):
        return error_response(
            code=ERR_INTERNAL,
            message=msg,
            request_id=req_id,
            status_code=500,
        )
    tmpl = _env.get_template("errors/error.html")
    html = tmpl.render(
        code=500,
        title="Internal Server Error",
        message=msg,
        request_id=req_id,
    )
    return HTMLResponse(content=html, status_code=500)


def register_error_handlers(app: FastAPI) -> None:
    app.add_exception_handler(SecureShareException, secureshare_exception_handler)
    app.add_exception_handler(StarletteHTTPException, http_exception_handler)
    app.add_exception_handler(RequestValidationError, validation_exception_handler)
    app.add_exception_handler(Exception, unhandled_exception_handler)
