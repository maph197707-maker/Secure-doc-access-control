"""Common utilities and safe URL validators."""
from __future__ import annotations

import re


def safe_redirect_url(url: str | None, default: str = "/dashboard") -> str:
    """Ensure a redirect target is internal and safe against open-redirect attacks."""
    if not url:
        return default
    url = url.strip()
    # Must start with single slash, no double slashes, no backslashes, no scheme
    if (
        url.startswith("/")
        and not url.startswith("//")
        and not url.startswith("/\\")
        and ":" not in url.split("?")[0]
        and not re.search(r"[\r\n\t]", url)
    ):
        return url
    return default


def mask_email(email: str) -> str:
    """Mask email for display, e.g. john@example.com -> j***@example.com"""
    if "@" not in email:
        return email
    local, domain = email.split("@", 1)
    if len(local) <= 1:
        masked_local = f"{local}***"
    else:
        masked_local = f"{local[0]}***"
    return f"{masked_local}@{domain}"
