"""FastAPI dependency injection providers."""
from __future__ import annotations

from typing import Annotated, Callable
from fastapi import Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.constants import COOKIE_SESSION
from app.core.enums import PermissionCode, RoleName, UserStatus
from app.core.exceptions import AuthenticationError, PermissionDeniedError
from app.db.session import get_db
from app.integrations.state import StateStore, get_state_store
from app.models.session import UserSession
from app.models.user import User
from app.services.sessions import SessionService


def get_client_ip(request: Request) -> str:
    """The TCP peer address, and nothing the client can write.

    X-Forwarded-For used to be trusted here unconditionally, so any client could send a fresh fake
    address on every request and sidestep the per-IP OTP throttle, the per-IP risk score and the
    audit trail. Behind a reverse proxy the real client address is restored by uvicorn itself
    (``--proxy-headers --forwarded-allow-ips``, see deploy/entrypoint.sh), which only honours the
    header from allowed proxy peers and rewrites ``request.client`` before this code runs.
    """
    return request.client.host if request.client else "unknown"


def get_user_agent(request: Request) -> str:
    return request.headers.get("user-agent", "")[:500]


def extract_raw_token(request: Request) -> str | None:
    """Extract raw session token from Bearer header or session cookie."""
    auth_header = request.headers.get("authorization")
    if auth_header and auth_header.startswith("Bearer "):
        return auth_header[7:].strip()
    return request.cookies.get(COOKIE_SESSION)


async def get_optional_user(
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> tuple[UserSession | None, User | None]:
    token = extract_raw_token(request)
    if not token:
        return None, None
    svc = SessionService(db)
    return await svc.get_session(token)


async def get_current_user_and_session(
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> tuple[UserSession, User]:
    session, user = await get_optional_user(request, db)
    if not session or not user:
        raise AuthenticationError("Authentication required.")
    return session, user


async def get_current_user(
    auth: Annotated[tuple[UserSession, User], Depends(get_current_user_and_session)],
) -> User:
    _, user = auth
    return user


async def get_current_active_user(
    user: Annotated[User, Depends(get_current_user)],
) -> User:
    if user.status != UserStatus.ACTIVE.value or user.is_deleted:
        raise PermissionDeniedError("Your account is not active.")
    return user


def require_role(role_name: RoleName) -> Callable[[User], User]:
    def dependency(user: Annotated[User, Depends(get_current_active_user)]) -> User:
        if user.is_superuser:
            return user
        if not any(r.name == role_name.value for r in user.roles):
            raise PermissionDeniedError(f"Role '{role_name.value}' required.")
        return user
    return dependency


def require_permission(perm: PermissionCode) -> Callable[[User], User]:
    def dependency(user: Annotated[User, Depends(get_current_active_user)]) -> User:
        if user.is_superuser:
            return user
        if not user.has_permission(perm.value):
            raise PermissionDeniedError(f"Permission '{perm.value}' required.")
        return user
    return dependency


async def get_mfa_verified(
    auth: Annotated[tuple[UserSession, User], Depends(get_current_user_and_session)],
) -> bool:
    """True only if THIS session completed MFA (sessions.py sets it False when the user has MFA on
    until the challenge is passed). Users without MFA are not 'verified' for MFA-gated documents."""
    session, user = auth
    return bool(session.mfa_verified and user.mfa_enabled)
