"""Standardized API response helpers and envelopes."""
from __future__ import annotations

from typing import Any
from fastapi.responses import JSONResponse


def success_response(
    data: Any = None,
    meta: dict[str, Any] | None = None,
    status_code: int = 200,
    headers: dict[str, str] | None = None,
) -> JSONResponse:
    """Standard API success response envelope."""
    content: dict[str, Any] = {}
    if data is not None:
        content["data"] = data
    if meta is not None:
        content["meta"] = meta
    return JSONResponse(content=content, status_code=status_code, headers=headers)


def error_response(
    code: str,
    message: str,
    request_id: str = "",
    details: Any = None,
    status_code: int = 400,
    headers: dict[str, str] | None = None,
) -> JSONResponse:
    """Standard API error response envelope matching spec:
    {"error": {"code": str, "message": str, "request_id": str, "details": ...}}
    """
    err_body: dict[str, Any] = {
        "code": code,
        "message": message,
        "request_id": request_id,
    }
    if details is not None:
        err_body["details"] = details
    return JSONResponse(
        content={"error": err_body},
        status_code=status_code,
        headers=headers,
    )
