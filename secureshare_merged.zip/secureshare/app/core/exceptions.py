"""Custom application exceptions with error codes and HTTP status mappings."""
from __future__ import annotations

from typing import Any

from app.config.constants import (
    ERR_ACCOUNT_LOCKED,
    ERR_BAD_REQUEST,
    ERR_CONFLICT,
    ERR_CSRF_FAILED,
    ERR_DELIVERY_FAILED,
    ERR_FORBIDDEN,
    ERR_NOT_FOUND,
    ERR_RATE_LIMIT,
    ERR_UNAUTHORIZED,
    ERR_VALIDATION,
)


class SecureShareException(Exception):
    """Base application exception."""

    def __init__(
        self,
        message: str,
        code: str = ERR_BAD_REQUEST,
        status_code: int = 400,
        details: Any = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code = code
        self.status_code = status_code
        self.details = details


class AuthenticationError(SecureShareException):
    def __init__(self, message: str = "Invalid credentials", details: Any = None) -> None:
        super().__init__(
            message=message,
            code=ERR_UNAUTHORIZED,
            status_code=401,
            details=details,
        )


class PermissionDeniedError(SecureShareException):
    def __init__(
        self, message: str = "You do not have permission to perform this action", details: Any = None
    ) -> None:
        super().__init__(
            message=message,
            code=ERR_FORBIDDEN,
            status_code=403,
            details=details,
        )


class NotFoundError(SecureShareException):
    def __init__(self, message: str = "Resource not found", details: Any = None) -> None:
        super().__init__(
            message=message,
            code=ERR_NOT_FOUND,
            status_code=404,
            details=details,
        )


class ConflictError(SecureShareException):
    def __init__(self, message: str = "Resource conflict", details: Any = None) -> None:
        super().__init__(
            message=message,
            code=ERR_CONFLICT,
            status_code=409,
            details=details,
        )


class ValidationError(SecureShareException):
    def __init__(self, message: str = "Validation failed", details: Any = None) -> None:
        super().__init__(
            message=message,
            code=ERR_VALIDATION,
            status_code=422,
            details=details,
        )


class RateLimitExceededError(SecureShareException):
    def __init__(
        self,
        message: str = "Rate limit exceeded. Please try again later.",
        retry_after: int = 60,
        details: Any = None,
    ) -> None:
        super().__init__(
            message=message,
            code=ERR_RATE_LIMIT,
            status_code=429,
            details={"retry_after": retry_after, **(details or {})},
        )
        self.retry_after = retry_after


class LockoutError(SecureShareException):
    def __init__(
        self,
        message: str = "Account temporarily locked due to too many failed attempts.",
        retry_after: int = 30,
        details: Any = None,
    ) -> None:
        super().__init__(
            message=message,
            code=ERR_ACCOUNT_LOCKED,
            status_code=423,
            details={"retry_after": retry_after, **(details or {})},
        )
        self.retry_after = retry_after


class CsrfError(SecureShareException):
    def __init__(
        self, message: str = "Invalid or missing CSRF token.", details: Any = None
    ) -> None:
        super().__init__(
            message=message,
            code=ERR_CSRF_FAILED,
            status_code=403,
            details=details,
        )


class BadRequestError(SecureShareException):
    def __init__(self, message: str = "Bad request", details: Any = None) -> None:
        super().__init__(
            message=message,
            code=ERR_BAD_REQUEST,
            status_code=400,
            details=details,
        )


class DeliveryError(SecureShareException):
    """A one-time code could not be delivered. `reason` is the provider-failure category (also in the
    audit trail); the user-facing message never reveals provider details or credentials."""

    def __init__(self, message: str = "We couldn't send the verification code.", details: Any = None,
                 status_code: int = 502, reason: str | None = None) -> None:
        super().__init__(
            message=message,
            code=ERR_DELIVERY_FAILED,
            status_code=status_code,
            details=details,
        )
        self.reason = reason


class ProviderUnavailableError(DeliveryError):
    """No (working) delivery provider: not configured, bad credentials or provider rate limit. 503."""

    def __init__(self, message: str = "Verification messages are temporarily unavailable.",
                 reason: str | None = None) -> None:
        super().__init__(message, status_code=503, reason=reason)


class MfaRequiredError(SecureShareException):
    """Password was correct but the account has MFA on: a second factor is needed before a session
    exists. Carries the short-lived challenge id; it is NOT an authentication failure."""

    def __init__(self, challenge_id: str, message: str = "Enter your authenticator code to finish signing in.") -> None:
        super().__init__(message, code="MFA_REQUIRED", status_code=401, details={"challenge_id": challenge_id})
        self.challenge_id = challenge_id
