from __future__ import annotations
from datetime import datetime
from typing import Optional
from sqlalchemy import String, Text, JSON, DateTime, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import AppBase

class AccessRequest(AppBase):
    __tablename__ = 'access_requests'

    document_id: Mapped[str] = mapped_column(String(36), ForeignKey('documents.id'), index=True)
    requester_id: Mapped[str] = mapped_column(String(36), ForeignKey('users.id'), index=True)
    requested_permissions: Mapped[list] = mapped_column(JSON, default=list)
    reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default='PENDING')
    reviewed_by: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('users.id'), nullable=True)
    reviewed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
