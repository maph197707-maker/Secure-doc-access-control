from __future__ import annotations
from datetime import datetime
from typing import TYPE_CHECKING
from sqlalchemy import String, Float, JSON, DateTime, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import AppBase, _now

if TYPE_CHECKING:
    from app.models.user import User

class BehaviourProfile(AppBase):
    __tablename__ = 'behaviour_profiles'

    user_id: Mapped[str] = mapped_column(String(36), ForeignKey('users.id'), unique=True, index=True)
    typical_ips: Mapped[list] = mapped_column(JSON, default=list)
    typical_user_agents: Mapped[list] = mapped_column(JSON, default=list)
    typical_hours: Mapped[list] = mapped_column(JSON, default=list)
    avg_daily_uploads: Mapped[float] = mapped_column(Float, default=0.0)
    avg_daily_downloads: Mapped[float] = mapped_column(Float, default=0.0)
    avg_daily_views: Mapped[float] = mapped_column(Float, default=0.0)
    anomaly_score: Mapped[float] = mapped_column(Float, default=0.0)
    last_updated: Mapped[datetime] = mapped_column(DateTime, default=_now)

    user: Mapped['User'] = relationship('User')
