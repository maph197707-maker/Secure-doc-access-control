from __future__ import annotations
from sqlalchemy import String, ForeignKey, Text, DateTime
from sqlalchemy.orm import Mapped, mapped_column
from typing import Optional
from datetime import datetime

from app.db.base import AppBase

class EncryptionKey(AppBase):
    __tablename__ = 'encryption_keys'

    reference: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    algorithm: Mapped[str] = mapped_column(String(30), default='AES_256_GCM')
    state: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    provider: Mapped[str] = mapped_column(String(50), default='local_dev')
    provider_key_id: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    wrapped_key_material: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    public_key_pem: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    activated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    rotated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    destroyed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    created_by: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('users.id'), nullable=True)
