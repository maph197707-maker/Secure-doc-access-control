from __future__ import annotations
from sqlalchemy import String, ForeignKey, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import List, Optional

from app.db.base import AppBase, SoftDeleteMixin
from app.models.tag import document_tags

class Document(AppBase, SoftDeleteMixin):
    __tablename__ = 'documents'

    owner_id: Mapped[str] = mapped_column(String(36), ForeignKey('users.id'), index=True)
    folder_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('folders.id'), nullable=True)
    original_filename: Mapped[str] = mapped_column(String(500))
    internal_name: Mapped[str] = mapped_column(String(36), unique=True, index=True)
    display_name: Mapped[str] = mapped_column(String(500))
    doc_type: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    category: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    status: Mapped[str] = mapped_column(String(30), default='UPLOADED')
    classification: Mapped[str] = mapped_column(String(30), default='INTERNAL')
    sensitivity_level: Mapped[int] = mapped_column(Integer, default=1)
    current_version_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    size_bytes: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    sha256: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    sha3_256: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    malware_scan_result: Mapped[str] = mapped_column(String(30), default='PENDING')
    dlp_level: Mapped[str] = mapped_column(String(20), default='NONE')

    owner: Mapped["User"] = relationship("User")
    folder: Mapped[Optional["Folder"]] = relationship("Folder", back_populates="documents")
    versions: Mapped[List["DocumentVersion"]] = relationship("DocumentVersion", back_populates="document")
    metadata_: Mapped[Optional["DocumentMetadata"]] = relationship("DocumentMetadata", uselist=False, back_populates="document")
    tags: Mapped[List["Tag"]] = relationship("Tag", secondary=document_tags, back_populates="documents")
    secure_links: Mapped[List["SecureLink"]] = relationship("SecureLink", back_populates="document")
    dlp_findings: Mapped[List["DLPFinding"]] = relationship("DLPFinding", back_populates="document")
    signatures: Mapped[List["Signature"]] = relationship("Signature", back_populates="document")
