from app.models.role import Permission, role_permissions

__all__ = ["Permission", "role_permissions"]
