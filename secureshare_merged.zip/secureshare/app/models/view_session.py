from __future__ import annotations
from sqlalchemy import String, ForeignKey, JSON, DateTime
from sqlalchemy.orm import Mapped, mapped_column
from typing import Optional, List, Any
from datetime import datetime

from app.db.base import AppBase, _now

class ViewSession(AppBase):
    __tablename__ = 'view_sessions'

    document_id: Mapped[str] = mapped_column(String(36), ForeignKey('documents.id'), index=True)
    link_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    user_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('users.id'), nullable=True)
    recipient_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    user_agent: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    watermark_text: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    pages_viewed: Mapped[List[Any]] = mapped_column(JSON, default=list)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    last_activity_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    ended_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    session_token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
