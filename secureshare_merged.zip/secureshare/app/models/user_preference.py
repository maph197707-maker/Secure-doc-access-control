from __future__ import annotations
from typing import Any
from sqlalchemy import String, Boolean, JSON, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import AppBase

class UserPreference(AppBase):
    __tablename__ = 'user_preferences'
    
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey('users.id'), unique=True, index=True, nullable=False)
    theme: Mapped[str] = mapped_column(String(20), default='system', nullable=False)
    onboarding_seen: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    email_notifications: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    notification_types: Mapped[list[str] | dict[str, Any] | None] = mapped_column(JSON, default=list, nullable=True)
    language: Mapped[str] = mapped_column(String(10), default='en', nullable=False)
    timezone: Mapped[str] = mapped_column(String(50), default='UTC', nullable=False)
    
    user: Mapped['User'] = relationship(back_populates='preference')
