from __future__ import annotations
from sqlalchemy import String, ForeignKey, Integer, JSON, DateTime
from sqlalchemy.orm import Mapped, mapped_column
from typing import Optional, Dict, Any
from datetime import datetime

from app.db.base import AppBase

class ShareDraft(AppBase):
    __tablename__ = 'share_drafts'

    owner_id: Mapped[str] = mapped_column(String(36), ForeignKey('users.id'), index=True)
    step: Mapped[int] = mapped_column(Integer, default=1)
    data: Mapped[Dict[str, Any]] = mapped_column(JSON, default=dict)
    document_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('documents.id'), nullable=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime)
    idempotency_key: Mapped[Optional[str]] = mapped_column(String(64), unique=True, nullable=True)
