"""Database models package — registers all models with SQLAlchemy Base."""
from app.models.user import User
from app.models.role import Role, Permission, user_roles, role_permissions
from app.models.auth import PasswordReset, LoginHistory, PasswordResetToken
from app.models.otp import OtpChallenge
from app.models.device import Device
from app.models.session import UserSession
from app.models.document import Document
from app.models.document_version import DocumentVersion
from app.models.document_metadata import DocumentMetadata
from app.models.classification import Classification
DocumentClassification = Classification
from app.models.processing_job import ProcessingJob
from app.models.encryption_key import EncryptionKey
from app.models.signature import Signature
DocumentSignature = Signature
from app.models.secure_link import SecureLink
from app.models.link_policy import LinkPolicy
from app.models.recipient import Recipient
ShareRecipient = Recipient
from app.models.access_policy import AccessPolicy
from app.models.access_request import AccessRequest
from app.models.access_grant import AccessGrant
from app.models.access_attempt import AccessAttempt
from app.models.risk import RiskAssessment
from app.models.behaviour_profile import BehaviourProfile
from app.models.security_event import SecurityEvent
from app.models.security_alert import SecurityAlert
from app.models.audit import AuditLog
from app.models.dlp_finding import DLPFinding
DlpFinding = DLPFinding
from app.models.watermark_record import WatermarkRecord
from app.models.notification import Notification
from app.models.usage_metric import UsageMetric
from app.models.system_setting import SystemSetting
from app.models.subscription import Subscription
from app.models.download import Download
DownloadRecord = Download
from app.models.view_session import ViewSession
from app.models.folder import Folder
from app.models.tag import Tag, document_tags
from app.models.share_draft import ShareDraft
from app.models.oauth_account import OAuthAccount
from app.models.user_preference import UserPreference

__all__ = [
    "User",
    "Role",
    "Permission",
    "user_roles",
    "role_permissions",
    "OtpChallenge",
    "PasswordReset",
    "LoginHistory",
    "PasswordResetToken",
    "Device",
    "UserSession",
    "Document",
    "DocumentVersion",
    "DocumentMetadata",
    "Classification",
    "DocumentClassification",
    "ProcessingJob",
    "EncryptionKey",
    "Signature",
    "DocumentSignature",
    "SecureLink",
    "LinkPolicy",
    "Recipient",
    "ShareRecipient",
    "AccessPolicy",
    "AccessRequest",
    "AccessGrant",
    "AccessAttempt",
    "RiskAssessment",
    "BehaviourProfile",
    "SecurityEvent",
    "SecurityAlert",
    "AuditLog",
    "DLPFinding",
    "DlpFinding",
    "WatermarkRecord",
    "Notification",
    "UsageMetric",
    "SystemSetting",
    "Subscription",
    "Download",
    "DownloadRecord",
    "ViewSession",
    "Folder",
    "Tag",
    "document_tags",
    "ShareDraft",
    "OAuthAccount",
    "UserPreference",
]
