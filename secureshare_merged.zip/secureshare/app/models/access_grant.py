from __future__ import annotations
from datetime import datetime
from typing import Optional
from sqlalchemy import String, JSON, DateTime, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import AppBase

class AccessGrant(AppBase):
    __tablename__ = 'access_grants'

    document_id: Mapped[str] = mapped_column(String(36), ForeignKey('documents.id'), index=True)
    grantee_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('users.id'), nullable=True)
    link_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('secure_links.id'), nullable=True)
    granted_by: Mapped[str] = mapped_column(String(36), ForeignKey('users.id'))
    permissions: Mapped[list] = mapped_column(JSON, default=list)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    revoked_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    revoke_reason: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
