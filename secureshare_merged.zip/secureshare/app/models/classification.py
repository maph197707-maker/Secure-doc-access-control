from __future__ import annotations
from sqlalchemy import String, ForeignKey, Float, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import Optional, List, Any

from app.db.base import AppBase

class Classification(AppBase):
    __tablename__ = 'classifications'

    document_id: Mapped[str] = mapped_column(String(36), ForeignKey('documents.id'), unique=True, index=True)
    label: Mapped[str] = mapped_column(String(30), default='INTERNAL')
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    method: Mapped[str] = mapped_column(String(20), default='rule_based')
    reasons: Mapped[Optional[List[str]]] = mapped_column(JSON, nullable=True)
    classified_by: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('users.id'), nullable=True)

    document: Mapped["Document"] = relationship("Document")
