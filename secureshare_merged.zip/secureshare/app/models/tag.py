from __future__ import annotations
from sqlalchemy import Table, Column, String, ForeignKey, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import List

from app.db.base import AppBase

document_tags = Table(
    'document_tags',
    AppBase.metadata,
    Column('document_id', String(36), ForeignKey('documents.id'), primary_key=True),
    Column('tag_id', String(36), ForeignKey('tags.id'), primary_key=True)
)

class Tag(AppBase):
    __tablename__ = 'tags'

    owner_id: Mapped[str] = mapped_column(String(36), ForeignKey('users.id'), index=True)
    name: Mapped[str] = mapped_column(String(100))

    __table_args__ = (
        UniqueConstraint('owner_id', 'name'),
    )

    documents: Mapped[List["Document"]] = relationship(
        "Document",
        secondary=document_tags,
        back_populates="tags"
    )
