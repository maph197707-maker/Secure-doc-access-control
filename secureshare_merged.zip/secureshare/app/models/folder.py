from __future__ import annotations
from sqlalchemy import String, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import List, Optional

from app.db.base import AppBase, SoftDeleteMixin

class Folder(AppBase, SoftDeleteMixin):
    __tablename__ = 'folders'

    owner_id: Mapped[str] = mapped_column(String(36), ForeignKey('users.id'), index=True)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    parent_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('folders.id'), nullable=True)

    owner: Mapped["User"] = relationship("User")
    children: Mapped[List["Folder"]] = relationship("Folder", back_populates="parent")
    parent: Mapped[Optional["Folder"]] = relationship("Folder", back_populates="children", remote_side="Folder.id")
    documents: Mapped[List["Document"]] = relationship("Document", back_populates="folder")
