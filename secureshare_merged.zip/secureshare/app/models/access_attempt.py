from __future__ import annotations
from typing import Optional
from sqlalchemy import String, Boolean, Float, JSON, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import AppBase

class AccessAttempt(AppBase):
    __tablename__ = 'access_attempts'

    link_id: Mapped[str] = mapped_column(String(36), ForeignKey('secure_links.id'), index=True)
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    user_agent: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    device_fingerprint: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    email_presented: Mapped[Optional[str]] = mapped_column(String(320), nullable=True)
    decision: Mapped[str] = mapped_column(String(20), default='DENY')
    deny_reasons: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)
    risk_score: Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    step_up_required: Mapped[bool] = mapped_column(Boolean, default=False)
    password_correct: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    otp_correct: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
