from __future__ import annotations
from datetime import datetime
from sqlalchemy import String, Boolean, Integer, Float, DateTime, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import AppBase, SoftDeleteMixin
from app.models.role import user_roles

class User(AppBase, SoftDeleteMixin):
    __tablename__ = 'users'
    
    email: Mapped[str] = mapped_column(String(320), unique=True, nullable=False, index=True)
    full_name: Mapped[str] = mapped_column(String(255), nullable=False)
    phone: Mapped[str | None] = mapped_column(String(30), nullable=True)
    phone_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    status: Mapped[str] = mapped_column(String(50), default='PENDING_VERIFICATION', nullable=False)
    email_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    failed_login_count: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    department: Mapped[str | None] = mapped_column(String(100), nullable=True)
    trust_score: Mapped[float] = mapped_column(Float, default=1.0)
    mfa_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    # Authenticator-app secret, stored ENCRYPTED (AES-256-GCM, see services/mfa.seal_secret); never plaintext.
    totp_secret: Mapped[str | None] = mapped_column(String(255), nullable=True)
    # Salted hashes of the single-use recovery codes (the plain codes are shown once, then discarded).
    recovery_codes: Mapped[list | None] = mapped_column(JSON, nullable=True)
    is_superuser: Mapped[bool] = mapped_column(Boolean, default=False)
    avatar_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    
    roles: Mapped[list['Role']] = relationship(secondary=user_roles, back_populates='users', lazy='selectin')
    sessions: Mapped[list['UserSession']] = relationship(back_populates='user', lazy='select')
    devices: Mapped[list['Device']] = relationship(back_populates='user', lazy='select')
    notifications: Mapped[list['Notification']] = relationship(back_populates='user', lazy='select')
    oauth_accounts: Mapped[list['OAuthAccount']] = relationship(back_populates='user', lazy='select')
    preference: Mapped['UserPreference'] = relationship(back_populates='user', uselist=False, lazy='selectin')

    @property
    def is_active(self) -> bool:
        return self.status == 'ACTIVE' and not self.is_deleted

    @property 
    def is_locked(self) -> bool:
        return self.locked_until is not None and self.locked_until > datetime.utcnow()

    @property
    def is_admin(self) -> bool:
        return self.is_superuser or any(r.name == 'ADMIN' for r in self.roles)

    @property
    def role(self) -> str:
        """Highest role name. Several API modules compare `user.role`; User only had a `roles`
        list, so those checks raised AttributeError for every non-owner request."""
        if self.is_admin:
            return 'ADMIN'
        names = {r.name for r in self.roles}
        return 'MANAGER' if 'MANAGER' in names else 'USER'

    def has_permission(self, code: str) -> bool:
        for role in self.roles:
            if any(p.code == code for p in role.permissions):
                return True
        return False
