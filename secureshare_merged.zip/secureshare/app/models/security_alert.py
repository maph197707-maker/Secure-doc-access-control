from __future__ import annotations
from datetime import datetime
from typing import Optional
from sqlalchemy import String, Boolean, Text, DateTime, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import AppBase

class SecurityAlert(AppBase):
    __tablename__ = 'security_alerts'

    alert_type: Mapped[str] = mapped_column(String(100))
    severity: Mapped[str] = mapped_column(String(20), default='LOW')
    user_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('users.id'), nullable=True)
    document_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('documents.id'), nullable=True)
    link_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('secure_links.id'), nullable=True)
    message: Mapped[str] = mapped_column(Text)
    acknowledged: Mapped[bool] = mapped_column(Boolean, default=False)
    acknowledged_by: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('users.id'), nullable=True)
    acknowledged_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
