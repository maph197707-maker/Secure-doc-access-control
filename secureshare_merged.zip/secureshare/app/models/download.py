from __future__ import annotations
from sqlalchemy import String, ForeignKey, Integer
from sqlalchemy.orm import Mapped, mapped_column
from typing import Optional

from app.db.base import AppBase

class Download(AppBase):
    __tablename__ = 'downloads'

    document_id: Mapped[str] = mapped_column(String(36), ForeignKey('documents.id'), index=True)
    version_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    link_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    user_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('users.id'), index=True, nullable=True)
    recipient_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    user_agent: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    size_bytes: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
