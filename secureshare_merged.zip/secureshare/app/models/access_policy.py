from __future__ import annotations
from typing import Optional
from sqlalchemy import String, Boolean, Integer, Text, JSON, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import AppBase

class AccessPolicy(AppBase):
    __tablename__ = 'access_policies'

    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    document_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('documents.id'), nullable=True)
    owner_id: Mapped[str] = mapped_column(String(36), ForeignKey('users.id'))
    rules: Mapped[list] = mapped_column(JSON, default=list)
    priority: Mapped[int] = mapped_column(Integer, default=0)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
