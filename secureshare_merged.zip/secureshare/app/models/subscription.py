from __future__ import annotations
from datetime import datetime
from typing import Optional, TYPE_CHECKING
from sqlalchemy import String, DateTime, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import AppBase, _now

if TYPE_CHECKING:
    from app.models.user import User

class Subscription(AppBase):
    __tablename__ = 'subscriptions'

    user_id: Mapped[str] = mapped_column(String(36), ForeignKey('users.id'), unique=True, index=True)
    plan: Mapped[str] = mapped_column(String(50), default='FREE')
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    started_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    user: Mapped['User'] = relationship('User')
