"""One-time-code challenge: the server-side record behind every email / SMS verification.

Only an HMAC of the code is stored (never the code, never the raw destination). The row carries the
expiry, attempt counter, resend cooldown and status, so every verification decision is made from
persisted state and survives restarts and multiple workers.
"""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Index, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import AppBase

# Status values (strings, so the column stays portable across SQLite / PostgreSQL).
PENDING, VERIFIED, LOCKED, EXPIRED, SUPERSEDED, DELIVERY_FAILED = (
    "PENDING", "VERIFIED", "LOCKED", "EXPIRED", "SUPERSEDED", "DELIVERY_FAILED")


class OtpChallenge(AppBase):
    __tablename__ = "otp_challenges"
    __table_args__ = (
        Index("ix_otp_lookup", "purpose", "subject", "destination_hash", "created_at"),
        Index("ix_otp_dest_created", "destination_hash", "created_at"),
    )

    purpose: Mapped[str] = mapped_column(String(32), nullable=False)          # EMAIL_VERIFY, PHONE_VERIFY, ...
    channel: Mapped[str] = mapped_column(String(8), nullable=False)           # email | sms
    subject: Mapped[str] = mapped_column(String(100), nullable=False, index=True)   # user id, or link:recipient
    destination_hash: Mapped[str] = mapped_column(String(64), nullable=False)  # HMAC(address|number)
    destination_hint: Mapped[str] = mapped_column(String(80), nullable=False)  # masked, for audit/UI only
    otp_hash: Mapped[str] = mapped_column(String(64), nullable=False)          # HMAC(challenge id : code)
    status: Mapped[str] = mapped_column(String(16), nullable=False, default=PENDING)
    expires_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    attempt_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, nullable=False)
    resend_available_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)  # set only after the provider accepted it
    verified_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
