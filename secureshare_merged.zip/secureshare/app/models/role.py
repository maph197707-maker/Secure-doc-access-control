from __future__ import annotations
from sqlalchemy import Table, Column, String, Boolean, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import AppBase

user_roles = Table(
    'user_roles',
    AppBase.metadata,
    Column('user_id', String(36), ForeignKey('users.id'), primary_key=True),
    Column('role_id', String(36), ForeignKey('roles.id'), primary_key=True)
)

role_permissions = Table(
    'role_permissions',
    AppBase.metadata,
    Column('role_id', String(36), ForeignKey('roles.id'), primary_key=True),
    Column('permission_id', String(36), ForeignKey('permissions.id'), primary_key=True)
)

class Role(AppBase):
    __tablename__ = 'roles'
    name: Mapped[str] = mapped_column(String(50), unique=True, nullable=False, index=True)
    description: Mapped[str | None] = mapped_column(String(500), nullable=True)
    is_system: Mapped[bool] = mapped_column(Boolean, default=True)

    permissions: Mapped[list['Permission']] = relationship(secondary=role_permissions, back_populates='roles', lazy='selectin')
    users: Mapped[list['User']] = relationship(secondary=user_roles, back_populates='roles', lazy='select')

class Permission(AppBase):
    __tablename__ = 'permissions'
    code: Mapped[str] = mapped_column(String(100), unique=True, nullable=False, index=True)
    description: Mapped[str | None] = mapped_column(String(500), nullable=True)
    resource: Mapped[str | None] = mapped_column(String(100), nullable=True)

    roles: Mapped[list['Role']] = relationship(secondary=role_permissions, back_populates='permissions', lazy='selectin')
