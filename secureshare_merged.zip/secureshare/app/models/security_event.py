from __future__ import annotations
from typing import Optional
from sqlalchemy import String, JSON, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import AppBase

class SecurityEvent(AppBase):
    __tablename__ = 'security_events'

    event_type: Mapped[str] = mapped_column(String(100), index=True)
    severity: Mapped[str] = mapped_column(String(20), default='LOW')
    user_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('users.id'), nullable=True, index=True)
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    details: Mapped[dict] = mapped_column(JSON, default=dict)
