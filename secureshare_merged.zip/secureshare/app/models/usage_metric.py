from __future__ import annotations
from datetime import datetime
from typing import Optional
from sqlalchemy import String, Float, JSON, DateTime, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import AppBase, _now

class UsageMetric(AppBase):
    __tablename__ = 'usage_metrics'

    user_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey('users.id'), nullable=True, index=True)
    metric_name: Mapped[str] = mapped_column(String(100), index=True)
    metric_value: Mapped[float] = mapped_column(Float)
    dimensions: Mapped[dict] = mapped_column(JSON, default=dict)
    recorded_at: Mapped[datetime] = mapped_column(DateTime, default=_now, index=True)
