from __future__ import annotations
from datetime import datetime
from sqlalchemy import String, DateTime, ForeignKey, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import AppBase

class Device(AppBase):
    __tablename__ = 'devices'
    
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey('users.id'), index=True, nullable=False)
    device_fingerprint: Mapped[str] = mapped_column(String(255), index=True, nullable=False)
    name: Mapped[str | None] = mapped_column(String(100), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(500), nullable=True)
    ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)
    trust: Mapped[str] = mapped_column(String(20), default='UNKNOWN', nullable=False)
    registered_at: Mapped[datetime] = mapped_column(DateTime, default=func.now(), nullable=False)
    last_seen_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    webauthn_credential_id: Mapped[str | None] = mapped_column(String(500), nullable=True)
    
    user: Mapped['User'] = relationship(back_populates='devices')
