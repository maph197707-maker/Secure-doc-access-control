from __future__ import annotations
from datetime import datetime
from typing import Optional, TYPE_CHECKING
from sqlalchemy import String, Boolean, Integer, DateTime, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import AppBase

if TYPE_CHECKING:
    from app.models.document import Document
    from app.models.user import User
    from app.models.recipient import Recipient
    from app.models.access_attempt import AccessAttempt
    from app.models.link_policy import LinkPolicy

class SecureLink(AppBase):
    __tablename__ = 'secure_links'

    document_id: Mapped[str] = mapped_column(String(36), ForeignKey('documents.id'), index=True)
    created_by: Mapped[str] = mapped_column(String(36), ForeignKey('users.id'), index=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    token_prefix: Mapped[str] = mapped_column(String(12))
    status: Mapped[str] = mapped_column(String(20), default='ACTIVE')
    reputation: Mapped[str] = mapped_column(String(20), default='NORMAL')
    password_hash: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    requires_mfa: Mapped[bool] = mapped_column(Boolean, default=False)
    binding_mode: Mapped[str] = mapped_column(String(30), default='NONE')
    device_binding_required: Mapped[bool] = mapped_column(Boolean, default=False)
    max_views: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    views_remaining: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    max_downloads: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    downloads_remaining: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    one_time_view: Mapped[bool] = mapped_column(Boolean, default=False)
    one_time_download: Mapped[bool] = mapped_column(Boolean, default=False)
    allow_downloads: Mapped[bool] = mapped_column(Boolean, default=True)
    allow_print: Mapped[bool] = mapped_column(Boolean, default=False)
    allow_copy: Mapped[bool] = mapped_column(Boolean, default=False)
    watermark_forced: Mapped[bool] = mapped_column(Boolean, default=True)
    valid_from: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    self_destruct: Mapped[bool] = mapped_column(Boolean, default=False)
    self_destruct_after_views: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    view_count: Mapped[int] = mapped_column(Integer, default=0)
    download_count: Mapped[int] = mapped_column(Integer, default=0)
    last_accessed_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    revoked_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    revoke_reason: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)

    document: Mapped['Document'] = relationship('Document', back_populates='secure_links')
    creator: Mapped['User'] = relationship('User')
    recipients: Mapped[list['Recipient']] = relationship('Recipient', back_populates='link')
    access_attempts: Mapped[list['AccessAttempt']] = relationship('AccessAttempt')
    policy: Mapped[Optional['LinkPolicy']] = relationship('LinkPolicy', back_populates='link', uselist=False)
