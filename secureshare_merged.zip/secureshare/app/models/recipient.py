from __future__ import annotations
from datetime import datetime
from typing import Optional, TYPE_CHECKING
from sqlalchemy import String, Boolean, Float, DateTime, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import AppBase

if TYPE_CHECKING:
    from app.models.secure_link import SecureLink

class Recipient(AppBase):
    __tablename__ = 'recipients'

    link_id: Mapped[str] = mapped_column(String(36), ForeignKey('secure_links.id'), index=True)
    email: Mapped[str] = mapped_column(String(320), index=True)
    phone: Mapped[Optional[str]] = mapped_column(String(30), nullable=True)
    email_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    otp_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    phone_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    device_fingerprint: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    passkey_credential_id: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    identity_confidence: Mapped[float] = mapped_column(Float, default=0.0)
    bound_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    link: Mapped['SecureLink'] = relationship('SecureLink', back_populates='recipients')
