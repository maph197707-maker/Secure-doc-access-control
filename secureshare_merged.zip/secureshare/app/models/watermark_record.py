from __future__ import annotations
from sqlalchemy import String, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column
from typing import Optional

from app.db.base import AppBase

class WatermarkRecord(AppBase):
    __tablename__ = 'watermark_records'

    document_id: Mapped[str] = mapped_column(String(36), ForeignKey('documents.id'), index=True)
    link_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    recipient_email: Mapped[Optional[str]] = mapped_column(String(320), nullable=True)
    watermark_text: Mapped[str] = mapped_column(String(500))
    session_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
