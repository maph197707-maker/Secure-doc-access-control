from __future__ import annotations
from sqlalchemy import String, ForeignKey, Integer, Text, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import Optional, Any, Dict

from app.db.base import AppBase

class DocumentMetadata(AppBase):
    __tablename__ = 'document_metadata'

    document_id: Mapped[str] = mapped_column(String(36), ForeignKey('documents.id'), unique=True, index=True)
    extracted_text: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    page_count: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    word_count: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    author: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    title: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    subject: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    extra: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSON, nullable=True)

    document: Mapped["Document"] = relationship("Document", back_populates="metadata_")
