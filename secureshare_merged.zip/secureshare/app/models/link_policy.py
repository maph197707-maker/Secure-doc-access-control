from __future__ import annotations
from typing import Optional, TYPE_CHECKING
from sqlalchemy import String, Boolean, Float, JSON, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.db.base import AppBase

if TYPE_CHECKING:
    from app.models.secure_link import SecureLink

class LinkPolicy(AppBase):
    __tablename__ = 'link_policies'

    link_id: Mapped[str] = mapped_column(String(36), ForeignKey('secure_links.id'), unique=True, index=True)
    allowed_countries: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)
    blocked_countries: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)
    allowed_ips: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)
    blocked_ips: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)
    allowed_time_start: Mapped[Optional[str]] = mapped_column(String(5), nullable=True)
    allowed_time_end: Mapped[Optional[str]] = mapped_column(String(5), nullable=True)
    allowed_days: Mapped[Optional[list]] = mapped_column(JSON, nullable=True)
    risk_threshold: Mapped[float] = mapped_column(Float, default=0.7)
    require_fresh_auth: Mapped[bool] = mapped_column(Boolean, default=False)

    link: Mapped['SecureLink'] = relationship('SecureLink', back_populates='policy')
