from __future__ import annotations
from sqlalchemy import String, ForeignKey, Integer
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import Optional

from app.db.base import AppBase

class DLPFinding(AppBase):
    __tablename__ = 'dlp_findings'

    document_id: Mapped[str] = mapped_column(String(36), ForeignKey('documents.id'), index=True)
    version_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    rule_name: Mapped[str] = mapped_column(String(100))
    category: Mapped[str] = mapped_column(String(50))
    severity: Mapped[str] = mapped_column(String(20), default='LOW')
    match_count: Mapped[int] = mapped_column(Integer, default=1)
    sample_masked: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    action_taken: Mapped[str] = mapped_column(String(20), default='WARN')

    document: Mapped["Document"] = relationship("Document", back_populates="dlp_findings")
