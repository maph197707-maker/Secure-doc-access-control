from __future__ import annotations
from sqlalchemy import String, ForeignKey, Integer, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import Optional

from app.db.base import AppBase, SoftDeleteMixin

class DocumentVersion(AppBase, SoftDeleteMixin):
    __tablename__ = 'document_versions'

    document_id: Mapped[str] = mapped_column(String(36), ForeignKey('documents.id'), index=True)
    version_number: Mapped[int] = mapped_column(Integer, nullable=False)
    created_by: Mapped[str] = mapped_column(String(36), ForeignKey('users.id'))
    size_bytes: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    sha256: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    sha3_256: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    storage_path: Mapped[str] = mapped_column(String(1000))
    wrapped_dek: Mapped[str] = mapped_column(Text)
    key_reference: Mapped[str] = mapped_column(String(255))
    key_version: Mapped[str] = mapped_column(String(50))
    encryption_algorithm: Mapped[str] = mapped_column(String(30), default='AES_256_GCM')
    nonce_prefix: Mapped[str] = mapped_column(String(32))
    signature_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    change_summary: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    __table_args__ = (
        UniqueConstraint('document_id', 'version_number'),
    )

    document: Mapped["Document"] = relationship("Document", back_populates="versions")
    creator: Mapped["User"] = relationship("User")
