from __future__ import annotations
from sqlalchemy import String, ForeignKey, Text, DateTime, Boolean
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import Optional
from datetime import datetime

from app.db.base import AppBase

class Signature(AppBase):
    __tablename__ = 'signatures'

    document_id: Mapped[str] = mapped_column(String(36), ForeignKey('documents.id'), index=True)
    version_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    algorithm: Mapped[str] = mapped_column(String(30), default='ED25519')
    signature_b64: Mapped[str] = mapped_column(Text)
    public_key_reference: Mapped[str] = mapped_column(String(255))
    signer_id: Mapped[str] = mapped_column(String(36), ForeignKey('users.id'))
    payload_sha256: Mapped[str] = mapped_column(String(64))
    verified_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    verify_result: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)

    document: Mapped["Document"] = relationship("Document", back_populates="signatures")
    signer: Mapped["User"] = relationship("User")
