"""FastAPI lifespan context manager — manages app startup and shutdown."""
from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncGenerator
from fastapi import FastAPI

from app.config.logging import logger, setup_logging
from app.config.settings import get_settings
from app.crypto.envelope import LocalDevelopmentKeyProvider
from app.db.session import create_tables, engine
from app.integrations.state import get_state_store
from app.integrations.storage import build_storage_service

_key_provider: LocalDevelopmentKeyProvider | None = None


def get_key_provider() -> LocalDevelopmentKeyProvider:
    global _key_provider
    if _key_provider is None:
        settings = get_settings()
        _key_provider = LocalDevelopmentKeyProvider(settings.master_secret.encode())
    return _key_provider


async def _schema_state() -> tuple[str | None, str | None]:
    """(current revision in the database, head revision shipped with the code)."""
    from sqlalchemy import text
    from app.services.db_status import migration_head
    current: str | None = None
    try:
        async with engine.connect() as conn:
            current = (await conn.execute(text("SELECT version_num FROM alembic_version"))).scalar_one_or_none()
    except Exception:  # noqa: BLE001 - no alembic_version table => never migrated
        current = None
    return current, migration_head()


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Startup and shutdown lifecycle for SecureShare."""
    settings = get_settings()
    setup_logging(level="DEBUG" if settings.debug else "INFO")
    logger.info("app_starting", app_name=settings.app_name, env=settings.app_env, mode=settings.app_mode)

    # 1. Ensure storage directories exist, and fail fast if the configured backend is unusable
    #    (e.g. STORAGE_BACKEND=s3 without boto3/credentials) instead of failing on first upload.
    settings.ensure_storage_dirs()
    build_storage_service(settings)

    # 2. Initialize StateStore
    get_state_store()

    # 3. Key provider. KMS_BACKEND=aws|vault must be configured and reachable-by-config; an unusable cloud KMS
    #    stops startup instead of silently falling back to the development key (a security downgrade).
    from app.integrations.kms import KmsUnavailable, build_kms
    try:
        build_kms(settings)
    except KmsUnavailable as exc:
        raise RuntimeError(f"KMS_BACKEND={settings.kms_backend!r} cannot start: {exc}. "
                           "Fix the configuration or use KMS_BACKEND=local_dev (development only).") from exc
    get_key_provider()

    # 4. Schema. Dev+SQLite: create tables directly. Everything else is managed by Alembic
    #    (`alembic upgrade head`, run by deploy/entrypoint.sh); production refuses to start on a
    #    missing or outdated schema.
    if settings.is_dev and settings.database_url.startswith("sqlite"):
        try:
            await create_tables()
        except Exception as e:
            logger.warning("create_tables_warning", error=str(e))
    else:
        current, head = await _schema_state()
        if head and current != head:
            msg = f"database schema is {current or 'not initialised'}, expected {head}: run `alembic upgrade head`"
            if settings.is_production or settings.app_env == "staging":
                raise RuntimeError(msg)
            logger.warning("schema_not_current", detail=msg)

    # 4b. Roles + permissions must exist before the first sign-up / guest login (idempotent upsert).
    #     Without them a fresh install creates role-less users.
    try:
        from scripts.seed_roles import seed_roles
        await seed_roles()
    except Exception as e:                      # schema not migrated yet etc.: reported, never hidden
        if settings.is_production or settings.app_env == "staging":
            raise
        logger.warning("seed_roles_failed", error=str(e))

    # 5. One-time-code delivery: report (never fake) what is configured, and drop long-dead challenges.
    logger.info("otp_delivery_config", email_configured=settings.email_configured, sms_configured=settings.sms_configured)
    if not settings.email_configured:
        logger.warning("email_not_configured",
                       detail="Email codes cannot be sent until SMTP_HOST, SMTP_USER and SMTP_PASSWORD are set; "
                              "sign-up and guest login still work, and email verification stays unavailable.")
    try:
        from app.db.session import AsyncSessionLocal
        from app.services.otp import OtpService
        async with AsyncSessionLocal() as session:
            purged = await OtpService(session, settings).purge()
            await session.commit()
        if purged:
            logger.info("otp_challenges_purged", count=purged)
    except Exception as e:  # noqa: BLE001 - housekeeping must never block startup (e.g. table not migrated yet)
        logger.warning("otp_purge_skipped", error=type(e).__name__)

    yield

    # Shutdown
    logger.info("app_shutting_down")
    await engine.dispose()
