"""Every page/API route templates may link to (v3 spec section 8). `{param}` matches one path segment.
The template audit test fails on any internal link not listed here, and the route-shadowing test
asserts static paths are registered before parametrised ones."""
from __future__ import annotations

import re

PUBLIC = ["/", "/welcome", "/login", "/guest-login", "/logout", "/register", "/forgot-password", "/reset-password",
          "/oauth/{provider}", "/oauth/{provider}/callback", "/verify-email", "/verify-identity", "/mfa", "/passkey", "/share/{token}", "/viewer/{token}",
          "/verify", "/view/{token}", "/view/{token}/claim", "/view/{token}/code", "/view/{token}/content", "/view/{token}/download", "/security", "/about", "/privacy", "/terms"]
USER = ["/home", "/dashboard", "/documents", "/documents/upload", "/documents/{id}", "/documents/{id}/viewer",
        "/documents/{id}/download", "/documents/{id}/versions", "/documents/{id}/compare",
        "/documents/{id}/security", "/documents/{id}/share", "/documents/{id}/rename", "/documents/{id}/delete",
        "/documents/{id}/revoke-links", "/shares", "/shares/create", "/shares/{id}", "/shares/{id}/rotate",
        "/shares/{id}/revoke", "/verify-phone", "/shared-with-me", "/access-requests", "/signatures", "/signatures/verify",
        "/search", "/notifications", "/notifications/mark-all-read", "/security/devices", "/security/sessions",
        "/security/activity", "/security/audit", "/security/devices/{id}/revoke", "/security/sessions/{id}/revoke", "/security/sessions/revoke-others", "/security/risk", "/security/score", "/security/alerts",
        "/analytics", "/profile", "/profile/email/send", "/profile/email/verify", "/profile/phone/send", "/profile/phone/verify", "/settings/security", "/settings/security/mfa/start", "/settings/security/mfa/enable", "/settings/security/mfa/disable", "/settings/security/mfa/recovery", "/settings/privacy", "/settings/account",
        "/folders", "/folders/create", "/folders/{id}", "/folders/{id}/rename", "/folders/{id}/move", "/folders/{id}/delete",
        "/documents/{id}/move", "/access-requests/{id}/approve", "/access-requests/{id}/reject", "/security/alerts/{id}/acknowledge"]
ADMIN = ["/admin", "/admin/users", "/admin/database", "/admin/users/{id}", "/admin/users/{id}/suspend", "/admin/roles", "/admin/permissions", "/admin/documents",
         "/admin/links", "/admin/access", "/admin/policies", "/admin/security", "/admin/security-events",
         "/admin/risk", "/admin/devices", "/admin/sessions", "/admin/analytics", "/admin/usage",
         "/admin/audit", "/admin/attack-simulator", "/admin/system-health", "/admin/configuration",
         "/admin/backup", "/admin/reports"]
API = ["/api/v1/search", "/api/v1/notifications/unread-count", "/api/v1/documents/upload",
       "/api/v1/share/{token}/recheck", "/api/v1/shares/draft"]
ALL = PUBLIC + USER + ADMIN + API


def _regex(pattern: str) -> re.Pattern[str]:
    return re.compile("^" + re.sub(r"\\\{[^/]+?\\\}", "[^/?#]+", re.escape(pattern)) + "$")


_COMPILED = [_regex(p) for p in ALL]


def is_known_route(path: str) -> bool:
    path = path.split("?")[0].split("#")[0]
    return any(r.match(path) for r in _COMPILED)


def shadowed_static_routes(routes: list[str]) -> list[tuple[str, str]]:
    """Return (static, parametrised) pairs where the parametrised route is registered first."""
    bad = []
    for i, a in enumerate(routes):
        if "{" not in a:
            continue
        rx = _regex(a)
        bad += [(b, a) for b in routes[i + 1:] if "{" not in b and rx.match(b)]
    return bad
