"""Public secure-link redemption: /view/{token}.

This is what the recipient's device opens. Pipeline for every request:
token -> HMAC lookup -> status / expiry / not-before / document-exists -> password gate
(signed cookie, brute-force lockout) -> atomic view/download counter -> decrypt-stream -> audit.
Document bytes are only ever streamed from here, decrypted per request; nothing is public.
The token is opaque and random; only its keyed hash is stored, so a DB leak cannot rebuild links.
"""
from __future__ import annotations

import mimetypes
from typing import Annotated

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.integrations import factory
from app.integrations.email import EmailService
from app.integrations.sms import SMSService
from app.services.otp import OtpService
from app.integrations.state import get_state_store
from datetime import datetime, timezone

from app.core.enums import Decision, Permission
from app.services import link_access, otp, recipient_gate as gate
from app.services.risk import RiskEngine
from app.core.dependencies import get_client_ip, get_db, get_user_agent
from app.core.exceptions import NotFoundError, PermissionDeniedError
from app.middleware.csrf import get_csrf_token
from app.models.secure_link import SecureLink
from app.services.documents import DocumentService
from app.services.secure_links import SecureLinkService
from app.web.templating import build_env

router = APIRouter(tags=["share-links"])
env = build_env()
settings = get_settings()

# Only these may render inline in the browser (same list as the owner's viewer).
_INLINE_OK = {"application/pdf", "image/png", "image/jpeg", "image/gif", "image/webp", "text/plain"}
_NO_STORE = {"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff",
             "Referrer-Policy": "no-referrer"}


def _page(request: Request, name: str, status: int = 200, **ctx) -> HTMLResponse:
    html = env.get_template(name).render(csrf_token=get_csrf_token(request), **ctx)
    return HTMLResponse(html, status_code=status, headers=_NO_STORE)


def _error(request: Request, code: int, title: str, message: str) -> HTMLResponse:
    html = env.get_template("errors/error.html").render(
        code=code, title=title, message=message,
        request_id=getattr(request.state, "request_id", ""))
    return HTMLResponse(html, status_code=code, headers=_NO_STORE)


async def _open(request: Request, db: AsyncSession, token: str):
    """Resolve + validate. Returns (svc, link) or raises; denials are audited and committed."""
    svc = SecureLinkService(db)
    ip, ua = get_client_ip(request), get_user_agent(request)
    link = await svc.find(token)
    if link is None:
        await svc.log_denied(None, "unknown_token", ip, ua)
        await db.commit()
        raise NotFoundError("Secure link not found.")
    try:
        svc._check_link_validity(link)
    except (PermissionDeniedError, NotFoundError) as e:
        await svc.log_denied(link, e.message, ip, ua)
        await db.commit()
        raise
    return svc, link


@router.get("/view/{token}", response_class=HTMLResponse)
async def view_link(token: str, request: Request,
                    db: Annotated[AsyncSession, Depends(get_db)]) -> HTMLResponse:
    try:
        svc, link = await _open(request, db, token)
    except (NotFoundError, PermissionDeniedError) as e:
        return _error(request, 404 if isinstance(e, NotFoundError) else 403,
                      "Link unavailable", e.message)
    unlocked = svc.unlock_valid(link, request.cookies.get(svc.unlock_cookie_name(link)))
    if not unlocked:
        return _page(request, "public/share_gate.html", token=token, password_required=True, error=None)
    if await _recipient_needed(svc, link, request):
        return _recipient_page(request, link, token, "claim")
    doc = link.document
    return _page(request, "public/link_open.html", token=token, link=link,
                 doc_name=doc.display_name or doc.original_filename, size=doc.size_bytes or 0,
                 can_download=bool(link.allow_downloads and
                                   (link.downloads_remaining is None or link.downloads_remaining > 0)))


@router.post("/view/{token}", response_class=HTMLResponse)
async def unlock_link(token: str, request: Request,
                      db: Annotated[AsyncSession, Depends(get_db)],
                      password: str = Form("")):
    try:
        svc, link = await _open(request, db, token)
    except (NotFoundError, PermissionDeniedError) as e:
        return _error(request, 404 if isinstance(e, NotFoundError) else 403,
                      "Link unavailable", e.message)
    ip, ua = get_client_ip(request), get_user_agent(request)
    try:
        ok = await svc.check_password(link, password, ip, ua)
    except PermissionDeniedError as e:
        await db.commit()                      # keep the lockout audit row
        return _page(request, "public/share_gate.html", 429, token=token,
                     password_required=True, error=e.message)
    await db.commit()                          # keep the failure audit row
    if not ok:
        return _page(request, "public/share_gate.html", 401, token=token,
                     password_required=True, error="Incorrect password.")
    resp = RedirectResponse(f"/view/{token}", status_code=303)
    resp.set_cookie(svc.unlock_cookie_name(link), svc.issue_unlock(link), httponly=True,
                    samesite="strict", secure=settings.cookie_secure,
                    max_age=svc.UNLOCK_TTL, path=f"/view/{token}")
    return resp


# ── recipient-bound links ────────────────────────────────────────────────────
def _services() -> tuple[EmailService | None, SMSService | None]:
    """Delivery providers from settings; an unconfigured one is simply unavailable (None)."""
    return factory.get_email_service(), factory.get_sms_service()


def _via(link: SecureLink) -> str:
    return "phone" if link.binding_mode == gate.MODE_PHONE else "email"


async def _recipient_needed(svc: SecureLinkService, link: SecureLink, request: Request) -> bool:
    """True when the link is recipient-bound and this browser has no valid verified session.
    The session is signed over (link, recipient, expiry, browser fingerprint), so a cookie copied to
    another browser/user is rejected."""
    if link.binding_mode not in gate.BOUND_MODES:
        return False
    rid = gate.session_recipient(svc.master_key, link.id, request.cookies.get(svc.recipient_cookie_name(link)),
                                 binding=gate.client_binding(get_user_agent(request)))
    if rid is None:
        return True
    return rid not in {r.id for r in await svc.recipient_refs(link)}     # recipient removed since


def _recipient_page(request: Request, link: SecureLink, token: str, stage: str, status: int = 200,
                    error: str | None = None, notice: str | None = None, pending: str = "", email: str = ""):
    return _page(request, "public/recipient_verify.html", status, token=token, stage=stage, via=_via(link),
                 error=error, notice=notice, pending=pending, email=email)


@router.post("/view/{token}/claim", response_class=HTMLResponse)
async def claim_link(token: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                     email: str = Form("")):
    try:
        svc, link = await _open(request, db, token)
    except (NotFoundError, PermissionDeniedError) as e:
        return _error(request, 404 if isinstance(e, NotFoundError) else 403, "Link unavailable", e.message)
    ip, ua = get_client_ip(request), get_user_agent(request)
    if link.binding_mode not in gate.BOUND_MODES or not svc.unlock_valid(link, request.cookies.get(svc.unlock_cookie_name(link))):
        return RedirectResponse(f"/view/{token}", status_code=303)       # password comes first
    em, sms = _services()
    out = await gate.claim(OtpService(db), get_state_store(), link_id=link.id, mode=link.binding_mode, ip=ip or "-",
                     typed_email=email, recipients=await svc.recipient_refs(link),
                     master=svc.master_key, email=em, sms=sms, user_agent=ua)
    await svc.audit_repo.log_event(
        action="SECURE_LINK_RECIPIENT_CLAIM", resource_type="secure_link", resource_id=link.id,
        ip_address=ip, user_agent=ua,
        details={"matched": out.pending is not None, "delivered": out.delivered, "via": _via(link)})
    await db.commit()
    if out.status is gate.ClaimStatus.THROTTLED:
        return _recipient_page(request, link, token, "claim", 429, error=out.message, email=email)
    return _recipient_page(request, link, token, "code", notice=out.message, pending=out.pending or "")


@router.post("/view/{token}/code", response_class=HTMLResponse)
async def verify_link_code(token: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                           code: str = Form(""), pending: str = Form("")):
    try:
        svc, link = await _open(request, db, token)
    except (NotFoundError, PermissionDeniedError) as e:
        return _error(request, 404 if isinstance(e, NotFoundError) else 403, "Link unavailable", e.message)
    ip, ua = get_client_ip(request), get_user_agent(request)
    if link.binding_mode not in gate.BOUND_MODES or not svc.unlock_valid(link, request.cookies.get(svc.unlock_cookie_name(link))):
        return RedirectResponse(f"/view/{token}", status_code=303)
    rid = gate.read_pending(svc.master_key, link.id, pending)
    rec = next((r for r in await svc.recipient_refs(link) if r.id == rid), None) if rid else None
    if rec is None:      # no code was ever sent (non-matching email) or the form is stale/forged
        await svc.audit_repo.log_event(action="SECURE_LINK_RECIPIENT_CODE_FAIL", resource_type="secure_link",
                                       resource_id=link.id, ip_address=ip, user_agent=ua,
                                       details={"reason": "no_pending_claim"})
        await db.commit()
        return _recipient_page(request, link, token, "claim", 400,
                               error="That code is not valid. Enter your email to get a new one.")
    res = await gate.check_code(OtpService(db), link_id=link.id, mode=link.binding_mode, rec=rec, code=code,
                                ip=ip, user_agent=ua)
    if res is not otp.OtpResult.OK:
        await svc.audit_repo.log_event(action="SECURE_LINK_RECIPIENT_CODE_FAIL", resource_type="secure_link",
                                       resource_id=link.id, ip_address=ip, user_agent=ua,
                                       details={"reason": res.value.lower()})
        await db.commit()
        if res is otp.OtpResult.LOCKED:
            return _recipient_page(request, link, token, "claim", 429, error="Too many wrong codes. Request a new code.")
        if res is not otp.OtpResult.WRONG:      # expired, already used, or no active code
            return _recipient_page(request, link, token, "claim", 400,
                                   error="That code has expired or was already used. Request a new one.")
        return _recipient_page(request, link, token, "code", 401, error="Incorrect code.", pending=pending)
    await svc.mark_recipient_verified(link, rec.id, link.binding_mode)
    await svc.audit_repo.log_event(action="SECURE_LINK_RECIPIENT_VERIFIED", resource_type="secure_link",
                                   resource_id=link.id, ip_address=ip, user_agent=ua,
                                   details={"recipient_id": rec.id, "via": _via(link)})
    await db.commit()
    resp = RedirectResponse(f"/view/{token}", status_code=303)
    resp.set_cookie(svc.recipient_cookie_name(link), gate.issue_session(svc.master_key, link.id, rec.id,
                                                                      binding=gate.client_binding(ua)),
                    httponly=True, samesite="strict", secure=settings.cookie_secure,
                    max_age=gate.SESSION_TTL, path=f"/view/{token}")
    return resp


async def _deliver(token: str, request: Request, db: AsyncSession, kind: str):
    ip, ua = get_client_ip(request), get_user_agent(request)
    try:
        svc, link = await _open(request, db, token)
    except (NotFoundError, PermissionDeniedError) as e:
        return _error(request, 404 if isinstance(e, NotFoundError) else 403,
                      "Link unavailable", e.message)
    if not svc.unlock_valid(link, request.cookies.get(svc.unlock_cookie_name(link))):
        await svc.log_denied(link, "password_required", ip, ua)
        await db.commit()
        return RedirectResponse(f"/view/{token}", status_code=303)
    if await _recipient_needed(svc, link, request):
        await svc.log_denied(link, "recipient_not_verified", ip, ua)
        await db.commit()
        return RedirectResponse(f"/view/{token}", status_code=303)
    if kind == "download" and not link.allow_downloads:
        await svc.log_denied(link, "download_not_allowed", ip, ua)
        await db.commit()
        return _error(request, 403, "Download not allowed", "The owner disabled downloads for this link.")

    # Zero-Trust PDP: the final server-side decision. Risk comes from the RiskEngine over this link's /
    # this IP's real audit history. There is no default score: if the engine fails, risk is unknown
    # and is treated as CRITICAL (deny), never as low or medium.
    action = Permission.DOWNLOAD if kind == "download" else Permission.VIEW
    try:
        risk_score = int((await RiskEngine(db).evaluate_link(link.id, ip))["score"])
    except Exception:                                   # noqa: BLE001
        risk_score = 100
    decision = link_access.decide_link_access(
        link, link.document, action, datetime.now(timezone.utc).replace(tzinfo=None),
        recipient_verified=link.binding_mode in gate.BOUND_MODES, risk_score=risk_score,
        correlation_id=getattr(request.state, "request_id", ""))
    allowed, why = link_access.enforce(decision, action)
    if not allowed:
        await svc.audit_repo.log_event(
            action="SECURE_LINK_DENIED", resource_type="secure_link", resource_id=link.id, ip_address=ip,
            user_agent=ua, details={"reason": "pdp", "decision": decision.decision.value,
                                    "reasons": decision.reasons, "risk_score": risk_score})
        await db.commit()
        if decision.decision == Decision.VERIFY:
            return _error(request, 403, "Additional verification required",
                          "This link needs a verification step that is not available for it.")
        return _error(request, 403, "Access denied", "You do not have access to this document.")

    ok = await (svc.consume_download(link) if kind == "download" else svc.consume_view(link))
    if not ok:
        await svc.log_denied(link, f"{kind}_limit_reached", ip, ua)
        await db.commit()
        return _error(request, 403, "Limit reached", f"This link has no {kind}s left.")

    doc = link.document
    try:
        stream = await DocumentService(db).open_stream(doc)
    except (NotFoundError, PermissionDeniedError) as e:      # missing blob, or QUARANTINED by malware policy
        await db.rollback()                                    # un-consume the view/download counter
        return _error(request, 404 if isinstance(e, NotFoundError) else 403, "Document unavailable", e.message)
    await svc.audit_repo.log_event(
        action=f"SECURE_LINK_{kind.upper()}", resource_type="secure_link", resource_id=link.id,
        ip_address=ip, user_agent=ua,
        details={"document_id": doc.id, "decision": decision.decision.value, "risk_score": risk_score,
                 "restrictions": decision.restrictions})
    await db.commit()
    safe = (doc.original_filename or "document").replace('"', "").replace("\r", "").replace("\n", "")
    ctype = mimetypes.guess_type(doc.original_filename or "")[0] or "application/octet-stream"
    # VIEW renders in the browser only for types that are safe to render (the sandbox CSP keeps any
    # active content inert); everything else, and every DOWNLOAD, is delivered as an attachment.
    inline = kind == "view" and ctype in _INLINE_OK
    headers = {**_NO_STORE, "Content-Disposition": f'{"inline" if inline else "attachment"}; filename="{safe}"'}
    if inline:
        # `sandbox` keeps images/text inert; Chromium refuses to open its PDF viewer inside a sandbox, and
        # a PDF is rendered by the browser's own isolated viewer, so PDFs only get frame protection.
        headers["Content-Security-Policy"] = "frame-ancestors 'none'" if ctype == "application/pdf" else "sandbox"
    return StreamingResponse(stream, media_type=ctype if inline else "application/octet-stream", headers=headers)


@router.get("/view/{token}/content")
async def link_content(token: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    return await _deliver(token, request, db, "view")


@router.get("/view/{token}/download")
async def link_download(token: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    return await _deliver(token, request, db, "download")
