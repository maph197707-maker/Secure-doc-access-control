"""Public web routes for user authentication and onboarding."""
from __future__ import annotations

import asyncio
import secrets
from typing import Annotated
from urllib.parse import parse_qsl, quote, urlsplit
from fastapi import APIRouter, Depends, Form, Request, Response
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.constants import COOKIE_SESSION
from app.config.settings import get_settings
from app.core.dependencies import (
    extract_raw_token,
    get_client_ip,
    get_db,
    get_optional_user,
    get_user_agent,
)
from app.core.exceptions import (
    AuthenticationError,
    ConflictError,
    DeliveryError,
    LockoutError,
    MfaRequiredError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitExceededError,
    ValidationError,
)
from app.integrations import factory, oauth
from app.integrations.state import get_state_store
from app.core.utils import mask_email, safe_redirect_url
from app.middleware.csrf import get_csrf_token
from app.services.auth import AuthService
from app.services.sessions import SessionService
from app.web.templating import build_env

router = APIRouter(tags=["web-public"])
env = build_env()
settings = get_settings()


FEATURES = [
    ("shield", "End-to-End Encryption"),
    ("eye", "Zero-Trust Access Control"),
    ("cpu", "Threat Detection & Audit Trail"),
    ("users", "Recipient Verification"),
]
TOUR_STEPS = [
    "Upload and encrypt your sensitive documents",
    "Define fine-grained access policies and link expiration",
    "Deliver links bound to verified recipient identity",
    "Monitor real-time access and tamper-evident audit trails",
]


@router.get("/", response_class=HTMLResponse)
@router.get("/welcome", response_class=HTMLResponse)
async def landing_page(request: Request, db: Annotated[AsyncSession, Depends(get_db)]) -> HTMLResponse:
    session, user = await get_optional_user(request, db)
    if session and user:
        return RedirectResponse("/dashboard", status_code=302)

    csrf_tok = get_csrf_token(request)
    tpl = env.get_template("public/landing.html")
    html = tpl.render(
        csrf_token=csrf_tok,
        features=FEATURES,
        tour_steps=TOUR_STEPS,
        request_id=getattr(request.state, "request_id", ""),
    )
    return HTMLResponse(html)


@router.get("/login", response_class=HTMLResponse)
async def login_page(
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
    next: str | None = None,
) -> HTMLResponse:
    # If already logged in, redirect to dashboard or next
    session, user = await get_optional_user(request, db)
    if session and user:
        return RedirectResponse(safe_redirect_url(next, "/dashboard"), status_code=302)

    csrf_tok = get_csrf_token(request)
    tpl = env.get_template("auth/login.html")
    html = tpl.render(
        csrf_token=csrf_tok,
        email="",
        error=None,
        notice=("Password updated. Please sign in with your new password."
                if request.query_params.get("reset") == "success" else None),
        next=next,
        oauth={
            "google": settings.google_oauth_configured,
            "microsoft": settings.microsoft_oauth_configured,
        },
    )
    return HTMLResponse(html)


@router.post("/login", response_class=HTMLResponse)
async def login_submit(
    request: Request,
    response: Response,
    db: Annotated[AsyncSession, Depends(get_db)],
    email: str = Form(""),
    password: str = Form(""),
    next: str | None = Form(None),
) -> Response:
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    auth_svc = AuthService(db)
    csrf_tok = get_csrf_token(request)

    try:
        user, session, raw_token = await auth_svc.login(
            email=email,
            password=password,
            ip_address=ip,
            user_agent=ua,
        )
        await db.commit()

        target = safe_redirect_url(next, "/dashboard")
        redirect = RedirectResponse(url=target, status_code=303)
        redirect.set_cookie(
            key=COOKIE_SESSION,
            value=raw_token,
            httponly=True,
            secure=settings.cookie_secure,
            samesite="lax",
            max_age=settings.session_absolute_timeout,
            path="/",
        )
        return redirect

    except MfaRequiredError as e:
        # Password was right and this account turned two-factor on: no session yet, ask for the code.
        auth_svc.store.set(f"mfa:next:{e.challenge_id}", safe_redirect_url(next, "/dashboard"), 300)
        redirect = RedirectResponse(url="/mfa", status_code=303)
        redirect.set_cookie(key="ss_mfa", value=e.challenge_id, httponly=True, secure=settings.cookie_secure,
                            samesite="lax", max_age=300, path="/")
        return redirect

    except (AuthenticationError, LockoutError, PermissionDeniedError, ValidationError) as e:
        tpl = env.get_template("auth/login.html")
        html = tpl.render(
            csrf_token=csrf_tok,
            email=email,
            error=str(e),
            next=next,
            oauth={
                "google": settings.google_oauth_configured,
                "microsoft": settings.microsoft_oauth_configured,
            },
        )
        return HTMLResponse(html, status_code=400)


@router.post("/guest-login", response_class=HTMLResponse)
async def guest_login_submit(
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> Response:
    """Continue as guest: a temporary verified account, no registration or OTP."""
    auth_svc = AuthService(db)
    try:
        _user, _session, raw_token = await auth_svc.guest_login(
            ip_address=get_client_ip(request), user_agent=get_user_agent(request))
        await db.commit()
    except (PermissionDeniedError, RateLimitExceededError) as e:
        await db.rollback()
        tpl = env.get_template("auth/login.html")
        html = tpl.render(
            csrf_token=get_csrf_token(request), email="", error=str(e), next=None,
            oauth={"google": settings.google_oauth_configured, "microsoft": settings.microsoft_oauth_configured},
        )
        return HTMLResponse(html, status_code=403 if isinstance(e, PermissionDeniedError) else 429)
    redirect = RedirectResponse(url="/dashboard", status_code=303)
    redirect.set_cookie(
        key=COOKIE_SESSION, value=raw_token, httponly=True, secure=settings.cookie_secure,
        samesite="lax", max_age=settings.session_absolute_timeout, path="/",
    )
    return redirect


@router.get("/register", response_class=HTMLResponse)
async def register_page(request: Request) -> HTMLResponse:
    csrf_tok = get_csrf_token(request)
    tpl = env.get_template("auth/register.html")
    progress = [
        {"label": "Secure Registration", "state": "done"},
        {"label": "Verify email later in Profile", "state": "pending"},
        {"label": "Verify phone later in Profile", "state": "pending"},
        {"label": "MFA Ready", "state": "pending"},
    ]
    html = tpl.render(
        csrf_token=csrf_tok,
        values={},
        errors={},
        progress=progress,
        sms_available=factory.get_sms_service() is not None,
    )
    return HTMLResponse(html)


@router.post("/register", response_class=HTMLResponse)
async def register_submit(
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
    email: str = Form(""),
    password: str = Form(""),
    full_name: str = Form(""),
    phone: str | None = Form(None),
) -> Response:
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    auth_svc = AuthService(db)
    csrf_tok = get_csrf_token(request)
    progress = [
        {"label": "Secure Registration", "state": "done"},
        {"label": "Verify email later in Profile", "state": "pending"},
        {"label": "Verify phone later in Profile", "state": "pending"},
        {"label": "MFA Ready", "state": "pending"},
    ]

    try:
        user, delivery = await auth_svc.register(
            email=email,
            password=password,
            full_name=full_name,
            phone=phone,
            ip_address=ip,
            user_agent=ua,
        )
        if delivery is None:
            # Sign-up needs no email delivery: sign the new account straight in. Email and phone are
            # verified later from /profile.
            _u, _session, raw_token = await auth_svc.login(email=email, password=password, ip_address=ip,
                                                           user_agent=ua)
            await db.commit()
            redirect = RedirectResponse(url="/dashboard", status_code=303)
            redirect.set_cookie(
                key=COOKIE_SESSION, value=raw_token, httponly=True, secure=settings.cookie_secure,
                samesite="lax", max_age=settings.session_absolute_timeout, path="/",
            )
            return redirect
        await db.commit()
        return RedirectResponse(f"/verify-email?email={quote(email.strip().lower(), safe='')}", status_code=303)

    except (ConflictError, ValidationError, DeliveryError) as e:
        # Delivery failed: nothing was committed, the OTP was revoked, and we do NOT claim it was sent.
        await db.rollback()
        tpl = env.get_template("auth/register.html")
        errors = {"email" if isinstance(e, ConflictError) else
                  "form" if isinstance(e, DeliveryError) else "password": str(e)}
        html = tpl.render(
            csrf_token=csrf_tok,
            values={"email": email, "full_name": full_name, "phone": phone or ""},
            errors=errors,
            progress=progress,
            sms_available=factory.get_sms_service() is not None,
        )
        return HTMLResponse(html, status_code=e.status_code if isinstance(e, DeliveryError) else 400)


def _verify_page(csrf_tok: str, email: str, *, status: str = "pending", error: str | None = None,
                 notice: str | None = None, attempts_left: int = 5, cooldown: int = 30,
                 code: int = 200) -> HTMLResponse:
    tpl = env.get_template("auth/verify_email.html")
    html = tpl.render(
        csrf_token=csrf_tok,
        status=status,
        email=email,
        email_masked=mask_email(email) if email else "your email",
        error=error,
        notice=notice,
        attempts_left=attempts_left,
        cooldown=cooldown,
    )
    return HTMLResponse(html, status_code=code)


@router.get("/verify-email", response_class=HTMLResponse)
async def verify_email_page(
    request: Request,
    email: str = "",
) -> HTMLResponse:
    return _verify_page(get_csrf_token(request), email.strip().lower())


@router.post("/verify-email", response_class=HTMLResponse)
async def verify_email_submit(
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
    email: str = Form(""),
    code: str = Form(""),
    action: str = Form(""),
) -> Response:
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    auth_svc = AuthService(db)
    csrf_tok = get_csrf_token(request)
    email = email.strip().lower()

    # ── Resend: issue + DELIVER a new code. Never treated as a verification attempt. ──
    if action == "resend":
        try:
            delivery = await auth_svc.resend_email_verification(email=email, ip_address=ip, user_agent=ua)
            await db.commit()
            # Same wording whether or not the address has an unverified account (no enumeration).
            notice = (delivery.message if delivery else
                      "If an unverified account exists for this address, a new code has been sent.")
            return _verify_page(csrf_tok, email, notice=notice)
        except (ValidationError, RateLimitExceededError, DeliveryError) as e:
            await db.rollback()
            status = 429 if isinstance(e, RateLimitExceededError) else e.status_code if isinstance(e, DeliveryError) else 400
            return _verify_page(csrf_tok, email, error=str(e), cooldown=0 if status != 400 else 30, code=status)

    try:
        await auth_svc.verify_email(email=email, code=code, ip_address=ip, user_agent=ua)
        await db.commit()
        return _verify_page(csrf_tok, email, status="success", cooldown=0)

    except NotFoundError:
        # Unknown address: same answer as a wrong code, so this form cannot be used to probe accounts.
        return _verify_page(csrf_tok, email, error="Invalid verification code. Please check and try again.",
                            attempts_left=4, code=400)
    except (ValidationError, LockoutError) as e:
        return _verify_page(csrf_tok, email, error=str(e), attempts_left=4, code=400)


@router.get("/forgot-password", response_class=HTMLResponse)
async def forgot_password_page(request: Request) -> HTMLResponse:
    csrf_tok = get_csrf_token(request)
    tpl = env.get_template("auth/forgot_password.html")
    html = tpl.render(csrf_token=csrf_tok, sent=False)
    return HTMLResponse(html)


@router.post("/forgot-password", response_class=HTMLResponse)
async def forgot_password_submit(
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
    email: str = Form(""),
) -> HTMLResponse:
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    auth_svc = AuthService(db)
    csrf_tok = get_csrf_token(request)
    tpl = env.get_template("auth/forgot_password.html")

    try:
        await auth_svc.request_password_reset(email=email, ip_address=ip, user_agent=ua,
                                              base_url=_public_base(request))
        await db.commit()
    except (DeliveryError, ValidationError) as e:
        await db.rollback()
        return HTMLResponse(tpl.render(csrf_token=csrf_tok, sent=False, error=str(e)), status_code=e.status_code)
    return HTMLResponse(tpl.render(csrf_token=csrf_tok, sent=True, error=None))


@router.get("/reset-password", response_class=HTMLResponse)
async def reset_password_page(
    request: Request,
    token: str = "",
    email: str = "",
) -> HTMLResponse:
    csrf_tok = get_csrf_token(request)
    tpl = env.get_template("auth/reset_password.html")
    html = tpl.render(csrf_token=csrf_tok, reset_token=token, email=email, error=None)
    return HTMLResponse(html)


@router.post("/reset-password", response_class=HTMLResponse)
async def reset_password_submit(
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
    email: str = Form(""),
    reset_token: str = Form(""),
    new_password: str = Form(""),
    confirm: str = Form(""),
) -> Response:
    ip = get_client_ip(request)
    ua = get_user_agent(request)
    auth_svc = AuthService(db)
    csrf_tok = get_csrf_token(request)

    def _again(msg: str) -> HTMLResponse:
        html = env.get_template("auth/reset_password.html").render(
            csrf_token=csrf_tok, reset_token=reset_token, email=email, error=msg)
        return HTMLResponse(html, status_code=400)

    if new_password != confirm:
        return _again("The two passwords do not match.")
    try:
        await auth_svc.confirm_password_reset(
            email=email,
            raw_token=reset_token,
            new_password=new_password,
            ip_address=ip,
            user_agent=ua,
        )
        await db.commit()
        return RedirectResponse("/login?reset=success", status_code=303)

    except NotFoundError:
        await db.rollback()
        return _again("Password reset token is invalid or expired.")    # same text as a wrong token: no account probing
    except ValidationError as e:
        await db.rollback()
        return _again(str(e))


def _public_base(request: Request) -> str:
    return settings.public_base_url if "public_base_url" in settings.model_fields_set else str(request.base_url).rstrip("/")


COOKIE_OAUTH = "ss_oauth"


def _oauth_flags() -> dict[str, bool]:
    return {"google": settings.google_oauth_configured, "microsoft": settings.microsoft_oauth_configured}


def _oauth_error(request: Request, message: str, status: int) -> HTMLResponse:
    html = env.get_template("auth/login.html").render(
        csrf_token=get_csrf_token(request), email="", error=message, next=None, oauth=_oauth_flags())
    return HTMLResponse(html, status_code=status)


def _oauth_client(request: Request, name: str) -> oauth.OAuthClient:
    """Redirect URI = PUBLIC_BASE_URL when it is set explicitly, otherwise the host the browser used
    (so http://127.0.0.1:8000 and http://localhost:8000 both work). It must be registered, exactly, with
    the provider: <base>/oauth/<provider>/callback."""
    base = settings.public_base_url if "public_base_url" in settings.model_fields_set else str(request.base_url)
    creds = {"google": (settings.google_client_id, settings.google_client_secret),
             "microsoft": (settings.microsoft_client_id, settings.microsoft_client_secret)}[name]
    return oauth.OAuthClient(name, creds[0], creds[1], f"{base.rstrip('/')}/oauth/{name}/callback",
                             get_state_store(), oauth.default_transport())


@router.get("/oauth/{provider}", response_class=HTMLResponse)
async def oauth_start(provider: str, request: Request, next: str | None = None) -> Response:
    """Step 1: Google / Microsoft button -> redirect to the provider's authorization page (code + PKCE)."""
    name = provider.lower()
    if name not in oauth.PROVIDERS:
        return _oauth_error(request, "Unknown sign-in provider.", 404)
    if not _oauth_flags()[name]:
        return _oauth_error(request, "Sign-in with %s is not configured by the administrator." % name.title(), 404)
    try:
        client = _oauth_client(request, name)
        url = client.authorize_url(safe_redirect_url(next, "/dashboard"))
    except oauth.OAuthError as e:
        return _oauth_error(request, str(e), 400)
    state = dict(parse_qsl(urlsplit(url).query))["state"]
    resp = RedirectResponse(url, status_code=303)
    # The state is also bound to THIS browser so a callback link planted by an attacker cannot log
    # the victim into the attacker's account (login CSRF).
    resp.set_cookie(COOKIE_OAUTH, state, httponly=True, secure=settings.cookie_secure, samesite="lax",
                    max_age=int(oauth.STATE_TTL), path="/")
    return resp


@router.get("/oauth/{provider}/callback", response_class=HTMLResponse)
async def oauth_callback(
    provider: str,
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
    code: str = "",
    state: str = "",
    error: str = "",
    error_description: str = "",
) -> Response:
    """Step 2: provider redirects back here -> exchange the code, find/create the user, start the session."""
    name = provider.lower()
    if name not in oauth.PROVIDERS or not _oauth_flags()[name]:
        return _oauth_error(request, "Unknown or unconfigured sign-in provider.", 404)
    cookie_state = request.cookies.get(COOKIE_OAUTH, "")
    if error:
        get_state_store().delete(f"oauth:{state}")
        resp = _oauth_error(request, "Sign-in was cancelled or refused by %s." % name.title(), 400)
        resp.delete_cookie(COOKIE_OAUTH, path="/")
        return resp
    if not code or not state or not secrets.compare_digest(cookie_state, state):
        get_state_store().delete(f"oauth:{state}")
        resp = _oauth_error(request, "Sign-in session expired or invalid. Please try again.", 400)
        resp.delete_cookie(COOKIE_OAUTH, path="/")
        return resp

    auth_svc = AuthService(db)
    nxt = "/dashboard"
    try:
        client = _oauth_client(request, name)
        profile, nxt = await asyncio.to_thread(client.complete, state, code)    # blocking HTTP off the event loop
        user, _session, raw_token = await auth_svc.oauth_login(
            profile, ip_address=get_client_ip(request), user_agent=get_user_agent(request))
        await db.commit()
    except MfaRequiredError as e:
        await db.commit()
        auth_svc.store.set(f"mfa:next:{e.challenge_id}", safe_redirect_url(nxt, "/dashboard"), 300)
        resp = RedirectResponse("/mfa", status_code=303)
        resp.set_cookie("ss_mfa", e.challenge_id, httponly=True, secure=settings.cookie_secure,
                        samesite="lax", max_age=300, path="/")
        resp.delete_cookie(COOKIE_OAUTH, path="/")
        return resp
    except (oauth.OAuthError, AuthenticationError, PermissionDeniedError, ValidationError) as e:
        await db.rollback()
        resp = _oauth_error(request, getattr(e, "message", None) or str(e), 400)
        resp.delete_cookie(COOKIE_OAUTH, path="/")
        return resp

    resp = RedirectResponse(safe_redirect_url(nxt, "/dashboard"), status_code=303)
    resp.set_cookie(COOKIE_SESSION, raw_token, httponly=True, secure=settings.cookie_secure, samesite="lax",
                    max_age=settings.session_absolute_timeout, path="/")
    resp.delete_cookie(COOKIE_OAUTH, path="/")
    return resp


@router.api_route("/logout", methods=["GET", "POST"])
async def logout_page(
    request: Request,
    response: Response,
    db: Annotated[AsyncSession, Depends(get_db)],
) -> RedirectResponse:
    session, user = await get_optional_user(request, db)
    if session and user:
        auth_svc = AuthService(db)
        await auth_svc.logout(session.id, user.id, get_client_ip(request), get_user_agent(request))
        await db.commit()

    redirect = RedirectResponse("/login", status_code=303)
    redirect.delete_cookie(key=COOKIE_SESSION, path="/")
    return redirect
