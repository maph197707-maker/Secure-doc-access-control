"""Security pages (/security/*), Settings redirects and public info pages (/about, /privacy, /terms,
/security) that templates link to but that previously had no route (404).

Everything is read from the database through existing services. Nothing is invented.

NOTE: written in a sandbox where FastAPI/SQLAlchemy could not be installed. Compiled and
template-rendered only; NEVER executed against a running server. Click through every page.
"""
from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.dependencies import get_db, get_optional_user
from app.core.enums import UserStatus
from app.models.audit import AuditLog
from app.models.device import Device
from app.models.session import UserSession
from app.repositories.audit import AuditRepository
from app.services import stats
from app.services.security_score import SecurityScoreService
from app.services.sessions import SessionService
from app.web.dashboard import _auth, _render
from app.web.templating import build_env

router = APIRouter(tags=["web-security"], include_in_schema=False)
_env = build_env()


def _mask_ip(ip: str | None) -> str:
    if not ip:
        return "unknown"
    if "." in ip:
        a = ip.split(".")
        return ".".join(a[:2] + ["x", "x"]) if len(a) == 4 else ip
    return ip.split(":")[0] + ":…"


def _device_name(ua: str | None) -> str:
    ua = ua or ""
    browser = next((n for k, n in (("Edg/", "Edge"), ("Chrome/", "Chrome"), ("Firefox/", "Firefox"),
                                   ("Safari/", "Safari")) if k in ua), "Browser")
    os_ = next((n for k, n in (("Windows", "Windows"), ("Android", "Android"), ("iPhone", "iOS"),
                               ("Mac OS", "macOS"), ("Linux", "Linux")) if k in ua), "unknown OS")
    return f"{browser} on {os_}"


# ── security pages ───────────────────────────────────────────────────────────
@router.get("/security/score", response_class=HTMLResponse)
async def security_score(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    result = await SecurityScoreService(db).compute_for_user(user.id)
    # templates use attribute access (result.label, result.controls); dicts support it in Jinja
    return await _render(request, db, user, "security/score.html", result=result,
                         key_provider_dev=get_settings().kms_backend == "local_dev")


@router.get("/security/sessions", response_class=HTMLResponse)
async def security_sessions(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    current, _ = await get_optional_user(request, db)
    rows = await SessionService(db).list_user_sessions(user.id)
    items = [{"id": s.id, "device": _device_name(s.user_agent), "ip_masked": _mask_ip(s.ip_address),
              "started": s.created_at, "last_active": s.last_active_at,
              "current": bool(current and s.id == current.id)} for s in rows]
    return await _render(request, db, user, "security/sessions.html", sessions=items)


@router.post("/security/sessions/revoke-others")
async def sessions_revoke_others(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    current, _ = await get_optional_user(request, db)
    if current:
        await SessionService(db).revoke_other_sessions(user.id, current.id)
        await db.commit()
    return RedirectResponse("/security/sessions", status_code=303)


@router.post("/security/sessions/{session_id}/revoke")
async def session_revoke(session_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    current, _ = await get_optional_user(request, db)
    own = await db.scalar(select(UserSession.id).where(UserSession.id == session_id, UserSession.user_id == user.id))
    if own and not (current and current.id == own):         # only your own, and never the one you're using
        await SessionService(db).revoke_session(own, reason="user_revocation")
        await db.commit()
    return RedirectResponse("/security/sessions", status_code=303)


@router.get("/security/devices", response_class=HTMLResponse)
async def security_devices(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    current, _ = await get_optional_user(request, db)
    rows = (await db.scalars(select(Device).where(Device.user_id == user.id, Device.trust != "BLOCKED")
                             .order_by(Device.last_seen_at.desc()))).all()
    items = [{"id": d.id, "name": d.name or _device_name(d.user_agent), "ip_masked": _mask_ip(d.ip_address),
              "last_seen": d.last_seen_at or d.registered_at, "trusted": d.trust == "TRUSTED",
              "current": bool(current and current.device_id == d.id)} for d in rows]
    return await _render(request, db, user, "security/devices.html", devices=items)


@router.post("/security/devices/{device_id}/revoke")
async def device_revoke(device_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    current, _ = await get_optional_user(request, db)
    dev = await db.scalar(select(Device).where(Device.id == device_id, Device.user_id == user.id))
    if dev and not (current and current.device_id == dev.id):
        dev.trust = "BLOCKED"
        svc = SessionService(db)
        for s in (await db.scalars(select(UserSession).where(
                UserSession.device_id == dev.id, UserSession.status == "ACTIVE"))).all():
            await svc.revoke_session(s.id, reason="device_revoked")
        await db.commit()
    return RedirectResponse("/security/devices", status_code=303)


@router.get("/security/activity", response_class=HTMLResponse)
async def security_activity(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    return await _render(request, db, user, "security/activity.html",
                         events=await stats.recent_activity(db, user.id, 50))


@router.get("/security/audit", response_class=HTMLResponse)
async def security_audit(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    repo = AuditRepository(db)
    ver = await repo.verify()                       # walks the WHOLE chain; this is the tamper check
    rows = (await db.scalars(select(AuditLog).where(AuditLog.user_id == user.id)
                             .order_by(AuditLog.sequence_number.desc()).limit(100))).all()
    latest = await repo.get_latest_entry()
    entries = [{"seq": r.sequence_number, "action": r.action, "actor": user.email, "when": r.created_at,
                "hash_short": (r.entry_hash or "")[:12]} for r in rows]
    chain = {"ok": ver.ok, "broken_at": ver.broken_at, "count": ver.checked,
             "head": (latest.entry_hash[:16] if latest and latest.entry_hash else "none")}
    return await _render(request, db, user, "security/audit.html", entries=entries, chain=chain)


# ── settings: /settings/security is real (web/mfa_pages.py); privacy/account still point at the profile page ──────────
@router.get("/settings/privacy")
@router.get("/settings/account")
async def settings_redirect(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    return RedirectResponse("/profile", status_code=303)


# ── public info pages ────────────────────────────────────────────────────────
_INFO: dict[str, tuple[str, list[str]]] = {
    "security": ("How SecureShare protects your documents", [
        "Every file is encrypted with its own random key using AES-256-GCM before it is stored; that key is itself wrapped by a master key. A tampered or truncated file fails authentication and is never served.",
        "Share links use long random tokens that are stored only as keyed hashes. Links can expire, limit views and downloads, require a password, bind to a recipient, and be revoked at any time.",
        "Every access decision is checked before a file is decrypted, and each action is written to a hash-chained audit log so after-the-fact changes can be detected.",
        "Screenshots cannot be technically prevented; views are watermarked and audited instead."]),
    "about": ("About SecureShare", [
        "SecureShare is a secure, intelligent document-sharing and zero-trust access platform: upload a document, encrypt it, and share it through a controlled, auditable link.",
        "It is a student/engineering project. Features that need external providers (email and SMS codes) are shown as unavailable until those providers are configured."]),
    "privacy": ("Privacy", [
        "SecureShare stores the account details you provide, the encrypted documents you upload, and an audit trail of actions on them.",
        "Document contents are encrypted at rest. Guest accounts are temporary and carry no email or phone number.",
        "This is a project build; replace this text with your organisation's policy before real-world use."]),
    "terms": ("Terms of use", [
        "Use SecureShare only for documents you are entitled to store and share.",
        "You are responsible for who you send links to. Revoke a link to stop access immediately.",
        "This is a project build provided as-is, without warranty."]),
}


async def _info(request: Request, db: AsyncSession, key: str) -> HTMLResponse:
    title, paras = _INFO[key]
    from app.middleware.csrf import get_csrf_token
    html = _env.get_template("public/info.html").render(
        title=title, paragraphs=paras, csrf_token=get_csrf_token(request),
        request_id=getattr(request.state, "request_id", ""))
    return HTMLResponse(html)


@router.get("/security", response_class=HTMLResponse)
async def page_security(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    return await _info(request, db, "security")


@router.get("/about", response_class=HTMLResponse)
async def page_about(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    return await _info(request, db, "about")


@router.get("/privacy", response_class=HTMLResponse)
async def page_privacy(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    return await _info(request, db, "privacy")


@router.get("/terms", response_class=HTMLResponse)
async def page_terms(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    return await _info(request, db, "terms")
