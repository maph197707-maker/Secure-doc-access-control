"""/verify-phone: a signed-in user adds a phone number and proves they own it with an SMS code.

One path, two forms (action=send | action=verify). The code is created, hashed, persisted, sent and
verified by services.otp (database-backed: expiry, attempts, cooldown, quotas, one-time use); this
route only maps outcomes to pages. Changing the number clears `phone_verified` until the new number is
verified.
"""
from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_client_ip, get_db, get_user_agent
from app.core.exceptions import DeliveryError, RateLimitExceededError
from app.integrations import factory
from app.integrations.sms import SMSService, mask_phone, normalize_phone
from app.models.user import User
from app.repositories.audit import AuditRepository
from app.services.otp import OtpPurpose, OtpResult, OtpService
from app.web.user import _auth, _render


router = APIRouter(tags=["web-account"], include_in_schema=False)


def _sms() -> SMSService | None:
    return factory.get_sms_service()


def _page(request: Request, user: User, stage: str, status: int = 200, error: str | None = None,
          notice: str | None = None, phone_value: str = ""):
    return _render(request, user, "auth/verify_phone.html", status, stage=stage, error=error, notice=notice,
                   phone_masked=mask_phone(user.phone) if user.phone else "", phone_value=phone_value,
                   sms_available=_sms() is not None)


def _stage(user: User) -> str:
    return "done" if (user.phone and user.phone_verified) else "enter"


@router.get("/verify-phone", response_class=HTMLResponse)
async def verify_phone_get(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    return _page(request, user, _stage(user), phone_value=user.phone or "")


@router.post("/verify-phone", response_class=HTMLResponse)
async def verify_phone_post(request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                            action: str = Form("send"), phone: str = Form(""), code: str = Form("")):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    sms = _sms()
    audit = AuditRepository(db)
    ip, ua = get_client_ip(request), get_user_agent(request)
    otp_svc = OtpService(db)
    if sms is None:
        return _page(request, user, _stage(user), 503, error="Phone verification is unavailable: no SMS provider is configured.",
                     phone_value=phone or user.phone or "")

    if action == "verify":
        if not user.phone:
            return _page(request, user, "enter", 400, error="Enter your phone number first.")
        res = await otp_svc.verify(purpose=OtpPurpose.PHONE_VERIFY, subject=user.id, destination=user.phone,
                                   code=code, user_id=user.id, ip=ip, user_agent=ua)
        if res is OtpResult.OK:                          # decided server-side, from the persisted challenge
            user.phone_verified = True
            await audit.log_event(action="PHONE_VERIFIED", user_id=user.id, resource_type="user", resource_id=user.id,
                                  ip_address=ip, user_agent=ua)
            await db.commit()
            return _page(request, user, "done", notice="Phone verified.")
        await audit.log_event(action="PHONE_CODE_FAIL", user_id=user.id, resource_type="user", resource_id=user.id,
                              ip_address=ip, user_agent=ua, details={"reason": res.value.lower()})
        await db.commit()
        msgs = {OtpResult.WRONG: ("Incorrect code.", 401, "code"),
                OtpResult.LOCKED: ("Too many wrong codes. Request a new code.", 429, "enter")}
        msg, status, stage = msgs.get(res, ("That code has expired or was already used. Request a new one.", 400, "enter"))
        return _page(request, user, stage, status, error=msg, phone_value=user.phone or "")

    # action == "send"
    try:
        e164 = normalize_phone(phone or user.phone or "", sms.cc)
    except ValueError as exc:
        return _page(request, user, _stage(user), 400, error=str(exc), phone_value=phone)
    if e164 != user.phone:                                   # a new number is unverified until proven
        user.phone, user.phone_verified = e164, False
    try:
        receipt = await otp_svc.send(
            purpose=OtpPurpose.PHONE_VERIFY, subject=user.id, destination=e164, channel="sms",
            deliver=lambda c, minutes: sms.send_otp(e164, c, minutes), user_id=user.id, ip=ip, user_agent=ua)
    except RateLimitExceededError as exc:
        await db.commit()
        return _page(request, user, "code" if "wait" in exc.message else _stage(user), 429, error=exc.message,
                     phone_value=e164)
    except DeliveryError as exc:                              # OtpService already audited + committed this
        return _page(request, user, _stage(user), exc.status_code, error=exc.message, phone_value=e164)
    await db.commit()
    return _page(request, user, "code", notice=f"Code sent to {receipt.destination_hint}.")
