"""/profile: where a signed-in person verifies their email and phone AFTER sign-up.

Sign-up needs no email delivery, so a new account starts with an unverified email and phone. The
codes are issued and checked by the same database-backed OtpService as everywhere else (hashed,
expiring, attempt-limited, one-time). If SMTP / SMS is not configured the page says so and the
verification stays unavailable: nothing is ever marked verified without a real code.
"""
from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_client_ip, get_db, get_user_agent
from app.core.exceptions import DeliveryError, LockoutError, RateLimitExceededError, ValidationError
from app.core.utils import mask_email
from app.integrations import factory
from app.integrations.sms import SMSService, mask_phone, normalize_phone
from app.repositories.audit import AuditRepository
from app.services.otp import OtpPurpose, OtpResult, OtpService
from app.models.user import User
from app.services.auth import AuthService, is_guest_user
from app.web.user import _auth, _render

router = APIRouter(tags=["web-profile"], include_in_schema=False)


def _page(request: Request, user: User, status: int = 200, *, stage: str | None = None,
          error: str | None = None, notice: str | None = None, phone_stage: str = "idle",
          phone_value: str = "") -> HTMLResponse:
    guest = is_guest_user(user)
    return _render(
        request, user, "auth/profile.html", status,
        guest=guest, email_verified=bool(user.email_verified), email_masked=mask_email(user.email),
        email_available=factory.get_email_service() is not None,
        phone=mask_phone(user.phone) if user.phone else "", phone_verified=bool(user.phone_verified),
        sms_available=factory.get_sms_service() is not None,
        stage=stage or "idle", phone_stage=phone_stage, phone_value=phone_value or user.phone or "",
        error=error, notice=notice, full_name=user.full_name)


@router.get("/profile", response_class=HTMLResponse)
async def profile_get(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    return _page(request, user)


@router.post("/profile/email/send", response_class=HTMLResponse)
async def profile_email_send(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    try:
        delivery = await AuthService(db).send_profile_email_code(
            user, ip_address=get_client_ip(request), user_agent=get_user_agent(request))
        await db.commit()
    except DeliveryError as e:             # SMTP missing/failing: OtpService already audited + committed
        return _page(request, user, e.status_code, error=e.message)
    except (ValidationError, RateLimitExceededError) as e:
        await db.rollback()
        await db.refresh(user)             # rollback expires the instance; the page re-reads it
        return _page(request, user, 429 if isinstance(e, RateLimitExceededError) else 400, error=e.message)
    return _page(request, user, stage="code", notice=f"A verification code was sent to {delivery.destination}.")


@router.post("/profile/email/verify", response_class=HTMLResponse)
async def profile_email_verify(request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                               code: str = Form("")):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    if is_guest_user(user):
        return _page(request, user, 400, error="Guest accounts have no real email address to verify.")
    try:
        await AuthService(db).verify_email(email=user.email, code=code.strip(),
                                           ip_address=get_client_ip(request), user_agent=get_user_agent(request))
        await db.commit()
    except (ValidationError, LockoutError) as e:
        return _page(request, user, 423 if isinstance(e, LockoutError) else 400, stage="code", error=e.message)
    return _page(request, user, notice="Email verified.")


def _sms() -> SMSService | None:
    return factory.get_sms_service()


@router.post("/profile/phone/send", response_class=HTMLResponse)
async def profile_phone_send(request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                             phone: str = Form("")):
    """Add / change the phone number and text a one-time code to it."""
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    if is_guest_user(user):
        return _page(request, user, 400, error="Guest accounts cannot add a phone number. Create an account first.")
    sms = _sms()
    if sms is None:
        return _page(request, user, 503, error="Phone verification is unavailable: no SMS provider is configured.",
                     phone_value=phone)
    try:
        e164 = normalize_phone(phone or user.phone or "", sms.cc)
    except ValueError as exc:
        return _page(request, user, 400, error=str(exc), phone_value=phone)
    if e164 != user.phone:                          # a new number is unverified until proven
        user.phone, user.phone_verified = e164, False
    try:
        receipt = await OtpService(db).send(
            purpose=OtpPurpose.PHONE_VERIFY, subject=user.id, destination=e164, channel="sms",
            deliver=lambda c, minutes: sms.send_otp(e164, c, minutes), user_id=user.id,
            ip=get_client_ip(request), user_agent=get_user_agent(request))
    except RateLimitExceededError as exc:
        await db.commit()
        return _page(request, user, 429, error=exc.message, phone_stage="code" if "wait" in exc.message else "idle")
    except DeliveryError as exc:                    # OtpService already audited + committed this
        return _page(request, user, exc.status_code, error=exc.message)
    await db.commit()
    return _page(request, user, phone_stage="code", notice=f"Code sent to {receipt.destination_hint}.")


@router.post("/profile/phone/verify", response_class=HTMLResponse)
async def profile_phone_verify(request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                               code: str = Form("")):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    if not user.phone:
        return _page(request, user, 400, error="Add your phone number first.")
    ip, ua = get_client_ip(request), get_user_agent(request)
    res = await OtpService(db).verify(purpose=OtpPurpose.PHONE_VERIFY, subject=user.id, destination=user.phone,
                                      code=code.strip(), user_id=user.id, ip=ip, user_agent=ua)
    audit = AuditRepository(db)
    if res is OtpResult.OK:                          # decided server-side from the persisted challenge
        user.phone_verified = True
        await audit.log_event(action="PHONE_VERIFIED", user_id=user.id, resource_type="user",
                              resource_id=user.id, ip_address=ip, user_agent=ua)
        await db.commit()
        return _page(request, user, notice="Phone verified.")
    await audit.log_event(action="PHONE_CODE_FAIL", user_id=user.id, resource_type="user", resource_id=user.id,
                          ip_address=ip, user_agent=ua, details={"reason": res.value.lower()})
    await db.commit()
    msgs = {OtpResult.WRONG: ("Incorrect code.", 401, "code"),
            OtpResult.LOCKED: ("Too many wrong codes. Request a new code.", 429, "idle")}
    msg, status, stage = msgs.get(res, ("That code has expired or was already used. Request a new one.", 400, "idle"))
    return _page(request, user, status, error=msg, phone_stage=stage)
