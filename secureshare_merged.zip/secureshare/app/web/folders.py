"""Nested folder browser: /folders, /folders/{id}, create / rename / move / delete, move a document.

Every path starts with /folders, except POST /documents/{id}/move (a distinct method and path, so it cannot
clash with the GET /documents/{id} page). Static `/folders/create` is registered before
`/folders/{folder_id}` to satisfy the route-shadowing rule.

NOTE: written without FastAPI/SQLAlchemy installed in the authoring sandbox. Compiled and the template
rendered with Jinja only; click through it once and run tests/unit/test_folder_store.py.
"""
from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_client_ip, get_db, get_user_agent
from app.repositories.audit import AuditRepository
from app.services.folder_store import FolderError, FolderStore
from app.web.dashboard import _auth, _render

router = APIRouter(tags=["web-folders"], include_in_schema=False)


def _back(folder_id: str | None) -> RedirectResponse:
    return RedirectResponse(f"/folders/{folder_id}" if folder_id else "/folders", status_code=303)


async def _page(request: Request, db: AsyncSession, user, folder_id: str | None, *,
                error: str | None = None, notice: str | None = None, status: int = 200) -> HTMLResponse:
    store = FolderStore(db)
    try:
        data: dict[str, Any] = await store.listing(user.id, folder_id)
    except FolderError:
        data = await store.listing(user.id, None)
        error, status, folder_id = "That folder does not exist.", 404, None
    resp = await _render(request, db, user, "documents/folders.html", folder_id=folder_id,
                         error=error, notice=notice, **data)
    resp.status_code = status
    return resp


async def _audit(request: Request, db: AsyncSession, user, action: str, rid: str | None, **details: Any) -> None:
    await AuditRepository(db).log_event(action=action, user_id=user.id, resource_type="folder", resource_id=rid,
                                        ip_address=get_client_ip(request), user_agent=get_user_agent(request),
                                        details=details)


@router.get("/folders", response_class=HTMLResponse)
async def folders_root(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    return await _page(request, db, user, None)


@router.post("/folders/create")
async def folder_create(request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                        name: str = Form(""), parent_id: str = Form("")):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    try:
        f = await FolderStore(db).create(user.id, parent_id or None, name)
        await _audit(request, db, user, "FOLDER_CREATED", f.id, name=f.name)
        await db.commit()
    except FolderError as exc:
        await db.rollback()
        return await _page(request, db, user, parent_id or None, error=str(exc), status=400)
    return _back(parent_id or None)


@router.get("/folders/{folder_id}", response_class=HTMLResponse)
async def folder_open(folder_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    return await _page(request, db, user, folder_id)


@router.post("/folders/{folder_id}/rename")
async def folder_rename(folder_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                        name: str = Form("")):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    store = FolderStore(db)
    try:
        f = await store.rename(user.id, folder_id, name)
        parent = f.parent_id
        await _audit(request, db, user, "FOLDER_RENAMED", f.id, name=f.name)
        await db.commit()
    except FolderError as exc:
        await db.rollback()
        return await _page(request, db, user, folder_id, error=str(exc), status=400)
    return _back(parent)


@router.post("/folders/{folder_id}/move")
async def folder_move(folder_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                      parent_id: str = Form("")):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    try:
        f = await FolderStore(db).move(user.id, folder_id, parent_id or None)
        await _audit(request, db, user, "FOLDER_MOVED", f.id, parent_id=parent_id or None)
        await db.commit()
    except FolderError as exc:
        await db.rollback()
        return await _page(request, db, user, folder_id, error=str(exc), status=400)
    return _back(parent_id or None)


@router.post("/folders/{folder_id}/delete")
async def folder_delete(folder_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    store = FolderStore(db)
    try:
        f = await store.get(user.id, folder_id)
        parent = f.parent_id
        moved = await store.delete(user.id, folder_id)
        await _audit(request, db, user, "FOLDER_DELETED", folder_id, **moved)
        await db.commit()
    except FolderError as exc:
        await db.rollback()
        return await _page(request, db, user, None, error=str(exc), status=404)
    return _back(parent)


@router.post("/documents/{doc_id}/move")
async def document_move(doc_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                        folder_id: str = Form(""), return_to: str = Form("")):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    try:
        await FolderStore(db).move_document(user.id, doc_id, folder_id or None)
        await _audit(request, db, user, "DOCUMENT_MOVED", doc_id, folder_id=folder_id or None)
        await db.commit()
    except FolderError as exc:
        await db.rollback()
        return await _page(request, db, user, return_to or None, error=str(exc), status=400)
    return _back(return_to or None)
