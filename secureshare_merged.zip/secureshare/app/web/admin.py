"""Admin web pages: /admin, /admin/users, /admin/users/{id}, /admin/configuration."""
from __future__ import annotations

from typing import Annotated, Any
from fastapi import APIRouter, Depends, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_db, get_optional_user
from app.core.enums import RoleName, UserStatus
from app.middleware.csrf import get_csrf_token
from app.models.user import User
from app.services import stats
from app.services.admin import AdminService
from app.services.db_status import database_status
from app.web.templating import build_env

router = APIRouter(prefix="/admin", tags=["web-admin"], include_in_schema=False)
env = build_env()


def _user_ctx(user: User) -> dict[str, Any]:
    parts = (user.full_name or user.email).split()
    return {
        "name": user.full_name or user.email,
        "initials": "".join(p[0] for p in parts[:2]).upper() or "U",
        "role": user.role,
        "email": user.email,
    }


async def _require_admin_web(request: Request, db: AsyncSession) -> tuple[User | None, Any | None]:
    _, user = await get_optional_user(request, db)
    if not user or user.status != UserStatus.ACTIVE.value or user.is_deleted:
        nxt = request.url.path + (f"?{request.url.query}" if request.url.query else "")
        return None, RedirectResponse(f"/login?next={nxt}", status_code=303)
    if not user.is_admin:
        # Signed in but not an administrator: a real 403 (not a redirect that looks like a normal page).
        html = env.get_template("errors/error.html").render(
            user=_user_ctx(user), unread=0, csrf_token=get_csrf_token(request), code=403, title="Forbidden",
            message="Administrator access required.", request_id=getattr(request.state, "request_id", ""))
        return None, HTMLResponse(html, status_code=403, headers={"Cache-Control": "no-store"})
    return user, None


async def _render(request: Request, db: AsyncSession, user: User, name: str, **ctx: Any) -> HTMLResponse:
    html = env.get_template(name).render(
        user=_user_ctx(user),
        unread=await stats.unread_count(db, user.id),
        csrf_token=get_csrf_token(request),
        request_id=getattr(request.state, "request_id", ""),
        **ctx,
    )
    return HTMLResponse(html, headers={"Cache-Control": "no-store"})


@router.get("", response_class=HTMLResponse)
@router.get("/", response_class=HTMLResponse)
async def admin_dashboard(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _require_admin_web(request, db)
    if redirect:
        return redirect

    admin_svc = AdminService(db)
    metrics = await admin_svc.get_admin_metrics()
    recent = await admin_svc.get_recent_users(limit=10)

    return await _render(
        request,
        db,
        user,
        "admin/dashboard.html",
        metrics=metrics,
        recent_users=recent,
        nav_active="admin",
    )


@router.get("/users", response_class=HTMLResponse)
async def admin_users(
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
    q: str = "",
    page: int = 1,
):
    user, redirect = await _require_admin_web(request, db)
    if redirect:
        return redirect

    admin_svc = AdminService(db)
    users, total = await admin_svc.list_users(skip=(max(page, 1) - 1) * 20, limit=20, search=q or None)

    formatted_users = []
    for u in users:
        name = u.full_name or u.email.split("@")[0]
        parts = name.split()
        initials = ("".join(p[0] for p in parts[:2])).upper() or "U"
        formatted_users.append({
            "id": u.id,
            "name": name,
            "initials": initials,
            "email": u.email,
            "role": u.role,
            "status": u.status.lower() if u.status else "active",
        })

    return await _render(
        request,
        db,
        user,
        "admin/users.html",
        users=formatted_users,
        q=q,
        page=page,
        total=total,
        nav_active="users",
    )


@router.get("/users/{user_id}", response_class=HTMLResponse)
async def admin_user_detail(
    user_id: str,
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
):
    user, redirect = await _require_admin_web(request, db)
    if redirect:
        return redirect

    admin_svc = AdminService(db)
    target_user = await admin_svc.get_user_detail(user_id)
    name = target_user.full_name or target_user.email.split("@")[0]
    parts = name.split()
    initials = ("".join(p[0] for p in parts[:2])).upper() or "U"

    u_data = {
        "id": target_user.id,
        "name": name,
        "initials": initials,
        "email": target_user.email,
        "role": target_user.role,
        "status": target_user.status.lower() if target_user.status else "active",
        "mfa": bool(target_user.totp_secret),
        "created": target_user.created_at,
        "last_login": target_user.last_login_at,
    }

    return await _render(
        request,
        db,
        user,
        "admin/user_detail.html",
        u=u_data,
        nav_active="users",
    )


@router.post("/users/{user_id}/suspend")
async def admin_suspend_user(
    user_id: str,
    request: Request,
    db: Annotated[AsyncSession, Depends(get_db)],
):
    user, redirect = await _require_admin_web(request, db)
    if redirect:
        return redirect

    admin_svc = AdminService(db)
    await admin_svc.toggle_suspend_user(user_id)
    await db.commit()
    return RedirectResponse(f"/admin/users/{user_id}", status_code=303)


@router.get("/configuration", response_class=HTMLResponse)
@router.get("/database", response_class=HTMLResponse)
async def admin_database(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _require_admin_web(request, db)
    if redirect:
        return redirect

    info = await database_status(db)
    return await _render(
        request,
        db,
        user,
        "admin/database.html",
        info=info,
        nav_active="config",
    )
