"""DEV-ONLY UI prototype (mounted at /dev/showcase when DEBUG=true; never in production).
Server-rendered UI routes with sample content matching the reference board (John Doe, 24 docs ...).
Static sample data only; swap each context for a service call when the real routes land."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse

from app.services.security_score import compute_score
from app.web.templating import build_env

router = APIRouter()
env = build_env()
NOW = datetime.now(timezone.utc)
USER = {"name": "John Doe", "initials": "JD", "role": "ADMIN", "email": "john@example.com"}
APP = {"user": USER, "unread": 3, "csrf_token": "demo", "request_id": "demo"}
DOC = {"id": "d1", "name": "project-report.pdf", "ext": "pdf", "size": 2_516_582, "updated": NOW - timedelta(hours=3), "shared": True}
ACT = [{"icon": "upload", "kind": "info", "title": "Document uploaded", "detail": "Project_Report.pdf", "when": NOW - timedelta(hours=2)},
       {"icon": "link", "kind": "success", "title": "Link accessed", "detail": "Design_Files", "when": NOW - timedelta(hours=3)},
       {"icon": "check", "kind": "warning", "title": "Document completed", "detail": "Team_Agreement.pdf", "when": NOW - timedelta(hours=5)},
       {"icon": "shield", "kind": "warning", "title": "Security scan completed", "detail": "All files", "when": NOW - timedelta(hours=2)}]
DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
ANALYSIS = {"doc_id": "d1", "done": True, "classification": "Business Document", "classification_source": "rules v1",
            "pii_summary": "No PII found", "dlp_level": "LOW", "scan_status": "CLEAN", "scan_engine": "ClamAV"}


def _m(rows, icons):
    return [{"label": l, "value": v, "delta": d, "icon": i, "suffix": s} for (l, v, d, s), i in zip(rows, icons)]


def pages() -> dict[str, tuple[str, dict]]:
    score = compute_score({"encryption": (1.0, "All documents encrypted"), "key_protection": (1.0, "KMS key"), "mfa": (1.0, "MFA on"), "link_expiry": (1.0, "All links expire")})
    auth_steps = [{"label": x, "state": "done"} for x in ("Email Verified", "OTP Verified", "Device Verified", "Risk Check")]
    return {
        "/": ("public/landing.html", dict(
            features=[("lock", "End-to-End Encryption"), ("cpu", "AI Threat Detection"), ("shield-check", "Zero Trust Access"), ("link", "Secure Link Sharing"), ("shield", "DLP Protection"), ("activity", "Audit & Monitor")],
            tour_steps=["Upload a document", "Configure security", "Share the link"])),
        "/register": ("auth/register.html", dict(csrf_token="demo", values={}, errors={}, sms_available=True,
            progress=[{"label": l, "state": "pending"} for l in ("Secure Registration", "Email Verification", "Phone Verification", "MFA Ready")])),
        "/login": ("auth/login.html", dict(csrf_token="demo", email="", error=None, next=None, oauth={"google": True, "microsoft": True})),
        "/verify-email": ("auth/verify_email.html", dict(csrf_token="demo", status="pending", email_masked="j***@example.com", error=None, attempts_left=5, cooldown=30)),
        "/verify-identity": ("auth/verify_identity.html", dict(csrf_token="demo", locked_seconds=0, error=None, attempts_left=5, steps=auth_steps)),
        "/forgot-password": ("auth/forgot_password.html", dict(csrf_token="demo", sent=False)),
        "/dashboard": ("dashboard/dashboard.html", dict(**APP, hour=9, recent=ACT,
            metrics=_m([("Total Documents", 24, 5.0, ""), ("Active Links", 8, 2.0, ""), ("Total Downloads", 156, 8.0, ""), ("Security Score", 98, 2.0, "%")], ["file", "link", "download", "shield"]),
            activity={"values": [8, 12, 10, 18, 15, 24, 20], "labels": DAYS})),
        "/home": ("dashboard/home.html", dict(**APP,
            actions=[{"icon": "upload", "title": "Upload Document", "text": "Securely share your files", "cta": "Upload Now", "href": "/documents/upload"},
                     {"icon": "link", "title": "Generate Secure Link", "text": "Share with anyone", "cta": "Create Link", "href": "/shares/create"},
                     {"icon": "chart", "title": "View Analytics", "text": "Track usage & activity", "cta": "View Reports", "href": "/analytics"},
                     {"icon": "cpu", "title": "AI Intelligence", "text": "Detect & prevent threats", "cta": "Explore", "href": "/search"}],
            quick=[{"href": "/documents/upload", "icon": "upload", "label": "Upload"}, {"href": "/documents", "icon": "folder-plus", "label": "New Folder"},
                   {"href": "/shares", "icon": "link", "label": "Secure Links"}, {"href": "/security/score", "icon": "shield", "label": "Security"}, {"href": "/search", "icon": "cpu", "label": "AI Insights"}])),
        "/documents": ("documents/list.html", dict(**APP, docs=[DOC], filter="all", q="", page=1, pages=1)),
        "/documents/upload": ("documents/upload.html", dict(**APP, doc={"id": "d1", "name": "project-report.pdf", "size": 2_516_582}, types_label="PDF, DOC, DOCX, JPG, PNG", max_mb=50, accept=".pdf,.doc,.docx,.jpg,.png",
            doc_types=[("report", "Report"), ("contract", "Contract")], selected_type="report", categories=[("business", "Business")], selected_category="business", tags=["project", "report", "confidential"], analysis=ANALYSIS)),
        "/documents/d1": ("documents/detail.html", dict(**APP, doc={**DOC, "added": NOW, "classification": "Business Document"}, can_download=True, download_reason="", tab="overview", activity=ACT,
            grants=[{"recipient": "bob@example.com", "permissions": ["VIEW"], "expires": "2026-10-15"}])),
        "/documents/d1/versions": ("documents/versions.html", dict(**APP, doc=DOC, latest_number=2, version_options=[(1, "v1"), (2, "v2")],
            versions=[{"number": 2, "latest": True, "created": NOW, "size": 2048, "summary": "Updated figures"}, {"number": 1, "latest": False, "created": NOW - timedelta(days=5), "size": 1024, "summary": "Initial upload"}])),
        "/documents/d1/compare": ("documents/compare.html", dict(**APP, doc=DOC, a={"number": 1, "size": 1024, "sha256": "a" * 64}, b={"number": 2, "size": 2048, "sha256": "b" * 64}, diff=[("same", "Title"), ("del", "old line"), ("add", "new line")])),
        "/shares/create": ("sharing/wizard.html", dict(**APP, step=1, doc={"id": "d1", "name": "project-report.pdf", "size": 2048}, draft={}, types_label="PDF, DOC, DOCX, JPG, PNG", max_mb=50, accept=".pdf,.doc,.docx,.jpg,.png",
            binding_modes=[("EMAIL_OTP", "Email + OTP", True, ""), ("EMAIL_PHONE", "Email + Phone (OTP)", True, "")], idempotency_key="demo")),
        "/shares/s1": ("sharing/link_ready.html", dict(**APP, full_link="https://secshare.share.com/s/f739e4c1", qr_svg='<svg viewBox="0 0 10 10"><rect width="10" height="10" fill="#0E1A3D"/><rect x="1" y="1" width="3" height="3" fill="#fff"/><rect x="6" y="1" width="3" height="3" fill="#fff"/><rect x="1" y="6" width="3" height="3" fill="#fff"/></svg>',
            share={"id": "s1", "expires_at": "2025-10-15 12:00", "max_downloads": 5, "max_views": 10, "status": "active", "masked_link": "https://secshare.share.com/s/f739e..."})),
        "/shares": ("sharing/list.html", dict(**APP, shares=[{"id": "s1", "doc_name": "project-report.pdf", "status": "active", "views": 2, "max_views": 10, "expires": "2025-10-15"}])),
        "/share/abc": ("public/share_gate.html", dict(csrf_token="demo", error=None, token="abc", password_required=True)),
        "/viewer/abc": ("viewer/viewer.html", dict(csrf_token="demo", doc={"name": "project-report.pdf", "classification": "Business Document", "uploaded_by": "John Doe", "uploaded_on": NOW, "display_id": "DOC-775641"},
            recheck_url="/api/v1/share/abc/recheck", recheck_seconds=30, page_no=1, page_count=3, zoom=100, zoom_in=125, zoom_out=75,
            policy={"can_copy": False, "can_download": True, "download_url": "/documents/d1/download", "download_reason": ""}, stopped=False, stopped_reason="",
            pages=[{"n": i, "thumb_url": "/static/img/shield.svg", "url": "/static/img/shield.svg"} for i in (1, 2, 3)], page_url="/static/img/shield.svg",
            watermark={"on": True, "forced": True}, integrity={"label": "Integrity verified", "ok": True, "detail": "SHA-256 and signature match."})),
        "/analytics": ("analytics/analytics.html", dict(**APP, range=7, trend={"values": [10, 14, 12, 22, 18, 28, 26], "labels": DAYS}, types={"values": [45, 25, 20, 10], "labels": ["PDF", "DOCX", "Image", "Other"]},
            metrics=[{"label": "Total Documents", "value": 248, "delta": 12.0, "icon": "file"}, {"label": "Total Accesses", "value": 1482, "delta": 19.0, "icon": "eye"}, {"label": "Downloads", "value": 892, "delta": 24.0, "icon": "download"}, {"label": "Risk Events", "value": 5, "delta": -60.0, "icon": "alert"}])),
        "/security/score": ("security/score.html", dict(**APP, result=score, key_provider_dev=False)),
        "/notifications": ("notifications/list.html", dict(**APP, notifications=[
            {"kind": "SHARED_WITH_YOU", "title": "Document shared with you", "detail": "Project_Report.pdf", "when": NOW - timedelta(hours=2), "read": False},
            {"kind": "LINK_ACCESSED", "title": "Link accessed", "detail": "Design_Files", "when": NOW - timedelta(hours=3), "read": False},
            {"kind": "NEW_DEVICE_LOGIN", "title": "New device login", "detail": "iPhone", "when": NOW - timedelta(hours=5), "read": False},
            {"kind": "THREAT_DETECTED", "title": "Threat detected", "detail": "Suspicious activity", "when": NOW - timedelta(days=1), "read": True},
            {"kind": "DOCUMENT_COMPLETED", "title": "Document completed", "detail": "Financial_Report.pdf", "when": NOW - timedelta(days=2), "read": True}])),
        "/reset-password": ("auth/reset_password.html", dict(csrf_token="demo", reset_token="demo", error=None)),
        "/mfa": ("auth/mfa.html", dict(csrf_token="demo", locked_seconds=0, error=None, attempts_left=5)),
        "/passkey": ("auth/passkey.html", dict(csrf_token="demo", passkey_available=False)),
        "/welcome": ("public/welcome_mobile.html", dict(features=[("lock", "End-to-End Encryption"), ("shield-check", "Zero Trust Access"), ("link", "Secure Link Sharing")])),
        "/security/devices": ("security/devices.html", dict(**APP, devices=[{"id": "v1", "name": "This browser", "ip_masked": "127.0.0.x", "last_seen": NOW, "trusted": True, "current": True}])),
        "/security/sessions": ("security/sessions.html", dict(**APP, sessions=[{"id": "s1", "device": "This browser", "ip_masked": "127.0.0.x", "started": NOW - timedelta(hours=1), "last_active": NOW, "current": True}])),
        "/security/activity": ("security/activity.html", dict(**APP, events=ACT)),
        "/security/audit": ("security/audit.html", dict(**APP, entries=[], chain={"ok": True, "count": 0, "head": "-", "broken_at": None})),
        "/admin/users": ("admin/users.html", dict(**{**APP, "user": {**USER, "role": "ADMIN"}}, q="", users=[{"id": "u1", "name": "Arun Kumar", "initials": "AK", "email": "arun@company.com", "role": "user", "status": "active"}])),
        "/admin/users/u1": ("admin/user_detail.html", dict(**APP, u={"id": "u1", "name": "Arun Kumar", "initials": "AK", "email": "arun@company.com", "role": "user", "status": "active", "mfa": True, "created": NOW - timedelta(days=30), "last_login": NOW})),
        "/admin": ("admin/dashboard.html", dict(**APP,
            metrics=[{"label": "Total Users", "value": 124, "delta": 5.0, "icon": "users"}, {"label": "Active Users", "value": 86, "delta": 3.0, "icon": "user"}, {"label": "Security Incidents", "value": 5, "delta": 60.0, "icon": "alert"}],
            recent_users=[{"name": n, "initials": "".join(w[0] for w in n.split()), "email": e, "status": "active"} for n, e in
                          (("Arun Kumar", "arun@company.com"), ("Sneha Reddy", "sneha@company.com"), ("Rahul Sharma", "rahul@company.com"), ("Divya Patel", "divya@company.com"))])),
    }


def _register() -> None:
    for path, (tpl, ctx) in pages().items():
        def view(request: Request, _t=tpl, _c=ctx) -> HTMLResponse:
            return HTMLResponse(env.get_template(_t).render(**_c))
        router.add_api_route(path, view, methods=["GET"], response_class=HTMLResponse, include_in_schema=False)


_register()
