"""Real, database-backed document pages that templates link to but that previously had NO route (404):

  /home, /search, /documents/upload (GET+POST), /documents/{id}, /documents/{id}/viewer,
  /documents/{id}/download, /documents/{id}/share, /documents/{id}/rename, /documents/{id}/delete,
  /documents/{id}/revoke-links, /documents/{id}/versions, /documents/{id}/compare,
  

Every action goes through the same services the JSON API uses (DocumentService, SecureLinkService,
AccessControlService). View/download authorise BEFORE any decryption, and the audit row is committed
even when access is denied.

NOTE: written in a sandbox where FastAPI/SQLAlchemy could not be installed. These routes are
compiled and their templates are rendered with real Jinja2, but they have NEVER been executed
against a running server. Run the test-suite and click through every page before relying on them.
"""
from __future__ import annotations

import mimetypes
from typing import Annotated, Any
from urllib.parse import quote

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse
from sqlalchemy import select

from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.dependencies import get_client_ip, get_db, get_optional_user, get_user_agent
from app.core.enums import Permission
from app.core.exceptions import NotFoundError, PermissionDeniedError, ValidationError
from app.models.audit import AuditLog
from app.models.document import Document
from app.models.document_version import DocumentVersion
from app.models.secure_link import SecureLink
from app.models.tag import Tag, document_tags
from app.services import stats
from app.services.access_control import AccessControlService, get_document_or_404
from app.services.documents import DocumentService
from app.services.secure_links import SecureLinkService
from app.web.dashboard import _auth, _render

router = APIRouter(tags=["web-documents"], include_in_schema=False)

DOC_TYPES = [("report", "Report"), ("contract", "Contract"), ("invoice", "Invoice"),
             ("certificate", "Certificate / marksheet"), ("medical_record", "Medical record / prescription"), ("other", "Other")]
CATEGORIES = [("business", "Business"), ("legal", "Legal"), ("finance", "Finance"), ("personal", "Personal"),
              ("education", "Education"), ("health", "Health")]
# Only these may render inline in the browser; anything else is always sent as a download.
_INLINE_OK = {"application/pdf", "image/png", "image/jpeg", "image/gif", "image/webp", "text/plain"}


def _name(d: Document) -> str:
    return d.display_name or d.original_filename


def _ext(name: str) -> str:
    return name.rsplit(".", 1)[-1].lower() if "." in name else ""


def _doc_ctx(d: Document) -> dict[str, Any]:
    return {"id": d.id, "name": _name(d), "size": d.size_bytes or 0, "ext": _ext(d.original_filename),
            "added": d.created_at, "classification": d.classification}


async def _owned(db: AsyncSession, user, doc_id: str) -> Document:
    """Owner (or superuser) only: same rule as DocumentService.get_for_user."""
    return await DocumentService(db).get_for_user(doc_id, user.id, is_superuser=user.is_superuser)


async def _tags(db: AsyncSession, doc_id: str) -> list[str]:
    rows = await db.scalars(select(Tag.name).join(document_tags, document_tags.c.tag_id == Tag.id)
                            .where(document_tags.c.document_id == doc_id).order_by(Tag.name))
    return list(rows.all())


# ── /home, /search ───────────────────────────────────────────────────────────
@router.get("/home", response_class=HTMLResponse)
async def home(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    actions = [
        {"icon": "upload", "title": "Upload", "text": "Encrypt and store a document.", "cta": "Upload Document", "href": "/documents/upload"},
        {"icon": "share", "title": "Share", "text": "Create a secure, expiring link.", "cta": "Create Link", "href": "/shares/create"},
        {"icon": "file", "title": "Documents", "text": "View and manage your files.", "cta": "My Documents", "href": "/documents"},
        {"icon": "chart", "title": "Analytics", "text": "See access activity.", "cta": "View Analytics", "href": "/analytics"},
    ]
    quick = [
        {"icon": "upload", "label": "Upload", "href": "/documents/upload"},
        {"icon": "link", "label": "New secure link", "href": "/shares/create"},
        {"icon": "share", "label": "My shares", "href": "/shares"},
        {"icon": "bell", "label": "Notifications", "href": "/notifications"},
        {"icon": "user", "label": "Profile", "href": "/profile"},
    ]
    return await _render(request, db, user, "dashboard/home.html", actions=actions, quick=quick)


@router.get("/search")
async def search(request: Request, q: str = ""):
    return RedirectResponse(f"/documents?q={quote(q)}", status_code=303)


# ── upload (static path: registered BEFORE /documents/{doc_id}) ──────────────
async def _upload_page(request: Request, db: AsyncSession, user, doc_id: str | None, error: str | None = None,
                       status: int = 200):
    s = get_settings()
    doc = None
    doc_row = None
    if doc_id:
        doc_row = await _owned(db, user, doc_id)
        doc = {"id": doc_row.id, "name": _name(doc_row), "size": doc_row.size_bytes or 0}
    html = await _render(
        request, db, user, "documents/upload.html", doc=doc, error=error,
        types_label=", ".join(e.upper() for e in s.allowed_extensions[:6]), max_mb=s.max_upload_bytes // (1024 * 1024),
        accept="." + ",.".join(s.allowed_extensions), doc_types=DOC_TYPES, categories=CATEGORIES,
        selected_type=(doc_row.doc_type if doc_row and doc_row.doc_type else "report"),
        selected_category=(doc_row.category if doc_row and doc_row.category else "business"),
        tags=(await _tags(db, doc_row.id)) if doc_row else [])
    html.status_code = status
    return html


@router.get("/documents/upload", response_class=HTMLResponse)
async def upload_page(request: Request, db: Annotated[AsyncSession, Depends(get_db)], doc: str | None = None):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    return await _upload_page(request, db, user, doc)


@router.post("/documents/upload")
async def upload_details(request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                         doc: str = Form(""), doc_type: str = Form(""), category: str = Form(""),
                         new_tag: str = Form("")):
    """'Save details' for an already-uploaded document (the file itself is posted by upload.js to
    /api/v1/documents/upload, which stores + encrypts it and returns the new id)."""
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    if not doc:
        return await _upload_page(request, db, user, None, error="Upload a file first, then save its details.", status=400)
    row = await _owned(db, user, doc)
    if doc_type in dict(DOC_TYPES):
        row.doc_type = doc_type
    await DocumentService(db).update(
        doc_id=row.id, user_id=user.id, is_superuser=user.is_superuser,
        category=category if category in dict(CATEGORIES) else None,
        ip_address=get_client_ip(request), user_agent=get_user_agent(request))
    tag = new_tag.strip()[:32]
    if tag:
        t = await db.scalar(select(Tag).where(Tag.owner_id == user.id, Tag.name == tag))
        if t is None:
            t = Tag(owner_id=user.id, name=tag)
            db.add(t)
            await db.flush()
        linked = await db.scalar(select(document_tags.c.tag_id).where(
            document_tags.c.document_id == row.id, document_tags.c.tag_id == t.id))
        if linked is None:
            await db.execute(document_tags.insert().values(document_id=row.id, tag_id=t.id))
    await db.commit()
    return RedirectResponse(f"/documents/upload?doc={row.id}", status_code=303)


# ── detail ───────────────────────────────────────────────────────────────────
@router.get("/documents/{doc_id}", response_class=HTMLResponse)
async def document_detail(doc_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                          tab: str = "overview"):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    d = await _owned(db, user, doc_id)
    tab = tab if tab in ("overview", "activity", "permissions") else "overview"
    activity: list[dict[str, Any]] = []
    grants: list[dict[str, Any]] = []
    if tab == "activity":
        for row in (await db.scalars(select(AuditLog).where(AuditLog.resource_id == d.id)
                                     .order_by(AuditLog.created_at.desc()).limit(50))).all():
            icon, kind, title = stats.action_view(row.action)
            activity.append({"icon": icon, "kind": kind, "title": title,
                             "detail": str((row.details or {}).get("filename") or row.resource_type or ""),
                             "when": row.created_at})
    elif tab == "permissions":
        for lk in (await db.scalars(select(SecureLink).where(
                SecureLink.document_id == d.id, SecureLink.created_by == user.id,
                SecureLink.status == "ACTIVE").order_by(SecureLink.created_at.desc()))).all():
            perms = ["VIEW"] + (["DOWNLOAD"] if lk.allow_downloads else [])
            grants.append({"recipient": f"Link {lk.token_prefix}…", "permissions": perms,
                           "expires": lk.expires_at.strftime("%Y-%m-%d %H:%M") if lk.expires_at else "Never"})
    return await _render(request, db, user, "documents/detail.html", doc=_doc_ctx(d), tab=tab, activity=activity,
                         grants=grants, can_download=True, download_reason="")


# ── view / download (authorise first, decrypt second, audit always) ──────────
async def _serve(doc_id: str, request: Request, db: AsyncSession, action: Permission, disposition: str):
    session, user = await get_optional_user(request, db)
    if not user or user.is_deleted:
        nxt = quote(request.url.path, safe="/")
        return RedirectResponse(f"/login?next={nxt}", status_code=303)
    doc = await get_document_or_404(db, doc_id)
    mfa = bool(session and session.mfa_verified and user.mfa_enabled)
    out = await AccessControlService(db).authorize(
        user, doc, action, ip=get_client_ip(request), user_agent=get_user_agent(request), mfa_verified=mfa)
    if not out.allowed:
        await db.commit()                      # keep the ACCESS_DENIED audit row, then refuse (403 page, not 500)
        raise PermissionDeniedError("Access denied.", details={"reasons": out.reasons})
    stream = await DocumentService(db).open_stream(doc)
    await db.commit()
    ctype = mimetypes.guess_type(doc.original_filename)[0] or "application/octet-stream"
    if disposition == "inline" and ctype not in _INLINE_OK:
        disposition = "attachment"
    safe = doc.original_filename.replace('"', "").replace("\r", "").replace("\n", "")
    headers = {"Content-Disposition": f"{disposition}; filename=\"{safe}\"; filename*=UTF-8''{quote(safe)}",
               "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"}
    if disposition == "inline":
        headers["Content-Security-Policy"] = "frame-ancestors 'none'" if ctype == "application/pdf" else "sandbox"
    return StreamingResponse(stream, media_type=ctype, headers=headers)


@router.get("/documents/{doc_id}/viewer")
async def document_view(doc_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    return await _serve(doc_id, request, db, Permission.VIEW, "inline")


@router.get("/documents/{doc_id}/download")
async def document_download(doc_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    return await _serve(doc_id, request, db, Permission.DOWNLOAD, "attachment")


# ── share / rename / delete / revoke ─────────────────────────────────────────
@router.get("/documents/{doc_id}/share")
async def document_share(doc_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    d = await _owned(db, user, doc_id)
    return RedirectResponse(f"/shares/create?document_id={d.id}", status_code=303)


@router.get("/documents/{doc_id}/rename", response_class=HTMLResponse)
async def rename_page(doc_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    d = await _owned(db, user, doc_id)
    return await _render(request, db, user, "documents/rename.html", doc=_doc_ctx(d), error=None)


@router.post("/documents/{doc_id}/rename")
async def rename_submit(doc_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                        display_name: str = Form("")):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    name = display_name.strip()
    if not name or len(name) > 500:
        raise ValidationError("Enter a name between 1 and 500 characters.")
    await DocumentService(db).update(doc_id=doc_id, user_id=user.id, is_superuser=user.is_superuser,
                                     display_name=name, ip_address=get_client_ip(request),
                                     user_agent=get_user_agent(request))
    await db.commit()
    return RedirectResponse(f"/documents/{doc_id}", status_code=303)


@router.post("/documents/{doc_id}/delete")
async def document_delete(doc_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    await DocumentService(db).delete(doc_id, user.id, is_superuser=user.is_superuser,
                                     ip_address=get_client_ip(request), user_agent=get_user_agent(request))
    await db.commit()
    return RedirectResponse("/documents", status_code=303)


@router.post("/documents/{doc_id}/revoke-links")
async def document_revoke_links(doc_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    d = await _owned(db, user, doc_id)
    svc = SecureLinkService(db)
    ids = (await db.scalars(select(SecureLink.id).where(
        SecureLink.document_id == d.id, SecureLink.created_by == user.id, SecureLink.status == "ACTIVE"))).all()
    for link_id in ids:
        await svc.revoke_link(link_id, user.id, reason="owner_revoked_all",
                              ip_address=get_client_ip(request), user_agent=get_user_agent(request))
    await db.commit()
    return RedirectResponse(f"/documents/{d.id}?tab=permissions", status_code=303)


# ── versions / compare ────────────────────────────────────────────
async def _versions(db: AsyncSession, doc_id: str) -> list[DocumentVersion]:
    return list((await db.scalars(select(DocumentVersion).where(
        DocumentVersion.document_id == doc_id, DocumentVersion.is_deleted.is_(False))
        .order_by(DocumentVersion.version_number.desc()))).all())


@router.get("/documents/{doc_id}/versions", response_class=HTMLResponse)
async def document_versions(doc_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    d = await _owned(db, user, doc_id)
    vs = await _versions(db, d.id)
    latest = vs[0].version_number if vs else 1
    rows = [{"number": v.version_number, "latest": v.version_number == latest, "created": v.created_at,
             "size": v.size_bytes or 0, "summary": v.change_summary or "Initial upload"} for v in vs]
    return await _render(request, db, user, "documents/versions.html", doc=_doc_ctx(d), versions=rows,
                         latest_number=latest,
                         version_options=[(v.version_number, f"v{v.version_number}") for v in vs])


@router.get("/documents/{doc_id}/compare", response_class=HTMLResponse)
async def document_compare(doc_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                           a: int = 1, b: int = 1):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    d = await _owned(db, user, doc_id)
    by_no = {v.version_number: v for v in await _versions(db, d.id)}
    if a not in by_no or b not in by_no:
        raise NotFoundError("Version not found.")
    pick = lambda v: {"number": v.version_number, "size": v.size_bytes or 0, "sha256": v.sha256 or ""}  # noqa: E731
    return await _render(request, db, user, "documents/compare.html", doc=_doc_ctx(d), a=pick(by_no[a]),
                         b=pick(by_no[b]), diff=None)
