"""Real, database-backed pages: /dashboard, /documents (list), /analytics, /notifications.

These replace the sample-data pages in app/web/showcase.py. They are registered BEFORE the
showcase router and the showcase router is only mounted in debug mode, under /dev/showcase.
Every number comes from a query; with no data the page shows zeros / its empty state, never invented values.

NOTE: written in a sandbox where FastAPI/SQLAlchemy could not be installed, so these routes are
compiled but have NEVER been executed. They need an integration test run by the project owner.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_db, get_optional_user
from app.core.enums import UserStatus
from app.middleware.csrf import get_csrf_token
from app.models.document import Document
from app.models.document_version import DocumentVersion
from app.models.notification import Notification
from app.models.secure_link import SecureLink
from app.models.user import User
from app.services.auth import is_guest_user
from app.services import stats
from app.services.documents import DocumentService
from app.services.search import search as lexical_search
from app.web.templating import build_env

router = APIRouter(tags=["web-real"], include_in_schema=False)
env = build_env()
PAGE_SIZE = 20
LOGIN_FAILURE_ACTIONS = ("USER_LOGIN_FAILED",)


def _user_ctx(user: User) -> dict[str, Any]:
    parts = (user.full_name or user.email).split()
    return {"name": user.full_name or user.email, "initials": "".join(p[0] for p in parts[:2]).upper() or "U",
            "role": user.role, "email": user.email,
            "is_guest": is_guest_user(user), "email_verified": bool(user.email_verified),
            "phone_verified": bool(user.phone_verified)}


async def _auth(request: Request, db: AsyncSession):
    _, user = await get_optional_user(request, db)
    if not user or user.status != UserStatus.ACTIVE.value or user.is_deleted:
        nxt = request.url.path + (f"?{request.url.query}" if request.url.query else "")
        return None, RedirectResponse(f"/login?next={nxt}", status_code=303)
    return user, None


async def _render(request: Request, db: AsyncSession, user: User, name: str, **ctx: Any) -> HTMLResponse:
    html = env.get_template(name).render(
        user=_user_ctx(user), unread=await stats.unread_count(db, user.id),
        csrf_token=get_csrf_token(request), request_id=getattr(request.state, "request_id", ""), **ctx)
    return HTMLResponse(html, headers={"Cache-Control": "no-store"})


@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    now = stats.utcnow()
    week = now - timedelta(days=7)
    ov = await stats.user_overview(db, user)
    denied = len(await stats.audit_times(db, user_id=user.id, since=week, actions=stats.DENIAL_ACTIONS))
    failed = len(await stats.audit_times(db, user_id=user.id, since=week, actions=LOGIN_FAILURE_ACTIONS))
    encrypted = int(await db.scalar(
        select(func.count(func.distinct(DocumentVersion.document_id)))
        .join(Document, Document.id == DocumentVersion.document_id)
        .where(Document.owner_id == user.id, Document.is_deleted.is_(False),
               DocumentVersion.is_deleted.is_(False), DocumentVersion.encryption_algorithm.is_not(None))) or 0)
    used = int(await db.scalar(select(func.coalesce(func.sum(Document.size_bytes), 0)).where(
        Document.owner_id == user.id, Document.is_deleted.is_(False))) or 0)
    metrics = [
        {"label": "Total Documents", "value": ov["documents"], "delta": None, "icon": "file", "suffix": ""},
        {"label": "Active Links", "value": ov["active_links"], "delta": None, "icon": "link", "suffix": ""},
        {"label": "Total Downloads", "value": ov["downloads"], "delta": None, "icon": "download", "suffix": ""},
        {"label": "Denied Access (7d)", "value": denied, "delta": None, "icon": "shield", "suffix": ""},
        {"label": "Failed Logins (7d)", "value": failed, "delta": None, "icon": "alert", "suffix": ""},
    ]
    metrics.insert(1, {"label": "Encrypted Documents", "value": encrypted, "delta": None, "icon": "lock", "suffix": ""})
    return await _render(request, db, user, "dashboard/dashboard.html", hour=datetime.now().hour,
                          email_unverified=not user.email_verified and not is_guest_user(user),
                         metrics=metrics, activity=ov["activity"], recent=ov["recent"], storage_used=used)


@router.get("/documents", response_class=HTMLResponse)
async def documents(request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                    q: str = "", filter: str = "all", page: int = 1):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    if filter not in ("all", "recent", "shared", "personal"):
        filter = "all"
    rows, _total = await DocumentService(db).list_for_user(user.id, page=1, page_size=500)
    shared_ids = set((await db.scalars(select(SecureLink.document_id).where(
        SecureLink.created_by == user.id, SecureLink.status == "ACTIVE"))).all())
    records = [{"id": d.id, "name": d.display_name or d.original_filename, "owner": user.email,
                "classification": d.classification, "created": d.created_at, "updated": d.updated_at,
                "size": d.size_bytes or 0, "shared": d.id in shared_ids, "tags": [], "ocr_text": ""}
               for d in rows]
    if filter == "shared":
        records = [r for r in records if r["shared"]]
    elif filter == "personal":
        records = [r for r in records if not r["shared"]]
    elif filter == "recent":
        cutoff = stats.utcnow() - timedelta(days=14)
        records = [r for r in records if r["created"] and r["created"] >= cutoff]
    res = lexical_search(records, q, sort="relevance" if q else "created", page=max(page, 1), page_size=PAGE_SIZE)
    docs = [{"id": r["id"], "name": r["name"], "ext": r["name"].rsplit(".", 1)[-1].lower() if "." in r["name"] else "",
             "size": r["size"], "updated": r["updated"], "shared": r["shared"]} for r in res.items]
    return await _render(request, db, user, "documents/list.html", docs=docs, filter=filter, q=q,
                         page=res.page, pages=res.pages)


@router.get("/analytics", response_class=HTMLResponse)
async def analytics_page(request: Request, db: Annotated[AsyncSession, Depends(get_db)], range: int = 7):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    days = range if range in (7, 30, 90) else 7
    data = await stats.analytics(db, user, days)
    return await _render(request, db, user, "analytics/analytics.html", **data)


@router.get("/notifications", response_class=HTMLResponse)
async def notifications(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    rows = (await db.scalars(select(Notification).where(Notification.user_id == user.id)
                             .order_by(Notification.created_at.desc()).limit(100))).all()
    items = [{"kind": n.type, "title": n.title, "detail": n.message, "when": n.created_at, "read": n.read}
             for n in rows]
    return await _render(request, db, user, "notifications/list.html", notifications=items)


@router.post("/notifications/mark-all-read")
async def mark_all_read(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    await db.execute(update(Notification).where(Notification.user_id == user.id, Notification.read.is_(False))
                     .values(read=True, read_at=datetime.now(timezone.utc).replace(tzinfo=None)))
    await db.commit()
    return RedirectResponse("/notifications", status_code=303)
