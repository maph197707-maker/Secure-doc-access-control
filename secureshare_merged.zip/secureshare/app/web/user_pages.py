"""User pages that used to 404: /shared-with-me, /access-requests, /signatures, /signatures/verify,
/security/risk, /security/alerts, /documents/{id}/security.

Every page is scoped to the signed-in user. Documents shared with you are listed by name and opened through
the normal authorised viewer/download routes: this module never reads or decrypts document content.

NOTE: written without FastAPI/SQLAlchemy installed in the authoring sandbox. Compiled and the template
rendered with Jinja only; the queries have NOT been executed. Run tests/api/test_user_pages.py.
"""
from __future__ import annotations

import base64
from datetime import datetime, timezone
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_client_ip, get_db, get_user_agent
from app.crypto.signatures import SigAlg, verify as sig_verify
from app.models.access_grant import AccessGrant
from app.models.access_request import AccessRequest
from app.models.dlp_finding import DLPFinding
from app.models.document import Document
from app.models.risk import RiskAssessment
from app.models.secure_link import SecureLink
from app.models.security_alert import SecurityAlert
from app.models.signature import Signature
from app.models.user import User
from app.repositories.audit import AuditRepository
from app.services import grants_logic as gl
from app.services import notifications as nt
from app.web.admin_pages import SEVERITY, STATUS, Page, Section, _emails, badge, short, when, yes
from app.web.dashboard import _auth, _render
from app.web.documents import _owned
from app.web.templating import filesize

router = APIRouter(tags=["web-user-pages"], include_in_schema=False)


def _naive_now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


async def _table(request: Request, db: AsyncSession, user: User, page: Page, nav: str, status: int = 200) -> HTMLResponse:
    resp = await _render(request, db, user, "user/table.html", page=page, nav_active=nav)
    resp.status_code = status
    return resp


# ── /shared-with-me ──────────────────────────────────────────────────────────────────────────
@router.get("/shared-with-me", response_class=HTMLResponse)
async def shared_with_me(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    now = _naive_now()
    pairs = (await db.execute(
        select(AccessGrant, Document).join(Document, Document.id == AccessGrant.document_id)
        .where(AccessGrant.grantee_id == user.id, AccessGrant.revoked_at.is_(None),
               or_(AccessGrant.expires_at.is_(None), AccessGrant.expires_at > now), Document.is_deleted.is_(False))
        .order_by(AccessGrant.created_at.desc()).limit(200))).all()
    who = await _emails(db, {d.owner_id for _, d in pairs})
    rows = []
    for g, d in pairs:
        perms = list(g.permissions or [])
        links = [("View", f"/documents/{d.id}/viewer")] + ([("Download", f"/documents/{d.id}/download")] if "DOWNLOAD" in perms else [])
        rows.append([d.display_name or d.original_filename, who(d.owner_id), ", ".join(perms) or "-",
                     when(g.expires_at) if g.expires_at else "Never", when(g.created_at), {"links": links}])
    page = Page("Shared with me", "Documents other people have granted you access to. Opening one is checked against the owner's rules every time.",
                [Section("Documents", ["Document", "Owner", "Permissions", "Expires", "Shared", "Open"], rows,
                         "Nothing has been shared with you yet.")], [("Documents", len(rows))])
    return await _table(request, db, user, page, "sharing")


# ── /access-requests ─────────────────────────────────────────────────────────────────────────
@router.get("/access-requests", response_class=HTMLResponse)
async def access_requests(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    return await _access_page(request, db, user)


async def _access_page(request: Request, db: AsyncSession, user: User, status: int = 200, error: str | None = None):
    incoming = (await db.execute(
        select(AccessRequest, Document).join(Document, Document.id == AccessRequest.document_id)
        .where(Document.owner_id == user.id, Document.is_deleted.is_(False))
        .order_by(AccessRequest.created_at.desc()).limit(100))).all()
    mine = (await db.execute(
        select(AccessRequest, Document).join(Document, Document.id == AccessRequest.document_id)
        .where(AccessRequest.requester_id == user.id).order_by(AccessRequest.created_at.desc()).limit(100))).all()
    who = await _emails(db, {r.requester_id for r, _ in incoming})
    kinds = {"PENDING": "warning", "APPROVED": "success", "REJECTED": "danger"}
    rows_in = [[d.display_name or d.original_filename, who(r.requester_id), ", ".join(r.requested_permissions or []) or "-",
                r.reason or "-", badge(r.status, kinds), when(r.created_at),
                {"forms": [("Approve", f"/access-requests/{r.id}/approve"), ("Reject", f"/access-requests/{r.id}/reject")]}
                if r.status == "PENDING" else "-"] for r, d in incoming]
    rows_out = [[d.display_name or d.original_filename, ", ".join(r.requested_permissions or []) or "-", badge(r.status, kinds),
                 when(r.created_at)] for r, d in mine]
    page = Page("Access requests", "People asking for access to your documents, and the requests you have made.", [
        Section("Requests for my documents", ["Document", "Requester", "Permissions", "Reason", "Status", "Requested", "Decision"], rows_in,
                "Nobody has requested access to your documents."),
        Section("My requests", ["Document", "Permissions", "Status", "Requested"], rows_out, "You have not requested access to anything.")],
        [("Waiting for you", sum(1 for r, _ in incoming if r.status == "PENDING"))],
        note=error)
    return await _table(request, db, user, page, "sharing", status)


async def _review(request: Request, db: AsyncSession, user: User, request_id: str, decision: str):
    req = (await db.scalars(select(AccessRequest).where(AccessRequest.id == request_id))).first()
    doc = (await db.scalars(select(Document).where(Document.id == req.document_id))).first() if req else None
    # Only the owner decides. Same rule as POST /api/v1/access/requests/{id}/review.
    if not req or not doc or doc.owner_id != user.id:
        return await _access_page(request, db, user, 404, "That request was not found.")
    if req.status != "PENDING":
        return await _access_page(request, db, user, 409, "That request was already decided.")
    requester = (await db.scalars(select(User).where(User.id == req.requester_id))).one()
    req.status, req.reviewed_by, req.reviewed_at = decision, user.id, gl.utcnow()
    if decision == "APPROVED":
        from app.api.v1.shares import upsert_grant
        await upsert_grant(db, doc=doc, grantee=requester, granted_by=user,
                           permissions=gl.normalize_permissions(req.requested_permissions), expires_at=None)
    await AuditRepository(db).log_event(
        action="ACCESS_APPROVED" if decision == "APPROVED" else "ACCESS_REJECTED", user_id=user.id,
        resource_type="document", resource_id=doc.id, ip_address=get_client_ip(request),
        user_agent=get_user_agent(request), details={"request_id": req.id, "requester_id": requester.id})
    await nt.notify(db, requester.id, nt.ACCESS_APPROVED if decision == "APPROVED" else nt.ACCESS_REJECTED,
                    "Access request " + decision.lower(),
                    f"Your request for '{doc.display_name}' was {decision.lower()}.", "document", doc.id)
    await db.commit()
    return RedirectResponse("/access-requests", status_code=303)


@router.post("/access-requests/{request_id}/approve")
async def access_approve(request_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    return redirect or await _review(request, db, user, request_id, "APPROVED")


@router.post("/access-requests/{request_id}/reject")
async def access_reject(request_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    return redirect or await _review(request, db, user, request_id, "REJECTED")


# ── /signatures, /signatures/verify ──────────────────────────────────────────────────────────
async def _signature_rows(db: AsyncSession, user: User):
    return (await db.execute(
        select(Signature, Document).join(Document, Document.id == Signature.document_id)
        .where(Document.is_deleted.is_(False), or_(Document.owner_id == user.id, Signature.signer_id == user.id))
        .order_by(Signature.created_at.desc()).limit(200))).all()


def _result(v: bool | None) -> dict[str, str]:
    return badge("OK" if v else "FAILED", STATUS) if v is not None else badge("PENDING", STATUS)


@router.get("/signatures", response_class=HTMLResponse)
async def signatures(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    pairs = await _signature_rows(db, user)
    who = await _emails(db, {s.signer_id for s, _ in pairs})
    rows = [[d.display_name or d.original_filename, s.algorithm, who(s.signer_id), short(s.payload_sha256),
             _result(s.verify_result), when(s.verified_at), when(s.created_at)] for s, d in pairs]
    page = Page("Digital signatures", "Signatures on your documents. Check one on the verify page.",
                [Section("Signatures", ["Document", "Algorithm", "Signer", "Signed hash", "Last check", "Checked", "Signed"], rows,
                         "No documents are signed yet.")], [("Signatures", len(rows))],
                note="To check a signature, open Verify signatures (/signatures/verify).")
    return await _table(request, db, user, page, "documents")


async def _verify_page(request: Request, db: AsyncSession, user: User, message: str | None = None, status: int = 200):
    pairs = await _signature_rows(db, user)
    rows = [[d.display_name or d.original_filename, s.algorithm, short(s.payload_sha256), _result(s.verify_result), when(s.verified_at),
             {"forms": [("Verify now", f"/signatures/verify?id={s.id}")]}] for s, d in pairs]
    page = Page("Verify signatures", "Re-check a signature against the hash it was made over.",
                [Section("Signatures", ["Document", "Algorithm", "Signed hash", "Last check", "Checked", "Action"], rows, "No signatures to verify.")],
                note=message)
    return await _table(request, db, user, page, "documents", status)


@router.get("/signatures/verify", response_class=HTMLResponse)
async def signatures_verify_page(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    return await _verify_page(request, db, user)


@router.post("/signatures/verify", response_class=HTMLResponse)
async def signatures_verify(request: Request, db: Annotated[AsyncSession, Depends(get_db)], id: str = ""):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    hit = next(((s, d) for s, d in await _signature_rows(db, user) if s.id == id), None)
    if hit is None:
        return await _verify_page(request, db, user, "That signature was not found.", 404)
    sig = hit[0]
    try:
        ok = sig_verify(SigAlg(sig.algorithm), base64.b64decode(sig.public_key_reference),
                        bytes.fromhex(sig.payload_sha256), base64.b64decode(sig.signature_b64))
    except Exception:                                            # noqa: BLE001 - a malformed signature is a failed check
        ok = False
    sig.verify_result, sig.verified_at = ok, _naive_now()
    await db.commit()
    return await _verify_page(request, db, user, "Signature is valid." if ok else "Signature check FAILED.")


# ── /security/risk, /security/alerts ─────────────────────────────────────────────────────────
@router.get("/security/risk", response_class=HTMLResponse)
async def security_risk(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    rows_db = (await db.scalars(select(RiskAssessment).where(RiskAssessment.subject_id == user.id)
                                .order_by(RiskAssessment.assessed_at.desc()).limit(50))).all()
    rows = [[when(r.assessed_at), r.subject_type, f"{r.risk_score:.0f}", badge(r.risk_level, SEVERITY),
             "; ".join(str(f) for f in (r.factors or [])[:3]) or "-"] for r in rows_db]
    page = Page("My risk", "Risk assessments recorded for your account. Higher scores can trigger extra verification.",
                [Section("Assessments", ["When", "Subject", "Score", "Level", "Main factors"], rows, "No risk assessments recorded for you.")],
                [("Latest score", f"{rows_db[0].risk_score:.0f}" if rows_db else "-")])
    return await _table(request, db, user, page, "security")


@router.get("/security/alerts", response_class=HTMLResponse)
async def security_alerts(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    alerts = (await db.scalars(select(SecurityAlert).where(SecurityAlert.user_id == user.id)
                               .order_by(SecurityAlert.created_at.desc()).limit(100))).all()
    rows = [[when(a.created_at), a.alert_type, badge(a.severity, SEVERITY), a.message, yes(a.acknowledged),
             "-" if a.acknowledged else {"forms": [("Acknowledge", f"/security/alerts/{a.id}/acknowledge")]}] for a in alerts]
    page = Page("Security alerts", "Alerts about your account and documents.",
                [Section("Alerts", ["When", "Type", "Severity", "Message", "Acknowledged", "Action"], rows, "No security alerts. That is good news.")],
                [("Unacknowledged", sum(1 for a in alerts if not a.acknowledged))])
    return await _table(request, db, user, page, "security")


@router.post("/security/alerts/{alert_id}/acknowledge")
async def alert_ack(alert_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    a = (await db.scalars(select(SecurityAlert).where(SecurityAlert.id == alert_id, SecurityAlert.user_id == user.id))).first()
    if a and not a.acknowledged:
        a.acknowledged, a.acknowledged_by, a.acknowledged_at = True, user.id, _naive_now()
        await db.commit()
    return RedirectResponse("/security/alerts", status_code=303)


# ── /documents/{id}/security ─────────────────────────────────────────────────────────────────
@router.get("/documents/{doc_id}/security", response_class=HTMLResponse)
async def document_security(doc_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    d = await _owned(db, user, doc_id)                          # owner only; others get the normal not-found/denied page

    async def n(model: Any, *where: Any) -> int:
        return int(await db.scalar(select(func.count()).select_from(model).where(*where)) or 0)
    findings = await n(DLPFinding, DLPFinding.document_id == d.id)
    links = await n(SecureLink, SecureLink.document_id == d.id, SecureLink.status == "ACTIVE")
    signed = await n(Signature, Signature.document_id == d.id)
    grants = await n(AccessGrant, AccessGrant.document_id == d.id, AccessGrant.revoked_at.is_(None))
    rows = [["Classification", d.classification], ["Sensitivity level", d.sensitivity_level], ["Malware scan", d.malware_scan_result],
            ["DLP level", d.dlp_level], ["DLP findings", findings], ["Active links", links], ["People with access", grants],
            ["Digital signatures", signed], ["Size", filesize(d.size_bytes or 0)], ["SHA-256", d.sha256 or "-"]]
    page = Page(f"Security: {d.display_name or d.original_filename}", "Protection status for this document. Content is not shown.",
                [Section("Details", ["Property", "Value"], rows)])
    return await _table(request, db, user, page, "documents")
