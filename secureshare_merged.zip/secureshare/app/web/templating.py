"""Jinja2 environment for server-rendered pages.

* StrictUndefined: a missing context value fails loudly instead of rendering an empty string.
* Autoescape ON for every template; `|safe` is used only for server-generated SVG (icons, QR).
* Charts are rendered server-side as plain SVG (no JS library, CSP-friendly, works without JS).
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Sequence

from jinja2 import Environment, FileSystemLoader, StrictUndefined, select_autoescape

APP_DIR = Path(__file__).resolve().parent.parent
TEMPLATE_DIR = APP_DIR / "templates"
STATIC_DIR = APP_DIR / "static"


def filesize(n: int | float) -> str:
    size = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{int(size)} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    raise AssertionError("unreachable")


def relative_time(dt: datetime | None, now: datetime | None = None) -> str:
    if dt is None:
        return "never"
    now = now or datetime.now(timezone.utc)
    if dt.tzinfo is None:                      # SQLite returns naive datetimes; they are stored as UTC
        dt = dt.replace(tzinfo=timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    secs = int((now - dt).total_seconds())
    if secs < 0:
        return "in the future"
    if secs < 60:
        return "just now"
    for limit, div, unit in ((3600, 60, "min"), (86400, 3600, "h"), (7 * 86400, 86400, "d")):
        if secs < limit:
            return f"{secs // div} {unit} ago"
    return dt.strftime("%Y-%m-%d")


def number(n: int | float) -> str:
    return f"{n:,}"


def greeting(hour: int) -> str:
    return "Good morning" if hour < 12 else "Good afternoon" if hour < 18 else "Good evening"


def delta_text(delta: float | None) -> str:
    if delta is None:
        return "no prior data"
    return f"{'+' if delta >= 0 else ''}{delta:.0f}%"


def chart_points(values: Sequence[float], width: int = 600, height: int = 220, pad: int = 20) -> str:
    """SVG polyline points for a line chart; y axis starts at 0."""
    n = len(values)
    if n == 0:
        return ""
    vmax = max(max(values), 1)
    inner_w, inner_h = width - 2 * pad, height - 2 * pad
    pts = []
    for i, v in enumerate(values):
        x = pad + (inner_w / 2 if n == 1 else i * inner_w / (n - 1))
        y = height - pad - (v / vmax) * inner_h
        pts.append(f"{x:.1f},{y:.1f}")
    return " ".join(pts)


def chart_area(values: Sequence[float], width: int = 600, height: int = 220, pad: int = 20) -> str:
    pts = chart_points(values, width, height, pad)
    if not pts:
        return ""
    first_x, last_x = pts.split(" ")[0].split(",")[0], pts.split(" ")[-1].split(",")[0]
    base = height - pad
    return f"{first_x},{base} {pts} {last_x},{base}"


def chart_labels(labels: Sequence[str], width: int = 600, pad: int = 20) -> list[tuple[float, str]]:
    n = len(labels)
    inner = width - 2 * pad
    return [(round(pad + (inner / 2 if n == 1 else i * inner / (n - 1)), 1), lab) for i, lab in enumerate(labels)]


def donut_segments(values: Sequence[float]) -> list[dict[str, Any]]:
    """Segments for an SVG donut with r=15.9155 (circumference 100): dash lengths equal percentages."""
    total = float(sum(values))
    if total <= 0:
        return []
    out, acc = [], 0.0
    for v in values:
        pct = v / total * 100
        out.append({"pct": round(pct, 1), "dash": f"{pct:.2f} {100 - pct:.2f}", "offset": f"{25 - acc:.2f}"})
        acc += pct
    return out


def build_env(static_prefix: str = "/static") -> Environment:
    env = Environment(
        loader=FileSystemLoader(str(TEMPLATE_DIR)),
        autoescape=select_autoescape(enabled_extensions=("html", "xml", "svg"), default=True),
        undefined=StrictUndefined, trim_blocks=True, lstrip_blocks=True, enable_async=False,
    )
    env.filters.update(filesize=filesize, relative_time=relative_time, number=number, delta_text=delta_text,
                       chart_points=chart_points, chart_area=chart_area, chart_labels=chart_labels,
                       donut_segments=donut_segments)
    from app.config.settings import get_settings
    env.globals.update(static=lambda p: f"{static_prefix}/{p.lstrip('/')}", greeting=greeting,
                       guest_login_enabled=lambda: get_settings().guest_login_active)
    return env
