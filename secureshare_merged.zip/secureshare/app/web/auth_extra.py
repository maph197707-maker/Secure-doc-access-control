"""/passkey and /verify-identity: both had templates but no routes (404).

* /passkey: passkeys are NOT implemented in this build. The page says so and the POST refuses with 501.
  Nothing is faked; the "Use password instead" link works.
* /verify-identity: step-up check for a signed-in user with an authenticator app (TOTP). It uses the real
  IdentityService; on success the session records the step-up time and the user is sent on.

NOTE: written without FastAPI/SQLAlchemy installed in the authoring sandbox; compiled and rendered only.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Annotated

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_db, get_optional_user
from app.core.enums import UserStatus
from app.core.exceptions import AuthenticationError, ValidationError
from app.core.utils import safe_redirect_url
from app.middleware.csrf import get_csrf_token
from app.services.identity import IdentityService
from app.web.templating import build_env

router = APIRouter(tags=["web-auth-extra"], include_in_schema=False)
env = build_env()


def _html(name: str, request: Request, status: int = 200, **ctx) -> HTMLResponse:
    html = env.get_template(name).render(csrf_token=get_csrf_token(request),
                                         request_id=getattr(request.state, "request_id", ""), **ctx)
    return HTMLResponse(html, status_code=status, headers={"Cache-Control": "no-store"})


@router.get("/passkey", response_class=HTMLResponse)
async def passkey_get(request: Request):
    return _html("auth/passkey.html", request, passkey_available=False)


@router.post("/passkey", response_class=HTMLResponse)
async def passkey_post(request: Request):
    return _html("auth/passkey.html", request, 501, passkey_available=False)


def _steps(state: str) -> list[dict[str, str]]:
    return [{"label": "Signed in", "state": "done"}, {"label": "Authenticator code", "state": state}]


async def _active_user(request: Request, db: AsyncSession):
    session, user = await get_optional_user(request, db)
    if not user or user.status != UserStatus.ACTIVE.value or user.is_deleted:
        return None, None
    return session, user


@router.get("/verify-identity", response_class=HTMLResponse)
async def verify_identity_get(request: Request, db: Annotated[AsyncSession, Depends(get_db)], next: str = ""):
    session, user = await _active_user(request, db)
    if not user:
        return RedirectResponse("/login?next=/verify-identity", status_code=303)
    return _html("auth/verify_identity.html", request, locked_seconds=0, error=None, attempts_left=5,
                 steps=_steps("pending"))


@router.post("/verify-identity", response_class=HTMLResponse)
async def verify_identity_post(request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                               code: str = Form(""), next: str = Form("")):
    session, user = await _active_user(request, db)
    if not user:
        return RedirectResponse("/login?next=/verify-identity", status_code=303)
    try:
        await IdentityService(db).verify_totp(user.id, code.strip())
    except (AuthenticationError, ValidationError) as exc:
        return _html("auth/verify_identity.html", request, 400, locked_seconds=0, error=str(exc),
                     attempts_left=4, steps=_steps("failed"))
    if session is not None:
        session.step_up_verified_at = datetime.now(timezone.utc).replace(tzinfo=None)
    await db.commit()
    return RedirectResponse(safe_redirect_url(next, "/home"), status_code=303)
