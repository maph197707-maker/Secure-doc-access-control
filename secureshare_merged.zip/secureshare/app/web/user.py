"""Authenticated web pages for secure links: /shares, /shares/create, /shares/{id}.

Registered BEFORE the demo `showcase` router in main.py, so these real, database-backed routes win
over the sample-data pages that share the same paths.

Wizard state lives in the `share_drafts` table (one row per idempotency key). The link password is
hashed (argon2) the moment step 2 is submitted, so the plaintext is never stored in the draft.
"""
from __future__ import annotations

import math
import uuid
from datetime import datetime, timedelta, timezone
from typing import Annotated, Any

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from starlette.datastructures import UploadFile
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.dependencies import get_client_ip, get_db, get_optional_user, get_user_agent
from app.core.enums import UserStatus
from app.core.exceptions import NotFoundError, PermissionDeniedError, ValidationError
from app.crypto.password import hash_password
from app.integrations import factory
from app.services import expiry as expiry_tz, recipient_gate as gate
from app.middleware.csrf import get_csrf_token
from app.models.share_draft import ShareDraft
from app.models.user import User
from app.services.auth import is_guest_user
from app.services.db_status import database_status
from app.services.documents import DocumentService
from app.services.link_urls import base_url_for, share_url
from app.services.secure_links import SecureLinkService
from app.web.templating import build_env

router = APIRouter(tags=["web-shares"], include_in_schema=False)
env = build_env()
settings = get_settings()

def binding_modes() -> list[tuple[str, str, bool, str]]:
    """(value, label, available, why-not). A mode is selectable only when its delivery channel works
    in this deployment, so a link can never be created that nobody could ever open."""
    em_ok, sms_ok = factory.get_email_service() is not None, factory.get_sms_service() is not None
    em_why = sms_why = ""
    return [
        (gate.MODE_NONE, "Anyone with the link (password optional)", True, ""),
        (gate.MODE_EMAIL, "Recipient email: one-time code by email", em_ok, em_why or "Email delivery is not configured"),
        (gate.MODE_PHONE, "Recipient phone: one-time code by SMS", sms_ok, sms_why or "SMS delivery is not configured"),
    ]


def _naive_utc() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _user_ctx(user: User) -> dict[str, Any]:
    parts = (user.full_name or user.email).split()
    return {"name": user.full_name or user.email,
            "initials": "".join(p[0] for p in parts[:2]).upper() or "U",
            "role": user.role, "email": user.email,
            "is_guest": is_guest_user(user), "email_verified": bool(user.email_verified),
            "phone_verified": bool(user.phone_verified)}


def _render(request: Request, user: User, name: str, status: int = 200, **ctx: Any) -> HTMLResponse:
    html = env.get_template(name).render(
        user=_user_ctx(user), unread=0, csrf_token=get_csrf_token(request),
        request_id=getattr(request.state, "request_id", ""), **ctx)
    return HTMLResponse(html, status_code=status, headers={"Cache-Control": "no-store"})


async def _auth(request: Request, db: AsyncSession):
    """(user, None) when signed in and active, else (None, redirect-to-login)."""
    _, user = await get_optional_user(request, db)
    if not user or user.status != UserStatus.ACTIVE.value or user.is_deleted:
        nxt = request.url.path + (f"?{request.url.query}" if request.url.query else "")
        return None, RedirectResponse(f"/login?next={nxt}", status_code=303)
    return user, None


def _row(link, doc_name: str) -> dict[str, Any]:
    return {"id": link.id, "doc_name": doc_name, "status": link.status.lower(),
            "views": link.view_count, "max_views": link.max_views,
            "expires": link.expires_at.strftime("%Y-%m-%d %H:%M") if link.expires_at else "Never"}


def _qr_svg(url: str) -> str | None:
    try:
        import segno
        return segno.make(url, error="m").svg_inline(scale=4, border=1, dark="#0E1A3D")
    except Exception:           # segno missing/failing must never block link delivery
        return None


async def _documents(db: AsyncSession, user: User):
    docs, _ = await DocumentService(db).list_for_user(user.id, page=1, page_size=100)
    return [{"id": d.id, "name": d.display_name or d.original_filename, "size": d.size_bytes or 0}
            for d in docs]


# ── list ─────────────────────────────────────────────────────────────────────
@router.get("/shares", response_class=HTMLResponse)
async def shares_list(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    links, _ = await SecureLinkService(db).list_for_user(user.id, page=1, page_size=100)
    names = {}
    for lk in links:
        if lk.document_id not in names:
            d = await DocumentService(db).doc_repo.get_by_id(lk.document_id)
            names[lk.document_id] = (d.display_name or d.original_filename) if d else "(deleted)"
    return _render(request, user, "sharing/list.html",
                   shares=[_row(lk, names[lk.document_id]) for lk in links])


# ── create wizard ────────────────────────────────────────────────────────────
async def _draft(db: AsyncSession, user: User, key: str | None, create: bool = False) -> ShareDraft | None:
    if key:
        res = await db.execute(select(ShareDraft).where(
            ShareDraft.idempotency_key == key, ShareDraft.owner_id == user.id))
        d = res.scalar_one_or_none()
        if d and d.expires_at >= _naive_utc():
            return d
    if not create:
        return None
    d = ShareDraft(owner_id=user.id, step=1, data={}, idempotency_key=uuid.uuid4().hex,
                   expires_at=_naive_utc() + timedelta(hours=2))
    db.add(d)
    await db.flush()
    return d


async def _wizard_page(request, db, user, draft: ShareDraft, step: int, error: str | None = None,
                       status: int = 200):
    doc = None
    docs: list[dict] = []
    if draft.document_id:
        d = await DocumentService(db).doc_repo.get_by_id(draft.document_id)
        if d and d.owner_id == user.id:
            doc = {"id": d.id, "name": d.display_name or d.original_filename, "size": d.size_bytes or 0}
    if doc is None:
        docs = await _documents(db, user)
    return _render(
        request, user, "sharing/wizard.html", status, step=step, doc=doc, docs=docs, draft=draft.data,
        error=error, idempotency_key=draft.idempotency_key, binding_modes=binding_modes(),
        types_label=", ".join(e.upper() for e in settings.allowed_extensions[:6]),
        max_mb=settings.max_upload_bytes // (1024 * 1024),
        accept="." + ",.".join(settings.allowed_extensions))


@router.get("/shares/create", response_class=HTMLResponse)
async def wizard_get(request: Request, db: Annotated[AsyncSession, Depends(get_db)],
                     step: int = 1, document_id: str | None = None, key: str | None = None):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    draft = await _draft(db, user, key, create=True)
    if document_id and not draft.document_id:
        draft.document_id = document_id            # ownership re-checked when the page loads
    await db.commit()
    step = max(1, min(step, 4 if draft.document_id else 1))
    return await _wizard_page(request, db, user, draft, step)


def _form_bool(form, name: str) -> bool:
    return str(form.get(name, "")).lower() in {"on", "true", "1", "yes"}


@router.post("/shares/create", response_class=HTMLResponse)
async def wizard_post(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    form = await request.form()
    draft = await _draft(db, user, str(form.get("idempotency_key") or ""))
    if not draft:
        return RedirectResponse("/shares/create", status_code=303)   # finished/expired draft
    ip, ua = get_client_ip(request), get_user_agent(request)
    try:
        step = int(str(form.get("step", "1")))
    except ValueError:
        step = 1
    data = dict(draft.data or {})
    try:
        if step == 1:
            upload = form.get("file")
            if isinstance(upload, UploadFile) and upload.filename:
                doc = await DocumentService(db).upload(
                    owner_id=user.id, filename=upload.filename, content=await upload.read(),
                    ip_address=ip, user_agent=ua)
                draft.document_id = doc.id
            elif form.get("document_id"):
                d = await DocumentService(db).doc_repo.get_by_id(str(form["document_id"]))
                if not d or d.owner_id != user.id:
                    raise ValidationError("Choose one of your own documents.")
                draft.document_id = d.id
            if not draft.document_id:
                raise ValidationError("Choose a document or upload a file to continue.")
            nxt = 2
        elif step == 2:
            data["password_protect"] = _form_bool(form, "password_protect")
            pw = str(form.get("link_password") or "")
            if data["password_protect"]:
                if pw:
                    if len(pw) < 6:
                        raise ValidationError("Link password must be at least 6 characters.")
                    data["link_password_hash"] = hash_password(pw)   # plaintext is dropped here
                elif not data.get("link_password_hash"):
                    raise ValidationError("Enter a link password, or turn password protection off.")
            else:
                data.pop("link_password_hash", None)
            data["link_expiry"] = _form_bool(form, "link_expiry")
            data["expires_at"] = str(form.get("expires_at") or "")
            data["tz"] = str(form.get("tz") or "").strip() or expiry_tz.DEFAULT_TZ
            data["limit_views"] = _form_bool(form, "limit_views")
            mv = str(form.get("max_views") or "").strip()
            if data["limit_views"]:
                if not mv.isdigit() or not (1 <= int(mv) <= 10000):
                    raise ValidationError("Maximum views must be a number from 1 to 10000.")
                data["max_views"] = int(mv)
            else:
                data["max_views"] = None
            data["allow_download"] = _form_bool(form, "allow_download")
            data["one_time"] = _form_bool(form, "one_time")
            data["limit_downloads"] = _form_bool(form, "limit_downloads")
            md = str(form.get("max_downloads") or "").strip()
            if data["limit_downloads"] and data["allow_download"]:
                if not md.isdigit() or not (1 <= int(md) <= 10000):
                    raise ValidationError("Maximum downloads must be a number from 1 to 10000.")
                data["max_downloads"] = int(md)
            else:                                              # a download cap means nothing without downloads
                data["limit_downloads"], data["max_downloads"] = False, None
            data["one_time_download"] = _form_bool(form, "one_time_download") and data["allow_download"]
            data["start_at"] = str(form.get("start_at") or "").strip()
            expires = _expiry_from(data)                       # validates the expiry now
            start = _start_from(data)
            if start is not None and start >= expires:
                raise ValidationError("The start time must be before the expiry time.")
            nxt = 3
        elif step == 3:
            mode = str(form.get("binding_mode") or gate.MODE_NONE)
            avail = {m[0]: m for m in binding_modes()}
            if mode not in avail:
                raise ValidationError("Choose a verification mode from the list.")
            if not avail[mode][2]:
                raise ValidationError(f"{avail[mode][1]} is not available: {avail[mode][3]}.")
            data["binding_mode"] = mode
            data["recipient_email"] = str(form.get("recipient_email") or "").strip().lower()
            data["recipient_phone"] = str(form.get("recipient_phone") or "").strip()
            try:                                    # same rules the link service enforces at creation
                gate.clean_recipients([{"email": data["recipient_email"], "phone": data["recipient_phone"]}],
                                      mode, settings.sms_default_country_code)
            except gate.RecipientError as exc:
                raise ValidationError(str(exc)) from None
            nxt = 4
        else:
            return await _finalize(request, db, user, draft, data, ip, ua)
    except ValidationError as e:
        await db.commit()                                      # keep the (maybe) uploaded document
        shown = step if (step == 1 or draft.document_id) else 1
        return await _wizard_page(request, db, user, draft, shown, error=e.message, status=400)
    draft.data = data
    draft.step = nxt
    await db.commit()
    return await _wizard_page(request, db, user, draft, nxt)


def _expiry_from(data: dict[str, Any]) -> datetime:
    """Naive-UTC expiry. The wizard's datetime-local value is read in the browser's timezone
    (data['tz']); without a chosen time the default is 72 hours, and 'no expiry' is capped at a year."""
    now = _naive_utc()
    if not data.get("link_expiry"):
        return now + timedelta(hours=expiry_tz.MAX_HOURS)
    raw = data.get("expires_at") or ""
    if not raw:
        return now + timedelta(hours=72)
    try:
        return expiry_tz.expires_at(raw, data.get("tz"), now)
    except expiry_tz.ExpiryError as exc:
        raise ValidationError(str(exc)) from None


def _start_from(data: dict[str, Any]) -> datetime | None:
    """Naive-UTC 'not before' time, read in the browser's timezone like the expiry. Empty, or a time
    that has already passed, means the link is usable immediately (None)."""
    raw = (data.get("start_at") or "").strip()
    if not raw:
        return None
    try:
        when = expiry_tz.local_to_utc(raw, data.get("tz"))
    except expiry_tz.ExpiryError as exc:
        raise ValidationError(str(exc).replace("expiry", "start")) from None
    return when if when > _naive_utc() else None


async def _finalize(request, db, user, draft, data, ip, ua):
    if not draft.document_id:
        raise ValidationError("No document selected.")
    svc = SecureLinkService(db)
    email = data.get("recipient_email")
    mode = data.get("binding_mode") or gate.MODE_NONE
    try:
        link, raw = await svc.create_link(
            document_id=draft.document_id, created_by=user.id, expires_at_utc=_expiry_from(data),
            max_views=data.get("max_views"), max_downloads=data.get("max_downloads"),
            allow_downloads=bool(data.get("allow_download")),
            requires_password=bool(data.get("password_protect")),
            password_hash=data.get("link_password_hash"),
            one_time_view=bool(data.get("one_time")),
            one_time_download=bool(data.get("one_time_download")),
            valid_from_utc=_start_from(data),
            binding_mode=mode,
            recipients=[{"email": email, "phone": data.get("recipient_phone")}] if email else None,
            ip_address=ip, user_agent=ua)
    except ValidationError as e:
        await db.commit()
        return await _wizard_page(request, db, user, draft, 3, error=e.message, status=400)
    except (NotFoundError, PermissionDeniedError) as e:
        await db.commit()
        return await _wizard_page(request, db, user, draft, 1, error=e.message, status=403)
    await db.delete(draft)                                     # one-shot: a refresh can't re-create
    await db.commit()
    return await _link_ready(request, db, user, link, share_url(request, raw))


async def _link_ready(request, db, user, link, full_link: str | None):
    return _render(request, user, "sharing/link_ready.html", full_link=full_link,
                   qr_svg=_qr_svg(full_link) if full_link else None, share=_share_ctx(request, link))


def _share_ctx(request: Request, link) -> dict[str, Any]:
    return {"id": link.id, "status": link.status.lower(),
            "expires_at": link.expires_at.strftime("%Y-%m-%d %H:%M") if link.expires_at else "Never",
            "max_downloads": link.max_downloads if link.max_downloads is not None else "Unlimited",
            "max_views": link.max_views if link.max_views is not None else "Unlimited",
            "masked_link": f"{base_url_for(request)}/view/{link.token_prefix}…"}


# ── details / revoke / rotate ────────────────────────────────────────────────
@router.get("/shares/{link_id}", response_class=HTMLResponse)
async def share_detail(link_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    try:
        link = await SecureLinkService(db).get_owned(link_id, user.id)
    except NotFoundError as e:
        return _render(request, user, "errors/error.html", 404, code=404, title="Not found", message=e.message)
    return await _link_ready(request, db, user, link, None)


@router.post("/shares/{link_id}/revoke")
async def share_revoke(link_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    try:
        await SecureLinkService(db).revoke_link(link_id, user.id, ip_address=get_client_ip(request),
                                                user_agent=get_user_agent(request))
        await db.commit()
    except (NotFoundError, PermissionDeniedError):
        await db.rollback()
    return RedirectResponse(f"/shares/{link_id}", status_code=303)


@router.post("/shares/{link_id}/rotate", response_class=HTMLResponse)
async def share_rotate(link_id: str, request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    svc = SecureLinkService(db)
    try:
        link, raw = await svc.rotate_link(link_id, user.id, ip_address=get_client_ip(request),
                                          user_agent=get_user_agent(request))
        await db.commit()
    except (NotFoundError, PermissionDeniedError):
        await db.rollback()
        return RedirectResponse(f"/shares/{link_id}", status_code=303)
    return await _link_ready(request, db, user, link, share_url(request, raw))


# ── admin: database status (read-only; secrets never leave the server) ────────
@router.get("/admin/database", response_class=HTMLResponse)
async def admin_database(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    if not user.is_admin:
        return _render(request, user, "errors/error.html", 403, code=403, title="Forbidden",
                       message="Administrator access required.")
    return _render(request, user, "admin/database.html", info=await database_status(db))
