"""Developer and diagnostic web routes (active in dev/debug mode)."""
from __future__ import annotations

from fastapi import APIRouter, Depends, Request
from fastapi.responses import JSONResponse, RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.settings import get_settings
from app.core.dependencies import get_db
from app.services.db_status import database_status

router = APIRouter(prefix="/dev", tags=["dev"], include_in_schema=False)


@router.get("")
@router.get("/")
async def dev_index():
    settings = get_settings()
    if settings.debug:
        return RedirectResponse("/dev/showcase", status_code=303)
    return JSONResponse({"status": "dev endpoints disabled in production", "debug": False})


@router.get("/status")
async def dev_status(db: AsyncSession = Depends(get_db)):
    settings = get_settings()
    if not settings.debug:
        return JSONResponse({"status": "disabled"}, status_code=403)
    info = await database_status(db)
    return JSONResponse({"app_mode": settings.app_mode, "debug": settings.debug, "db": info})
