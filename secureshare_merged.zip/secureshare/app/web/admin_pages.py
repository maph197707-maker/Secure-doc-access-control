"""The 18 admin pages that used to 404: roles, permissions, documents, links, access, policies, security,
security-events, risk, devices, sessions, analytics, usage, audit, attack-simulator, system-health,
backup, reports.

Every page is read-only, admin-only (real 403 for non-admins, login redirect for anonymous), and shows
METADATA ONLY: no document content, no token hashes, no password hashes, no key material.

NOTE: written without FastAPI/SQLAlchemy installed in the authoring sandbox. Compiled, and the template
rendered with Jinja, but the queries have NOT been executed. Run tests/api/test_admin_pages.py.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Awaitable, Callable

from fastapi import APIRouter, Depends, Request
from fastapi.responses import HTMLResponse
from sqlalchemy import func, select, text
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Annotated

from app.config.settings import get_settings
from app.core.dependencies import get_db
from app.models.access_grant import AccessGrant
from app.models.access_policy import AccessPolicy
from app.models.audit import AuditLog
from app.models.device import Device
from app.models.document import Document
from app.models.risk import RiskAssessment
from app.models.role import Permission as PermissionRow, Role, user_roles
from app.models.secure_link import SecureLink
from app.models.security_alert import SecurityAlert
from app.models.security_event import SecurityEvent
from app.models.session import UserSession
from app.models.user import User
from app.services import attack_simulator, stats
from app.web.admin import _render, _require_admin_web
from app.web.templating import filesize

router = APIRouter(prefix="/admin", tags=["web-admin-pages"], include_in_schema=False)

SEVERITY = {"LOW": "info", "MEDIUM": "warning", "HIGH": "danger", "CRITICAL": "danger", "INFO": "info"}
STATUS = {"ACTIVE": "success", "TRUSTED": "success", "OK": "success", "REVOKED": "danger", "EXPIRED": "warning",
          "FAILED": "danger", "BLOCKED": "danger", "PENDING": "warning", "UNKNOWN": "neutral"}


# ── cell helpers (cells are plain strings, or {"badge": text, "kind": kind}) ────────────────
def badge(value: Any, kinds: dict[str, str]) -> dict[str, str]:
    s = str(value if value is not None else "-")
    return {"badge": s.capitalize() if s.isupper() else s, "kind": kinds.get(s.upper(), "neutral")}


def when(v: datetime | None) -> str:
    return v.strftime("%Y-%m-%d %H:%M") if v else "-"


def yes(v: Any) -> str:
    return "Yes" if v else "No"


def short(v: str | None) -> str:
    return (v[:8] + "…") if v else "-"


@dataclass
class Section:
    title: str
    columns: list[str]
    rows: list[list[Any]]
    empty: str = "Nothing to show yet."


@dataclass
class Page:
    title: str
    blurb: str
    sections: list[Section] = field(default_factory=list)
    summary: list[tuple[str, Any]] = field(default_factory=list)
    note: str | None = None


Loader = Callable[[AsyncSession], Awaitable[Page]]


async def _emails(db: AsyncSession, ids: set[str | None]) -> Callable[[str | None], str]:
    clean = {i for i in ids if i}
    found: dict[str, str] = {}
    if clean:
        found = dict((await db.execute(select(User.id, User.email).where(User.id.in_(clean)))).all())
    return lambda i: found.get(i, short(i)) if i else "-"


def _live(model: Any):
    """`is_deleted` filter for models that have it."""
    return [model.is_deleted.is_(False)] if hasattr(model, "is_deleted") else []


def table_page(*, title: str, blurb: str, model: Any, order: Any, columns: list[tuple[str, Callable]],
               user_attrs: tuple[str, ...] = (), limit: int = 200, note: str | None = None,
               empty: str = "Nothing to show yet.") -> Loader:
    """Generic loader: newest `limit` rows of `model`, each column is (header, fn(row, who))."""
    async def load(db: AsyncSession) -> Page:
        rows = (await db.scalars(select(model).where(*_live(model)).order_by(order.desc()).limit(limit))).all()
        who = await _emails(db, {getattr(r, a, None) for r in rows for a in user_attrs})
        body = [[fn(r, who) for _, fn in columns] for r in rows]
        total = int(await db.scalar(select(func.count()).select_from(model).where(*_live(model))) or 0)
        return Page(title, blurb, [Section(title, [h for h, _ in columns], body, empty)],
                    [("Total", total), ("Shown", len(body))], note)
    return load


# ── custom loaders ───────────────────────────────────────────────────────────────────────────
async def _roles(db: AsyncSession) -> Page:
    roles = (await db.scalars(select(Role).order_by(Role.name))).all()
    counts = dict((await db.execute(select(user_roles.c.role_id, func.count()).group_by(user_roles.c.role_id))).all())
    rows = [[r.name, r.description or "-", yes(r.is_system), len(r.permissions), int(counts.get(r.id, 0))] for r in roles]
    return Page("Roles", "Roles and how many permissions and users each one has.",
                [Section("Roles", ["Role", "Description", "System role", "Permissions", "Users"], rows, "No roles are seeded. Run scripts/seed_roles.py.")],
                [("Roles", len(rows))])


async def _permissions(db: AsyncSession) -> Page:
    perms = (await db.scalars(select(PermissionRow).order_by(PermissionRow.code))).all()
    rows = [[p.code, p.resource or "-", p.description or "-", ", ".join(sorted(r.name for r in p.roles)) or "-"] for p in perms]
    return Page("Permissions", "Every permission code and the roles that hold it.",
                [Section("Permissions", ["Code", "Resource", "Description", "Held by roles"], rows, "No permissions are seeded. Run scripts/seed_roles.py.")],
                [("Permissions", len(rows))])


async def _audit(db: AsyncSession) -> Page:
    chain = await stats.verify_audit_chain(db)
    rows = (await db.scalars(select(AuditLog).order_by(AuditLog.created_at.desc()).limit(100))).all()
    who = await _emails(db, {r.user_id for r in rows})
    body = [[when(r.created_at), r.sequence_number or "-", r.action, who(r.user_id),
             f"{r.resource_type or '-'} {short(r.resource_id)}".strip(), r.ip_address or "-"] for r in rows]
    summary = [("Entries", chain["count"]), ("Chain", "Intact" if chain["ok"] else f"BROKEN at #{chain['broken_at']}"),
               ("Head", chain["head"])]
    return Page("Audit log", "Tamper-evident, hash-chained record of security-relevant actions (latest 100).",
                [Section("Latest entries", ["Time", "#", "Action", "User", "Resource", "IP"], body, "No audit entries yet.")], summary)


async def _analytics(db: AsyncSession) -> Page:
    since = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=7)
    top = (await db.execute(select(AuditLog.action, func.count().label("n")).where(AuditLog.created_at >= since)
                            .group_by(AuditLog.action).order_by(func.count().desc()).limit(15))).all()

    async def count(model: Any, *where: Any) -> int:
        return int(await db.scalar(select(func.count()).select_from(model).where(*_live(model), *where)) or 0)
    summary = [("Users", await count(User)), ("Documents", await count(Document)),
               ("Active links", await count(SecureLink, SecureLink.status == "ACTIVE")),
               ("Open alerts", await count(SecurityAlert, SecurityAlert.acknowledged.is_(False))),
               ("Audit events (7d)", sum(n for _, n in top))]
    return Page("System analytics", "Platform-wide totals and the most frequent actions in the last 7 days.",
                [Section("Top actions (7 days)", ["Action", "Count"], [[a, n] for a, n in top], "No activity in the last 7 days.")], summary)


async def _usage(db: AsyncSession) -> Page:
    rows = (await db.execute(select(Document.owner_id, func.count(), func.coalesce(func.sum(Document.size_bytes), 0))
                             .where(Document.is_deleted.is_(False)).group_by(Document.owner_id)
                             .order_by(func.coalesce(func.sum(Document.size_bytes), 0).desc()).limit(25))).all()
    who = await _emails(db, {r[0] for r in rows})
    total = int(await db.scalar(select(func.coalesce(func.sum(Document.size_bytes), 0)).where(Document.is_deleted.is_(False))) or 0)
    return Page("Usage", "Storage and document counts per user (top 25 by storage).",
                [Section("Storage by user", ["User", "Documents", "Storage"], [[who(o), n, filesize(s)] for o, n, s in rows], "No documents uploaded yet.")],
                [("Total storage", filesize(total)), ("Users with documents", len(rows))])


async def _attack(db: AsyncSession) -> Page:
    res = attack_simulator.run()
    body = [[r["scenario"], r["expected"], r["actual"], badge("OK" if r["passed"] else "FAILED", STATUS)] for r in res["results"]]
    return Page("Attack simulator", "Hostile access scenarios replayed against the real policy engine. This runs in memory and touches no data.",
                [Section("Scenarios", ["Scenario", "Expected", "Actual", "Result"], body)],
                [("Passed", f"{res['passed']} / {res['total']}")])


async def _health(db: AsyncSession) -> Page:
    from app.integrations import factory
    s = get_settings()
    checks: list[list[Any]] = []

    def add(name: str, ok: bool, detail: str, warn: bool = False) -> None:
        checks.append([name, badge("OK" if ok else ("PENDING" if warn else "FAILED"), STATUS), detail])
    try:
        await db.execute(text("SELECT 1"))
        add("Database", True, s.database_url.split(":", 1)[0])
    except Exception as exc:                                  # noqa: BLE001
        add("Database", False, type(exc).__name__)
    for label, p in (("Encrypted storage", s.storage_root), ("Quarantine", s.quarantine_root), ("Temporary", s.temp_root)):
        add(label, os.path.isdir(p) and os.access(p, os.W_OK), "directory writable" if os.access(p, os.W_OK) else "not writable")
    add("Key provider", s.kms_backend != "local_dev", f"backend: {s.kms_backend}" + (" (development key, not for production)" if s.kms_backend == "local_dev" else ""), warn=True)
    add("Email delivery", factory.get_email_service() is not None, "configured" if factory.get_email_service() else "not configured", warn=True)
    add("SMS delivery", factory.get_sms_service() is not None, "configured" if factory.get_sms_service() else "not configured", warn=True)
    add("Debug mode", not s.debug, "off" if not s.debug else "ON: sample-data pages are mounted", warn=True)
    return Page("System health", "Live checks run when this page loads.", [Section("Checks", ["Check", "Status", "Detail"], checks)],
                [("Mode", s.app_mode)])


async def _backup(db: AsyncSession) -> Page:
    s = get_settings()
    rows = [["Database", s.database_url.split(":", 1)[0], "Use your database's native dump (pg_dump, or copy the SQLite file while the app is stopped)."],
            ["Encrypted documents", str(s.storage_root), "Copy this directory. Files are encrypted; they are useless without the keys."],
            ["Encryption keys", "scripts/backup_keys.py", "Run scripts/backup_keys.py; restore with scripts/restore_keys.py. Store the output separately from the documents."]]
    return Page("Backup", "What to back up. No backup job runs inside the app.",
                [Section("Back-up checklist", ["Item", "Location", "How"], rows)],
                note="Automated, scheduled backups are not built in. Nothing on this page creates or restores a backup.")


async def _reports(db: AsyncSession) -> Page:
    async def grouped(col: Any, model: Any) -> list[list[Any]]:
        rs = (await db.execute(select(col, func.count()).where(*_live(model)).group_by(col).order_by(func.count().desc()))).all()
        return [[str(k or "-"), n] for k, n in rs]
    return Page("Reports", "Summary breakdowns across the platform.", [
        Section("Documents by classification", ["Classification", "Documents"], await grouped(Document.classification, Document), "No documents."),
        Section("Links by status", ["Status", "Links"], await grouped(SecureLink.status, SecureLink), "No links."),
        Section("Alerts by severity", ["Severity", "Alerts"], await grouped(SecurityAlert.severity, SecurityAlert), "No alerts."),
        Section("Users by status", ["Status", "Users"], await grouped(User.status, User), "No users.")])


# ── registry: slug -> (nav label, loader) ────────────────────────────────────────────────────
PAGES: dict[str, tuple[str, Loader]] = {
    "roles": ("Roles", _roles),
    "permissions": ("Permissions", _permissions),
    "documents": ("Documents", table_page(
        title="Documents", blurb="Document metadata only. Content is never shown here.", model=Document, order=Document.created_at,
        user_attrs=("owner_id",), columns=[
            ("Name", lambda r, w: r.display_name or r.original_filename), ("Owner", lambda r, w: w(r.owner_id)),
            ("Classification", lambda r, w: r.classification), ("Status", lambda r, w: badge(r.status, STATUS)),
            ("Size", lambda r, w: filesize(r.size_bytes or 0)), ("Malware scan", lambda r, w: r.malware_scan_result),
            ("DLP", lambda r, w: r.dlp_level), ("Created", lambda r, w: when(r.created_at))])),
    "links": ("Links", table_page(
        title="Secure links", blurb="Link metadata. The secret token is never stored or shown, only a short prefix.", model=SecureLink,
        order=SecureLink.created_at, user_attrs=("created_by",), columns=[
            ("Link", lambda r, w: f"{r.token_prefix}…"), ("Document", lambda r, w: short(r.document_id)),
            ("Created by", lambda r, w: w(r.created_by)), ("Status", lambda r, w: badge(r.status, STATUS)),
            ("Views", lambda r, w: r.view_count), ("Downloads", lambda r, w: r.download_count),
            ("Expires", lambda r, w: when(r.expires_at)), ("Created", lambda r, w: when(r.created_at))])),
    "access": ("Access", table_page(
        title="Access grants", blurb="Who has been granted access to which document.", model=AccessGrant, order=AccessGrant.created_at,
        user_attrs=("grantee_id", "granted_by"), columns=[
            ("Document", lambda r, w: short(r.document_id)), ("Grantee", lambda r, w: w(r.grantee_id) if r.grantee_id else "Link recipient"),
            ("Granted by", lambda r, w: w(r.granted_by)), ("Permissions", lambda r, w: ", ".join(r.permissions or []) or "-"),
            ("Expires", lambda r, w: when(r.expires_at)), ("Revoked", lambda r, w: when(r.revoked_at)),
            ("Created", lambda r, w: when(r.created_at))])),
    "policies": ("Policies", table_page(
        title="Access policies", blurb="Zero-trust policies and whether they are active.", model=AccessPolicy, order=AccessPolicy.created_at,
        user_attrs=("owner_id",), columns=[
            ("Name", lambda r, w: r.name), ("Owner", lambda r, w: w(r.owner_id)), ("Active", lambda r, w: yes(r.is_active)),
            ("Priority", lambda r, w: r.priority), ("Rules", lambda r, w: len(r.rules or [])), ("Created", lambda r, w: when(r.created_at))])),
    "security": ("Security alerts", table_page(
        title="Security alerts", blurb="Alerts raised by the platform, newest first.", model=SecurityAlert, order=SecurityAlert.created_at,
        user_attrs=("user_id",), columns=[
            ("Type", lambda r, w: r.alert_type), ("Severity", lambda r, w: badge(r.severity, SEVERITY)), ("User", lambda r, w: w(r.user_id)),
            ("Message", lambda r, w: r.message), ("Acknowledged", lambda r, w: yes(r.acknowledged)), ("Time", lambda r, w: when(r.created_at))])),
    "security-events": ("Security events", table_page(
        title="Security events", blurb="Low-level security events (sign-ins, lockouts, denials).", model=SecurityEvent, order=SecurityEvent.created_at,
        user_attrs=("user_id",), columns=[
            ("Time", lambda r, w: when(r.created_at)), ("Event", lambda r, w: r.event_type), ("Severity", lambda r, w: badge(r.severity, SEVERITY)),
            ("User", lambda r, w: w(r.user_id)), ("IP", lambda r, w: r.ip_address or "-")])),
    "risk": ("Risk", table_page(
        title="Risk assessments", blurb="Recent risk scores per subject.", model=RiskAssessment, order=RiskAssessment.assessed_at, columns=[
            ("Subject", lambda r, w: r.subject_type), ("Subject ID", lambda r, w: short(r.subject_id)), ("Score", lambda r, w: f"{r.risk_score:.0f}"),
            ("Level", lambda r, w: badge(r.risk_level, SEVERITY)), ("Factors", lambda r, w: len(r.factors or [])), ("Assessed", lambda r, w: when(r.assessed_at))])),
    "devices": ("Devices", table_page(
        title="Devices", blurb="Registered devices and their trust level.", model=Device, order=Device.registered_at, user_attrs=("user_id",), columns=[
            ("User", lambda r, w: w(r.user_id)), ("Device", lambda r, w: r.name or (r.user_agent or "-")[:60]), ("IP", lambda r, w: r.ip_address or "-"),
            ("Trust", lambda r, w: badge(r.trust, STATUS)), ("Registered", lambda r, w: when(r.registered_at)), ("Last seen", lambda r, w: when(r.last_seen_at))])),
    "sessions": ("Sessions", table_page(
        title="Sessions", blurb="Sign-in sessions. Session secrets are never stored in readable form.", model=UserSession, order=UserSession.last_active_at,
        user_attrs=("user_id",), columns=[
            ("User", lambda r, w: w(r.user_id)), ("IP", lambda r, w: r.ip_address or "-"), ("Status", lambda r, w: badge(r.status, STATUS)),
            ("MFA", lambda r, w: yes(r.mfa_verified)), ("Last active", lambda r, w: when(r.last_active_at)), ("Expires", lambda r, w: when(r.expires_at))])),
    "analytics": ("Analytics", _analytics),
    "usage": ("Usage", _usage),
    "audit": ("Audit", _audit),
    "attack-simulator": ("Attack simulator", _attack),
    "system-health": ("System health", _health),
    "backup": ("Backup", _backup),
    "reports": ("Reports", _reports),
}


def _make(slug: str, loader: Loader):
    async def handler(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
        user, redirect = await _require_admin_web(request, db)
        if redirect:
            return redirect
        page = await loader(db)
        return await _render(request, db, user, "admin/table.html", page=page, nav_active=slug)
    handler.__name__ = "admin_page_" + slug.replace("-", "_")
    return handler


for _slug, (_label, _loader) in PAGES.items():
    router.add_api_route(f"/{_slug}", _make(_slug, _loader), methods=["GET"], response_class=HTMLResponse)
