"""Optional two-factor sign-in (authenticator app).

  /mfa                      second step of login (only reached after a correct password, when the account has MFA on)
  /settings/security        turn MFA on / off, see recovery-code count, make new recovery codes
  /settings/security/mfa/*  start, enable (first code proves the app works), disable, recovery

MFA is never forced: sign-up and login work without it. Registered BEFORE security_pages/showcase so
these real routes win. NOTE: written without FastAPI installed in the sandbox: compiled and
template-rendered only; click through it once.
"""
from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.config.constants import COOKIE_SESSION
from app.config.settings import get_settings
from app.core.dependencies import get_client_ip, get_db, get_user_agent
from app.core.exceptions import AuthenticationError, LockoutError, RateLimitExceededError, ValidationError
from app.core.utils import safe_redirect_url
from app.middleware.csrf import get_csrf_token
from app.models.user import User
from app.services import mfa
from app.services.auth import AuthService, is_guest_user
from app.services.mfa_service import MfaService
from app.web.templating import build_env
from app.web.user import _auth, _qr_svg, _render

router = APIRouter(tags=["web-mfa"], include_in_schema=False)
env = build_env()
settings = get_settings()
COOKIE_MFA = "ss_mfa"


# ── login step 2 ─────────────────────────────────────────────────────────────
def _mfa_page(request: Request, auth: AuthService, uid: str | None, status: int = 200,
              error: str | None = None) -> HTMLResponse:
    locked = int(auth.store.ttl(f"mfa:lock:{uid}")) if uid and auth.store.get(f"mfa:lock:{uid}") else 0
    used = int(auth.store.get(f"mfa:att:{uid}") or 0) if uid else 0
    html = env.get_template("auth/mfa.html").render(
        csrf_token=get_csrf_token(request), error=error, locked_seconds=locked,
        attempts_left=max(mfa.MAX_ATTEMPTS - used, 0), request_id=getattr(request.state, "request_id", ""))
    return HTMLResponse(html, status_code=status, headers={"Cache-Control": "no-store"})


@router.get("/mfa", response_class=HTMLResponse)
async def mfa_get(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    auth = AuthService(db)
    cid = request.cookies.get(COOKIE_MFA, "")
    uid = mfa.resolve_challenge(auth.store, cid) if cid else None
    if not uid:
        return RedirectResponse("/login", status_code=303)
    return _mfa_page(request, auth, uid)


@router.post("/mfa", response_class=HTMLResponse)
async def mfa_post(request: Request, db: Annotated[AsyncSession, Depends(get_db)], code: str = Form("")):
    auth = AuthService(db)
    cid = request.cookies.get(COOKIE_MFA, "")
    uid = mfa.resolve_challenge(auth.store, cid) if cid else None
    if not uid:
        return RedirectResponse("/login", status_code=303)
    nxt = safe_redirect_url(auth.store.get(f"mfa:next:{cid}"), "/dashboard")
    try:
        _user, _session, raw_token = await auth.complete_mfa_login(
            cid, code.strip(), ip_address=get_client_ip(request), user_agent=get_user_agent(request))
        await db.commit()
    except LockoutError as e:
        await db.commit()
        return _mfa_page(request, auth, uid, 423, error=e.message)
    except (AuthenticationError, ValidationError) as e:
        await db.commit()                        # keeps the MFA_FAILED audit row
        return _mfa_page(request, auth, uid, 400, error=e.message)
    auth.store.delete(f"mfa:next:{cid}")
    resp = RedirectResponse(nxt, status_code=303)
    resp.set_cookie(COOKIE_SESSION, raw_token, httponly=True, secure=settings.cookie_secure, samesite="lax",
                    max_age=settings.session_absolute_timeout, path="/")
    resp.delete_cookie(COOKIE_MFA, path="/")
    return resp


# ── settings ─────────────────────────────────────────────────────────────────
def _settings_page(request: Request, user: User, svc: MfaService, status: int = 200, *, error: str | None = None,
                   notice: str | None = None, new_codes: list[str] | None = None) -> HTMLResponse:
    pending = None if user.mfa_enabled else svc.pending_setup(user)
    return _render(
        request, user, "auth/security_settings.html", status,
        guest=is_guest_user(user), mfa_on=bool(user.mfa_enabled), codes_left=svc.recovery_codes_left(user),
        setup_secret=pending[0] if pending else None, setup_uri=pending[1] if pending else None,
        setup_qr=_qr_svg(pending[1]) if pending else None, new_codes=new_codes, error=error, notice=notice)


@router.get("/settings/security", response_class=HTMLResponse)
async def settings_security(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    return _settings_page(request, user, MfaService(db))


@router.post("/settings/security/mfa/start", response_class=HTMLResponse)
async def mfa_start(request: Request, db: Annotated[AsyncSession, Depends(get_db)]):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    svc = MfaService(db)
    try:
        svc.begin_setup(user)
    except ValidationError as e:
        return _settings_page(request, user, svc, 400, error=e.message)
    return _settings_page(request, user, svc)


@router.post("/settings/security/mfa/enable", response_class=HTMLResponse)
async def mfa_enable(request: Request, db: Annotated[AsyncSession, Depends(get_db)], code: str = Form("")):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    svc = MfaService(db)
    try:
        codes = await svc.confirm_setup(user, code, ip=get_client_ip(request), ua=get_user_agent(request))
        await db.commit()
    except (ValidationError, LockoutError) as e:
        await db.rollback()
        await db.refresh(user)
        return _settings_page(request, user, svc, 423 if isinstance(e, LockoutError) else 400, error=e.message)
    return _settings_page(request, user, svc, new_codes=codes,
                          notice="Two-factor sign-in is on. Save these recovery codes now: they are shown only once.")


@router.post("/settings/security/mfa/disable", response_class=HTMLResponse)
async def mfa_disable(request: Request, db: Annotated[AsyncSession, Depends(get_db)], password: str = Form("")):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    svc = MfaService(db)
    try:
        await svc.disable(user, password, ip=get_client_ip(request), ua=get_user_agent(request))
        await db.commit()
    except AuthenticationError as e:
        await db.rollback()
        await db.refresh(user)
        return _settings_page(request, user, svc, 400, error=e.message)
    return _settings_page(request, user, svc, notice="Two-factor sign-in is off.")


@router.post("/settings/security/mfa/recovery", response_class=HTMLResponse)
async def mfa_recovery(request: Request, db: Annotated[AsyncSession, Depends(get_db)], password: str = Form("")):
    user, redirect = await _auth(request, db)
    if redirect:
        return redirect
    svc = MfaService(db)
    try:
        codes = await svc.regenerate_recovery_codes(user, password)
        await db.commit()
    except (AuthenticationError, ValidationError) as e:
        await db.rollback()
        await db.refresh(user)
        return _settings_page(request, user, svc, 400, error=e.message)
    return _settings_page(request, user, svc, new_codes=codes,
                          notice="New recovery codes made. The old ones no longer work.")
