"""Request ID middleware — assigns or propagates X-Request-ID."""
from __future__ import annotations

import uuid
from typing import Callable
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from app.config.constants import HEADER_REQUEST_ID


class RequestIDMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: Callable[[Request], Response]) -> Response:
        req_id = request.headers.get(HEADER_REQUEST_ID)
        if not req_id:
            req_id = uuid.uuid4().hex
        request.state.request_id = req_id

        response = await call_next(request)
        response.headers[HEADER_REQUEST_ID] = req_id
        return response
