"""Structured HTTP access logging middleware."""
from __future__ import annotations

import time
from typing import Callable
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from app.config.logging import logger


class AccessLogMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next: Callable[[Request], Response]) -> Response:
        start_time = time.perf_counter()
        req_id = getattr(request.state, "request_id", "") or request.headers.get("x-request-id", "")
        client_ip = request.client.host if request.client else "unknown"

        response = await call_next(request)

        duration_ms = round((time.perf_counter() - start_time) * 1000, 2)
        status_code = response.status_code

        # Avoid spamming logs for static asset requests unless in error
        if not request.url.path.startswith("/static/") or status_code >= 400:
            logger.info(
                "http_request",
                method=request.method,
                path=request.url.path,
                status=status_code,
                duration_ms=duration_ms,
                request_id=req_id,
                client_ip=client_ip,
            )

        return response
