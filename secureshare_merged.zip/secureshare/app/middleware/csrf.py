"""CSRF protection middleware and helpers using double-submit token verification."""
from __future__ import annotations

import hmac
import secrets
from typing import Callable
from urllib.parse import urlsplit
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from app.config.constants import COOKIE_CSRF, COOKIE_SESSION, ERR_CSRF_FAILED, HEADER_CSRF_TOKEN
from app.config.settings import get_settings
from app.core.exceptions import CsrfError
from app.core.responses import error_response
from app.crypto.hashing import constant_time_equal

SAFE_METHODS = {"GET", "HEAD", "OPTIONS", "TRACE"}
EXEMPT_PATHS = {
    "/api/v1/health",
    "/health",
}


def generate_csrf_token() -> str:
    """Generate a cryptographically secure CSRF token."""
    return secrets.token_urlsafe(32)


def get_csrf_token(request: Request) -> str:
    """Get the current request's CSRF token."""
    token = getattr(request.state, "csrf_token", None)
    if not token:
        token = request.cookies.get(COOKIE_CSRF) or generate_csrf_token()
        request.state.csrf_token = token
    return token


def _netloc(value: str) -> str:
    return urlsplit(value).netloc.lower()


def origin_is_allowed(request: Request, settings) -> bool:  # noqa: ANN001
    """Defence in depth on top of the double-submit token: a browser-supplied Origin (or, failing that,
    Referer) on an unsafe request must be this site (the Host the browser used), PUBLIC_BASE_URL, or one of
    TRUSTED_ORIGINS. Requests with neither header (non-browser clients) are judged by the token alone."""
    supplied = request.headers.get("origin") or request.headers.get("referer")
    if supplied is None:
        return True
    if supplied == "null":                      # sandboxed iframe / data: URL origin
        return False
    got = _netloc(supplied)
    allowed = {(request.headers.get("host") or "").lower()}
    allowed.update(_netloc(o) for o in (settings.trusted_origins or []))
    if getattr(settings, "public_base_url", ""):
        allowed.add(_netloc(settings.public_base_url))
    allowed.discard("")
    return got in allowed


class CSRFMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: object) -> None:
        super().__init__(app)
        self.settings = get_settings()

    async def dispatch(self, request: Request, call_next: Callable[[Request], Response]) -> Response:
        # Read or create CSRF token for this request
        existing_cookie_token = request.cookies.get(COOKIE_CSRF)
        csrf_token = existing_cookie_token or generate_csrf_token()
        request.state.csrf_token = csrf_token

        # Verify on unsafe HTTP methods
        if request.method not in SAFE_METHODS and request.url.path not in EXEMPT_PATHS:
            has_session_cookie = COOKIE_SESSION in request.cookies
            content_type = request.headers.get("content-type", "")
            is_form = "application/x-www-form-urlencoded" in content_type or "multipart/form-data" in content_type

            # CSRF is required when session cookie is attached, or for browser form submissions
            requires_csrf = has_session_cookie or (is_form and not request.url.path.startswith("/api/"))

            if requires_csrf and not origin_is_allowed(request, self.settings):
                return error_response(
                    code=ERR_CSRF_FAILED, message="Cross-site request blocked.",
                    request_id=getattr(request.state, "request_id", ""), status_code=403)

            if requires_csrf:
                # Check header first, then form data if content-type is form
                submitted_token = request.headers.get(HEADER_CSRF_TOKEN)
                if not submitted_token and is_form:
                    try:
                        # The framework replays this body to the endpoint; keep the ORIGINAL request
                        # object (passing a bare Request to call_next breaks on current Starlette).
                        await request.body()
                        form = await request.form()
                        submitted_token = form.get("csrf_token")
                    except Exception:
                        submitted_token = None

                expected_token = existing_cookie_token or csrf_token

                if not submitted_token or not constant_time_equal(submitted_token, expected_token):
                    # The "demo" token is honoured ONLY when CSRF_ALLOW_DEMO_TOKEN=true (APP_ENV=dev test runs).
                    is_demo = self.settings.csrf_allow_demo_token and submitted_token == "demo"
                    if not is_demo:
                        req_id = getattr(request.state, "request_id", "")
                        return error_response(
                            code=ERR_CSRF_FAILED,
                            message="CSRF verification failed. Please refresh and try again.",
                            request_id=req_id,
                            status_code=403,
                        )

        response = await call_next(request)

        # Set or refresh CSRF cookie if not set or changed
        if not existing_cookie_token:
            response.set_cookie(
                key=COOKIE_CSRF,
                value=csrf_token,
                httponly=False,  # Allow JavaScript to read for AJAX headers
                samesite="lax",
                secure=self.settings.cookie_secure,
                path="/",
            )

        return response
