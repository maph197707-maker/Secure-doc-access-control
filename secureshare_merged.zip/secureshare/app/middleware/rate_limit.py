"""Rate limit middleware using StateStore and fixed-window rate limiter."""
from __future__ import annotations

from typing import Callable
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from app.config.constants import COOKIE_SESSION, ERR_RATE_LIMIT
from app.config.settings import get_settings
from app.core.responses import error_response
from app.integrations.state import get_state_store
from app.services.rate_limiter import hit

EXEMPT_PREFIXES = ("/static/", "/health", "/docs", "/openapi.json")


def parse_rate(rate_str: str) -> tuple[int, int]:
    """Parse '200/minute' or '10/second' to (count, window_seconds)."""
    parts = rate_str.split("/")
    count = int(parts[0])
    unit = parts[1].lower() if len(parts) > 1 else "minute"
    multiplier = {"second": 1, "minute": 60, "hour": 3600, "day": 86400}.get(unit, 60)
    return count, multiplier


class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: object) -> None:
        super().__init__(app)
        self.settings = get_settings()
        self.store = get_state_store()
        self.api_limit, self.api_window = parse_rate(self.settings.rate_limit_api)

    async def dispatch(self, request: Request, call_next: Callable[[Request], Response]) -> Response:
        path = request.url.path
        if any(path.startswith(p) for p in EXEMPT_PREFIXES):
            return await call_next(request)

        # Subject: user session cookie or IP
        subject = request.cookies.get(COOKIE_SESSION) or (request.client.host if request.client else "unknown")
        key = f"api:{subject}"

        result = hit(self.store, key, self.api_limit, self.api_window)
        if not result.allowed:
            req_id = getattr(request.state, "request_id", "")
            resp = error_response(
                code=ERR_RATE_LIMIT,
                message="Too many requests. Please slow down.",
                request_id=req_id,
                details={"retry_after": result.retry_after},
                status_code=429,
                headers={"Retry-After": str(result.retry_after)},
            )
            return resp

        response = await call_next(request)
        response.headers["X-RateLimit-Limit"] = str(self.api_limit)
        response.headers["X-RateLimit-Remaining"] = str(result.remaining)
        return response
