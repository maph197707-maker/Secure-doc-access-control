"""Host header guard middleware — validates incoming Host against ALLOWED_HOSTS."""
from __future__ import annotations

from typing import Callable
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import HTMLResponse, JSONResponse, Response

from app.config.settings import get_settings
from app.services.link_urls import is_private_host


class HostGuardMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: object) -> None:
        super().__init__(app)
        self.settings = get_settings()

    async def dispatch(self, request: Request, call_next: Callable[[Request], Response]) -> Response:
        host_header = request.headers.get("host")
        if host_header:
            hostname = host_header.split(":")[0].strip().lower()
            allowed = [h.strip().lower() for h in self.settings.allowed_hosts]
            # Dev/demo only: a phone or second laptop reaches the server by its LAN IP, which can't be
            # listed in advance. Production/staging stay strict (ALLOWED_HOSTS only).
            lan_ok = self.settings.is_dev and is_private_host(hostname)
            if "*" not in allowed and hostname not in allowed and "testserver" not in allowed and not lan_ok:
                accept = request.headers.get("accept", "")
                if "application/json" in accept and "text/html" not in accept:
                    return JSONResponse(
                        status_code=400,
                        content={"error": {"code": "INVALID_HOST", "message": f"Host '{hostname}' is not allowed."}},
                    )
                return HTMLResponse(
                    status_code=400,
                    content=f"<!DOCTYPE html><html><body><h1>400 Invalid Host</h1><p>The host '{hostname}' is not authorized.</p></body></html>",
                )

        return await call_next(request)
