"""User repository for async SQLAlchemy database operations."""
from __future__ import annotations

from typing import Sequence
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.user import User


class UserRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_id(self, user_id: str) -> User | None:
        stmt = (
            select(User)
            .options(selectinload(User.roles), selectinload(User.preference))
            .where(User.id == user_id, User.is_deleted == False)
        )
        res = await self.session.execute(stmt)
        return res.scalar_one_or_none()

    async def get_by_email(self, email: str) -> User | None:
        stmt = (
            select(User)
            .options(selectinload(User.roles), selectinload(User.preference))
            .where(User.email == email.strip().lower(), User.is_deleted == False)
        )
        res = await self.session.execute(stmt)
        return res.scalar_one_or_none()

    async def add(self, user: User) -> User:
        self.session.add(user)
        await self.session.flush()
        return user

    async def list_users(self, skip: int = 0, limit: int = 50) -> Sequence[User]:
        stmt = (
            select(User)
            .options(selectinload(User.roles))
            .where(User.is_deleted == False)
            .order_by(User.created_at.desc())
            .offset(skip)
            .limit(limit)
        )
        res = await self.session.execute(stmt)
        return res.scalars().all()
