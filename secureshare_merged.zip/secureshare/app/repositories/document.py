"""Document repository for async SQLAlchemy database operations."""
from __future__ import annotations

from typing import Optional, Sequence
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.document import Document


class DocumentRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_by_id(self, doc_id: str) -> Document | None:
        stmt = (
            select(Document)
            .options(selectinload(Document.owner), selectinload(Document.tags))
            .where(Document.id == doc_id, Document.is_deleted == False)
        )
        res = await self.session.execute(stmt)
        return res.scalar_one_or_none()

    async def get_by_internal_name(self, internal_name: str) -> Document | None:
        stmt = select(Document).where(Document.internal_name == internal_name)
        res = await self.session.execute(stmt)
        return res.scalar_one_or_none()

    async def list_for_user(
        self,
        owner_id: str,
        skip: int = 0,
        limit: int = 50,
        folder_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> tuple[Sequence[Document], int]:
        base_stmt = select(Document).where(
            Document.owner_id == owner_id, Document.is_deleted == False
        )
        if folder_id is not None:
            base_stmt = base_stmt.where(Document.folder_id == folder_id)
        if status:
            base_stmt = base_stmt.where(Document.status == status)

        count_stmt = select(func.count()).select_from(base_stmt.subquery())
        count_res = await self.session.execute(count_stmt)
        total = count_res.scalar_one()

        stmt = (
            base_stmt.order_by(Document.created_at.desc())
            .offset(skip)
            .limit(limit)
        )
        res = await self.session.execute(stmt)
        return res.scalars().all(), total

    async def list_all(
        self,
        skip: int = 0,
        limit: int = 50,
    ) -> tuple[Sequence[Document], int]:
        base_stmt = select(Document).where(Document.is_deleted == False)
        count_stmt = select(func.count()).select_from(base_stmt.subquery())
        count_res = await self.session.execute(count_stmt)
        total = count_res.scalar_one()
        stmt = base_stmt.order_by(Document.created_at.desc()).offset(skip).limit(limit)
        res = await self.session.execute(stmt)
        return res.scalars().all(), total

    async def add(self, document: Document) -> Document:
        self.session.add(document)
        await self.session.flush()
        return document

    async def delete(self, document: Document) -> None:
        document.soft_delete()
        await self.session.flush()
