"""Audit repository for tamper-evident audit log persistence."""
from __future__ import annotations

from typing import Any, Sequence
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.audit import AuditLog
from app.services.audit import (GENESIS, VerifyResult, chain_hash, event_payload, merkle_root,
                                rows_to_records, verify_chain)


class AuditRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    async def get_latest_entry(self) -> AuditLog | None:
        # FOR UPDATE serialises concurrent writers on PostgreSQL so two requests cannot both chain
        # off the same predecessor (SQLite serialises writes itself and ignores the clause).
        stmt = select(AuditLog).order_by(desc(AuditLog.sequence_number)).limit(1).with_for_update()
        res = await self.session.execute(stmt)
        return res.scalar_one_or_none()

    async def log_event(
        self,
        action: str,
        user_id: str | None = None,
        resource_type: str | None = None,
        resource_id: str | None = None,
        ip_address: str | None = None,
        user_agent: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> AuditLog:
        latest = await self.get_latest_entry()
        prev_hash = latest.entry_hash if latest else GENESIS
        prev_seq = latest.sequence_number or 0 if latest else 0
        seq = prev_seq + 1

        entry_h = chain_hash(prev_hash, event_payload(seq, action, user_id, resource_type, resource_id, details))

        log = AuditLog(
            sequence_number=seq,
            action=action,
            user_id=user_id,
            resource_type=resource_type,
            resource_id=resource_id,
            ip_address=ip_address,
            user_agent=user_agent,
            details=details or {},
            prev_hash=prev_hash,
            entry_hash=entry_h,
        )
        self.session.add(log)
        await self.session.flush()
        return log

    async def list_recent(self, limit: int = 50) -> Sequence[AuditLog]:
        stmt = select(AuditLog).order_by(desc(AuditLog.sequence_number)).limit(limit)
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def _ordered(self, start: int = 1, end: int | None = None) -> Sequence[AuditLog]:
        stmt = select(AuditLog).where(AuditLog.sequence_number >= start)
        if end is not None:
            stmt = stmt.where(AuditLog.sequence_number <= end)
        res = await self.session.execute(stmt.order_by(AuditLog.sequence_number))
        return res.scalars().all()

    async def verify(self) -> VerifyResult:
        """Re-walk the whole persisted chain: detects modified rows, broken links and deleted/reordered rows."""
        return verify_chain(rows_to_records(await self._ordered()))

    async def merkle_anchor(self, start: int = 1, end: int | None = None) -> dict[str, Any]:
        """Merkle root over entry hashes in [start, end] for external anchoring (publish/sign the root)."""
        rows = await self._ordered(start, end)
        return {"start": start, "end": rows[-1].sequence_number if rows else None, "count": len(rows),
                "root": merkle_root([r.entry_hash for r in rows])}
