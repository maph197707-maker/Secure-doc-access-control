"""Repository for secure links, drafts, and share persistence."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional, Sequence
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.secure_link import SecureLink
from app.models.share_draft import ShareDraft
from app.models.recipient import Recipient
from app.models.access_grant import AccessGrant


class ShareRepository:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session

    # --- Secure Links ---
    async def get_by_id(self, link_id: str) -> SecureLink | None:
        stmt = select(SecureLink).where(SecureLink.id == link_id)
        res = await self.session.execute(stmt)
        return res.scalar_one_or_none()

    async def get_by_token_hash(self, token_hash: str) -> SecureLink | None:
        stmt = select(SecureLink).where(SecureLink.token_hash == token_hash)
        res = await self.session.execute(stmt)
        return res.scalar_one_or_none()

    async def list_for_user(self, user_id: str, skip: int = 0, limit: int = 20) -> Sequence[SecureLink]:
        stmt = (
            select(SecureLink)
            .where(SecureLink.created_by == user_id)
            .order_by(desc(SecureLink.created_at))
            .offset(skip)
            .limit(limit)
        )
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def list_for_document(self, document_id: str) -> Sequence[SecureLink]:
        stmt = (
            select(SecureLink)
            .where(SecureLink.document_id == document_id)
            .order_by(desc(SecureLink.created_at))
        )
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def create_link(self, link: SecureLink) -> SecureLink:
        self.session.add(link)
        await self.session.flush()
        return link

    async def revoke_link(self, link_id: str, reason: str | None = None) -> bool:
        link = await self.get_by_id(link_id)
        if not link:
            return False
        link.status = "REVOKED"
        link.revoked_at = datetime.now(timezone.utc).replace(tzinfo=None)
        link.revoke_reason = reason
        await self.session.flush()
        return True

    # --- Share Drafts ---
    async def get_draft(self, owner_id: str, idempotency_key: str | None = None) -> ShareDraft | None:
        stmt = select(ShareDraft).where(ShareDraft.owner_id == owner_id)
        if idempotency_key:
            stmt = stmt.where(ShareDraft.idempotency_key == idempotency_key)
        stmt = stmt.order_by(desc(ShareDraft.updated_at)).limit(1)
        res = await self.session.execute(stmt)
        return res.scalar_one_or_none()

    async def save_draft(self, draft: ShareDraft) -> ShareDraft:
        self.session.add(draft)
        await self.session.flush()
        return draft

    async def delete_draft(self, draft_id: str) -> bool:
        stmt = select(ShareDraft).where(ShareDraft.id == draft_id)
        res = await self.session.execute(stmt)
        draft = res.scalar_one_or_none()
        if not draft:
            return False
        await self.session.delete(draft)
        await self.session.flush()
        return True

    # --- Recipients & Grants ---
    async def get_recipients_for_link(self, link_id: str) -> Sequence[Recipient]:
        stmt = select(Recipient).where(Recipient.link_id == link_id)
        res = await self.session.execute(stmt)
        return res.scalars().all()

    async def get_active_grants_for_user(self, user_id: str) -> Sequence[AccessGrant]:
        stmt = select(AccessGrant).where(AccessGrant.grantee_id == user_id, AccessGrant.is_revoked == False)
        res = await self.session.execute(stmt)
        return res.scalars().all()
