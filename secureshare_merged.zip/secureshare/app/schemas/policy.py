"""Schemas for access policy definitions and evaluation."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, ConfigDict, Field


class PolicyRule(BaseModel):
    effect: str = Field(pattern="^(ALLOW|DENY|STEP_UP)$")
    condition: str
    description: Optional[str] = None
    parameters: dict[str, Any] = Field(default_factory=dict)


class PolicyCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    description: Optional[str] = None
    document_id: Optional[str] = None
    rules: list[dict[str, Any]] = Field(default_factory=list)
    priority: int = 0
    is_active: bool = True


class PolicyUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    rules: Optional[list[dict[str, Any]]] = None
    priority: Optional[int] = None
    is_active: Optional[bool] = None


class PolicyResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    name: str
    description: Optional[str] = None
    document_id: Optional[str] = None
    owner_id: str
    rules: list[dict[str, Any]]
    priority: int
    is_active: bool
    created_at: Optional[datetime] = None
