"""Pydantic schemas for user profile and management."""
from __future__ import annotations

from datetime import datetime
from pydantic import BaseModel, ConfigDict, EmailStr, Field

from app.schemas.auth import RoleSummary


class UserProfileResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    email: EmailStr
    full_name: str
    phone: str | None = None
    department: str | None = None
    status: str
    email_verified: bool
    phone_verified: bool
    mfa_enabled: bool
    trust_score: float = 1.0
    avatar_url: str | None = None
    roles: list[RoleSummary] = []
    created_at: datetime


class UserUpdateRequest(BaseModel):
    full_name: str | None = Field(default=None, min_length=2, max_length=255)
    phone: str | None = Field(default=None, max_length=30)
    department: str | None = Field(default=None, max_length=100)


class PasswordChangeRequest(BaseModel):
    old_password: str
    new_password: str = Field(..., min_length=12)
