"""Schemas for sharing and link management."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, ConfigDict, Field


class DraftSaveRequest(BaseModel):
    step: int = Field(ge=1, le=5)
    data: dict[str, Any] = Field(default_factory=dict)
    document_id: Optional[str] = None
    idempotency_key: Optional[str] = None


class DraftCompleteRequest(BaseModel):
    document_id: str
    password_protect: bool = False
    link_password: Optional[str] = None
    expires_in_hours: Optional[int] = 72
    max_views: Optional[int] = None
    max_downloads: Optional[int] = None
    allow_download: bool = False
    one_time: bool = False
    recipient_email: Optional[str] = None
    recipient_phone: Optional[str] = None
    binding_mode: str = "NONE"


class ShareRecipientBinding(BaseModel):
    identifier: str
    channel: str = "EMAIL"  # EMAIL, PHONE, DOMAIN, USER_ID
    require_mfa: bool = False


class ShareCreateRequest(BaseModel):
    document_id: str
    binding_mode: str = "NONE"
    recipients: list[ShareRecipientBinding] = Field(default_factory=list)
    password: Optional[str] = None
    expires_in_hours: Optional[int] = 72
    max_views: Optional[int] = None
    max_downloads: Optional[int] = None
    allow_downloads: bool = True
    allow_print: bool = False
    allow_copy: bool = False
    watermark_forced: bool = True
    device_binding_required: bool = False
    one_time_view: bool = False
    one_time_download: bool = False


class ShareUpdateRequest(BaseModel):
    status: Optional[str] = None
    expires_at: Optional[datetime] = None
    max_views: Optional[int] = None
    max_downloads: Optional[int] = None
    allow_downloads: Optional[bool] = None
    allow_print: Optional[bool] = None
    allow_copy: Optional[bool] = None
    watermark_forced: Optional[bool] = None


class ShareResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    document_id: str
    created_by: str
    token_prefix: str
    status: str
    binding_mode: str
    allow_downloads: bool
    allow_print: bool
    allow_copy: bool
    watermark_forced: bool
    max_views: Optional[int] = None
    views_remaining: Optional[int] = None
    max_downloads: Optional[int] = None
    downloads_remaining: Optional[int] = None
    view_count: int = 0
    download_count: int = 0
    expires_at: Optional[datetime] = None
    created_at: datetime
    url: Optional[str] = None
