"""Pydantic schemas for audit log entries."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Optional
from pydantic import BaseModel, ConfigDict, field_validator


class AuditLogEntry(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    action: str
    user_id: Optional[str] = None
    resource_type: Optional[str] = None
    resource_id: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    details: Optional[Any] = None
    entry_hash: Optional[str] = None
    created_at: datetime


class AuditListResponse(BaseModel):
    items: list[AuditLogEntry]
    total: int
    page: int
    page_size: int
