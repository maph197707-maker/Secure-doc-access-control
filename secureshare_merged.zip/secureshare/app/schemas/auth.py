"""Pydantic schemas for authentication and session endpoints."""
from __future__ import annotations

from datetime import datetime
from pydantic import BaseModel, ConfigDict, EmailStr, Field


class UserRegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=12, description="At least 12 chars with upper, lower, and digit")
    full_name: str = Field(..., min_length=2, max_length=255)
    phone: str | None = Field(default=None, max_length=30)


class UserLoginRequest(BaseModel):
    email: EmailStr
    password: str
    device_fingerprint: str | None = None
    remember_me: bool = False


class VerifyEmailRequest(BaseModel):
    email: EmailStr
    code: str = Field(..., min_length=6, max_length=6)


class ResendVerificationRequest(BaseModel):
    email: EmailStr


class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    email: EmailStr
    token: str
    new_password: str = Field(..., min_length=12)


class RoleSummary(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    name: str
    description: str | None = None


class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    email: str
    full_name: str
    phone: str | None = None
    status: str
    email_verified: bool
    phone_verified: bool
    mfa_enabled: bool
    roles: list[RoleSummary] = []
    created_at: datetime


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    user: UserResponse


class SessionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    device_id: str | None = None
    ip_address: str | None = None
    user_agent: str | None = None
    status: str
    last_active_at: datetime
    expires_at: datetime
    is_current: bool = False
