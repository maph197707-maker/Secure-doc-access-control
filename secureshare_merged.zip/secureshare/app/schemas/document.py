"""Pydantic schemas for document upload, listing, and management."""
from __future__ import annotations

from datetime import datetime
from typing import Optional
from pydantic import BaseModel, ConfigDict, Field


class DocumentResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    owner_id: str
    folder_id: Optional[str] = None
    original_filename: str
    display_name: str
    doc_type: Optional[str] = None
    category: Optional[str] = None
    status: str
    classification: str
    sensitivity_level: int
    size_bytes: Optional[int] = None
    sha256: Optional[str] = None
    malware_scan_result: str
    dlp_level: str
    created_at: datetime
    updated_at: Optional[datetime] = None


class DocumentListResponse(BaseModel):
    items: list[DocumentResponse]
    total: int
    page: int
    page_size: int


class DocumentUpdateRequest(BaseModel):
    display_name: Optional[str] = Field(default=None, min_length=1, max_length=500)
    classification: Optional[str] = Field(default=None)
    category: Optional[str] = Field(default=None, max_length=100)
    sensitivity_level: Optional[int] = Field(default=None, ge=1, le=5)
    folder_id: Optional[str] = Field(default=None)


class SecureLinkCreateRequest(BaseModel):
    document_id: str
    expires_in_hours: Optional[int] = Field(default=72, ge=1, le=8760)
    max_views: Optional[int] = Field(default=None, ge=1)
    max_downloads: Optional[int] = Field(default=None, ge=1)
    allow_downloads: bool = True
    allow_print: bool = False
    allow_copy: bool = False
    requires_password: bool = False
    password: Optional[str] = Field(default=None, min_length=6)
    watermark_forced: bool = True
    one_time_view: bool = False
    one_time_download: bool = False
    valid_from: Optional[datetime] = None          # not usable before this instant (naive = UTC)
    requires_mfa: bool = False
    recipient_emails: list[str] = []
    binding_mode: str = "NONE"          # NONE | EMAIL_OTP (PHONE_OTP needs the web wizard)


class SecureLinkResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    document_id: str
    created_by: str
    token_prefix: str
    status: str
    reputation: str
    requires_mfa: bool
    allow_downloads: bool
    allow_print: bool
    allow_copy: bool
    watermark_forced: bool
    max_views: Optional[int] = None
    views_remaining: Optional[int] = None
    max_downloads: Optional[int] = None
    downloads_remaining: Optional[int] = None
    one_time_view: bool
    expires_at: Optional[datetime] = None
    view_count: int
    download_count: int
    created_at: datetime

    # full URL added by the endpoint
    share_url: Optional[str] = None
