"""Statistical anomaly signals (z-score and EWMA). Signals only: the PDP decides."""
from __future__ import annotations

from statistics import fmean, pstdev

MIN_HISTORY = 5


def zscore_anomaly(history: list[float], value: float, threshold: float = 3.0) -> tuple[bool, float]:
    if len(history) < MIN_HISTORY:
        return False, 0.0                      # not enough data: never fabricate an anomaly
    mean, sd = fmean(history), pstdev(history)
    if sd == 0:
        return (value != mean), (0.0 if value == mean else float("inf"))
    z = (value - mean) / sd
    return abs(z) >= threshold, z


def ewma_anomaly(history: list[float], value: float, alpha: float = 0.3, k: float = 3.0) -> bool:
    if len(history) < MIN_HISTORY:
        return False
    mean, var = history[0], 0.0
    for x in history[1:]:
        diff = x - mean
        mean += alpha * diff
        var = (1 - alpha) * (var + alpha * diff * diff)
    sd = var ** 0.5
    return abs(value - mean) > k * max(sd, 1e-9) if sd else value != mean
