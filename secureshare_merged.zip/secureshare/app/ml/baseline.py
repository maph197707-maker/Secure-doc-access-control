"""Baseline statistical models: z-score anomaly on per-user activity and a naive-Bayes-free
keyword-weight scorer. Signals only; the Zero-Trust PDP makes decisions."""
from __future__ import annotations

from app.ml.anomaly_detector import ewma_anomaly, zscore_anomaly

# Category -> weighted vocabulary. Transparent and editable; no trained weights are claimed.
VOCAB: dict[str, dict[str, float]] = {
    "financial": {"invoice": 2, "payment": 2, "balance": 2, "account": 1, "tax": 2, "salary": 3, "bank": 2, "budget": 2},
    "legal": {"agreement": 2, "contract": 3, "clause": 2, "liability": 2, "confidential": 2, "party": 1, "hereby": 2, "nda": 3},
    "hr": {"employee": 2, "resume": 3, "performance": 1, "payroll": 3, "candidate": 2, "leave": 1},
    "medical": {"patient": 3, "diagnosis": 3, "prescription": 3, "clinical": 2, "treatment": 2},
    "education": {"student": 2, "transcript": 3, "marksheet": 3, "semester": 2, "grade": 1, "enrollment": 2,
                  "diploma": 3, "certificate": 2, "university": 1, "school": 1, "degree": 2, "course": 1},
    "technical": {"server": 1, "api": 1, "password": 2, "credentials": 3, "token": 2, "deployment": 1, "database": 1},
}


def category_scores(tokens: list[str]) -> dict[str, float]:
    return {cat: sum(w for t in tokens if (w := vocab.get(t)) is not None) for cat, vocab in VOCAB.items()}


def activity_anomaly(history: list[float], value: float) -> dict[str, object]:
    z_flag, z = zscore_anomaly(history, value)
    return {"anomalous": z_flag or ewma_anomaly(history, value), "z": z,
            "sufficient_history": len(history) >= 5}
