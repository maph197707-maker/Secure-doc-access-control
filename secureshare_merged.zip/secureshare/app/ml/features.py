"""Text feature extraction for the baseline models. Pure stdlib, deterministic."""
from __future__ import annotations

import math
import re
from collections import Counter

_WORD = re.compile(r"[A-Za-z][A-Za-z'-]{1,}")
STOPWORDS = frozenset("""a an and are as at be but by for from has have he her his i in is it its of on or our she that the
their them they this to was we were will with you your not no do does did can may shall should would could been being""".split())


def tokens(text: str) -> list[str]:
    return [w.lower() for w in _WORD.findall(text)]


def keywords(text: str, n: int = 10) -> list[tuple[str, int]]:
    c = Counter(t for t in tokens(text) if t not in STOPWORDS and len(t) > 2)
    return sorted(c.items(), key=lambda kv: (-kv[1], kv[0]))[:n]


def entropy(text: str) -> float:
    if not text:
        return 0.0
    c = Counter(text)
    n = len(text)
    return -sum(v / n * math.log2(v / n) for v in c.values())


def extract(text: str) -> dict[str, float]:
    """Numeric features: size, digit/upper ratios, entropy, lexical diversity."""
    toks = tokens(text)
    n = max(len(text), 1)
    return {"chars": float(len(text)), "words": float(len(toks)),
            "digit_ratio": sum(ch.isdigit() for ch in text) / n,
            "upper_ratio": sum(ch.isupper() for ch in text) / n,
            "entropy": entropy(text),
            "unique_word_ratio": (len(set(toks)) / len(toks)) if toks else 0.0}
