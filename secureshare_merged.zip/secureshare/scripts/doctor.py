"""Environment checks. Prints exact fix commands."""
import importlib.util, secrets, socket, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
REQUIRED = ["fastapi", "uvicorn", "pydantic", "sqlalchemy", "argon2", "cryptography", "jinja2"]

def check_python() -> list[str]:
    return [] if sys.version_info >= (3, 12) else ["Python >= 3.12 required"]

def check_packages() -> list[str]:
    miss = [m for m in REQUIRED if importlib.util.find_spec(m) is None]
    return [f"Missing packages: {', '.join(miss)} -> pip install -e .[dev]"] if miss else []

def ensure_env() -> bool:
    env, ex = ROOT / ".env", ROOT / ".env.example"
    if env.exists():
        return False
    text = ex.read_text(encoding="utf-8")
    while "__GENERATE__" in text:
        text = text.replace("__GENERATE__", secrets.token_urlsafe(48), 1)
    env.write_text(text, encoding="utf-8")
    return True

def check_env() -> list[str]:
    env = ROOT / ".env"
    if not env.exists():
        return [".env missing -> python -m scripts.run dev creates it"]
    if "__GENERATE__" in env.read_text(encoding="utf-8"):
        return [".env has unreplaced secrets -> delete .env and rerun"]
    return []

def port_free(port: int = 8000) -> bool:
    with socket.socket() as s:
        return s.connect_ex(("127.0.0.1", port)) != 0

def run() -> int:
    problems = check_python() + check_packages() + check_env()
    if not port_free():
        problems.append("Port 8000 in use -> stop the other process or set another port")
    for p in problems:
        print("FAIL", p)
    if not problems:
        print("doctor: all checks passed")
    return 1 if problems else 0

if __name__ == "__main__":
    sys.exit(run())
