"""Seed roles and permissions into the database."""
import asyncio
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import select
from sqlalchemy.orm import selectinload
from app.db.session import AsyncSessionLocal
from app.models.role import Role, Permission
from app.core.enums import RoleName, PermissionCode

ROLE_PERMISSIONS = {
    RoleName.ADMIN: list(PermissionCode),
    RoleName.MANAGER: [
        PermissionCode.DOCUMENT_VIEW,
        PermissionCode.DOCUMENT_DOWNLOAD,
        PermissionCode.DOCUMENT_UPLOAD,
        PermissionCode.DOCUMENT_EDIT,
        PermissionCode.DOCUMENT_DELETE,
        PermissionCode.DOCUMENT_SHARE,
        PermissionCode.DOCUMENT_RESHARE,
        PermissionCode.DOCUMENT_REVOKE,
        PermissionCode.DOCUMENT_SIGN,
        PermissionCode.DOCUMENT_VERIFY,
        PermissionCode.AUDIT_VIEW,
        PermissionCode.SECURITY_VIEW,
        PermissionCode.ANALYTICS_VIEW,
    ],
    RoleName.USER: [
        PermissionCode.DOCUMENT_VIEW,
        PermissionCode.DOCUMENT_DOWNLOAD,
        PermissionCode.DOCUMENT_UPLOAD,
        PermissionCode.DOCUMENT_SHARE,
        PermissionCode.DOCUMENT_REVOKE,
        PermissionCode.DOCUMENT_SIGN,
        PermissionCode.DOCUMENT_VERIFY,
    ],
}


async def seed_roles() -> None:
    async with AsyncSessionLocal() as session:
        # 1. Create permissions
        perm_map: dict[str, Permission] = {}
        for code in PermissionCode:
            res = await session.execute(select(Permission).where(Permission.code == code.value))
            p = res.scalar_one_or_none()
            if not p:
                p = Permission(code=code.value, description=f"Permission for {code.value}", resource=code.value.split('_')[0].lower())
                session.add(p)
                await session.flush()
            perm_map[code.value] = p

        from app.models.role import role_permissions
        from sqlalchemy import insert, delete

        for role_name, allowed_perms in ROLE_PERMISSIONS.items():
            res = await session.execute(select(Role).where(Role.name == role_name.value))
            r = res.scalar_one_or_none()
            if not r:
                r = Role(
                    name=role_name.value,
                    description=f"System {role_name.value} role",
                    is_system=True,
                )
                session.add(r)
                await session.flush()

            # Clear existing role_permissions and re-insert
            await session.execute(delete(role_permissions).where(role_permissions.c.role_id == r.id))
            for p_code in allowed_perms:
                perm = perm_map[p_code.value]
                await session.execute(
                    insert(role_permissions).values(role_id=r.id, permission_id=perm.id)
                )

        await session.commit()
        pass


if __name__ == "__main__":
    asyncio.run(seed_roles())
