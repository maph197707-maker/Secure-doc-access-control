"""Send ONE real verification-style email through the configured SMTP provider and say exactly what is missing.

    python -m scripts.test_email you@example.com

Sends a throw-away code (123456) that is NOT stored anywhere and verifies nothing.
"""
from __future__ import annotations

import sys

from app.config.settings import get_settings
from app.integrations import errors as E
from app.integrations.email import EmailConfigError, EmailDeliveryError, EmailService

_HINT = {
    E.AUTH: "SMTP rejected the login. Gmail needs 2-Step Verification + an App Password (not your account password).",
    E.TIMEOUT: "Timed out. Check SMTP_HOST/SMTP_PORT and that outbound SMTP is not blocked by a firewall.",
    E.NETWORK: "Could not connect/negotiate TLS. Check SMTP_HOST, SMTP_PORT and SMTP_SECURITY (587=starttls, 465=ssl).",
    E.RECIPIENT: "The server refused the recipient address.",
    E.RATE_LIMITED: "The provider's sending limit was hit; wait and retry.",
    E.CONFIG: "The sender address was refused; set EMAIL_FROM to the authenticated account (SMTP_USER).",
}


def missing_vars(st) -> list[str]:
    out = []
    if not st.smtp_host.strip():
        out.append("SMTP_HOST=<your provider's SMTP host>   (Gmail: smtp.gmail.com)")
    if not st.smtp_user.strip():
        out.append("SMTP_USER=<smtp username / email>")
    if not st.smtp_password.get_secret_value().strip():
        out.append("SMTP_PASSWORD=<smtp password or Gmail App Password>")
    if not st.email_from_address:
        out.append("EMAIL_FROM=<an address your provider allows, usually the same as SMTP_USER>")
    return out


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: python -m scripts.test_email recipient@example.com")
        return 2
    st = get_settings()
    problems = missing_vars(st)
    if problems:
        print("NOT SENT. Set these in .env, then restart the server:")
        for p in problems:
            print("  -", p)
        return 1
    try:
        EmailService.from_settings(st).send_otp(argv[1], "123456")
    except EmailConfigError as exc:
        print(f"NOT SENT: {exc}")
        return 1
    except EmailDeliveryError as exc:
        print(f"NOT SENT ({exc.reason}). {_HINT.get(exc.reason, 'The provider failed to accept the message.')}")
        return 1
    print(f"SENT via {st.smtp_host}:{st.smtp_port} ({st.smtp_security}). Check the inbox (and spam) of {argv[1]} for code 123456.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
