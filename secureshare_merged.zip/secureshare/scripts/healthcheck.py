"""Container health probe: GET /api/v1/health and require a live database connection.

Sends a Host header from ALLOWED_HOSTS, otherwise HostGuardMiddleware would reject the loopback
probe in production (400 Invalid Host) and the container would be reported unhealthy forever.
"""
from __future__ import annotations

import json
import os
import sys
import urllib.request


def main() -> int:
    from app.config.settings import get_settings
    hosts = [h for h in get_settings().allowed_hosts if h and h != "*"]
    req = urllib.request.Request(
        f"http://127.0.0.1:{os.environ.get('PORT', '8000')}/api/v1/health",
        headers={"Host": hosts[0] if hosts else "localhost", "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=4) as resp:  # noqa: S310 - fixed loopback URL
            body = json.load(resp)
    except Exception as exc:  # noqa: BLE001
        print(f"unhealthy: {type(exc).__name__}", file=sys.stderr)
        return 1
    if body.get("database") != "connected":
        print("unhealthy: database unreachable", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
