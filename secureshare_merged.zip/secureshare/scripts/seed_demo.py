"""Seed demonstration data using real models and services."""
import asyncio
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import select
from sqlalchemy.orm import selectinload
from app.core.enums import Classification, RoleName, UserStatus
from app.crypto.password import hash_password
from app.db.session import AsyncSessionLocal
from app.models.document import Document
from app.models.document_version import DocumentVersion
from app.models.role import Role
from app.models.secure_link import SecureLink
from app.models.security_alert import SecurityAlert
from app.models.user import User
from app.repositories.audit import AuditRepository
from scripts.seed_roles import seed_roles


async def seed_demo_data() -> None:
    print("[*] Seeding roles and permissions...")
    await seed_roles()

    async with AsyncSessionLocal() as session:
        audit_repo = AuditRepository(session)

        # 1. Fetch available roles
        stmt_roles = select(Role)
        res_roles = await session.execute(stmt_roles)
        roles = {r.name: r for r in res_roles.scalars().all()}

        # 2. Create Demo Admin and Users
        print("[*] Creating demo users...")
        users_data = [
            ("admin@secureshare.local", "AdminSecret123!", "Admin User", RoleName.ADMIN.value, True),
            ("analyst@secureshare.local", "AnalystPass123!", "Security Analyst", RoleName.MANAGER.value, False),
            ("user@secureshare.local", "UserPass123!", "Standard User", RoleName.USER.value, False),
        ]

        user_map: dict[str, User] = {}
        for email, password, full_name, role_name, is_su in users_data:
            stmt = select(User).options(selectinload(User.roles)).where(User.email == email)
            res = await session.execute(stmt)
            existing = res.scalar_one_or_none()
            if not existing:
                u = User(
                    email=email,
                    hashed_password=hash_password(password),
                    full_name=full_name,
                    status=UserStatus.ACTIVE.value,
                    email_verified=True,
                    is_superuser=is_su,
                )
                if role_name in roles:
                    u.roles.append(roles[role_name])
                session.add(u)
                await session.flush()
                user_map[email] = u
            else:
                user_map[email] = existing

        admin_u = user_map["admin@secureshare.local"]
        user_u = user_map["user@secureshare.local"]

        # 3. Create Sample Documents
        print("[*] Creating sample documents...")
        from app.services.documents import DocumentService
        doc_svc = DocumentService(session)
        created_docs: list[Document] = []
        for filename, display_name, classification, sample_content in [
            ("Financial_Quarterly_Report_2026.pdf", "Financial Quarterly Report", Classification.CONFIDENTIAL.value, b"%PDF-1.4\n% Financial report sample content for SecureShare demonstration purposes."),
            ("Security_Assessment_Findings.txt", "Security Assessment Findings", Classification.RESTRICTED.value, b"Security assessment report: All critical endpoints enforce zero-trust access controls."),
            ("Customer_Feedback_Summary.txt", "Customer Feedback Summary", Classification.INTERNAL.value, b"Customer feedback summary: Highly rated security and sharing features."),
        ]:
            stmt = select(Document).where(Document.original_filename == filename, Document.owner_id == user_u.id)
            res = await session.execute(stmt)
            doc = res.scalar_one_or_none()
            if not doc:
                doc = await doc_svc.upload(
                    owner_id=user_u.id,
                    filename=filename,
                    content=sample_content,
                    display_name=display_name,
                    classification=classification,
                )
            created_docs.append(doc)

        # 4. Create a Demo Secure Link
        print("[*] Creating demo secure links...")
        if created_docs:
            sample_doc = created_docs[0]
            stmt = select(SecureLink).where(SecureLink.document_id == sample_doc.id)
            res = await session.execute(stmt)
            link = res.scalar_one_or_none()
            if not link:
                from app.services.secure_links import SecureLinkService
                link_svc = SecureLinkService(session)
                link, raw_token = await link_svc.create_link(
                    document_id=sample_doc.id,
                    created_by=user_u.id,
                    expires_in_hours=168,
                    max_views=10,
                    max_downloads=5,
                    allow_downloads=True,
                )

        # 5. Create Security Alert
        print("[*] Creating sample security alerts...")
        stmt = select(SecurityAlert).limit(1)
        res = await session.execute(stmt)
        if not res.scalar_one_or_none():
            alert = SecurityAlert(
                alert_type="SUSPICIOUS_LOGIN_LOCATION",
                severity="HIGH",
                user_id=user_u.id,
                message="Login attempt detected from previously unrecognized IP subnet (198.51.100.42).",
                acknowledged=False,
            )
            session.add(alert)

        await session.commit()
        print("\n[OK] Demonstration data successfully seeded!")
        print("  Admin user: admin@secureshare.local / AdminSecret123!")
        print("  Standard user: user@secureshare.local / UserPass123!")


def main() -> None:
    asyncio.run(seed_demo_data())


if __name__ == "__main__":
    main()
