"""Send ONE real SMS through the configured Twilio account and say exactly what is missing.

    python -m scripts.test_sms +15551234567

Sends a throw-away code (123456) that is NOT stored anywhere and verifies nothing. Costs one SMS.
"""
from __future__ import annotations

import sys

from app.config.settings import get_settings
from app.integrations import errors as E
from app.integrations.sms import SMSConfigError, SMSDeliveryError, SMSService, mask_phone, normalize_phone

_HINT = {
    E.AUTH: "Twilio rejected the credentials. Check TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN.",
    E.RECIPIENT: "Twilio refused the destination (invalid, unverified trial number, opted out, or region not enabled).",
    E.RATE_LIMITED: "Twilio rate limit; wait and retry.",
    E.TIMEOUT: "Timed out reaching api.twilio.com.",
    E.NETWORK: "Could not reach api.twilio.com (network/firewall).",
}


def missing_vars(st) -> list[str]:
    out = []
    if not st.twilio_account_sid.strip():
        out.append("TWILIO_ACCOUNT_SID=AC...")
    if not st.twilio_auth_token.get_secret_value().strip():
        out.append("TWILIO_AUTH_TOKEN=<auth token>")
    if not (st.twilio_from_number.strip() or st.twilio_messaging_service_sid.strip()):
        out.append("TWILIO_FROM_NUMBER=+<E.164 number>   (or TWILIO_MESSAGING_SERVICE_SID=MG...)")
    return out


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("usage: python -m scripts.test_sms +15551234567")
        return 2
    st = get_settings()
    problems = missing_vars(st)
    if problems:
        print("NOT SENT. Set these in .env, then restart the server:")
        for p in problems:
            print("  -", p)
        return 1
    try:
        to = normalize_phone(argv[1], st.sms_default_country_code)
        SMSService.from_settings(st).send_otp(to, "123456")
    except ValueError as exc:
        print(f"NOT SENT: {exc}")
        return 1
    except SMSConfigError as exc:
        print(f"NOT SENT: {exc}")
        return 1
    except SMSDeliveryError as exc:
        print(f"NOT SENT ({exc.reason}). {_HINT.get(exc.reason, 'Twilio failed to accept the message.')}")
        return 1
    print(f"ACCEPTED by Twilio for {mask_phone(to)}. Delivery to the handset is asynchronous; check the phone for code 123456.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
