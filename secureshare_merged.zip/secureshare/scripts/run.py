"""python -m scripts.run dev|demo"""
import subprocess, sys
from scripts import doctor

def main(argv: list[str]) -> int:
    mode = argv[0] if argv else "dev"
    if mode not in ("dev", "demo"):
        print("usage: python -m scripts.run dev|demo")
        return 2
    if doctor.ensure_env():
        print("Created .env with fresh random secrets")
    if doctor.run() != 0:
        return 1
    host = "0.0.0.0" if mode == "demo" else "127.0.0.1"
    if mode == "demo":
        from scripts import lan_info
        print("DEMO MODE: reachable from your local network (not the Internet).")
        lan_info.main(["8000"])
    return subprocess.call([sys.executable, "-m", "uvicorn", "app.main:app", "--host", host, "--port", "8000"])

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
