"""Script to rotate master and document encryption keys."""
import asyncio
import os
import secrets
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import select
from app.db.session import AsyncSessionLocal
from app.models.encryption_key import EncryptionKey


async def rotate_keys() -> None:
    print("[*] Starting key rotation...")
    async with AsyncSessionLocal() as session:
        # Mark existing active keys as ROTATED
        stmt = select(EncryptionKey).where(EncryptionKey.state == "ACTIVE")
        res = await session.execute(stmt)
        active_keys = res.scalars().all()

        now = datetime.now(timezone.utc).replace(tzinfo=None)
        for k in active_keys:
            k.state = "ROTATED"
            k.rotated_at = now
            print(f"[*] Rotated key reference: {k.reference}")

        # Create new primary key entry
        new_ref = f"master-key-{now.strftime('%Y%m%d%H%M%S')}"
        new_key = EncryptionKey(
            reference=new_ref,
            algorithm="AES_256_GCM",
            state="ACTIVE",
            provider="local_dev",
            provider_key_id=secrets.token_hex(16),
            activated_at=now,
        )
        session.add(new_key)
        await session.commit()
        print(f"[OK] New active key registered: {new_ref}")


def main() -> None:
    asyncio.run(rotate_keys())


if __name__ == "__main__":
    main()
