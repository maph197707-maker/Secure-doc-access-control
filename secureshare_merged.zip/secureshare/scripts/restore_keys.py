"""Script to restore encryption key registry from backup."""
import argparse
import asyncio
import json
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import select
from app.db.session import AsyncSessionLocal
from app.models.encryption_key import EncryptionKey


async def restore_keys(backup_path: Path) -> None:
    if not backup_path.exists():
        print(f"[FAIL] Backup file {backup_path} does not exist.")
        sys.exit(1)

    print(f"[*] Restoring keys from {backup_path}...")
    with open(backup_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    keys = data.get("keys", [])
    restored = 0

    async with AsyncSessionLocal() as session:
        for k in keys:
            stmt = select(EncryptionKey).where(EncryptionKey.reference == k["reference"])
            res = await session.execute(stmt)
            existing = res.scalar_one_or_none()
            if not existing:
                act = datetime.fromisoformat(k["activated_at"]) if k.get("activated_at") else None
                rot = datetime.fromisoformat(k["rotated_at"]) if k.get("rotated_at") else None
                key = EncryptionKey(
                    reference=k["reference"],
                    algorithm=k.get("algorithm", "AES_256_GCM"),
                    state=k.get("state", "ACTIVE"),
                    provider=k.get("provider", "local_dev"),
                    provider_key_id=k.get("provider_key_id"),
                    wrapped_key_material=k.get("wrapped_key_material"),
                    public_key_pem=k.get("public_key_pem"),
                    activated_at=act,
                    rotated_at=rot,
                )
                session.add(key)
                restored += 1

        await session.commit()
        print(f"[OK] Restored {restored} key record(s) from backup.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Restore encryption key records from backup.")
    parser.add_argument("--input", default="storage/keys_backup.json", help="Input backup path")
    args = parser.parse_args()

    asyncio.run(restore_keys(Path(args.input)))


if __name__ == "__main__":
    main()
