"""Script to verify the tamper-evident audit hash chain integrity."""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import asc, select
from app.db.session import AsyncSessionLocal
from app.models.audit import AuditLog
from app.services.audit import rows_to_records, verify_chain


async def run_verification() -> int:
    async with AsyncSessionLocal() as session:
        stmt = select(AuditLog).order_by(asc(AuditLog.sequence_number))
        res = await session.execute(stmt)
        entries = res.scalars().all()

        if not entries:
            print("[INFO] Audit log is empty. Chain is pristine (0 entries).")
            return 0

        records = rows_to_records(entries)     # same payload definition the writer hashes

        result = verify_chain(records)
        if result.ok:
            print(f"[OK] Audit chain verified successfully. {result.checked} entries checked, 0 errors.")
            return 0
        else:
            print(f"[FAIL] Audit chain compromised at seq {result.broken_at}: {result.reason}")
            return 1


def main() -> None:
    code = asyncio.run(run_verification())
    sys.exit(code)


if __name__ == "__main__":
    main()
