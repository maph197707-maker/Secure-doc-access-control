"""Reset demo database: drop all tables, recreate schema, and seed demo records."""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.db.session import create_tables, drop_tables
from scripts.seed_demo import seed_demo_data


async def reset_demo() -> None:
    print("[*] Resetting SecureShare database...")
    await drop_tables()
    print("[*] Recreating database tables...")
    await create_tables()
    print("[*] Populating demo data...")
    await seed_demo_data()
    print("[OK] Database reset complete.")


def main() -> None:
    asyncio.run(reset_demo())


if __name__ == "__main__":
    main()
