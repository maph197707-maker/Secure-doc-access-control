"""CLI script to create or promote an admin user."""
import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import select
from sqlalchemy.orm import selectinload
from app.core.enums import RoleName, UserStatus
from app.crypto.password import hash_password
from app.db.session import AsyncSessionLocal
from app.models.role import Role
from app.models.user import User


async def create_or_promote_admin(email: str, password: str, full_name: str | None = None) -> None:
    async with AsyncSessionLocal() as session:
        # Load admin role
        stmt_role = select(Role).where(Role.name == RoleName.ADMIN.value)
        res_role = await session.execute(stmt_role)
        admin_role = res_role.scalar_one_or_none()

        stmt = select(User).options(selectinload(User.roles)).where(User.email == email.lower().strip())
        res = await session.execute(stmt)
        user = res.scalar_one_or_none()

        if user:
            user.status = UserStatus.ACTIVE.value
            user.email_verified = True
            user.is_superuser = True
            if admin_role and admin_role not in user.roles:
                user.roles.append(admin_role)
            if password:
                user.hashed_password = hash_password(password)
            if full_name:
                user.full_name = full_name
            await session.commit()
            print(f"[OK] Existing user '{email}' promoted to ADMIN.")
        else:
            hashed = hash_password(password)
            user = User(
                email=email.lower().strip(),
                hashed_password=hashed,
                full_name=full_name or "System Administrator",
                status=UserStatus.ACTIVE.value,
                email_verified=True,
                is_superuser=True,
            )
            if admin_role:
                user.roles.append(admin_role)
            session.add(user)
            await session.commit()
            print(f"[OK] Admin user '{email}' created successfully.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Create or promote an administrator.")
    parser.add_argument("--email", default="admin@secureshare.local", help="Admin email address")
    parser.add_argument("--password", default=None, help="Admin password (omit to be prompted; never use a shared default)")
    parser.add_argument("--name", default="Administrator", help="Admin display name")
    args = parser.parse_args()

    password = args.password
    if not password:
        import getpass
        from app.crypto.password import password_problems
        while True:
            password = getpass.getpass("Admin password (12+ chars, upper, lower, digit): ")
            problems = password_problems(password)
            if problems:
                print("  " + problems[0])
            elif password == getpass.getpass("Repeat password: "):
                break
            else:
                print("  Passwords do not match.")
    asyncio.run(create_or_promote_admin(args.email, password, args.name))


if __name__ == "__main__":
    main()
