"""Vendor frontend dependencies with integrity checks."""
import hashlib
import sys
from pathlib import Path
import httpx

ROOT = Path(__file__).resolve().parents[1]
VENDOR_DIR = ROOT / "app" / "static" / "vendor"
VENDOR_DIR.mkdir(parents=True, exist_ok=True)

ASSETS = [
    {
        "filename": "htmx.min.js",
        "url": "https://unpkg.com/htmx.org@2.0.4/dist/htmx.min.js",
        "sha256": "e209dda5c8235479f3166defc7750e1dbcd5a5c1808b7792fc2e6733768fb447",
    },
    {
        "filename": "chart.umd.js",
        "url": "https://unpkg.com/chart.js@4.4.7/dist/chart.umd.js",
        "sha256": "2812cb8825fdc57469eb2f7bb055e9429244e599920511ee477e828499b632cb",
    },
]


def fetch_vendor_assets() -> bool:
    all_ok = True
    for asset in ASSETS:
        target_path = VENDOR_DIR / asset["filename"]
        if target_path.exists():
            computed = hashlib.sha256(target_path.read_bytes()).hexdigest()
            if computed == asset["sha256"]:
                print(f"[OK] {asset['filename']} already present and verified.")
                continue

        print(f"Downloading {asset['filename']} from {asset['url']}...")
        try:
            resp = httpx.get(asset["url"], timeout=15.0, follow_redirects=True)
            resp.raise_for_status()
            content = resp.content
            computed = hashlib.sha256(content).hexdigest()
            if computed != asset["sha256"]:
                print(f"[ERROR] SHA256 mismatch for {asset['filename']}: expected {asset['sha256']}, got {computed}")
                all_ok = False
                continue
            target_path.write_bytes(content)
            print(f"[SUCCESS] Saved {asset['filename']} ({len(content)} bytes)")
        except Exception as e:
            print(f"[WARN] Failed to download {asset['filename']}: {e}")
            if not target_path.exists():
                print(f"[FALLBACK] Writing minimal fallback for {asset['filename']}")
                target_path.write_text(f"/* Fallback for {asset['filename']} */\n", encoding="utf-8")
            all_ok = False
    return all_ok


if __name__ == "__main__":
    success = fetch_vendor_assets()
    sys.exit(0 if success else 1)
