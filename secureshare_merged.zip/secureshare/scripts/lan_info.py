"""python -m scripts.lan_info [port]  -> prints the URL another device on the same Wi-Fi should open.

Detects this machine's LAN address without sending any packet. It does NOT open the firewall or
expose anything to the Internet; start the server with --host 0.0.0.0 for LAN access.
"""
import socket
import sys


def lan_ips() -> list[str]:
    found: list[str] = []
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        found.append(s.getsockname()[0])
    except OSError:
        pass
    finally:
        s.close()
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127.") and ip not in found:
                found.append(ip)
    except OSError:
        pass
    return [ip for ip in found if not ip.startswith("127.")]


def main(argv: list[str]) -> int:
    port = argv[0] if argv else "8000"
    ips = lan_ips()
    print(f"This computer:        http://localhost:{port}")
    if not ips:
        print("No LAN address found. Connect to Wi-Fi/Ethernet and try again.")
        return 1
    for ip in ips:
        print(f"Other devices (LAN):  http://{ip}:{port}")
    print("Same Wi-Fi only. Start with:  uvicorn app.main:app --host 0.0.0.0 --port " + port)
    print("If it does not open: allow Python through the OS firewall for PRIVATE networks.")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
