"""Smoke tests for SecureShare endpoints and database connectivity."""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from httpx import ASGITransport, AsyncClient
from app.main import app
from app.db.session import AsyncSessionLocal
from sqlalchemy import text


async def run_smoke() -> int:
    print("[*] Running SecureShare smoke tests...")
    failures = 0

    # 1. Direct DB check
    try:
        async with AsyncSessionLocal() as session:
            await session.execute(text("SELECT 1"))
        print("[OK] Database connection healthy.")
    except Exception as e:
        print(f"[FAIL] Database connection failed: {e}")
        failures += 1

    # 2. HTTP ASGI checks
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://localhost:8000") as client:
        # Root health check
        resp = await client.get("/health")
        if resp.status_code == 200:
            print(f"[OK] GET /health returned 200: {resp.json()}")
        else:
            print(f"[FAIL] GET /health returned {resp.status_code}")
            failures += 1

        # API v1 health
        resp = await client.get("/api/v1/health")
        if resp.status_code == 200 and resp.json().get("status") in ("healthy", "ok"):
            print(f"[OK] GET /api/v1/health healthy: {resp.json()}")
        else:
            print(f"[FAIL] GET /api/v1/health returned {resp.status_code}: {resp.text}")
            failures += 1

        # Public landing
        resp = await client.get("/")
        if resp.status_code in (200, 302, 303):
            print(f"[OK] GET / returned {resp.status_code}")
        else:
            print(f"[FAIL] GET / returned {resp.status_code}")
            failures += 1

        # Login page
        resp = await client.get("/login")
        if resp.status_code == 200:
            print(f"[OK] GET /login returned 200 HTML")
        else:
            print(f"[FAIL] GET /login returned {resp.status_code}")
            failures += 1

    if failures == 0:
        print("\nAll smoke tests PASSED.")
        return 0
    else:
        print(f"\nSmoke tests finished with {failures} failure(s).")
        return 1


def main() -> None:
    code = asyncio.run(run_smoke())
    sys.exit(code)


if __name__ == "__main__":
    main()
