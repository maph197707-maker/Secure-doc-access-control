"""Script to securely backup encryption key registry."""
import argparse
import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy import select
from app.db.session import AsyncSessionLocal
from app.models.encryption_key import EncryptionKey


async def backup_keys(output_path: Path) -> None:
    print(f"[*] Exporting keys to {output_path}...")
    async with AsyncSessionLocal() as session:
        stmt = select(EncryptionKey)
        res = await session.execute(stmt)
        keys = res.scalars().all()

        data = []
        for k in keys:
            data.append({
                "reference": k.reference,
                "algorithm": k.algorithm,
                "state": k.state,
                "provider": k.provider,
                "provider_key_id": k.provider_key_id,
                "wrapped_key_material": k.wrapped_key_material,
                "public_key_pem": k.public_key_pem,
                "activated_at": k.activated_at.isoformat() if k.activated_at else None,
                "rotated_at": k.rotated_at.isoformat() if k.rotated_at else None,
            })

        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump({"version": 1, "keys": data}, f, indent=2)

        print(f"[OK] Successfully backed up {len(data)} key record(s) to {output_path}.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Backup encryption key records.")
    parser.add_argument("--output", default="storage/keys_backup.json", help="Output backup path")
    args = parser.parse_args()

    asyncio.run(backup_keys(Path(args.output)))


if __name__ == "__main__":
    main()
