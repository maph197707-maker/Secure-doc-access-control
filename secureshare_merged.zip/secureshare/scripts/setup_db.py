"""python -m scripts.setup_db  -- one-shot, idempotent first-run setup used by install.bat.

Creates the tables (SQLite dev database) and the system roles/permissions. Safe to re-run: existing
data is never dropped. For PostgreSQL / production use `alembic upgrade head` instead."""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


async def main() -> int:
    from app.config.settings import get_settings
    from app.db.session import create_tables
    from scripts.seed_roles import seed_roles

    st = get_settings()
    if not st.database_url.startswith("sqlite"):
        print("DATABASE_URL is not SQLite: run  alembic upgrade head  instead, then  python -m scripts.seed_roles")
        return 0
    await create_tables()
    await seed_roles()
    print(f"Database ready ({st.database_url.split('///')[-1]}) with roles and permissions.")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
