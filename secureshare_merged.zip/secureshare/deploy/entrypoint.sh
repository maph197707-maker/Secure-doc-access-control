#!/bin/sh
# Container entrypoint: wait for the database + apply migrations, then start the app server.
# Works unchanged for SQLite and for any PostgreSQL service (only DATABASE_URL differs).
set -eu

tries=0
max="${MIGRATE_RETRIES:-20}"
until alembic upgrade head; do
    tries=$((tries + 1))
    if [ "$tries" -ge "$max" ]; then
        echo "entrypoint: migrations still failing after $tries attempts; giving up" >&2
        exit 1
    fi
    echo "entrypoint: database not ready or migration failed (attempt $tries/$max); retrying in 3s" >&2
    sleep 3
done

# Behind Caddy/Nginx the proxy terminates TLS. The app port is only reachable on the compose
# network, so trusting X-Forwarded-* from any peer is safe there; narrow FORWARDED_ALLOW_IPS if exposed.
# Worker count comes from WEB_CONCURRENCY (default 1). More than one worker needs REDIS_URL (APP_MODE=full)
# because the lite-mode state store (rate limits, OTP cooldowns) is per-process.
exec python -m uvicorn app.main:app \
    --host 0.0.0.0 --port "${PORT:-8000}" \
    --proxy-headers --forwarded-allow-ips "${FORWARDED_ALLOW_IPS:-*}"
